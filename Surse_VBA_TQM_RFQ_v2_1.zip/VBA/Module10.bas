Attribute VB_Name = "Module10"
Option Explicit

Private Const TQM_DASH_NAME As String = "00_DASHBOARD"
Private Const TQM_SOURCE_NAME As String = "Control_Achizitii"
Private Const TQM_MARKER As String = "TQM_DASHBOARD_V1"

' Import this module using File > Import File in Excel VBA.
' Existing macros and source data are never replaced by this module.
' Start with TQM_Dashboard_Creeaza. Formulas update automatically.
' TQM_Dashboard_Actualizeaza also extends coverage and refreshes projects.

Public Sub TQM_Dashboard_Creeaza()
    TQM_Dash_Rebuild True
End Sub

Public Sub TQM_Dashboard_Actualizeaza()
    TQM_Dash_Rebuild False
End Sub

Private Sub TQM_Dash_Rebuild(ByVal anunta As Boolean)
    Dim ws As Worksheet, sursa As Worksheet
    Dim oldEvents As Boolean, oldScreen As Boolean
    Dim lastRow As Long, oldLast As Long, clearLast As Long
    Dim dStart As Variant, dEnd As Variant, proiect As Variant
    Dim obj As Shape, i As Long
    Dim errText As String

    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating
    On Error GoTo Failed
    Set sursa = TQM_Dash_Source()
    TQM_Dash_CheckHeaders sursa
    If ThisWorkbook.ProtectStructure Then
        Err.Raise vbObjectError + 910, "TQM Dashboard", "Structura fisierului este protejata."
    End If
    Set ws = TQM_Dash_Sheet(TQM_DASH_NAME)
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(before:=ThisWorkbook.Worksheets(1))
        ws.name = TQM_DASH_NAME
    Else
        If CStr(ws.Range("U1").Value2) <> TQM_MARKER Then
            Err.Raise vbObjectError + 911, "TQM Dashboard", _
                "Foaia 00_DASHBOARD contine alt continut. Redenumiti-o inainte de instalare."
        End If
        If ws.ProtectContents Then
            Err.Raise vbObjectError + 912, "TQM Dashboard", "Foaia Dashboard este protejata."
        End If
        dStart = ws.Range("E5").Value2
        dEnd = ws.Range("J5").Value2
        proiect = ws.Range("O5").Value2
        If IsNumeric(ws.Range("Z1").Value2) Then oldLast = CLng(ws.Range("Z1").Value2)
    End If

    lastRow = TQM_Dash_LastRow(sursa) + 250
    If lastRow < 1012 Then lastRow = 1012
    If lastRow > sursa.rows.count - 1 Then lastRow = sursa.rows.count - 1
    clearLast = lastRow
    If oldLast > clearLast Then clearLast = oldLast
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    ws.Range("A1:AH" & clearLast).UnMerge
    ws.Range("A1:AH" & clearLast).ClearContents
    ws.Range("A1:S52").ClearFormats
    For i = ws.Shapes.count To 1 Step -1
        Set obj = ws.Shapes(i)
        If Left$(obj.name, 9) = "TQM_DASH_" Then obj.Delete
    Next i
    TQM_Dash_Layout ws
    If IsEmpty(dStart) Then dStart = DateSerial(Year(Date), 1, 1)
    If IsEmpty(dEnd) Then dEnd = DateSerial(Year(Date), 12, 31)
    If IsEmpty(proiect) Then proiect = "Toate proiectele"
    ws.Range("E5").Value2 = dStart
    ws.Range("J5").Value2 = dEnd
    ws.Range("O5").Value2 = proiect
    ws.Range("U1").Value2 = TQM_MARKER
    ws.Range("Z1").Value2 = lastRow
    TQM_Dash_Formulas ws, lastRow
    TQM_Dash_Projects ws, sursa
    TQM_Dash_Charts ws
    TQM_Dash_Buttons ws
    If Not TQM_Dash_Sheet("02_CERERI_SI_OFERTE") Is Nothing Then
        ws.Range("B47").formula = "=HYPERLINK(""#'02_CERERI_SI_OFERTE'!A2"",""Cereri si oferte - modul activ"")"
        ws.Range("B47:G48").Font.Color = RGB(37, 99, 235)
    End If
    ws.Columns("T:AH").Hidden = True
    ws.Tab.Color = RGB(31, 41, 55)
    With ws.PageSetup
        .PrintArea = "$B$2:$S$50"
        .Orientation = xlLandscape
        .PaperSize = xlPaperA4
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = 1
        .CenterHorizontally = True
    End With
    sursa.Calculate
    ws.Calculate
    ThisWorkbook.Activate
    ws.Activate
    If Not ActiveWindow Is Nothing Then
        ActiveWindow.DisplayGridlines = False
        ActiveWindow.FreezePanes = False
        ActiveWindow.SplitRow = 0
        ActiveWindow.SplitColumn = 0
        ActiveWindow.Zoom = 80
    End If
    ws.Range("E5").Select
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    If anunta Then MsgBox "Dashboardul este pregatit. Modificati filtrele galbene pentru analiza.", vbInformation, "TQM Calarasi"
    Exit Sub
Failed:
    errText = Err.description
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    MsgBox "Dashboardul nu a fost actualizat: " & errText, vbExclamation, "TQM Calarasi"
End Sub

Private Function TQM_Dash_Sheet(ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If StrComp(ws.name, sheetName, vbTextCompare) = 0 Then
            Set TQM_Dash_Sheet = ws
            Exit Function
        End If
    Next ws
End Function

Private Function TQM_Dash_Source() As Worksheet
    Set TQM_Dash_Source = TQM_Dash_Sheet(TQM_SOURCE_NAME)
    If TQM_Dash_Source Is Nothing Then
        Err.Raise vbObjectError + 913, "TQM Dashboard", "Lipseste foaia Control_Achizitii."
    End If
End Function

Private Sub TQM_Dash_CheckHeaders(ByVal ws As Worksheet)
    Dim cols As Variant, labels As Variant, i As Long
    cols = Array("B", "C", "E", "F", "G", "I", "J", "N", "O")
    labels = Array("Data", "Nr. Factura / Aviz", "Valoare (RON fara TVA)", _
        "Lucrare / Obiectiv", "Partener", "Intrare", "Aviz necesar", "Status dosar", "Documente lipsa")
    For i = LBound(cols) To UBound(cols)
        If StrComp(Replace(Trim$(CStr(TQM_Control_Cell(ws, 12, cols(i)).Value2)), "?", ""), labels(i), vbTextCompare) <> 0 Then
            Err.Raise vbObjectError + 914, "TQM Dashboard", _
                "Structura registrului difera: " & cols(i) & "12 trebuie sa fie " & labels(i) & "."
        End If
    Next i
End Sub

Private Function TQM_Dash_LastRow(ByVal ws As Worksheet) As Long
    Dim found As Range
    Set found = ws.Columns(TQM_Control_Col("G")).Find(What:="*", after:=TQM_Control_Cell(ws, 1, "G"), _
        LookIn:=xlValues, LookAt:=xlPart, SearchOrder:=xlByRows, _
        SearchDirection:=xlPrevious, MatchCase:=False, SearchFormat:=False)
    If found Is Nothing Then
        TQM_Dash_LastRow = 12
    Else
        TQM_Dash_LastRow = found.row
    End If
End Function

Private Sub TQM_Dash_Layout(ByVal ws As Worksheet)
    ws.Range("B2:S2").Merge
    ws.Range("B3:F3").Merge
    ws.Range("H3:L3").Merge
    ws.Range("N3:S3").Merge
    ws.Range("B5:D5").Merge
    ws.Range("E5:G5").Merge
    ws.Range("H5:I5").Merge
    ws.Range("J5:L5").Merge
    ws.Range("M5:N5").Merge
    ws.Range("O5:S5").Merge
    ws.Range("B6:S6").Merge
    ws.Range("B8:G8").Merge
    ws.Range("B9:G10").Merge
    ws.Range("I8:S8").Merge
    ws.Range("I9:S10").Merge
    ws.Range("B12:E12").Merge
    ws.Range("B13:E14").Merge
    ws.Range("G12:J12").Merge
    ws.Range("G13:J14").Merge
    ws.Range("L12:O12").Merge
    ws.Range("L13:O14").Merge
    ws.Range("Q12:S12").Merge
    ws.Range("Q13:S14").Merge
    ws.Range("B16:S17").Merge
    ws.Range("B18:S18").Merge
    ws.Range("B20:J20").Merge
    ws.Range("L20:S20").Merge
    ws.Range("B32:S32").Merge
    ws.Range("B33:S33").Merge
    ws.Range("B34:D34").Merge
    ws.Range("E34:G34").Merge
    ws.Range("H34:J34").Merge
    ws.Range("K34:M34").Merge
    ws.Range("N34:Q34").Merge
    ws.Range("R34:S34").Merge
    ws.Range("B35:D35").Merge
    ws.Range("E35:G35").Merge
    ws.Range("H35:J35").Merge
    ws.Range("K35:M35").Merge
    ws.Range("N35:Q35").Merge
    ws.Range("R35:S35").Merge
    ws.Range("B36:D36").Merge
    ws.Range("E36:G36").Merge
    ws.Range("H36:J36").Merge
    ws.Range("K36:M36").Merge
    ws.Range("N36:Q36").Merge
    ws.Range("R36:S36").Merge
    ws.Range("B37:D37").Merge
    ws.Range("E37:G37").Merge
    ws.Range("H37:J37").Merge
    ws.Range("K37:M37").Merge
    ws.Range("N37:Q37").Merge
    ws.Range("R37:S37").Merge
    ws.Range("B38:D38").Merge
    ws.Range("E38:G38").Merge
    ws.Range("H38:J38").Merge
    ws.Range("K38:M38").Merge
    ws.Range("N38:Q38").Merge
    ws.Range("R38:S38").Merge
    ws.Range("B39:D39").Merge
    ws.Range("E39:G39").Merge
    ws.Range("H39:J39").Merge
    ws.Range("K39:M39").Merge
    ws.Range("N39:Q39").Merge
    ws.Range("R39:S39").Merge
    ws.Range("B40:D40").Merge
    ws.Range("E40:G40").Merge
    ws.Range("H40:J40").Merge
    ws.Range("K40:M40").Merge
    ws.Range("N40:Q40").Merge
    ws.Range("R40:S40").Merge
    ws.Range("B41:D41").Merge
    ws.Range("E41:G41").Merge
    ws.Range("H41:J41").Merge
    ws.Range("K41:M41").Merge
    ws.Range("N41:Q41").Merge
    ws.Range("R41:S41").Merge
    ws.Range("B42:D42").Merge
    ws.Range("E42:G42").Merge
    ws.Range("H42:J42").Merge
    ws.Range("K42:M42").Merge
    ws.Range("N42:Q42").Merge
    ws.Range("R42:S42").Merge
    ws.Range("B43:D43").Merge
    ws.Range("E43:G43").Merge
    ws.Range("H43:J43").Merge
    ws.Range("K43:M43").Merge
    ws.Range("N43:Q43").Merge
    ws.Range("R43:S43").Merge
    ws.Range("B44:D44").Merge
    ws.Range("E44:G44").Merge
    ws.Range("H44:J44").Merge
    ws.Range("K44:M44").Merge
    ws.Range("N44:Q44").Merge
    ws.Range("R44:S44").Merge
    ws.Range("B46:S46").Merge
    ws.Range("B47:G48").Merge
    ws.Range("I47:M48").Merge
    ws.Range("O47:S48").Merge
    ws.Range("B50:S50").Merge
    ws.Range("B2").Value2 = "TQM Calarasi - Dashboard achizitii"
    ws.Range("B3").Value2 = "Deschide registrul"
    ws.Range("H3").Value2 = "Documente si dosare"
    ws.Range("N3").Value2 = "Filtrele actualizeaza automat datele"
    ws.Range("B5").Value2 = "De la"
    ws.Range("H5").Value2 = "Pana la"
    ws.Range("M5").Value2 = "Proiect"
    ws.Range("B6").Value2 = "Perioada foloseste data inregistrarii. Modificati celulele galbene pentru filtrare."
    ws.Range("T12").Value2 = "Factura"
    ws.Range("U12").Value2 = "Data lipsa / text"
    ws.Range("V12").Value2 = "Inclus in filtru"
    ws.Range("W12").Value2 = "Rand cu actiune"
    ws.Range("X12").Value2 = "Valoare factura invalida"
    ws.Range("Y12").Value2 = "Clasa status"
    ws.Range("AH12").Value2 = "Status contradictoriu"
    ws.Range("B8").Value2 = "Inregistrari"
    ws.Range("B9").Value2 = ""
    ws.Range("I8").Value2 = "Valoare facturi (RON fara TVA)"
    ws.Range("I9").Value2 = ""
    ws.Range("B12").Value2 = "Dosare complete"
    ws.Range("B13").Value2 = ""
    ws.Range("G12").Value2 = "Dosare incomplete"
    ws.Range("G13").Value2 = ""
    ws.Range("L12").Value2 = "Avize obligatorii"
    ws.Range("L13").Value2 = ""
    ws.Range("Q12").Value2 = "Rata completare"
    ws.Range("Q13").Value2 = ""
    ws.Range("B16").Value2 = ""
    ws.Range("B18").Value2 = ""
    ws.Range("AA2").Value2 = "Status"
    ws.Range("AB2").Value2 = "Dosare"
    ws.Range("AA3").Value2 = "Complete"
    ws.Range("AA4").Value2 = "Incomplete"
    ws.Range("AA5").Value2 = "Alte statusuri"
    ws.Range("AA8").Value2 = "Luna"
    ws.Range("AB8").Value2 = "Eticheta"
    ws.Range("AC8").Value2 = "Facturi RON"
    ws.Range("AB9").Value2 = "Ian"
    ws.Range("AB10").Value2 = "Feb"
    ws.Range("AB11").Value2 = "Mar"
    ws.Range("AB12").Value2 = "Apr"
    ws.Range("AB13").Value2 = "Mai"
    ws.Range("AB14").Value2 = "Iun"
    ws.Range("AB15").Value2 = "Iul"
    ws.Range("AB16").Value2 = "Aug"
    ws.Range("AB17").Value2 = "Sep"
    ws.Range("AB18").Value2 = "Oct"
    ws.Range("AB19").Value2 = "Nov"
    ws.Range("AB20").Value2 = "Dec"
    ws.Range("B20").Value2 = "Dosare dupa status"
    ws.Range("L20").Value2 = "Facturi pe luni (RON fara TVA)"
    ws.Range("B32").Value2 = "Graficul lunar arata anul datei ""Pana la"", in limitele perioadei si proiectului selectat."
    ws.Range("B33").Value2 = ""
    ws.Range("B34").Value2 = "Document"
    ws.Range("E34").Value2 = "Partener"
    ws.Range("H34").Value2 = "Proiect"
    ws.Range("K34").Value2 = "Motiv"
    ws.Range("N34").Value2 = "Actiune"
    ws.Range("R34").Value2 = "Registru"
    ws.Range("B35").Value2 = ""
    ws.Range("E35").Value2 = ""
    ws.Range("H35").Value2 = ""
    ws.Range("K35").Value2 = ""
    ws.Range("N35").Value2 = ""
    ws.Range("R35").Value2 = ""
    ws.Range("B36").Value2 = ""
    ws.Range("E36").Value2 = ""
    ws.Range("H36").Value2 = ""
    ws.Range("K36").Value2 = ""
    ws.Range("N36").Value2 = ""
    ws.Range("R36").Value2 = ""
    ws.Range("B37").Value2 = ""
    ws.Range("E37").Value2 = ""
    ws.Range("H37").Value2 = ""
    ws.Range("K37").Value2 = ""
    ws.Range("N37").Value2 = ""
    ws.Range("R37").Value2 = ""
    ws.Range("B38").Value2 = ""
    ws.Range("E38").Value2 = ""
    ws.Range("H38").Value2 = ""
    ws.Range("K38").Value2 = ""
    ws.Range("N38").Value2 = ""
    ws.Range("R38").Value2 = ""
    ws.Range("B39").Value2 = ""
    ws.Range("E39").Value2 = ""
    ws.Range("H39").Value2 = ""
    ws.Range("K39").Value2 = ""
    ws.Range("N39").Value2 = ""
    ws.Range("R39").Value2 = ""
    ws.Range("B40").Value2 = ""
    ws.Range("E40").Value2 = ""
    ws.Range("H40").Value2 = ""
    ws.Range("K40").Value2 = ""
    ws.Range("N40").Value2 = ""
    ws.Range("R40").Value2 = ""
    ws.Range("B41").Value2 = ""
    ws.Range("E41").Value2 = ""
    ws.Range("H41").Value2 = ""
    ws.Range("K41").Value2 = ""
    ws.Range("N41").Value2 = ""
    ws.Range("R41").Value2 = ""
    ws.Range("B42").Value2 = ""
    ws.Range("E42").Value2 = ""
    ws.Range("H42").Value2 = ""
    ws.Range("K42").Value2 = ""
    ws.Range("N42").Value2 = ""
    ws.Range("R42").Value2 = ""
    ws.Range("B43").Value2 = ""
    ws.Range("E43").Value2 = ""
    ws.Range("H43").Value2 = ""
    ws.Range("K43").Value2 = ""
    ws.Range("N43").Value2 = ""
    ws.Range("R43").Value2 = ""
    ws.Range("B44").Value2 = ""
    ws.Range("E44").Value2 = ""
    ws.Range("H44").Value2 = ""
    ws.Range("K44").Value2 = ""
    ws.Range("N44").Value2 = ""
    ws.Range("R44").Value2 = ""
    ws.Range("B46").Value2 = "Module de conectat in etapele urmatoare"
    ws.Range("B47").Value2 = "Cereri si oferte / Comenzi"
    ws.Range("I47").Value2 = "Livrari / Stocuri"
    ws.Range("O47").Value2 = "Facturi / Plati / Bugete"
    ws.Range("B50").Value2 = "Statusurile sunt preluate din registru. Aviz obligatoriu indica o cerinta, nu confirma lipsa avizului."
    With ws.Range("A1:S52")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .RowHeight = 21
    End With
    With ws.Range("A1:A52")
        .ColumnWidth = 2.5
    End With
    With ws.Range("B1:S52")
        .ColumnWidth = 8.8
    End With
    With ws.Range("B2:S2")
        .Font.name = "Aptos Display"
        .Font.size = 20
        .Font.Bold = True
        .Font.Color = RGB(31, 41, 55)
        .RowHeight = 34
    End With
    With ws.Range("B3:F3")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H3:L3")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N3:S3")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(107, 114, 128)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B3:L3")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Bold = True
        .Font.Color = RGB(37, 99, 235)
        .RowHeight = 25
    End With
    With ws.Range("B5:D5")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E5:G5")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E5:G5")
        .Interior.Color = RGB(254, 243, 199)
        .NumberFormat = "dd.mm.yyyy"
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("H5:I5")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("J5:L5")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("J5:L5")
        .Interior.Color = RGB(254, 243, 199)
        .NumberFormat = "dd.mm.yyyy"
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("M5:N5")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("O5:S5")
        .Interior.Color = RGB(254, 243, 199)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B5:S5")
        .RowHeight = 28
    End With
    With ws.Range("E5:G5")
        .Interior.Color = RGB(254, 243, 199)
        .NumberFormat = "dd.mm.yyyy"
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("J5:L5")
        .Interior.Color = RGB(254, 243, 199)
        .NumberFormat = "dd.mm.yyyy"
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B6:S6")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(107, 114, 128)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B8:G8")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B9:G10")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 23
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B9:G10")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos Display"
        .Font.size = 23
        .Font.Bold = True
        .Font.Color = RGB(29, 78, 216)
        .NumberFormat = "0"
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("I8:S8")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("I9:S10")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 23
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("I9:S10")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos Display"
        .Font.size = 23
        .Font.Bold = True
        .Font.Color = RGB(29, 78, 216)
        .NumberFormat = "#,##0.00"
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B12:E12")
        .Interior.Color = RGB(240, 253, 244)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(21, 128, 61)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B13:E14")
        .Interior.Color = RGB(240, 253, 244)
        .Font.name = "Aptos"
        .Font.size = 23
        .Font.Color = RGB(21, 128, 61)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B13:E14")
        .Interior.Color = RGB(240, 253, 244)
        .Font.name = "Aptos Display"
        .Font.size = 23
        .Font.Bold = True
        .Font.Color = RGB(21, 128, 61)
        .NumberFormat = "0"
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("G12:J12")
        .Interior.Color = RGB(254, 242, 242)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(185, 28, 28)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("G13:J14")
        .Interior.Color = RGB(254, 242, 242)
        .Font.name = "Aptos"
        .Font.size = 23
        .Font.Color = RGB(185, 28, 28)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("G13:J14")
        .Interior.Color = RGB(254, 242, 242)
        .Font.name = "Aptos Display"
        .Font.size = 23
        .Font.Bold = True
        .Font.Color = RGB(185, 28, 28)
        .NumberFormat = "0"
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("L12:O12")
        .Interior.Color = RGB(255, 247, 237)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(194, 65, 12)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("L13:O14")
        .Interior.Color = RGB(255, 247, 237)
        .Font.name = "Aptos"
        .Font.size = 23
        .Font.Color = RGB(194, 65, 12)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("L13:O14")
        .Interior.Color = RGB(255, 247, 237)
        .Font.name = "Aptos Display"
        .Font.size = 23
        .Font.Bold = True
        .Font.Color = RGB(194, 65, 12)
        .NumberFormat = "0"
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("Q12:S12")
        .Interior.Color = RGB(243, 244, 246)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(55, 65, 81)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("Q13:S14")
        .Interior.Color = RGB(243, 244, 246)
        .Font.name = "Aptos"
        .Font.size = 23
        .Font.Color = RGB(55, 65, 81)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("Q13:S14")
        .Interior.Color = RGB(243, 244, 246)
        .Font.name = "Aptos Display"
        .Font.size = 23
        .Font.Bold = True
        .Font.Color = RGB(55, 65, 81)
        .NumberFormat = "0%"
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B16:S17")
        .Interior.Color = RGB(255, 247, 237)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(154, 52, 18)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B16:S17")
        .WrapText = True
    End With
    With ws.Range("B18:S18")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(107, 114, 128)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B20:J20")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 12
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("L20:S20")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 12
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B32:S32")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(107, 114, 128)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B33:S33")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 12
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B34:D34")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B34:D34")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("E34:G34")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E34:G34")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("H34:J34")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H34:J34")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("K34:M34")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K34:M34")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("N34:Q34")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N34:Q34")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("R34:S34")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R34:S34")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B34:S34")
        .RowHeight = 27
    End With
    With ws.Range("B35:D35")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E35:G35")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H35:J35")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K35:M35")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N35:Q35")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R35:S35")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B35:S35")
        .RowHeight = 42
        .WrapText = True
    End With
    With ws.Range("R35:S35")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(37, 99, 235)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B36:D36")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E36:G36")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H36:J36")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K36:M36")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N36:Q36")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R36:S36")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B36:S36")
        .RowHeight = 42
        .WrapText = True
    End With
    With ws.Range("R36:S36")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(37, 99, 235)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B37:D37")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E37:G37")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H37:J37")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K37:M37")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N37:Q37")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R37:S37")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B37:S37")
        .RowHeight = 42
        .WrapText = True
    End With
    With ws.Range("R37:S37")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(37, 99, 235)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B38:D38")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E38:G38")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H38:J38")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K38:M38")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N38:Q38")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R38:S38")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B38:S38")
        .RowHeight = 42
        .WrapText = True
    End With
    With ws.Range("R38:S38")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(37, 99, 235)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B39:D39")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E39:G39")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H39:J39")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K39:M39")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N39:Q39")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R39:S39")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B39:S39")
        .RowHeight = 42
        .WrapText = True
    End With
    With ws.Range("R39:S39")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(37, 99, 235)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B40:D40")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E40:G40")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H40:J40")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K40:M40")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N40:Q40")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R40:S40")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B40:S40")
        .RowHeight = 42
        .WrapText = True
    End With
    With ws.Range("R40:S40")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(37, 99, 235)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B41:D41")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E41:G41")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H41:J41")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K41:M41")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N41:Q41")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R41:S41")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B41:S41")
        .RowHeight = 42
        .WrapText = True
    End With
    With ws.Range("R41:S41")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(37, 99, 235)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B42:D42")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E42:G42")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H42:J42")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K42:M42")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N42:Q42")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R42:S42")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B42:S42")
        .RowHeight = 42
        .WrapText = True
    End With
    With ws.Range("R42:S42")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(37, 99, 235)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B43:D43")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E43:G43")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H43:J43")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K43:M43")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N43:Q43")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R43:S43")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B43:S43")
        .RowHeight = 42
        .WrapText = True
    End With
    With ws.Range("R43:S43")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(37, 99, 235)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B44:D44")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("E44:G44")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("H44:J44")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("K44:M44")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("N44:Q44")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("R44:S44")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B44:S44")
        .RowHeight = 42
        .WrapText = True
    End With
    With ws.Range("R44:S44")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(37, 99, 235)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("B46:S46")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 12
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B47:G48")
        .Interior.Color = RGB(243, 244, 246)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(107, 114, 128)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("I47:M48")
        .Interior.Color = RGB(243, 244, 246)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(107, 114, 128)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("O47:S48")
        .Interior.Color = RGB(243, 244, 246)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(107, 114, 128)
        .VerticalAlignment = xlCenter
    End With
    With ws.Range("B50:S50")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(107, 114, 128)
        .VerticalAlignment = xlCenter
    End With
End Sub

Private Sub TQM_Dash_Formulas(ByVal ws As Worksheet, ByVal lastRow As Long)
    Dim col As Variant, fc As FormatCondition
    TQM_Dash_SetFormula ws, "B3", "=HYPERLINK(""#'Control_Achizitii'!A12"",""Deschide registrul"")", lastRow
    TQM_Dash_SetFormula ws, "H3", "=HYPERLINK(""#'Control_Achizitii'!N12"",""Documente si dosare"")", lastRow
    TQM_Dash_SetFormula ws, "Z2", "=IF(NOT(AND(ISNUMBER($E$5),ISNUMBER($J$5),$E$5<=$J$5,$O$5<>"""")),""Verifica filtrele"",IF(COUNTA('Control_Achizitii'!$G$1013:$G$1048576)>0,""Actualizeaza dashboardul"",""OK""))", lastRow
    TQM_Dash_SetFormula ws, "T13", "=IF(LEFT('Control_Achizitii'!$I13,4)=""Fact"",1,0)", lastRow
    ws.Range("T13:T" & lastRow).FillDown
    TQM_Dash_SetFormula ws, "U13", "=IF('Control_Achizitii'!$G13="""",0,IF(ISNUMBER('Control_Achizitii'!$B13),0,1))", lastRow
    ws.Range("U13:U" & lastRow).FillDown
    TQM_Dash_SetFormula ws, "V13", "=IF('Control_Achizitii'!$G13="""",0,IF($Z$2<>""OK"",0,IF(AND(ISNUMBER('Control_Achizitii'!$B13),'Control_Achizitii'!$B13>=$E$5,'Control_Achizitii'!$B13<$J$5+1,OR($O$5=""Toate proiectele"",'Control_Achizitii'!$F13=$O$5)),1,0)))", lastRow
    ws.Range("V13:V" & lastRow).FillDown
    TQM_Dash_SetFormula ws, "W13", "=IF(AND(V13=1,OR('Control_Achizitii'!$N13<>""DOSAR COMPLET"",'Control_Achizitii'!$O13<>"""")),ROW(),1000000000)", lastRow
    ws.Range("W13:W" & lastRow).FillDown
    TQM_Dash_SetFormula ws, "X13", "=IF(AND(V13=1,LEFT('Control_Achizitii'!$I13,4)=""Fact"",NOT(ISNUMBER('Control_Achizitii'!$E13))),1,0)", lastRow
    ws.Range("X13:X" & lastRow).FillDown
    TQM_Dash_SetFormula ws, "Y13", "=IF(V13=0,0,IF('Control_Achizitii'!$N13=""DOSAR COMPLET"",1,IF(LEFT('Control_Achizitii'!$N13,9)=""INCOMPLET"",2,3)))", lastRow
    ws.Range("Y13:Y" & lastRow).FillDown
    TQM_Dash_SetFormula ws, "AH13", "=IF(AND(V13=1,'Control_Achizitii'!$N13=""DOSAR COMPLET"",'Control_Achizitii'!$O13<>""""),1,0)", lastRow
    ws.Range("AH13:AH" & lastRow).FillDown
    TQM_Dash_SetFormula ws, "B9", "=IF($Z$2<>""OK"",$Z$2,SUM($V$13:$V$1012))", lastRow
    TQM_Dash_SetFormula ws, "I9", "=IF($Z$2<>""OK"",$Z$2,IF(SUM($X$13:$X$1012)>0,""Valori de verificat"",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1)))", lastRow
    TQM_Dash_SetFormula ws, "B13", "=IF($Z$2<>""OK"",$Z$2,COUNTIFS($Y$13:$Y$1012,1))", lastRow
    TQM_Dash_SetFormula ws, "G13", "=IF($Z$2<>""OK"",$Z$2,COUNTIFS($Y$13:$Y$1012,2))", lastRow
    TQM_Dash_SetFormula ws, "L13", "=IF($Z$2<>""OK"",$Z$2,COUNTIFS($V$13:$V$1012,1,'Control_Achizitii'!$J$13:$J$1012,""OBLIGATORIU AVIZ""))", lastRow
    TQM_Dash_SetFormula ws, "Q13", "=IF($Z$2<>""OK"",$Z$2,IF(B9=0,""n.a."",B13/B9))", lastRow
    TQM_Dash_SetFormula ws, "B16", "=IF($Z$2<>""OK"",$Z$2,IF(SUM($AH$13:$AH$1012)=0,""Nu exista statusuri COMPLETE cu documente lipsa declarate."",SUM($AH$13:$AH$1012)&"" dosare au status COMPLET si documente lipsa. Verificati regulile in registru.""))", lastRow
    TQM_Dash_SetFormula ws, "B18", "=IF($Z$2<>""OK"",$Z$2,SUM($U$13:$U$1012)&"" inregistrari fara data valida (toate proiectele). ""&SUM($X$13:$X$1012)&"" facturi cu valoare nenumerica in selectie."")", lastRow
    TQM_Dash_SetFormula ws, "AB3", "=IF($Z$2=""OK"",B13,0)", lastRow
    TQM_Dash_SetFormula ws, "AB4", "=IF($Z$2=""OK"",G13,0)", lastRow
    TQM_Dash_SetFormula ws, "AB5", "=IF($Z$2=""OK"",B9-B13-G13,0)", lastRow
    TQM_Dash_SetFormula ws, "AA9", "=DATE(YEAR($J$5),1,1)", lastRow
    TQM_Dash_SetFormula ws, "AC9", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA9,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA9),MONTH(AA9)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA10", "=DATE(YEAR($J$5),2,1)", lastRow
    TQM_Dash_SetFormula ws, "AC10", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA10,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA10),MONTH(AA10)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA11", "=DATE(YEAR($J$5),3,1)", lastRow
    TQM_Dash_SetFormula ws, "AC11", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA11,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA11),MONTH(AA11)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA12", "=DATE(YEAR($J$5),4,1)", lastRow
    TQM_Dash_SetFormula ws, "AC12", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA12,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA12),MONTH(AA12)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA13", "=DATE(YEAR($J$5),5,1)", lastRow
    TQM_Dash_SetFormula ws, "AC13", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA13,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA13),MONTH(AA13)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA14", "=DATE(YEAR($J$5),6,1)", lastRow
    TQM_Dash_SetFormula ws, "AC14", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA14,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA14),MONTH(AA14)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA15", "=DATE(YEAR($J$5),7,1)", lastRow
    TQM_Dash_SetFormula ws, "AC15", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA15,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA15),MONTH(AA15)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA16", "=DATE(YEAR($J$5),8,1)", lastRow
    TQM_Dash_SetFormula ws, "AC16", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA16,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA16),MONTH(AA16)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA17", "=DATE(YEAR($J$5),9,1)", lastRow
    TQM_Dash_SetFormula ws, "AC17", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA17,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA17),MONTH(AA17)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA18", "=DATE(YEAR($J$5),10,1)", lastRow
    TQM_Dash_SetFormula ws, "AC18", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA18,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA18),MONTH(AA18)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA19", "=DATE(YEAR($J$5),11,1)", lastRow
    TQM_Dash_SetFormula ws, "AC19", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA19,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA19),MONTH(AA19)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "AA20", "=DATE(YEAR($J$5),12,1)", lastRow
    TQM_Dash_SetFormula ws, "AC20", "=IF(OR($Z$2<>""OK"",SUM($X$13:$X$1012)>0),"""",SUMIFS('Control_Achizitii'!$E$13:$E$1012,$V$13:$V$1012,1,$T$13:$T$1012,1,'Control_Achizitii'!$B$13:$B$1012,"">=""&AA20,'Control_Achizitii'!$B$13:$B$1012,""<""&DATE(YEAR(AA20),MONTH(AA20)+1,1)))", lastRow
    TQM_Dash_SetFormula ws, "B33", "=IF($Z$2<>""OK"",$Z$2,""Dosare de verificat: ""&COUNTIFS($W$13:$W$1012,""<1000000000"")&"". Primele 10 in ordinea registrului."")", lastRow
    TQM_Dash_SetFormula ws, "Z35", "=IF(OR($Z$2<>""OK"",1>COUNTIFS($W$13:$W$1012,""<1000000000"")),"""",SMALL($W$13:$W$1012,1))", lastRow
    TQM_Dash_SetFormula ws, "B35", "=IF($Z35="""","""",IF(INDEX('Control_Achizitii'!$C$13:$C$1012,$Z35-12)="""",""Fara numar document"",INDEX('Control_Achizitii'!$C$13:$C$1012,$Z35-12)))", lastRow
    TQM_Dash_SetFormula ws, "E35", "=IF($Z35="""","""",INDEX('Control_Achizitii'!$G$13:$G$1012,$Z35-12))", lastRow
    TQM_Dash_SetFormula ws, "H35", "=IF($Z35="""","""",IF(INDEX('Control_Achizitii'!$F$13:$F$1012,$Z35-12)="""",""Fara proiect"",INDEX('Control_Achizitii'!$F$13:$F$1012,$Z35-12)))", lastRow
    TQM_Dash_SetFormula ws, "K35", "=IF($Z35="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z35-12)=""DOSAR COMPLET"",""Status si documente necorelate"",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z35-12)="""",""Status necompletat"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z35-12)="""",""Dosar incomplet"",INDEX('Control_Achizitii'!$O$13:$O$1012,$Z35-12)))))", lastRow
    TQM_Dash_SetFormula ws, "N35", "=IF($Z35="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z35-12)=""DOSAR COMPLET"",""Verifica regulile dosarului"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z35-12)="""",""Verifica dosarul in registru"",""Solicita documentele lipsa"")))", lastRow
    TQM_Dash_SetFormula ws, "R35", "=IF($Z35="""","""",HYPERLINK(""#'Control_Achizitii'!A""&$Z35,""Deschide""))", lastRow
    TQM_Dash_SetFormula ws, "Z36", "=IF(OR($Z$2<>""OK"",2>COUNTIFS($W$13:$W$1012,""<1000000000"")),"""",SMALL($W$13:$W$1012,2))", lastRow
    TQM_Dash_SetFormula ws, "B36", "=IF($Z36="""","""",IF(INDEX('Control_Achizitii'!$C$13:$C$1012,$Z36-12)="""",""Fara numar document"",INDEX('Control_Achizitii'!$C$13:$C$1012,$Z36-12)))", lastRow
    TQM_Dash_SetFormula ws, "E36", "=IF($Z36="""","""",INDEX('Control_Achizitii'!$G$13:$G$1012,$Z36-12))", lastRow
    TQM_Dash_SetFormula ws, "H36", "=IF($Z36="""","""",IF(INDEX('Control_Achizitii'!$F$13:$F$1012,$Z36-12)="""",""Fara proiect"",INDEX('Control_Achizitii'!$F$13:$F$1012,$Z36-12)))", lastRow
    TQM_Dash_SetFormula ws, "K36", "=IF($Z36="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z36-12)=""DOSAR COMPLET"",""Status si documente necorelate"",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z36-12)="""",""Status necompletat"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z36-12)="""",""Dosar incomplet"",INDEX('Control_Achizitii'!$O$13:$O$1012,$Z36-12)))))", lastRow
    TQM_Dash_SetFormula ws, "N36", "=IF($Z36="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z36-12)=""DOSAR COMPLET"",""Verifica regulile dosarului"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z36-12)="""",""Verifica dosarul in registru"",""Solicita documentele lipsa"")))", lastRow
    TQM_Dash_SetFormula ws, "R36", "=IF($Z36="""","""",HYPERLINK(""#'Control_Achizitii'!A""&$Z36,""Deschide""))", lastRow
    TQM_Dash_SetFormula ws, "Z37", "=IF(OR($Z$2<>""OK"",3>COUNTIFS($W$13:$W$1012,""<1000000000"")),"""",SMALL($W$13:$W$1012,3))", lastRow
    TQM_Dash_SetFormula ws, "B37", "=IF($Z37="""","""",IF(INDEX('Control_Achizitii'!$C$13:$C$1012,$Z37-12)="""",""Fara numar document"",INDEX('Control_Achizitii'!$C$13:$C$1012,$Z37-12)))", lastRow
    TQM_Dash_SetFormula ws, "E37", "=IF($Z37="""","""",INDEX('Control_Achizitii'!$G$13:$G$1012,$Z37-12))", lastRow
    TQM_Dash_SetFormula ws, "H37", "=IF($Z37="""","""",IF(INDEX('Control_Achizitii'!$F$13:$F$1012,$Z37-12)="""",""Fara proiect"",INDEX('Control_Achizitii'!$F$13:$F$1012,$Z37-12)))", lastRow
    TQM_Dash_SetFormula ws, "K37", "=IF($Z37="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z37-12)=""DOSAR COMPLET"",""Status si documente necorelate"",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z37-12)="""",""Status necompletat"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z37-12)="""",""Dosar incomplet"",INDEX('Control_Achizitii'!$O$13:$O$1012,$Z37-12)))))", lastRow
    TQM_Dash_SetFormula ws, "N37", "=IF($Z37="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z37-12)=""DOSAR COMPLET"",""Verifica regulile dosarului"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z37-12)="""",""Verifica dosarul in registru"",""Solicita documentele lipsa"")))", lastRow
    TQM_Dash_SetFormula ws, "R37", "=IF($Z37="""","""",HYPERLINK(""#'Control_Achizitii'!A""&$Z37,""Deschide""))", lastRow
    TQM_Dash_SetFormula ws, "Z38", "=IF(OR($Z$2<>""OK"",4>COUNTIFS($W$13:$W$1012,""<1000000000"")),"""",SMALL($W$13:$W$1012,4))", lastRow
    TQM_Dash_SetFormula ws, "B38", "=IF($Z38="""","""",IF(INDEX('Control_Achizitii'!$C$13:$C$1012,$Z38-12)="""",""Fara numar document"",INDEX('Control_Achizitii'!$C$13:$C$1012,$Z38-12)))", lastRow
    TQM_Dash_SetFormula ws, "E38", "=IF($Z38="""","""",INDEX('Control_Achizitii'!$G$13:$G$1012,$Z38-12))", lastRow
    TQM_Dash_SetFormula ws, "H38", "=IF($Z38="""","""",IF(INDEX('Control_Achizitii'!$F$13:$F$1012,$Z38-12)="""",""Fara proiect"",INDEX('Control_Achizitii'!$F$13:$F$1012,$Z38-12)))", lastRow
    TQM_Dash_SetFormula ws, "K38", "=IF($Z38="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z38-12)=""DOSAR COMPLET"",""Status si documente necorelate"",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z38-12)="""",""Status necompletat"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z38-12)="""",""Dosar incomplet"",INDEX('Control_Achizitii'!$O$13:$O$1012,$Z38-12)))))", lastRow
    TQM_Dash_SetFormula ws, "N38", "=IF($Z38="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z38-12)=""DOSAR COMPLET"",""Verifica regulile dosarului"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z38-12)="""",""Verifica dosarul in registru"",""Solicita documentele lipsa"")))", lastRow
    TQM_Dash_SetFormula ws, "R38", "=IF($Z38="""","""",HYPERLINK(""#'Control_Achizitii'!A""&$Z38,""Deschide""))", lastRow
    TQM_Dash_SetFormula ws, "Z39", "=IF(OR($Z$2<>""OK"",5>COUNTIFS($W$13:$W$1012,""<1000000000"")),"""",SMALL($W$13:$W$1012,5))", lastRow
    TQM_Dash_SetFormula ws, "B39", "=IF($Z39="""","""",IF(INDEX('Control_Achizitii'!$C$13:$C$1012,$Z39-12)="""",""Fara numar document"",INDEX('Control_Achizitii'!$C$13:$C$1012,$Z39-12)))", lastRow
    TQM_Dash_SetFormula ws, "E39", "=IF($Z39="""","""",INDEX('Control_Achizitii'!$G$13:$G$1012,$Z39-12))", lastRow
    TQM_Dash_SetFormula ws, "H39", "=IF($Z39="""","""",IF(INDEX('Control_Achizitii'!$F$13:$F$1012,$Z39-12)="""",""Fara proiect"",INDEX('Control_Achizitii'!$F$13:$F$1012,$Z39-12)))", lastRow
    TQM_Dash_SetFormula ws, "K39", "=IF($Z39="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z39-12)=""DOSAR COMPLET"",""Status si documente necorelate"",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z39-12)="""",""Status necompletat"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z39-12)="""",""Dosar incomplet"",INDEX('Control_Achizitii'!$O$13:$O$1012,$Z39-12)))))", lastRow
    TQM_Dash_SetFormula ws, "N39", "=IF($Z39="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z39-12)=""DOSAR COMPLET"",""Verifica regulile dosarului"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z39-12)="""",""Verifica dosarul in registru"",""Solicita documentele lipsa"")))", lastRow
    TQM_Dash_SetFormula ws, "R39", "=IF($Z39="""","""",HYPERLINK(""#'Control_Achizitii'!A""&$Z39,""Deschide""))", lastRow
    TQM_Dash_SetFormula ws, "Z40", "=IF(OR($Z$2<>""OK"",6>COUNTIFS($W$13:$W$1012,""<1000000000"")),"""",SMALL($W$13:$W$1012,6))", lastRow
    TQM_Dash_SetFormula ws, "B40", "=IF($Z40="""","""",IF(INDEX('Control_Achizitii'!$C$13:$C$1012,$Z40-12)="""",""Fara numar document"",INDEX('Control_Achizitii'!$C$13:$C$1012,$Z40-12)))", lastRow
    TQM_Dash_SetFormula ws, "E40", "=IF($Z40="""","""",INDEX('Control_Achizitii'!$G$13:$G$1012,$Z40-12))", lastRow
    TQM_Dash_SetFormula ws, "H40", "=IF($Z40="""","""",IF(INDEX('Control_Achizitii'!$F$13:$F$1012,$Z40-12)="""",""Fara proiect"",INDEX('Control_Achizitii'!$F$13:$F$1012,$Z40-12)))", lastRow
    TQM_Dash_SetFormula ws, "K40", "=IF($Z40="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z40-12)=""DOSAR COMPLET"",""Status si documente necorelate"",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z40-12)="""",""Status necompletat"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z40-12)="""",""Dosar incomplet"",INDEX('Control_Achizitii'!$O$13:$O$1012,$Z40-12)))))", lastRow
    TQM_Dash_SetFormula ws, "N40", "=IF($Z40="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z40-12)=""DOSAR COMPLET"",""Verifica regulile dosarului"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z40-12)="""",""Verifica dosarul in registru"",""Solicita documentele lipsa"")))", lastRow
    TQM_Dash_SetFormula ws, "R40", "=IF($Z40="""","""",HYPERLINK(""#'Control_Achizitii'!A""&$Z40,""Deschide""))", lastRow
    TQM_Dash_SetFormula ws, "Z41", "=IF(OR($Z$2<>""OK"",7>COUNTIFS($W$13:$W$1012,""<1000000000"")),"""",SMALL($W$13:$W$1012,7))", lastRow
    TQM_Dash_SetFormula ws, "B41", "=IF($Z41="""","""",IF(INDEX('Control_Achizitii'!$C$13:$C$1012,$Z41-12)="""",""Fara numar document"",INDEX('Control_Achizitii'!$C$13:$C$1012,$Z41-12)))", lastRow
    TQM_Dash_SetFormula ws, "E41", "=IF($Z41="""","""",INDEX('Control_Achizitii'!$G$13:$G$1012,$Z41-12))", lastRow
    TQM_Dash_SetFormula ws, "H41", "=IF($Z41="""","""",IF(INDEX('Control_Achizitii'!$F$13:$F$1012,$Z41-12)="""",""Fara proiect"",INDEX('Control_Achizitii'!$F$13:$F$1012,$Z41-12)))", lastRow
    TQM_Dash_SetFormula ws, "K41", "=IF($Z41="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z41-12)=""DOSAR COMPLET"",""Status si documente necorelate"",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z41-12)="""",""Status necompletat"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z41-12)="""",""Dosar incomplet"",INDEX('Control_Achizitii'!$O$13:$O$1012,$Z41-12)))))", lastRow
    TQM_Dash_SetFormula ws, "N41", "=IF($Z41="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z41-12)=""DOSAR COMPLET"",""Verifica regulile dosarului"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z41-12)="""",""Verifica dosarul in registru"",""Solicita documentele lipsa"")))", lastRow
    TQM_Dash_SetFormula ws, "R41", "=IF($Z41="""","""",HYPERLINK(""#'Control_Achizitii'!A""&$Z41,""Deschide""))", lastRow
    TQM_Dash_SetFormula ws, "Z42", "=IF(OR($Z$2<>""OK"",8>COUNTIFS($W$13:$W$1012,""<1000000000"")),"""",SMALL($W$13:$W$1012,8))", lastRow
    TQM_Dash_SetFormula ws, "B42", "=IF($Z42="""","""",IF(INDEX('Control_Achizitii'!$C$13:$C$1012,$Z42-12)="""",""Fara numar document"",INDEX('Control_Achizitii'!$C$13:$C$1012,$Z42-12)))", lastRow
    TQM_Dash_SetFormula ws, "E42", "=IF($Z42="""","""",INDEX('Control_Achizitii'!$G$13:$G$1012,$Z42-12))", lastRow
    TQM_Dash_SetFormula ws, "H42", "=IF($Z42="""","""",IF(INDEX('Control_Achizitii'!$F$13:$F$1012,$Z42-12)="""",""Fara proiect"",INDEX('Control_Achizitii'!$F$13:$F$1012,$Z42-12)))", lastRow
    TQM_Dash_SetFormula ws, "K42", "=IF($Z42="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z42-12)=""DOSAR COMPLET"",""Status si documente necorelate"",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z42-12)="""",""Status necompletat"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z42-12)="""",""Dosar incomplet"",INDEX('Control_Achizitii'!$O$13:$O$1012,$Z42-12)))))", lastRow
    TQM_Dash_SetFormula ws, "N42", "=IF($Z42="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z42-12)=""DOSAR COMPLET"",""Verifica regulile dosarului"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z42-12)="""",""Verifica dosarul in registru"",""Solicita documentele lipsa"")))", lastRow
    TQM_Dash_SetFormula ws, "R42", "=IF($Z42="""","""",HYPERLINK(""#'Control_Achizitii'!A""&$Z42,""Deschide""))", lastRow
    TQM_Dash_SetFormula ws, "Z43", "=IF(OR($Z$2<>""OK"",9>COUNTIFS($W$13:$W$1012,""<1000000000"")),"""",SMALL($W$13:$W$1012,9))", lastRow
    TQM_Dash_SetFormula ws, "B43", "=IF($Z43="""","""",IF(INDEX('Control_Achizitii'!$C$13:$C$1012,$Z43-12)="""",""Fara numar document"",INDEX('Control_Achizitii'!$C$13:$C$1012,$Z43-12)))", lastRow
    TQM_Dash_SetFormula ws, "E43", "=IF($Z43="""","""",INDEX('Control_Achizitii'!$G$13:$G$1012,$Z43-12))", lastRow
    TQM_Dash_SetFormula ws, "H43", "=IF($Z43="""","""",IF(INDEX('Control_Achizitii'!$F$13:$F$1012,$Z43-12)="""",""Fara proiect"",INDEX('Control_Achizitii'!$F$13:$F$1012,$Z43-12)))", lastRow
    TQM_Dash_SetFormula ws, "K43", "=IF($Z43="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z43-12)=""DOSAR COMPLET"",""Status si documente necorelate"",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z43-12)="""",""Status necompletat"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z43-12)="""",""Dosar incomplet"",INDEX('Control_Achizitii'!$O$13:$O$1012,$Z43-12)))))", lastRow
    TQM_Dash_SetFormula ws, "N43", "=IF($Z43="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z43-12)=""DOSAR COMPLET"",""Verifica regulile dosarului"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z43-12)="""",""Verifica dosarul in registru"",""Solicita documentele lipsa"")))", lastRow
    TQM_Dash_SetFormula ws, "R43", "=IF($Z43="""","""",HYPERLINK(""#'Control_Achizitii'!A""&$Z43,""Deschide""))", lastRow
    TQM_Dash_SetFormula ws, "Z44", "=IF(OR($Z$2<>""OK"",10>COUNTIFS($W$13:$W$1012,""<1000000000"")),"""",SMALL($W$13:$W$1012,10))", lastRow
    TQM_Dash_SetFormula ws, "B44", "=IF($Z44="""","""",IF(INDEX('Control_Achizitii'!$C$13:$C$1012,$Z44-12)="""",""Fara numar document"",INDEX('Control_Achizitii'!$C$13:$C$1012,$Z44-12)))", lastRow
    TQM_Dash_SetFormula ws, "E44", "=IF($Z44="""","""",INDEX('Control_Achizitii'!$G$13:$G$1012,$Z44-12))", lastRow
    TQM_Dash_SetFormula ws, "H44", "=IF($Z44="""","""",IF(INDEX('Control_Achizitii'!$F$13:$F$1012,$Z44-12)="""",""Fara proiect"",INDEX('Control_Achizitii'!$F$13:$F$1012,$Z44-12)))", lastRow
    TQM_Dash_SetFormula ws, "K44", "=IF($Z44="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z44-12)=""DOSAR COMPLET"",""Status si documente necorelate"",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z44-12)="""",""Status necompletat"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z44-12)="""",""Dosar incomplet"",INDEX('Control_Achizitii'!$O$13:$O$1012,$Z44-12)))))", lastRow
    TQM_Dash_SetFormula ws, "N44", "=IF($Z44="""","""",IF(INDEX('Control_Achizitii'!$N$13:$N$1012,$Z44-12)=""DOSAR COMPLET"",""Verifica regulile dosarului"",IF(INDEX('Control_Achizitii'!$O$13:$O$1012,$Z44-12)="""",""Verifica dosarul in registru"",""Solicita documentele lipsa"")))", lastRow
    TQM_Dash_SetFormula ws, "R44", "=IF($Z44="""","""",HYPERLINK(""#'Control_Achizitii'!A""&$Z44,""Deschide""))", lastRow
    ws.Range("B16:S17").FormatConditions.Delete
    Set fc = ws.Range("B16:S17").FormatConditions.Add(Type:=xlExpression, _
        Formula1:="=SUM($AH$13:$AH$" & lastRow & ")>0")
    fc.Interior.Color = RGB(254, 242, 242)
    fc.Font.Color = RGB(185, 28, 28)
End Sub

Private Sub TQM_Dash_SetFormula(ByVal ws As Worksheet, ByVal addr As String, _
    ByVal template As String, ByVal lastRow As Long)
    template = Replace(template, "$G$1013", "$G$" & (lastRow + 1))
    template = Replace(template, "$1012", "$" & lastRow)
    ws.Range(addr).formula = TQM_Control_Formula(template)
End Sub

Private Sub TQM_Dash_Projects(ByVal ws As Worksheet, ByVal sursa As Worksheet)
    Dim projects As Collection, v As Variant
    Dim data As Variant, i As Long, nextRow As Long, lastRow As Long
    Set projects = New Collection
    projects.Add "Toate proiectele", "Toate proiectele"
    lastRow = TQM_Dash_LastRow(sursa)
    If lastRow >= 13 Then
        data = TQM_Control_Range(sursa, "F13:F" & lastRow).Value2
        If lastRow = 13 Then
            TQM_Dash_AddProject projects, data
        Else
            For i = 1 To UBound(data, 1)
                TQM_Dash_AddProject projects, data(i, 1)
            Next i
        End If
    End If
    ws.Range("AF1").Value2 = "Proiecte"
    nextRow = 2
    For Each v In projects
        ws.Range("AF" & nextRow).Value2 = v
        nextRow = nextRow + 1
    Next v
    With ws.Range("O5:S5").Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, _
            Operator:=xlBetween, Formula1:="=$AF$2:$AF$" & (nextRow - 1)
        .IgnoreBlank = False
        .InCellDropdown = True
        .ShowError = True
        .ErrorTitle = "Selectati un proiect"
        .errorMessage = "Alegeti un proiect din lista. Actualizati dashboardul pentru proiectele noi."
    End With
End Sub

Private Sub TQM_Dash_AddProject(ByVal projects As Collection, ByVal candidateValue As Variant)
    Dim projectName As String, item As Variant
    If IsError(candidateValue) Or IsEmpty(candidateValue) Then Exit Sub
    projectName = Trim$(CStr(candidateValue))
    If Len(projectName) = 0 Then Exit Sub
    For Each item In projects
        If StrComp(CStr(item), projectName, vbTextCompare) = 0 Then Exit Sub
    Next item
    projects.Add projectName
End Sub

Private Sub TQM_Dash_Charts(ByVal ws As Worksheet)
    Dim ch As ChartObject, frame As Range
    Set frame = ws.Range("B21:J31")
    Set ch = ws.ChartObjects.Add(frame.Left, frame.Top, frame.width, frame.Height)
    ch.name = "TQM_DASH_Status"
    With ch.Chart
        .ChartType = xlColumnClustered
        .SetSourceData source:=ws.Range("AA2:AB5"), PlotBy:=xlColumns
        .HasLegend = False
        .HasTitle = False
        .PlotVisibleOnly = False
        .ChartArea.Font.name = "Aptos"
        .ChartArea.Font.size = 10
        .SeriesCollection(1).Format.Fill.ForeColor.RGB = RGB(37, 99, 235)
        .Axes(xlValue).MinimumScale = 0
        .Axes(xlValue).TickLabels.NumberFormat = "0"
    End With
    Set frame = ws.Range("L21:S31")
    Set ch = ws.ChartObjects.Add(frame.Left, frame.Top, frame.width, frame.Height)
    ch.name = "TQM_DASH_Luni"
    With ch.Chart
        .ChartType = xlLineMarkers
        .SetSourceData source:=ws.Range("AB8:AC20"), PlotBy:=xlColumns
        .HasLegend = False
        .HasTitle = False
        .PlotVisibleOnly = False
        .ChartArea.Font.name = "Aptos"
        .ChartArea.Font.size = 10
        .SeriesCollection(1).Format.line.ForeColor.RGB = RGB(37, 99, 235)
        .Axes(xlValue).MinimumScale = 0
        .Axes(xlValue).TickLabels.NumberFormat = "#,##0"
    End With
End Sub

Private Sub TQM_Dash_Buttons(ByVal ws As Worksheet)
    Dim r As Long
    ws.Range("B3:S3").ClearContents
    TQM_Dash_Button ws, "TQM_DASH_Refresh", "B3:E3", "Actualizeaza", "TQM_Dashboard_Actualizeaza", RGB(37, 99, 235)
    TQM_Dash_Button ws, "TQM_DASH_Registru", "G3:J3", "Registru", "TQM_Dashboard_Registru", RGB(31, 41, 55)
    TQM_Dash_Button ws, "TQM_DASH_Incomplete", "L3:O3", "Dosare incomplete", "TQM_Dashboard_Incomplete", RGB(185, 28, 28)
    TQM_Dash_Button ws, "TQM_DASH_Reset", "Q3:S3", "Reset filtre", "TQM_Dashboard_ResetFiltre", RGB(75, 85, 99)
    For r = 35 To 44
        TQM_Dash_Button ws, "TQM_DASH_Row_" & r, "R" & r & ":S" & r, _
            "Deschide", "TQM_Dashboard_DeschideDosar", RGB(37, 99, 235)
    Next r
End Sub

Private Sub TQM_Dash_Button(ByVal ws As Worksheet, ByVal shapeName As String, _
    ByVal addr As String, ByVal captionText As String, ByVal macroName As String, ByVal fillColor As Long)
    Dim target As Range, button As Shape
    Set target = ws.Range(addr)
    Set button = ws.Shapes.AddShape(msoShapeRoundedRectangle, _
        target.Left + 2, target.Top + 2, target.width - 4, target.Height - 4)
    button.name = shapeName
    button.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & macroName
    button.Placement = xlMoveAndSize
    button.Fill.ForeColor.RGB = fillColor
    button.line.Visible = msoFalse
    With button.TextFrame2
        .TextRange.text = captionText
        .TextRange.Font.name = "Aptos"
        .TextRange.Font.size = 10
        .TextRange.Font.Bold = msoTrue
        .TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
        .TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .VerticalAnchor = msoAnchorMiddle
        .MarginLeft = 2
        .MarginRight = 2
        .MarginTop = 1
        .MarginBottom = 1
    End With
End Sub

Public Sub TQM_Dashboard_Registru()
    Dim ws As Worksheet
    On Error GoTo Failed
    Set ws = TQM_Dash_Source()
    ThisWorkbook.Activate
    ws.Activate
    Application.Goto ws.Range("A12"), True
    Exit Sub
Failed:
    MsgBox Err.description, vbExclamation, "TQM Calarasi"
End Sub

Public Sub TQM_Dashboard_ResetFiltre()
    Dim ws As Worksheet
    Set ws = TQM_Dash_Sheet(TQM_DASH_NAME)
    If ws Is Nothing Then Exit Sub
    ws.Range("E5").Value2 = DateSerial(Year(Date), 1, 1)
    ws.Range("J5").Value2 = DateSerial(Year(Date), 12, 31)
    ws.Range("O5").Value2 = "Toate proiectele"
    ws.Calculate
End Sub

Public Sub TQM_Dashboard_Incomplete()
    Dim ws As Worksheet, dash As Worksheet, lastRow As Long
    On Error GoTo Failed
    Set ws = TQM_Dash_Source()
    Set dash = TQM_Dash_Sheet(TQM_DASH_NAME)
    If dash Is Nothing Then Exit Sub
    dash.Calculate
    If CStr(dash.Range("Z2").Value2) <> "OK" Then
        MsgBox CStr(dash.Range("Z2").Value2), vbExclamation, "TQM Calarasi"
        Exit Sub
    End If
    lastRow = TQM_Dash_LastRow(ws)
    If lastRow < 13 Then lastRow = 13
    If ws.FilterMode Then ws.ShowAllData
    If ws.AutoFilterMode Then ws.AutoFilterMode = False
    With ws.Range("A12:Z" & lastRow)
        .AutoFilter field:=TQM_Control_Col(14), Criteria1:="INCOMPLET*"
        .AutoFilter field:=2, Criteria1:=">=" & CLng(dash.Range("E5").Value2), _
            Operator:=xlAnd, Criteria2:="<" & (CLng(dash.Range("J5").Value2) + 1)
        If CStr(dash.Range("O5").Value2) <> "Toate proiectele" Then
            .AutoFilter field:=TQM_Control_Col(6), Criteria1:=CStr(dash.Range("O5").Value2)
        End If
    End With
    ThisWorkbook.Activate
    ws.Activate
    Application.Goto ws.Range("A12"), True
    Exit Sub
Failed:
    MsgBox "Filtrarea nu a reusit: " & Err.description, vbExclamation, "TQM Calarasi"
End Sub

Public Sub TQM_Dashboard_DeschideDosar()
    Dim ws As Worksheet, dash As Worksheet
    Dim callerName As Variant, dashboardRow As Long, sourceRow As Variant
    On Error GoTo Failed
    Set dash = TQM_Dash_Sheet(TQM_DASH_NAME)
    If dash Is Nothing Then Exit Sub
    callerName = Application.Caller
    If VarType(callerName) = vbString Then
        If Left$(CStr(callerName), 13) = "TQM_DASH_Row_" Then
            dashboardRow = CLng(mID$(CStr(callerName), 14))
        End If
    Else
        If ActiveSheet.name = TQM_DASH_NAME Then dashboardRow = ActiveCell.row
    End If
    If dashboardRow < 35 Or dashboardRow > 44 Then
        MsgBox "Selectati un dosar din lista dashboardului.", vbInformation, "TQM Calarasi"
        Exit Sub
    End If
    dash.Calculate
    sourceRow = dash.Range("Z" & dashboardRow).Value2
    If Len(CStr(sourceRow)) = 0 Then Exit Sub
    If Not IsNumeric(sourceRow) Then Exit Sub
    Set ws = TQM_Dash_Source()
    If ws.FilterMode Then ws.ShowAllData
    ws.rows(CLng(sourceRow)).Hidden = False
    ThisWorkbook.Activate
    ws.Activate
    Application.Goto ws.Range("A" & CLng(sourceRow)), True
    Exit Sub
Failed:
    MsgBox "Dosarul nu a putut fi deschis: " & Err.description, vbExclamation, "TQM Calarasi"
End Sub


