Attribute VB_Name = "Module9"
Option Explicit
' Registru central de linkuri. Fisierele raman in locatia aleasa de utilizator.
' Confirmarea continutului este manuala; un link importat nu este verificat automat.
Private Const DOC_SHEET As String = "09_DOCUMENTE"
Private mForm As Workbook, mMode As String, mID As String, mTarget As String, mStamp As String
Private mBusy As Boolean, mGood As Boolean, mSources As Object
Private Type DOC_GUID
    Data1 As Long
    Data2 As Integer
    Data3 As Integer
    Data4(0 To 7) As Byte
End Type
#If VBA7 Then
Private Declare PtrSafe Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As DOC_GUID) As Long
#Else
Private Declare Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As DOC_GUID) As Long
#End If
Private Function DOC_SName(ByVal kind As Long) As String
    Select Case kind
    Case 1: DOC_SName = "09_DOCUMENTE"
    Case 2: DOC_SName = "_TQM_DOC_LEG"
    Case 3: DOC_SName = "_TQM_DOC_SURSE"
    Case 4: DOC_SName = "_TQM_DOC_DOS"
    Case 5: DOC_SName = "_TQM_DOC_LOG"
    End Select
End Function
Private Function DOC_TName(ByVal kind As Long) As String
    Select Case kind
    Case 1: DOC_TName = "tTQMDocumente"
    Case 2: DOC_TName = "tTQMDOCLinkuri"
    Case 3: DOC_TName = "tTQMDOCSurse"
    Case 4: DOC_TName = "tTQMDOCDosare"
    Case 5: DOC_TName = "tTQMDOCJurnal"
    End Select
End Function
Private Function DOC_Heads(ByVal kind As Long) As Variant
    Select Case kind
    Case 1: DOC_Heads = Split("Nr_document|Tip_document|Data_document|Emitent|Titlu|Link|Stare|Valabil_pana|Responsabil|Actiune|Nr_legaturi|ID_document|Revizie|Creat_la|Actualizat_la|Actualizat_de|Cheie_link|Verificat_de|Verificat_la|Observatii|Utilizabil|Proiecte|Link_valid", "|")
    Case 2: DOC_Heads = Split("ID_legatura|ID_document|Tip_entitate|ID_entitate|Tip_acoperit|Stare|Origine|Cheie_sursa|Referinta|Proiect|Partener|Creat_la|Actualizat_la|Observatii|Sursa_activa|Acopera", "|")
    Case 3: DOC_Heads = Split("Cheie_entitate|Tip_entitate|ID_entitate|Referinta|Proiect|Partener|Stare_sursa|Activa|Data|Link_sursa|Tip_document_sursa|Foaie_sursa|Tabel_sursa", "|")
    Case 4: DOC_Heads = Split("Nr_dosar|Document_sursa|Proiect|Partener|Tip_partener|Intrare|Stare_regula|Aviz|Conformitate|Producator|Fise_tehnice|Documente_lipsa_arhiva|Status_arhiva|Status_Control|ID_dosar|Cheie_regula|Cere_aviz|Cere_conformitate|Cere_producator|Cere_fise|Nr_lipsuri", "|")
    Case 5: DOC_Heads = Split("ID_eveniment|Data|Utilizator|Entitate|ID_inregistrare|Actiune|Camp|Valoare_veche|Valoare_noua", "|")
    End Select
End Function
Private Function DOC_SourceNames() As String
    DOC_SourceNames = "tTQMReguliDoc|tTQMComenzi|tTQMCFPoz|tTQMCFRec|tTQMFacturi|tTQMFPRepartizari|tTQMFPPlati|tTQMSTMiscari|tTQMCereri|tTQMOferte|tTQMNMProiecte|tTQMNMMateriale|tTQMNMParteneri|tTQMRFQ|tTQMRFQOferte"
End Function
Private Function DOC_SourceHeads(ByVal name As String) As Variant
    Select Case name
    Case "tTQMRFQ": DOC_SourceHeads = Split("ID_RFQ|Nr_RFQ|Data|Proiect|Solicitant|Termen_raspuns|Observatii|Stare|Revizie|Link_document|Actualizat_la", "|")
    Case "tTQMRFQOferte": DOC_SourceHeads = Split("ID_document|ID_RFQ|Furnizor|Nr_oferta|Data_oferta|Valabila_pana|Transport_RON|Alte_costuri_RON|Minim_comanda_RON|Conditie_pachet|Discount_pachet_RON|Conditii_plata|Link_oferta|Observatii|Revizie|Stare|Actualizat_la", "|")
    Case "tTQMReguliDoc": DOC_SourceHeads = Split("Cheie_regula|Tip_partener|Tip_intrare|Aviz|Decl_conformitate|Decl_producator|Fise_tehnice|Stare|Observatii|Revizie|Actualizat_la|Actualizat_de|ID_regula", "|")
    Case "tTQMComenzi": DOC_SourceHeads = Split("ID_comanda|Nr_comanda|Data_comanda|Furnizor|Proiect|Canal|Responsabil|Termen|Stare|Nr_pozitii|Valoare_net_RON|De_primit_RON|Livrare|Pozitii_intarziate|Transport_RON|Alte_costuri_RON|Referinta|Link_document|Observatii|Revizie|Actualizat_de|Actualizat_la", "|")
    Case "tTQMCFPoz": DOC_SourceHeads = Split("ID_pozitie|ID_comanda|Cod_material|Material|Specificatie|UM|Cant_comandata|Pret_unitar|Discount_pct|Cant_primita|Cant_anulata|Cant_ramasa|Val_initiala|Val_de_primit|Termen_livrare|Proiect|ID_cerere|ID_oferta|Observatii", "|")
    Case "tTQMCFRec": DOC_SourceHeads = Split("ID_receptie|ID_pozitie|ID_comanda|Data|Document|Cantitate|Stare|Link|Creat_de|Creat_la|Motiv_anulare", "|")
    Case "tTQMFacturi": DOC_SourceHeads = Split("Nr_factura|Data_factura|Partener|CIF_partener|Tip_factura|Scadenta|Net_RON|TVA_RON|Total_RON|Achitat_RON|Sold_RON|Status_plata|Proiecte|Link_factura|Observatii|ID_factura|ID_factura_originala|Responsabil|Stare|Creat_la|Actualizat_la|Anulat_la|Anulat_de|Motiv_anulare", "|")
    Case "tTQMFPRepartizari": DOC_SourceHeads = Split("ID_repartizare|ID_factura|Proiect|Net_RON|TVA_RON|Total_RON|Achitat_RON|Sold_RON|ID_comanda|ID_pozitie|ID_receptie|Descriere|Stare|Creat_la|Ordine|ID_repartizare_originala", "|")
    Case "tTQMFPPlati": DOC_SourceHeads = Split("ID_miscare|ID_operatie|ID_factura|ID_repartizare|Proiect|Data|Suma_RON|Tip|Metoda|Document|Responsabil|Observatii|Link|Stare|Creat_la|Anulat_la|Anulat_de|Motiv_anulare|ID_factura_pereche", "|")
    Case "tTQMSTMiscari": DOC_SourceHeads = Split("ID_miscare|ID_operatie|Data|Tip|ID_material|ID_locatie|Cantitate|Document|Responsabil|Observatii|ID_receptie|ID_pozitie|ID_comanda|Stare|Creat_la|Anulat_la|Anulat_de|Motiv_anulare|Proiect|Partener|Link", "|")
    Case "tTQMCereri": DOC_SourceHeads = Split("ID_cerere|Data_cerere|Proiect|Material|UM|Cantitate|Data_necesara|Prioritate|Oferte_valide|Cost_min|Furnizor_recom|Status|Specificatie|Solicitant|Buget_RON|ID_oferta_aprobata|Aprobat_de|Data_aprobarii|Motiv_decizie|Observatii|Amprenta_aprobarii|Creat_de|Actualizat_la|Amprenta_cerere", "|")
    Case "tTQMOferte": DOC_SourceHeads = Split("ID_oferta|ID_cerere|Furnizor|Cantitate|UM|Pret_unitar|Total_RON|Data_livrare|Valabila_pana|Conform_tehnic|Eligibila|Motiv|Nr_oferta|Data_oferta|Discount_pct|Transport_RON|Alte_costuri_RON|Conditii_plata|Garantie|Link_oferta|Observatii|Amprenta_oferta|Creat_de|Actualizat_la|Rang_cost|Cheie_cost|Rang_eligibil|Cheie_min|Cost_sortare", "|")
    Case "tTQMNMProiecte": DOC_SourceHeads = Split("ID_proiect|Cod_proiect|Denumire|Client|Adresa|Manager|Responsabil|Stare|Observatii|Revizie|Actualizat_la|Actualizat_de", "|")
    Case "tTQMNMMateriale": DOC_SourceHeads = Split("Cod_material|Denumire|Categorie|Subcategorie|Specificatie|UM|Producator|Model|Stare|Observatii|ID_material|Revizie|Creat_la|Actualizat_la|Actualizat_de|Sursa", "|")
    Case "tTQMNMParteneri": DOC_SourceHeads = Split("ID_partener|Cod_partener|Denumire|CIF|Tip|Contact|Email|Telefon|IBAN|Banca|Termen_plata_zile|Adresa|Stare|Observatii|Revizie|Actualizat_la|Actualizat_de", "|")
    End Select
End Function
Private Function DOC_Dict() As Object
    Set DOC_Dict = CreateObject("Scripting.Dictionary"): DOC_Dict.CompareMode = vbTextCompare
End Function
Private Function DOC_Text(ByVal v As Variant) As String
    If IsError(v) Then Err.Raise vbObjectError + 1000, , "O sursa contine o eroare Excel."
    DOC_Text = Trim$(CStr(v))
    If Len(DOC_Text) > 30000 Then Err.Raise vbObjectError + 1001, , "Camp prea lung."
End Function
Private Function DOC_Norm(ByVal v As Variant) As String
    Dim a As Variant, b As Variant, i As Long
    DOC_Norm = UCase$(Replace(DOC_Text(v), ChrW(160), " "))
    a = Array(258, 194, 206, 536, 350, 538, 354): b = Array("A", "A", "I", "S", "S", "T", "T")
    For i = 0 To UBound(a): DOC_Norm = Replace(DOC_Norm, ChrW(a(i)), b(i)): Next i
    Do While InStr(DOC_Norm, "  ") > 0: DOC_Norm = Replace(DOC_Norm, "  ", " "): Loop
End Function
Private Function DOC_NewID(ByVal prefix As String) As String
    Dim g As DOC_GUID, s As String, i As Long
    If CoCreateGuid(g) <> 0 Then Err.Raise vbObjectError + 1002, , "Nu s-a putut genera identificatorul."
    s = Right$("00000000" & Hex$(g.Data1), 8) & "-" & Right$("0000" & Hex$(g.Data2), 4) & "-" & Right$("0000" & Hex$(g.Data3), 4) & "-"
    For i = 0 To 7
        If i = 2 Then s = s & "-"
        s = s & Right$("00" & Hex$(g.Data4(i)), 2)
    Next i
    DOC_NewID = prefix & "-" & s
End Function
Private Function DOC_Source(ByVal name As String) As ListObject
    Dim ws As Worksheet, lo As ListObject
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            If lo.name = name Then Set DOC_Source = lo: Exit Function
        Next lo
    Next ws
    Err.Raise vbObjectError + 1003, , "Lipseste tabelul " & name & ". Instalati modulele precedente."
End Function
Private Function DOC_Table(ByVal kind As Long) As ListObject
    Set DOC_Table = DOC_Source(DOC_TName(kind))
End Function
Private Function DOC_Read(ByVal name As String, ByVal idColumn As Long) As Object
    Dim lr As ListRow, lo As ListObject, a As Variant, c As Long, id As String
    Set DOC_Read = DOC_Dict(): Set lo = DOC_Source(name)
    For Each lr In lo.ListRows
        id = DOC_Text(lr.Range.Cells(1, idColumn).Value2)
        If Len(id) > 0 Then
            If name = "tTQMCFRec" Then
                If Len(DOC_Text(lr.Range.Cells(1, 2).Value2)) = 0 Then Err.Raise vbObjectError + 1073, , "Receptie fara ID pozitie."
                id = Len(id) & ":" & id & "|" & DOC_Text(lr.Range.Cells(1, 2).Value2)
            End If
            If DOC_Read.exists(id) Then Err.Raise vbObjectError + 1004, , "ID duplicat in " & name & ": " & id
            ReDim a(0 To lo.ListColumns.count - 1)
            For c = 0 To UBound(a): a(c) = lr.Range.Cells(1, c + 1).Value2: Next c
            DOC_Read.Add id, a
        End If
    Next lr
End Function
Private Function DOC_Find(ByVal kind As Long, ByVal id As String, Optional ByVal column As Long = 1) As Range
    Dim lr As ListRow
    If Len(id) = 0 Then Exit Function
    For Each lr In DOC_Table(kind).ListRows
        If StrComp(DOC_Text(lr.Range.Cells(1, column).Value2), id, vbBinaryCompare) = 0 Then
            If Not DOC_Find Is Nothing Then Err.Raise vbObjectError + 1005, , "Cheie duplicata: " & id
            Set DOC_Find = lr.Range
        End If
    Next lr
End Function
Private Sub DOC_Ensure()
    Dim k As Long, c As Long, ws As Worksheet, lo As ListObject, hs As Variant, name As Variant
    For k = 1 To 5
        Set ws = Nothing: On Error Resume Next: Set ws = ThisWorkbook.Worksheets(DOC_SName(k)): On Error GoTo 0
        If ws Is Nothing Then Set ws = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count)): ws.name = DOC_SName(k)
        ws.Unprotect: Set lo = Nothing: On Error Resume Next: Set lo = ws.ListObjects(DOC_TName(k)): On Error GoTo 0
        hs = DOC_Heads(k)
        If lo Is Nothing Then
            If Application.CountA(ws.Cells) > 0 Then Err.Raise vbObjectError + 1006, , "Foaie existenta cu alta structura: " & ws.name
            For c = 0 To UBound(hs): ws.Cells(12, c + 1).Value2 = hs(c): Next c
            Set lo = ws.ListObjects.Add(xlSrcRange, ws.Cells(12, 1).Resize(2, UBound(hs) + 1), , xlYes): lo.name = DOC_TName(k)
        End If
        If lo.ListColumns.count <> UBound(hs) + 1 Then Err.Raise vbObjectError + 1007, , "Structura incompatibila: " & lo.name
        For c = 0 To UBound(hs)
            If lo.ListColumns(c + 1).name <> hs(c) Then Err.Raise vbObjectError + 1008, , "Coloana incompatibila: " & lo.name
        Next c
        If lo.ListRows.count = 0 Then lo.ListRows.Add
        If k > 1 Then ws.Visible = xlSheetVeryHidden
    Next k
    For Each name In Split(DOC_SourceNames(), "|")
        Set lo = DOC_Source(CStr(name)): hs = DOC_SourceHeads(CStr(name))
        If lo.ListColumns.count <> UBound(hs) + 1 Then Err.Raise vbObjectError + 1009, , "Structura sursa incompatibila: " & lo.name
        For c = 0 To UBound(hs)
            If lo.ListColumns(c + 1).name <> hs(c) Then Err.Raise vbObjectError + 1010, , "Coloana sursa incompatibila: " & lo.name
        Next c
    Next name
End Sub
Private Function DOC_Profile(ByVal partnerType As Variant, ByVal entry As Variant) As String
    Dim p As String, t As String
    p = DOC_Norm(partnerType): t = DOC_Norm(entry)
    If Left$(p, 4) = "FURN" Then p = "Furnizor"
    If Left$(p, 4) = "PROD" Then p = "Producator"
    If Left$(p, 4) = "PRES" Then p = "Prestator"
    If Left$(p, 3) = "ALT" Then p = "Alt partener"
    If Left$(t, 4) = "DOAR" Then t = "Doar Aviz"
    If Left$(t, 4) = "FACT" Then t = "Factura"
    DOC_Profile = p & "|" & t
End Function
Private Sub DOC_AddSource(ByVal entity As String, ByVal id As String, ByVal reference As Variant, ByVal project As Variant, ByVal partner As Variant, ByVal state As Variant, ByVal dateValue As Variant, ByVal link As Variant, ByVal docType As String, ByVal sheet As String, ByVal table As String)
    Dim key As String, active As Long
    key = entity & "|" & id: active = 1
    If Len(table) > 0 Then sheet = DOC_Source(table).Parent.name
    If Len(id) = 0 Or mSources.exists(key) Then Err.Raise vbObjectError + 1011, , "Cheie sursa lipsa / duplicata: " & key
    If state = "Anulata" Or state = "Inactiv" Then active = 0
    mSources.Add key, Array(key, entity, id, reference, project, partner, state, active, dateValue, link, docType, sheet, table)
End Sub
Private Sub DOC_ReceiptSource(ByVal id As String, ByVal reference As Variant, ByVal project As String, ByVal partner As Variant, ByVal state As Variant, ByVal dateValue As Variant, ByVal link As Variant)
    Dim key As String, a As Variant, value As Variant, exists As Boolean
    key = "Receptie|" & id
    If Not mSources.exists(key) Then
        DOC_AddSource "Receptie", id, reference, project, partner, state, dateValue, link, "Receptie", "_TQM_CF_REC", "tTQMCFRec"
        Exit Sub
    End If
    a = mSources(key)
    If CStr(a(3)) <> CStr(reference) Or CStr(a(5)) <> CStr(partner) Or CStr(a(6)) <> CStr(state) Or CStr(a(8)) <> CStr(dateValue) Or CStr(a(9)) <> CStr(link) Then _
        Err.Raise vbObjectError + 1074, , "Pozitiile aceleiasi receptii au document, furnizor, stare, data sau link incompatibile."
    For Each value In Split(CStr(a(4)), " / ")
        If StrComp(CStr(value), project, vbTextCompare) = 0 Then exists = True
    Next value
    If Len(project) > 0 And Not exists Then
        If Len(CStr(a(4))) > 0 Then a(4) = CStr(a(4)) & " / " & project Else a(4) = project
        mSources(key) = a
    End If
End Sub

Private Sub DOC_BuildSources(ByRef dossiers As Collection)
    Dim ws As Worksheet, r As Long, id As String, key As Variant, a As Variant, b As Variant, projects As String
    Dim orders As Object, positions As Object, invoices As Object, requests As Object, rows As Object, reps As Object, rules As Object
    Set mSources = DOC_Dict(): Set dossiers = New Collection
    Set rules = DOC_Read("tTQMReguliDoc", 1)
    For Each key In rules.keys
        a = rules(key)
        If a(7) <> "Confirmata" And a(7) <> "De confirmat" Then Err.Raise vbObjectError + 1012, , "Stare de regula necunoscuta."
        For r = 3 To 6
            If a(r) <> "Da" And a(r) <> "Nu" Then Err.Raise vbObjectError + 1013, , "Regula de documente invalida."
        Next r
    Next key
    Set ws = ThisWorkbook.Worksheets("Control_Achizitii")
    For r = 13 To TQM_Control_Cell(ws, ws.rows.count, "G").End(xlUp).row
        If Len(DOC_Text(TQM_Control_Cell(ws, r, "G").Value2)) > 0 Then
            id = DOC_Text(TQM_Control_Cell(ws, r, "R").Value2)
            If Len(id) = 0 Then Err.Raise vbObjectError + 1014, , "Dosar fara ID. Rulati SL_ActualizeazaControl."
            DOC_AddSource "Dosar", id, TQM_Control_Cell(ws, r, "C").Value2, TQM_Control_Cell(ws, r, "F").Value2, TQM_Control_Cell(ws, r, "G").Value2, "Activ", TQM_Control_Cell(ws, r, "D").Value2, "", "Alt document", "Control_Achizitii", ""
            dossiers.Add Array(TQM_Control_Cell(ws, r, "A").Value2, TQM_Control_Cell(ws, r, "C").Value2, TQM_Control_Cell(ws, r, "F").Value2, TQM_Control_Cell(ws, r, "G").Value2, TQM_Control_Cell(ws, r, "H").Value2, TQM_Control_Cell(ws, r, "I").Value2, "", "", "", "", "", "", "", TQM_Control_Cell(ws, r, "N").Value2, id, DOC_Profile(TQM_Control_Cell(ws, r, "H").Value2, TQM_Control_Cell(ws, r, "I").Value2), "", "", "", "", "")
        End If
    Next r
    Set orders = DOC_Read("tTQMComenzi", 1): Set positions = DOC_Read("tTQMCFPoz", 1)
    For Each key In orders.keys
        a = orders(key)
        DOC_AddSource "Comanda", CStr(key), a(1), a(4), a(3), a(8), a(2), a(17), "Comanda", "03_COMENZI_FURNIZORI", "tTQMComenzi"
    Next key
    Set rows = DOC_Read("tTQMCFRec", 1)
    For Each key In rows.keys
        a = rows(key)
        If Not positions.exists(CStr(a(1))) Or Not orders.exists(CStr(a(2))) Then Err.Raise vbObjectError + 1015, , "Receptie fara comanda / pozitie."
        b = positions(CStr(a(1))): projects = CStr(b(15))
        If CStr(b(1)) <> CStr(a(2)) Then Err.Raise vbObjectError + 1015, , "Receptie cu alta comanda."
        b = orders(CStr(a(2)))
        DOC_ReceiptSource CStr(a(0)), a(4), projects, b(3), a(6), a(3), a(7)
    Next key
    Set invoices = DOC_Read("tTQMFacturi", 16): Set reps = DOC_Read("tTQMFPRepartizari", 1)
    For Each key In invoices.keys
        a = invoices(key): projects = DOC_InvoiceProjects(CStr(key), reps)
        DOC_AddSource "Factura", CStr(key), a(0), projects, a(2), a(18), a(1), a(13), "Factura", "05_FACTURI_SI_PLATI", "tTQMFacturi"
    Next key
    Set rows = DOC_Read("tTQMFPPlati", 1)
    For Each key In rows.keys
        a = rows(key)
        If Not invoices.exists(CStr(a(2))) Then Err.Raise vbObjectError + 1016, , "Plata fara factura."
        b = invoices(CStr(a(2)))
        DOC_AddSource "Plata", CStr(key), a(9), a(4), b(2), a(13), a(5), a(12), "Dovada plata", "_TQM_FP_PLATI", "tTQMFPPlati"
    Next key
    Set rows = DOC_Read("tTQMSTMiscari", 1)
    For Each key In rows.keys
        a = rows(key)
        DOC_AddSource "Miscare stoc", CStr(key), a(7), a(18), a(19), a(13), a(2), a(20), "Document stoc", "_TQM_ST_MISC", "tTQMSTMiscari"
    Next key
    Set requests = DOC_Read("tTQMCereri", 1)
    For Each key In requests.keys
        a = requests(key)
        DOC_AddSource "Cerere", CStr(key), key, a(2), "", "Activ", a(1), "", "Alt document", "02_CERERI_SI_OFERTE", "tTQMCereri"
    Next key
    Set rows = DOC_Read("tTQMOferte", 1)
    For Each key In rows.keys
        a = rows(key)
        If Not requests.exists(CStr(a(1))) Then Err.Raise vbObjectError + 1017, , "Oferta fara cerere."
        b = requests(CStr(a(1)))
        DOC_AddSource "Oferta", CStr(key), a(12), b(2), a(2), "Activ", a(13), a(19), "Oferta", "_TQM_OFERTE", "tTQMOferte"
    Next key
    Set rows = DOC_Read("tTQMNMProiecte", 1)
    For Each key In rows.keys
        a = rows(key)
        DOC_AddSource "Proiect", CStr(key), a(1), a(2), a(3), a(7), "", "", "Contract", "06_NOMENCLATOARE", "tTQMNMProiecte"
    Next key
    Set rows = DOC_Read("tTQMNMParteneri", 1)
    For Each key In rows.keys
        a = rows(key)
        DOC_AddSource "Partener", CStr(key), a(1), "", a(2), a(12), "", "", "Certificat", "06_NOMENCLATOARE", "tTQMNMParteneri"
    Next key
    Set rows = DOC_Read("tTQMRFQ", 1)
    For Each key In rows.keys
        a = rows(key)
        DOC_AddSource "Cerere RFQ", CStr(key), a(1), a(3), "", a(7), a(2), a(9), "Alt document", "_TQM_RFQ", "tTQMRFQ"
    Next key
    Set rows = DOC_Read("tTQMRFQOferte", 1)
    For Each key In rows.keys
        a = rows(key)
        DOC_AddSource "Oferta furnizor", CStr(key), a(3), "", a(2), a(15), a(4), a(12), "Oferta", "_TQM_RFQ_OF", "tTQMRFQOferte"
    Next key
    Set rows = DOC_Read("tTQMNMMateriale", 11)
    For Each key In rows.keys
        a = rows(key)
        DOC_AddSource "Material", CStr(key), a(0), "", a(6), a(8), "", "", "Fise tehnice", "06_NOMENCLATOARE", "tTQMNMMateriale"
    Next key
End Sub
Private Function DOC_InvoiceProjects(ByVal invoiceID As String, ByVal reps As Object) As String
    Dim key As Variant, a As Variant, seen As Object, name As String
    Set seen = DOC_Dict()
    For Each key In reps.keys
        a = reps(key): name = DOC_Text(a(2))
        If CStr(a(1)) = invoiceID And a(12) = "Valida" And Len(name) > 0 Then
            If Not seen.exists(name) Then
                seen.Add name, True
                If Len(DOC_InvoiceProjects) > 0 Then DOC_InvoiceProjects = DOC_InvoiceProjects & "; "
                DOC_InvoiceProjects = DOC_InvoiceProjects & name
            End If
        End If
    Next key
End Function
Private Function DOC_LinkKey(ByVal value As String) As String
    Dim p As Long, start As Long, cut As Long, mark As Variant, host As String
    value = Trim$(value)
    If LCase$(Left$(value, 7)) = "http://" Or LCase$(Left$(value, 8)) = "https://" Then
        start = InStr(value, "://") + 3: cut = Len(value) + 1
        For Each mark In Array("/", "?", "#")
            p = InStr(start, value, CStr(mark))
            If p > 0 And p < cut Then cut = p
        Next mark
        host = VBA.mID$(value, start, cut - start)
        DOC_LinkKey = LCase$(Left$(value, start - 1) & host) & VBA.mID$(value, cut)
    Else
        DOC_LinkKey = UCase$(Replace(value, "/", "\"))
    End If
End Function
Private Function DOC_LinkOK(ByVal value As String) As Boolean
    Dim ext As String, p As Long, prefix As String, host As String, start As Long, cut As Long, mark As Variant
    If Len(value) = 0 Then Exit Function
    If InStr(value, vbCr) > 0 Or InStr(value, vbLf) > 0 Or InStr(value, Chr$(0)) > 0 Then Exit Function
    prefix = LCase$(value)
    If Left$(prefix, 8) = "https://" Or Left$(prefix, 7) = "http://" Then
        start = InStr(value, "://") + 3: cut = Len(value) + 1
        For Each mark In Array("/", "?", "#")
            p = InStr(start, value, CStr(mark))
            If p > 0 And p < cut Then cut = p
        Next mark
        host = VBA.mID$(value, start, cut - start)
        DOC_LinkOK = (Len(host) > 0 And InStr(host, " ") = 0 And InStr(host, "\") = 0 And InStr(host, "@") = 0)
        Exit Function
    End If
    If Left$(value, 2) <> "\\" And Not (Len(value) > 3 And VBA.mID$(value, 2, 2) = ":\") Then Exit Function
    p = InStrRev(value, "."): If p = 0 Then Exit Function
    ext = LCase$(VBA.mID$(value, p))
    DOC_LinkOK = (InStr("|.pdf|.doc|.docx|.xls|.xlsx|.xlsm|.png|.jpg|.jpeg|.tif|.tiff|.dwg|.dxf|.zip|.txt|.eml|.msg|", "|" & ext & "|") > 0)
End Function
Private Function DOC_Types() As Variant
    DOC_Types = Split("Comanda|Oferta|Factura|Aviz|Declaratie conformitate|Declaratie producator|Fise tehnice|Receptie|Dovada plata|Document stoc|Contract|Garantie|Certificat|Pachet documente|Alt document", "|")
End Function
Private Function DOC_TypeOK(ByVal value As String) As Boolean
    Dim a As Variant
    For Each a In DOC_Types(): If CStr(a) = value Then DOC_TypeOK = True: Exit Function
    Next a
End Function
Private Function DOC_Add(ByVal kind As Long) As Range
    Dim lr As ListRow, lo As ListObject, idColumn As Long
    Set lo = DOC_Table(kind): lo.Parent.Unprotect: idColumn = 1: If kind = 1 Then idColumn = 12
    For Each lr In lo.ListRows
        If Len(DOC_Text(lr.Range.Cells(1, idColumn).Value2)) = 0 Then Set DOC_Add = lr.Range: Exit Function
    Next lr
    Set DOC_Add = lo.ListRows.Add.Range
End Function
Private Sub DOC_Write(ByVal row As Range, ByVal a As Variant)
    Dim c As Long
    For c = 0 To UBound(a)
        If VarType(a(c)) = vbString Then
            If Len(CStr(a(c))) > 0 Then row.Cells(1, c + 1).NumberFormat = "@"
        End If
        row.Cells(1, c + 1).Value2 = a(c)
    Next c
End Sub
Private Sub DOC_Audit(ByVal entity As String, ByVal id As String, ByVal action As String, ByVal field As String, ByVal oldValue As String, ByVal newValue As String)
    Dim row As Range
    Set row = DOC_Add(5)
    DOC_Write row, Array(DOC_NewID("DE"), CDbl(Now), Application.UserName, entity, id, action, field, oldValue, newValue)
End Sub
Private Function DOC_LinkRow(ByVal docID As String, ByVal target As String, ByVal coverage As String) As Range
    Dim lr As ListRow
    For Each lr In DOC_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = docID And CStr(lr.Range.Cells(1, 3).Value2) & "|" & CStr(lr.Range.Cells(1, 4).Value2) = target And CStr(lr.Range.Cells(1, 5).Value2) = coverage And lr.Range.Cells(1, 6).Value2 = "Valida" Then
            If Not DOC_LinkRow Is Nothing Then Err.Raise vbObjectError + 1018, , "Asociere activa duplicata."
            Set DOC_LinkRow = lr.Range
        End If
    Next lr
End Function
Private Sub DOC_Attach(ByVal docID As String, ByVal target As String, ByVal coverage As String, ByVal origin As String, ByVal note As String)
    Dim row As Range, a As Variant, id As String
    If Not mSources.exists(target) Then Err.Raise vbObjectError + 1019, , "Operatiunea nu mai exista."
    If Not DOC_TypeOK(coverage) Then Err.Raise vbObjectError + 1020, , "Tip acoperit necunoscut."
    a = mSources(target): Set row = DOC_LinkRow(docID, target, coverage)
    If Not row Is Nothing Then
        If origin = "Sursa" And row.Cells(1, 7).Value2 <> "Sursa" Then
            DOC_Table(2).Parent.Unprotect: row.Cells(1, 7).Value2 = "Sursa": row.Cells(1, 8).Value2 = target
            DOC_Audit "Asociere", CStr(row.Cells(1, 1).Value2), "Legatura preluata din sursa", "Origine", "Manual", "Sursa"
        End If
        Exit Sub
    End If
    id = DOC_NewID("DL"): Set row = DOC_Add(2)
    DOC_Write row, Array(id, docID, a(1), a(2), coverage, "Valida", origin, IIf(origin = "Sursa", target, ""), a(3), a(4), a(5), CDbl(Now), CDbl(Now), note, a(7), "")
    DOC_Audit "Asociere", id, "Creare", "Document / sursa / tip", "", docID & "|" & target & "|" & coverage
End Sub
Private Sub DOC_ImportLinks()
    Dim links As Object, key As Variant, a As Variant, doc As Range, row As Range, lr As ListRow, link As String, sourceKey As String, previous As String, id As String
    Set links = DOC_Dict(): links.CompareMode = vbBinaryCompare: DOC_Table(1).Parent.Unprotect: DOC_Table(2).Parent.Unprotect
    For Each lr In DOC_Table(1).ListRows
        id = DOC_Text(lr.Range.Cells(1, 12).Value2): link = DOC_Text(lr.Range.Cells(1, 6).Value2)
        If Len(id) > 0 And Len(link) > 0 Then
            sourceKey = DOC_LinkKey(link)
            If links.exists(sourceKey) Then Err.Raise vbObjectError + 1021, , "Acelasi link este inregistrat de doua ori."
            links.Add sourceKey, id: lr.Range.Cells(1, 17).Value2 = sourceKey
        End If
    Next lr
    ' Old automatic associations are kept with their history when the owning link changes.
    For Each lr In DOC_Table(2).ListRows
        If lr.Range.Cells(1, 7).Value2 = "Sursa" And lr.Range.Cells(1, 6).Value2 = "Valida" Then
            sourceKey = CStr(lr.Range.Cells(1, 8).Value2): previous = "": Set doc = DOC_Find(1, CStr(lr.Range.Cells(1, 2).Value2), 12)
            If doc Is Nothing Then Err.Raise vbObjectError + 1022, , "Asociere fara document."
            If mSources.exists(sourceKey) Then a = mSources(sourceKey): previous = DOC_Text(a(9))
            If Len(previous) = 0 Or DOC_LinkKey(previous) <> DOC_LinkKey(CStr(doc.Cells(1, 6).Value2)) Then
                lr.Range.Cells(1, 6).Value2 = "Retrasa_sursa": lr.Range.Cells(1, 13).Value2 = CDbl(Now)
                DOC_Audit "Asociere", CStr(lr.Range.Cells(1, 1).Value2), "Retragere din sursa", "Stare", "Valida", "Retrasa_sursa"
            End If
        End If
    Next lr
    For Each key In mSources.keys
        a = mSources(key): link = DOC_Text(a(9))
        If Len(link) > 0 Then
            sourceKey = DOC_LinkKey(link)
            If links.exists(sourceKey) Then
                id = CStr(links(sourceKey))
            Else
                id = DOC_NewID("DA"): Set row = DOC_Add(1)
                DOC_Write row, Array(a(3), a(10), a(8), a(5), a(10) & " " & CStr(a(3)), link, "Inregistrat", "", Application.UserName, "", "", id, 1, CDbl(Now), CDbl(Now), Application.UserName, sourceKey, "", "", "Link preluat din " & CStr(a(1)) & ". Verificati continutul.", "", "", IIf(DOC_LinkOK(link), 1, 0))
                links.Add sourceKey, id: DOC_Audit "Document", id, "Preluare din sursa", "Link", "", link
            End If
            DOC_Attach id, CStr(key), CStr(a(10)), "Sursa", "Asociere din registrul operatiunii."
        End If
    Next key
End Sub
Private Sub DOC_Validate()
    Dim docs As Object, seen As Object, key As Variant, a As Variant, lr As ListRow, id As String, target As String, composite As String, value As String
    Set docs = DOC_Read(DOC_TName(1), 12): Set seen = DOC_Dict(): seen.CompareMode = vbBinaryCompare
    For Each key In docs.keys
        a = docs(key): value = DOC_Text(a(5))
        If a(6) <> "Inregistrat" And a(6) <> "Verificat" And a(6) <> "Respins" And a(6) <> "Arhivat" Then Err.Raise vbObjectError + 1023, , "Stare document invalida."
        If Not DOC_TypeOK(CStr(a(1))) Then Err.Raise vbObjectError + 1024, , "Tip de document invalid."
        If a(6) = "Verificat" And (Len(DOC_Text(a(17))) = 0 Or Not IsNumeric(a(18))) Then Err.Raise vbObjectError + 1025, , "Document verificat fara verificator / data."
        If Len(DOC_Text(a(7))) > 0 Then
            If Not IsNumeric(a(7)) Then Err.Raise vbObjectError + 1026, , "Valabilitate invalida."
        End If
        If Len(value) > 0 Then
            composite = DOC_LinkKey(value)
            If seen.exists(composite) Then Err.Raise vbObjectError + 1027, , "Link duplicat."
            seen.Add composite, True
        End If
    Next key
    Set seen = DOC_Dict(): DOC_Table(2).Parent.Unprotect
    For Each lr In DOC_Table(2).ListRows
        id = DOC_Text(lr.Range.Cells(1, 1).Value2)
        If Len(id) > 0 Then
            If Not docs.exists(CStr(lr.Range.Cells(1, 2).Value2)) Then Err.Raise vbObjectError + 1028, , "Asociere fara document."
            target = CStr(lr.Range.Cells(1, 3).Value2) & "|" & CStr(lr.Range.Cells(1, 4).Value2)
            lr.Range.Cells(1, 15).Value2 = 0
            If mSources.exists(target) Then
                a = mSources(target): lr.Range.Cells(1, 9).Resize(, 3).Value2 = Array(a(3), a(4), a(5)): lr.Range.Cells(1, 15).Value2 = a(7)
            End If
            If lr.Range.Cells(1, 6).Value2 = "Valida" Then
                composite = CStr(lr.Range.Cells(1, 2).Value2) & "|" & target & "|" & CStr(lr.Range.Cells(1, 5).Value2)
                If seen.exists(composite) Then Err.Raise vbObjectError + 1029, , "Asociere duplicata."
                seen.Add composite, True
                If Not DOC_TypeOK(CStr(lr.Range.Cells(1, 5).Value2)) Then Err.Raise vbObjectError + 1030, , "Tip acoperit invalid."
            End If
        End If
    Next lr
    ' Validate stable association IDs separately.
    Set seen = DOC_Read(DOC_TName(2), 1)
End Sub
Private Sub DOC_Put(ByVal kind As Long, ByVal rows As Collection)
    Dim lo As ListObject, data As Variant, a As Variant, r As Long, c As Long, count As Long
    Dim body As Range
    Set lo = DOC_Table(kind)
    lo.Parent.Unprotect
    count = CLng(Application.Max(2, rows.count))
    Set body = lo.DataBodyRange
    If Not body Is Nothing Then body.ClearContents
    lo.Resize lo.HeaderRowRange.Resize(count + 1, lo.ListColumns.count)
    Set body = DOC_DataArea(lo)
    ReDim data(1 To count, 1 To lo.ListColumns.count)
    For r = 1 To rows.count
        a = rows(r)
        For c = 0 To UBound(a): data(r, c + 1) = a(c): Next c
    Next r
    body.NumberFormat = "@"
    body.Value2 = data
End Sub
Private Function DOC_CellText(ByVal sourceCell As Range, ByVal tableName As String, ByVal fieldName As String) As String
    Dim sourceValue As Variant, details As String, formulaText As String
    sourceValue = sourceCell.Value2
    If IsError(sourceValue) Then
        If sourceCell.HasFormula Then
            formulaText = CStr(sourceCell.formula)
        Else
            formulaText = "(valoare de eroare, fara formula)"
        End If
        details = "O sursa contine o eroare Excel." & vbCrLf & _
                  "Foaie: " & sourceCell.Parent.name & vbCrLf & _
                  "Tabel / sursa: " & tableName & vbCrLf & _
                  "Celula: " & sourceCell.address(False, False) & vbCrLf & _
                  "Coloana: " & fieldName & vbCrLf & _
                  "Eroare Excel: " & sourceCell.text
        Debug.Print details
        Debug.Print "Formula completa: " & formulaText
        Err.Raise vbObjectError + 1000, "DOC_CellText", _
                  details & vbCrLf & "Formula: " & Left$(formulaText, 400)
    End If
    DOC_CellText = DOC_Text(sourceValue)
End Function

Private Function DOC_Stamp() As String
    Dim names As Variant, name As Variant, lo As ListObject, lr As ListRow, c As Long, s As String, v As String, ws As Worksheet, r As Long
    names = Split(DOC_SourceNames() & "|tTQMDocumente|tTQMDOCLinkuri", "|")
    For Each name In names
        Set lo = DOC_Source(CStr(name)): s = s & CStr(name) & ":" & lo.ListRows.count & ";"
        For Each lr In lo.ListRows
            For c = 1 To lo.ListColumns.count
                v = DOC_CellText(lr.Range.Cells(1, c), lo.name, lo.ListColumns(c).name): s = s & Len(v) & ":" & v & ";"
            Next c
        Next lr
    Next name
    Set ws = ThisWorkbook.Worksheets("Control_Achizitii")
    For r = 13 To TQM_Control_Cell(ws, ws.rows.count, "G").End(xlUp).row
        For c = 1 To 18
            v = DOC_CellText(TQM_Control_Cell(ws, r, c), "Control_Achizitii", "Coloana logica " & CStr(c)): s = s & Len(v) & ":" & v & ";"
        Next c
    Next r
    DOC_Stamp = s
End Function
Private Sub DOC_Restore(ByVal kind As Long, ByVal data As Variant)
    Dim lo As ListObject, body As Range
    Dim rowCount As Long, columnCount As Long, tableRows As Long

    Set lo = DOC_Table(kind)
    If Not IsArray(data) Then Err.Raise vbObjectError + 972, "DOC_Restore", "Starea anterioara lipseste pentru " & lo.name
    rowCount = UBound(data, 1) - LBound(data, 1) + 1
    columnCount = UBound(data, 2) - LBound(data, 2) + 1
    If columnCount <> lo.ListColumns.count Then Err.Raise vbObjectError + 973, "DOC_Restore", "Stare anterioara incompatibila pentru " & lo.name
    tableRows = CLng(Application.Max(2, rowCount))

    lo.Parent.Unprotect Password:=""
    Set body = lo.DataBodyRange
    If Not body Is Nothing Then body.ClearContents
    lo.Resize lo.HeaderRowRange.Resize(tableRows + 1, lo.ListColumns.count)
    Set body = DOC_DataArea(lo)
    body.Cells(1, 1).Resize(rowCount, columnCount).formula = data
End Sub
Private Sub DOC_Formulas()
    Dim lo As ListObject, k As Long, body As Range
    For k = 1 To 4
        Set lo = DOC_Table(k)
        lo.Parent.Unprotect
        Set body = DOC_DataArea(lo)
    Next k
    Set lo = DOC_Table(1)
    lo.ListColumns("Utilizabil").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Utilizabil", "=IF(LEN([@ID_document])=0,"""",IF(AND([@Stare]=""Verificat"",[@Link_valid]=1,LEN([@Link])>0,LEN([@Emitent])>0,LEN([@Verificat_de])>0,IF(ISNUMBER([@Verificat_la]),[@Verificat_la]>0,FALSE),IF(LEN([@Valabil_pana])=0,TRUE,IF(ISNUMBER([@Valabil_pana]),[@Valabil_pana]>=TODAY(),FALSE))),1,0))"
    lo.ListColumns("Nr_legaturi").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Nr_legaturi", "=IF(LEN([@ID_document])=0,"""",COUNTIFS(tTQMDOCLinkuri[ID_document],[@ID_document],tTQMDOCLinkuri[Stare],""Valida"",tTQMDOCLinkuri[Sursa_activa],1))"
    lo.ListColumns("Actiune").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Actiune", "=IF(LEN([@ID_document])=0,"""",IF([@Stare]=""Arhivat"",""ARHIVAT"",IF([@Stare]=""Respins"",""DOCUMENT RESPINS"",IF(LEN([@Link])=0,""ADAUGATI LINKUL"",IF([@Link_valid]<>1,""CORECTATI LINKUL"",IF(IF(LEN([@Valabil_pana])=0,FALSE,[@Valabil_pana]<TODAY()),""DOCUMENT EXPIRAT"",IF([@Stare]<>""Verificat"",""VERIFICATI DOCUMENTUL"",IF([@Utilizabil]<>1,""COMPLETATI VERIFICAREA"",IF([@Nr_legaturi]=0,""ASOCIATI OPERATIUNEA"",""DOCUMENT VERIFICAT"")))))))))"
    Set lo = DOC_Table(2)
    lo.ListColumns("Acopera").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Acopera", "=IF(LEN([@ID_legatura])=0,"""",IF(AND([@Stare]=""Valida"",[@Sursa_activa]=1,COUNTIFS(tTQMDocumente[ID_document],[@ID_document],tTQMDocumente[Utilizabil],1)=1),1,0))"
    Set lo = DOC_Table(4)
    lo.ListColumns("Stare_regula").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Stare_regula", "=IF(LEN([@ID_dosar])=0,"""",IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],[@Cheie_regula])<>1,""REGULA NECONFIGURATA"",IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],[@Cheie_regula],tTQMReguliDoc[Stare],""Confirmata"")=1,""Confirmata"",""De confirmat"")))"
    lo.ListColumns("Cere_aviz").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Cere_aviz", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",0,IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],[@Cheie_regula],tTQMReguliDoc[Aviz],""Da"")=1,1,0)))"
    lo.ListColumns("Cere_conformitate").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Cere_conformitate", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",0,IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],[@Cheie_regula],tTQMReguliDoc[Decl_conformitate],""Da"")=1,1,0)))"
    lo.ListColumns("Cere_producator").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Cere_producator", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",0,IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],[@Cheie_regula],tTQMReguliDoc[Decl_producator],""Da"")=1,1,0)))"
    lo.ListColumns("Cere_fise").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Cere_fise", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",0,IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],[@Cheie_regula],tTQMReguliDoc[Fise_tehnice],""Da"")=1,1,0)))"
    lo.ListColumns("Aviz").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Aviz", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",""De confirmat"",IF([@Cere_aviz]=0,""N/A"",IF(COUNTIFS(tTQMDOCLinkuri[Tip_entitate],""Dosar"",tTQMDOCLinkuri[ID_entitate],[@ID_dosar],tTQMDOCLinkuri[Tip_acoperit],""Aviz"",tTQMDOCLinkuri[Acopera],1)>0,""Verificat"",""Lipsa""))))"
    lo.ListColumns("Conformitate").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Conformitate", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",""De confirmat"",IF([@Cere_conformitate]=0,""N/A"",IF(COUNTIFS(tTQMDOCLinkuri[Tip_entitate],""Dosar"",tTQMDOCLinkuri[ID_entitate],[@ID_dosar],tTQMDOCLinkuri[Tip_acoperit],""Declaratie conformitate"",tTQMDOCLinkuri[Acopera],1)>0,""Verificat"",""Lipsa""))))"
    lo.ListColumns("Producator").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Producator", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",""De confirmat"",IF([@Cere_producator]=0,""N/A"",IF(COUNTIFS(tTQMDOCLinkuri[Tip_entitate],""Dosar"",tTQMDOCLinkuri[ID_entitate],[@ID_dosar],tTQMDOCLinkuri[Tip_acoperit],""Declaratie producator"",tTQMDOCLinkuri[Acopera],1)>0,""Verificat"",""Lipsa""))))"
    lo.ListColumns("Fise_tehnice").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Fise_tehnice", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",""De confirmat"",IF([@Cere_fise]=0,""N/A"",IF(COUNTIFS(tTQMDOCLinkuri[Tip_entitate],""Dosar"",tTQMDOCLinkuri[ID_entitate],[@ID_dosar],tTQMDOCLinkuri[Tip_acoperit],""Fise tehnice"",tTQMDOCLinkuri[Acopera],1)>0,""Verificat"",""Lipsa""))))"
    lo.ListColumns("Nr_lipsuri").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Nr_lipsuri", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",""n.a."",IF([@Aviz]=""Lipsa"",1,0)+IF([@Conformitate]=""Lipsa"",1,0)+IF([@Producator]=""Lipsa"",1,0)+IF([@Fise_tehnice]=""Lipsa"",1,0)))"
    lo.ListColumns("Documente_lipsa_arhiva").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Documente_lipsa_arhiva", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",""Confirmati regulile documentelor"",IF([@Aviz]=""Lipsa"",""Aviz; "","""")&IF([@Conformitate]=""Lipsa"",""Declaratie conformitate; "","""")&IF([@Producator]=""Lipsa"",""Declaratie producator; "","""")&IF([@Fise_tehnice]=""Lipsa"",""Fise tehnice; "","""")))"
    lo.ListColumns("Status_arhiva").DataBodyRange.NumberFormat = "General"
    DOC_CalcSetR1C1 lo, "Status_arhiva", "=IF(LEN([@ID_dosar])=0,"""",IF([@Stare_regula]<>""Confirmata"",""REGULI DE CONFIRMAT"",IF([@Nr_lipsuri]=0,""ARHIVA COMPLETA"",""ARHIVA INCOMPLETA"")))"
    DOC_Table(1).ListColumns("Utilizabil").DataBodyRange.NumberFormat = "0"
    DOC_Table(1).ListColumns("Nr_legaturi").DataBodyRange.NumberFormat = "0"
    DOC_Table(2).ListColumns("Acopera").DataBodyRange.NumberFormat = "0"
    DOC_Table(4).ListColumns("Cere_aviz").DataBodyRange.Resize(, 5).NumberFormat = "0"
    DOC_Table(1).Parent.Calculate: DOC_Table(2).Parent.Calculate: DOC_Table(3).Parent.Calculate: DOC_Table(4).Parent.Calculate
End Sub
Private Sub DOC_ProjectLabels()
    Dim lr As ListRow, leg As ListRow, s As String, seen As Object, v As String, id As String
    DOC_Table(1).Parent.Unprotect
    For Each lr In DOC_Table(1).ListRows
        id = DOC_Text(lr.Range.Cells(1, 12).Value2)
        If Len(id) > 0 Then
            s = "": Set seen = DOC_Dict()
            For Each leg In DOC_Table(2).ListRows
                If CStr(leg.Range.Cells(1, 2).Value2) = id And leg.Range.Cells(1, 6).Value2 = "Valida" And leg.Range.Cells(1, 15).Value2 = 1 Then
                    v = DOC_Text(leg.Range.Cells(1, 10).Value2)
                    If Len(v) > 0 And Not seen.exists(v) Then
                        seen.Add v, True: If Len(s) > 0 Then s = s & "; "
                        s = s & v
                    End If
                End If
            Next leg
            lr.Range.Cells(1, 22).Value2 = s
            lr.Range.Cells(1, 23).Value2 = IIf(DOC_LinkOK(CStr(lr.Range.Cells(1, 6).Value2)), 1, 0)
        End If
    Next lr
End Sub
Private Sub DOC_Protect()
    Dim k As Long
    For k = 1 To 5: DOC_Table(k).Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True: Next k
End Sub
Private Sub DOC_Refresh()
    Dim oldE As Boolean, oldS As Boolean, before As String, rows As Collection, dossiers As Collection, key As Variant
    Dim backups(1 To 5) As Variant, k As Long, changed As Boolean, msg As String, eno As Long
    Dim stage As String, errorSource As String, lo As ListObject, body As Range
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating
    On Error GoTo Fail
    Application.EnableEvents = False: Application.ScreenUpdating = False
    stage = "Creare si verificare structura - DOC_Ensure"
    Call DOC_Ensure
    stage = "Salvare stare anterioara"
    For k = 1 To 5
        Set lo = DOC_Table(k)
        lo.Parent.Unprotect
        Set body = DOC_DataArea(lo)
        backups(k) = body.formula
    Next k
    changed = True
    stage = "Refacere formule calculate existente - DOC_Formulas"
    Call DOC_Formulas
    stage = "Citire surse - DOC_Stamp"
    before = DOC_Stamp()
    stage = "Construire surse si dosare - DOC_BuildSources"
    DOC_BuildSources dossiers
    stage = "Verificare consistenta surse"
    If before <> DOC_Stamp() Then Err.Raise vbObjectError + 1031, , "Sursele s-au modificat. Reluati actualizarea."
    stage = "Preluare linkuri - DOC_ImportLinks"
    Call DOC_ImportLinks
    stage = "Validare documente si asocieri - DOC_Validate"
    Call DOC_Validate
    Set rows = New Collection
    For Each key In mSources.keys: rows.Add mSources(key): Next key
    stage = "Actualizare registru surse - DOC_Put 3"
    DOC_Put 3, rows
    stage = "Actualizare registru dosare - DOC_Put 4"
    DOC_Put 4, dossiers
    stage = "Actualizare proiecte si linkuri - DOC_ProjectLabels"
    Call DOC_ProjectLabels
    stage = "Refacere formule dupa actualizare - DOC_Formulas"
    Call DOC_Formulas
    stage = "Refacere interfata - DOC_Layout"
    Call DOC_Layout
    DOC_Table(1).Parent.Unprotect
    DOC_Table(1).Parent.Range("A4").Value2 = "ACTUALIZAT " & Format$(Now, "dd.mm.yyyy hh:mm:ss") & ". Linkurile preluate asteapta verificarea continutului."
    stage = "Protejare foi - DOC_Protect"
    Call DOC_Protect
    mGood = True
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
    Exit Sub
Fail:
    eno = Err.number: msg = Err.description: errorSource = Err.source: mGood = False
    msg = "Etapa: " & stage & vbCrLf & "Eroare: " & CStr(eno) & vbCrLf & _
          "Sursa: " & errorSource & vbCrLf & "Mesaj: " & msg
    On Error Resume Next
    If changed Then
        For k = 1 To 5: DOC_Restore k, backups(k): Next k
    End If
    DOC_Table(1).Parent.Unprotect
    DOC_Table(1).Parent.Range("A4").Value2 = "NEACTUALIZAT - " & msg & ". Corectati sursa si reluati Actualizeaza."
    Call DOC_Protect
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
    On Error GoTo 0
    Err.Raise eno, "DOC_Refresh", msg
End Sub
Private Sub DOC_Button(ByVal ws As Worksheet, ByVal area As String, ByVal caption As String, ByVal macro As String)
    Dim sh As Shape, rg As Range
    On Error Resume Next: ws.Shapes("DOC_" & macro).Delete: On Error GoTo 0
    Set rg = ws.Range(area): Set sh = ws.Shapes.AddShape(msoShapeRoundedRectangle, rg.Left + 2, rg.Top + 1, rg.width - 4, rg.Height - 2)
    sh.name = "DOC_" & macro: sh.Fill.ForeColor.RGB = RGB(37, 99, 235): sh.line.Visible = msoFalse
    sh.TextFrame.Characters.text = caption: sh.TextFrame.Characters.Font.Color = vbWhite: sh.TextFrame.Characters.Font.size = 10
    sh.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & macro
End Sub
Private Sub DOC_Layout()
    Dim k As Long, ws As Worksheet, lo As ListObject, specs As Variant, a As Variant, width As Variant, c As Long
    For k = 1 To 5
        Set lo = DOC_Table(k): Set ws = lo.Parent: ws.Unprotect
        lo.Range.Font.name = "Aptos": lo.Range.Font.size = 10: lo.TableStyle = "TableStyleMedium2"
        lo.HeaderRowRange.Interior.Color = RGB(31, 41, 55): lo.HeaderRowRange.Font.Color = vbWhite
        lo.HeaderRowRange.Font.Bold = True: lo.HeaderRowRange.WrapText = True: lo.HeaderRowRange.RowHeight = 42
    Next k
    Set ws = DOC_Table(1).Parent
    Call DOC_PrepareHeader(ws)
    Call DOC_MergeUI(ws, "A2:J2"): ws.Range("A2").Value2 = "TQM Calarasi - Documente": ws.Range("A2").Font.name = "Aptos Display": ws.Range("A2").Font.size = 18: ws.Range("A2").Font.Bold = True: ws.rows(2).RowHeight = 34
    Call DOC_MergeUI(ws, "A3:J3"): ws.Range("A3").Value2 = "Registru de fisiere si asocieri. Verificarea documentelor si valabilitatea stabilesc acoperirea dosarului."
    Call DOC_MergeUI(ws, "A4:J4"): ws.Range("A4").Font.Color = RGB(154, 52, 18): ws.rows(4).RowHeight = 24: ws.rows("5:6").RowHeight = 26
    specs = Array(Array("A5:B5", "Document nou", "DOC_Nou"), Array("C5:D5", "Editeaza / verifica", "DOC_Editeaza"), Array("E5:F5", "Asociaza", "DOC_Asociaza"), Array("G5:H5", "Deschide fisierul", "DOC_Deschide"), Array("I5:J5", "Surse / operatiuni", "DOC_Surse"), _
        Array("A6:B6", "Dosare si lipsuri", "DOC_Dosare"), Array("C6:D6", "Asocieri", "DOC_Asocieri"), Array("E6:F6", "Actualizeaza", "DOC_Actualizeaza"), Array("G6:H6", "Jurnal modificari", "DOC_Jurnal"), Array("I6:J6", "Reguli documente", "DOC_Reguli"))
    For Each a In specs: DOC_Button ws, CStr(a(0)), CStr(a(1)), CStr(a(2)): Next a
    Call DOC_MergeUI(ws, "A8:B8"): ws.Range("A8").Value2 = "Documente in registru": Call DOC_MergeUI(ws, "A9:B9")
    Call DOC_MergeUI(ws, "C8:E8"): ws.Range("C8").Value2 = "Documente de rezolvat": Call DOC_MergeUI(ws, "C9:E9")
    Call DOC_MergeUI(ws, "F8:G8"): ws.Range("F8").Value2 = "Documente expirate": Call DOC_MergeUI(ws, "F9:G9")
    Call DOC_MergeUI(ws, "H8:J8"): ws.Range("H8").Value2 = "Dosare de completat / confirmat": Call DOC_MergeUI(ws, "H9:J9")
    ws.Range("A9").formula = "=COUNTIFS(tTQMDocumente[ID_document],""?*"")"
    ws.Range("C9").formula = "=COUNTIFS(tTQMDocumente[Actiune],""VERIFICATI DOCUMENTUL"")+COUNTIFS(tTQMDocumente[Actiune],""ADAUGATI LINKUL"")+COUNTIFS(tTQMDocumente[Actiune],""CORECTATI LINKUL"")+COUNTIFS(tTQMDocumente[Actiune],""ASOCIATI OPERATIUNEA"")+COUNTIFS(tTQMDocumente[Actiune],""DOCUMENT RESPINS"")+COUNTIFS(tTQMDocumente[Actiune],""COMPLETATI VERIFICAREA"")"
    ws.Range("F9").formula = "=COUNTIFS(tTQMDocumente[Actiune],""DOCUMENT EXPIRAT"")"
    ws.Range("H9").formula = "=COUNTIFS(tTQMDOCDosare[Status_arhiva],""ARHIVA INCOMPLETA"")+COUNTIFS(tTQMDOCDosare[Status_arhiva],""REGULI DE CONFIRMAT"")"
    ws.Range("A8:J9").Interior.Color = RGB(239, 246, 255): ws.Range("A9:J9").Font.size = 18: ws.Range("A9:J9").Font.Bold = True: ws.Range("A9:J9").NumberFormat = "0": ws.Range("A9:J9").HorizontalAlignment = xlCenter: ws.rows(9).RowHeight = 32
    Call DOC_MergeUI(ws, "A11:J11"): ws.Range("A11").Value2 = "Selectati un document. Dosare si lipsuri foloseste fisiere verificate, valabile si regulile confirmate din Setari Liste."
    ws.Range("A11").Font.Color = RGB(71, 85, 105): ws.rows(11).RowHeight = 24
    width = Array(20, 26, 15, 25, 36, 43, 17, 16, 22, 28, 14, 43, 11, 22, 22, 24, 43, 23, 22, 50, 13, 35, 14)
    For c = 0 To UBound(width): ws.Columns(c + 1).ColumnWidth = width(c): Next c
    DOC_Table(1).DataBodyRange.RowHeight = 30
    For Each a In Array("Data_document", "Valabil_pana"): DOC_Table(1).ListColumns(CStr(a)).Range.NumberFormat = "dd.mm.yyyy": Next a
    For Each a In Array("Creat_la", "Actualizat_la", "Verificat_la"): DOC_Table(1).ListColumns(CStr(a)).Range.NumberFormat = "dd.mm.yyyy hh:mm": Next a
    DOC_Table(1).ListColumns("Link").Range.Font.Color = RGB(37, 99, 235)
    DOC_Protect
End Sub
Public Sub DOC_Sync()
    Dim ws As Worksheet
    If mBusy Then Exit Sub
    On Error Resume Next: Set ws = ThisWorkbook.Worksheets(DOC_SHEET): On Error GoTo 0
    If ws Is Nothing Then Exit Sub
    mBusy = True
    On Error GoTo Done
    DOC_Refresh
Done: mBusy = False
End Sub
Public Sub DOC_Actualizeaza()
    On Error GoTo Fail
    If mBusy Then Exit Sub
    mBusy = True: Call DOC_Refresh: mBusy = False
    Exit Sub
Fail: mBusy = False: MsgBox Err.description, vbExclamation, "TQM - Documente"
End Sub
Public Sub DOC_Instaleaza()
    On Error GoTo Fail
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 1032, , "Registrul este doar pentru citire."
    mBusy = True
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_ActualizeazaControl"
Call DOC_Refresh:     mBusy = False
    ThisWorkbook.Worksheets(DOC_SHEET).Activate: ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 85
    ActiveWindow.FreezePanes = False: ActiveWindow.SplitRow = 12: ActiveWindow.SplitColumn = 2: ActiveWindow.FreezePanes = True
    MsgBox "Documente instalat. Confirmati regulile si verificati fisierele inainte de completarea arhivei.", vbInformation, "TQM"
    Exit Sub
Fail: mBusy = False: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Private Function DOC_Selected() As String
    Dim lo As ListObject, hit As Range, n As Long
    If Not ActiveWorkbook Is ThisWorkbook Then Err.Raise vbObjectError + 1033, , "Selectati documentul in registrul principal."
    If ActiveSheet.name <> DOC_SHEET Then Err.Raise vbObjectError + 1034, , "Deschideti Documente."
    Set lo = DOC_Table(1): Set hit = Intersect(ActiveCell, lo.DataBodyRange)
    If hit Is Nothing Then Err.Raise vbObjectError + 1035, , "Selectati un rand de document."
    n = ActiveCell.row - lo.HeaderRowRange.row: DOC_Selected = DOC_Text(lo.ListRows(n).Range.Cells(1, 12).Value2)
    If Len(DOC_Selected) = 0 Then Err.Raise vbObjectError + 1036, , "Randul selectat este gol."
End Function
Private Function DOC_Start(ByVal mode As String, ByVal id As String, Optional ByVal target As String = "") As Worksheet
    If Not mForm Is Nothing Then
        On Error Resume Next: Err.Clear: mForm.Activate
        If Err.number = 0 Then On Error GoTo 0: Err.Raise vbObjectError + 1037, , "Inchideti formularul local existent."
        Err.Clear: Set mForm = Nothing: On Error GoTo 0
    End If
    Set mForm = Workbooks.Add(xlWBATWorksheet): mMode = mode: mID = id: mTarget = target: mStamp = DOC_Stamp()
    Set DOC_Start = mForm.Worksheets(1): DOC_Start.name = "Formular_Documente"
    DOC_Start.Range("A1:J1").Merge: DOC_Start.Range("A1").Value2 = "TQM - " & mode & " (formular local)": DOC_Start.Range("A1").Font.name = "Aptos Display": DOC_Start.Range("A1").Font.size = 17
    DOC_Start.Range("A2:Z100").Font.name = "Aptos": DOC_Start.Range("A2:Z100").Font.size = 10
    DOC_Start.Columns("A").ColumnWidth = 30: DOC_Start.Columns("B").ColumnWidth = 58: DOC_Start.Columns("C:Z").ColumnWidth = 23
    DOC_Start.rows(3).RowHeight = 28: DOC_Button DOC_Start, "A3:B3", "Inchide", "DOC_Inchide"
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 85
End Function
Public Sub DOC_Inchide()
    On Error Resume Next
    If Not mForm Is Nothing Then mForm.Close SaveChanges:=False
    Set mForm = Nothing: mMode = "": mID = "": mTarget = "": mStamp = ""
    ThisWorkbook.Worksheets(DOC_SHEET).Activate
    On Error GoTo 0
End Sub
Private Sub DOC_Field(ByVal ws As Worksheet, ByVal n As Long, ByVal title As String, ByVal v As Variant, Optional ByVal editable As Boolean = True)
    ws.Cells(n, 1).Value2 = title: ws.Cells(n, 2).Value2 = v: ws.rows(n).RowHeight = 25
    If editable Then ws.Cells(n, 2).Locked = False: ws.Cells(n, 2).Interior.Color = RGB(239, 246, 255): ws.Cells(n, 2).Font.Color = RGB(37, 99, 235)
End Sub
Private Sub DOC_TypeList(ByVal target As Range)
    Dim cache As Worksheet, i As Long, types As Variant
    Set cache = Nothing: On Error Resume Next: Set cache = mForm.Worksheets("_DOC_LISTE_LOCALE"): On Error GoTo 0
    If cache Is Nothing Then Set cache = mForm.Worksheets.Add(after:=mForm.Worksheets(mForm.Worksheets.count)): cache.name = "_DOC_LISTE_LOCALE"
    types = DOC_Types()
    For i = 0 To UBound(types): cache.Cells(i + 1, 1).Value2 = types(i): Next i
    cache.Visible = xlSheetVeryHidden
    mForm.names.Add name:="DOC_Tipuri", RefersTo:="='_DOC_LISTE_LOCALE'!$A$1:$A$" & (UBound(types) + 1)
    target.Validation.Add xlValidateList, Formula1:="=DOC_Tipuri"
    mForm.Worksheets(1).Activate
End Sub
Private Sub DOC_EditForm(ByVal id As String, Optional ByVal target As String = "")
    Dim ws As Worksheet, row As Range, a As Variant, fields As Variant, cols As Variant, i As Long, values(5 To 16) As Variant
    On Error GoTo Fail
    If Len(id) > 0 Then
        Set row = DOC_Find(1, id, 12)
        If row Is Nothing Then Err.Raise vbObjectError + 1038, , "Documentul nu mai exista."
        fields = Array(1, 2, 3, 4, 5, 6, 7, 8, 9, 20)
        For i = 0 To UBound(fields): values(i + 5) = row.Cells(1, CLng(fields(i))).Value2: Next i
    Else
        values(6) = "Alt document": values(11) = "Inregistrat": values(13) = Application.UserName
        If Len(target) > 0 Then
            If Not mSources.exists(target) Then Err.Raise vbObjectError + 1039, , "Sursa nu mai exista."
            a = mSources(target): values(5) = a(3): values(6) = a(10): values(7) = a(8): values(8) = a(5): values(9) = a(10) & " " & CStr(a(3)): values(10) = a(9)
        End If
    End If
    Set ws = DOC_Start("DOCUMENT", id, target)
    DOC_Button ws, "C3:D3", "Salveaza", "DOC_Salveaza": DOC_Button ws, "E3:F3", "Alege fisier", "DOC_AlegeFisier": DOC_Button ws, "G3:H3", "Deschide fisierul", "DOC_DeschideFormular"
    fields = Split("Numar document|Tip document|Data document (optional)|Emitent|Titlu|Link / cale fisier|Stare|Valabil pana (optional)|Responsabil|Observatii / justificare|Verificat de (pentru Verificat)|Tip acoperit (implicit tipul)", "|")
    For i = 0 To UBound(fields): DOC_Field ws, i + 5, CStr(fields(i)), values(i + 5): Next i
    ws.Range("B5:B6").NumberFormat = "@": ws.Range("B8:B11").NumberFormat = "@": ws.Range("B13:B16").NumberFormat = "@"
    ws.Range("B7").NumberFormat = "dd.mm.yyyy": ws.Range("B12").NumberFormat = "dd.mm.yyyy"
    ws.Range("B10").WrapText = True: ws.rows(10).RowHeight = 42: ws.Range("B14").WrapText = True: ws.rows(14).RowHeight = 42
    DOC_TypeList ws.Range("B6"): DOC_TypeList ws.Range("B16")
    ws.Range("B11").Validation.Add xlValidateList, Formula1:="Inregistrat,Verificat,Respins,Arhivat"
    ws.Range("A18:J18").Merge: ws.Range("A18").Value2 = "Verificat confirma continutul. Introduceti numele verificatorului. Linkul singur nu completeaza dosarul."
    If Len(target) > 0 Then a = mSources(target): ws.Range("A19:J19").Merge: ws.Range("A19").Value2 = "Asociere: " & CStr(a(1)) & " " & CStr(a(3)) & " / " & CStr(a(4))
    ws.Protect UserInterfaceOnly:=True: ws.Activate
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM - Documente"
End Sub
Public Sub DOC_Nou()
    On Error GoTo Fail
Call DOC_Refresh:     DOC_EditForm ""
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub DOC_Editeaza()
    Dim id As String
    On Error GoTo Fail
    id = DOC_Selected(): Call DOC_Refresh: DOC_EditForm id
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Private Sub DOC_CheckForm(ByVal mode As String)
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 1040, , "Registrul este doar pentru citire."
    If mForm Is Nothing Then Err.Raise vbObjectError + 1041, , "Nu exista formular local."
    If Not ActiveWorkbook Is mForm Or mMode <> mode Then Err.Raise vbObjectError + 1042, , "Folositi formularul local potrivit."
    If mStamp <> DOC_Stamp() Then Err.Raise vbObjectError + 1043, , "Date modificate intre timp. Inchideti si redeschideti formularul."
End Sub
Public Sub DOC_AlegeFisier()
    Dim dialog As FileDialog
    On Error GoTo Fail
    DOC_CheckForm "DOCUMENT"
    Set dialog = Application.FileDialog(msoFileDialogFilePicker): dialog.title = "Selectati documentul": dialog.AllowMultiSelect = False
    dialog.Filters.Clear: dialog.Filters.Add "Documente", "*.pdf;*.doc;*.docx;*.xls;*.xlsx;*.xlsm;*.png;*.jpg;*.jpeg;*.tif;*.tiff;*.dwg;*.dxf;*.zip;*.txt;*.eml;*.msg"
    If dialog.Show = -1 Then mForm.Worksheets(1).Range("B10").Value2 = dialog.SelectedItems(1)
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Private Function DOC_Date(ByVal value As Variant) As Variant
    If Len(DOC_Text(value)) = 0 Then DOC_Date = "": Exit Function
    If IsNumeric(value) Then
        If CDbl(value) < 1 Or CDbl(value) > 2958465 Then Err.Raise vbObjectError + 1044, , "Data invalida."
        DOC_Date = Int(CDbl(value))
    ElseIf IsDate(value) Then
        DOC_Date = CDbl(dateValue(CDate(value)))
    Else
        Err.Raise vbObjectError + 1044, , "Introduceti o data Excel sau lasati campul gol."
    End If
End Function
Public Sub DOC_Salveaza()
    Dim ws As Worksheet, row As Range, lr As ListRow, values(0 To 22) As Variant, old As Variant, backups(1 To 5) As Variant
    Dim i As Long, k As Long, map As Variant, state As String, link As String, key As String, verifiedBy As String, coverage As String, id As String
    Dim rev As Long, changed As Boolean, oldE As Boolean, oldBusy As Boolean, msg As String
    On Error GoTo Fail
    DOC_CheckForm "DOCUMENT": Set ws = mForm.Worksheets(1)
    map = Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 19)
    For i = 0 To UBound(map): values(CLng(map(i))) = DOC_Text(ws.Cells(i + 5, 2).Value2): Next i
    values(2) = DOC_Date(ws.Range("B7").Value2): values(7) = DOC_Date(ws.Range("B12").Value2)
    state = CStr(values(6)): link = CStr(values(5)): verifiedBy = DOC_Text(ws.Range("B15").Value2)
    If Len(CStr(values(4))) = 0 Then Err.Raise vbObjectError + 1045, , "Titlul este obligatoriu."
    If Not DOC_TypeOK(CStr(values(1))) Then Err.Raise vbObjectError + 1046, , "Alegeti tipul documentului."
    If state <> "Inregistrat" And state <> "Verificat" And state <> "Respins" And state <> "Arhivat" Then Err.Raise vbObjectError + 1047, , "Stare de document invalida."
    If Len(link) > 0 And Not DOC_LinkOK(link) Then Err.Raise vbObjectError + 1048, , "Folositi HTTP(S), o cale Windows absoluta sau UNC catre un document."
    If Len(CStr(values(8))) = 0 Then Err.Raise vbObjectError + 1049, , "Completati responsabilul."
    If state = "Verificat" And (Len(link) = 0 Or Len(verifiedBy) = 0 Or Len(CStr(values(3))) = 0) Then Err.Raise vbObjectError + 1050, , "Verificat necesita un link, emitent si numele verificatorului."
    If (state = "Respins" Or state = "Arhivat") And Len(CStr(values(19))) = 0 Then Err.Raise vbObjectError + 1051, , "Completati justificarea."
    If Len(CStr(values(2))) > 0 And Len(CStr(values(7))) > 0 Then
        If CDbl(values(7)) < CDbl(values(2)) Then Err.Raise vbObjectError + 1052, , "Valabilitatea este inaintea datei documentului."
    End If
    key = DOC_LinkKey(link)
    For Each lr In DOC_Table(1).ListRows
        If Len(link) > 0 And DOC_Text(lr.Range.Cells(1, 12).Value2) <> mID And Len(DOC_Text(lr.Range.Cells(1, 12).Value2)) > 0 Then
            If DOC_LinkKey(CStr(lr.Range.Cells(1, 6).Value2)) = key Then Err.Raise vbObjectError + 1053, , "Link deja inregistrat. Asociati documentul existent."
        End If
    Next lr
    id = mID: Set row = DOC_Find(1, id, 12)
    If Len(id) > 0 And row Is Nothing Then Err.Raise vbObjectError + 1054, , "Documentul nu mai exista."
    If Not row Is Nothing Then
        old = row.Value2: rev = CLng(row.Cells(1, 13).Value2)
        If CStr(row.Cells(1, 6).Value2) <> link Then
            For Each lr In DOC_Table(2).ListRows
                If CStr(lr.Range.Cells(1, 2).Value2) = id And lr.Range.Cells(1, 7).Value2 = "Sursa" And lr.Range.Cells(1, 6).Value2 = "Valida" Then Err.Raise vbObjectError + 1055, , "Modificati linkul in registrul sursa, apoi Actualizeaza."
            Next lr
        End If
        values(13) = row.Cells(1, 14).Value2
    Else
        id = DOC_NewID("DA"): values(13) = CDbl(Now)
    End If
    coverage = DOC_Text(ws.Range("B16").Value2): If Len(coverage) = 0 Then coverage = CStr(values(1))
    If Len(mTarget) > 0 And Not DOC_TypeOK(coverage) Then Err.Raise vbObjectError + 1056, , "Alegeti tipul acoperit."
    values(11) = id: values(12) = rev + 1: values(14) = CDbl(Now): values(15) = Application.UserName: values(16) = key
    values(17) = "": values(18) = ""
    If state = "Verificat" Then values(17) = verifiedBy: values(18) = CDbl(Now)
    values(22) = IIf(DOC_LinkOK(link), 1, 0)
    For k = 1 To 5: backups(k) = DOC_Table(k).DataBodyRange.formula: Next k
    oldE = Application.EnableEvents: oldBusy = mBusy: Application.EnableEvents = False: mBusy = True: changed = True
    If row Is Nothing Then Set row = DOC_Add(1) Else DOC_Table(1).Parent.Unprotect
    DOC_Write row, values
    For i = 0 To 22
        If IsEmpty(old) Then
            If Len(DOC_Text(values(i))) > 0 Then DOC_Audit "Document", id, "Creare", DOC_Table(1).ListColumns(i + 1).name, "", DOC_Text(values(i))
        Else
            If DOC_Text(old(1, i + 1)) <> DOC_Text(values(i)) And i <> 9 And i <> 10 And i <> 20 And i <> 21 Then DOC_Audit "Document", id, "Revizie", DOC_Table(1).ListColumns(i + 1).name, DOC_Text(old(1, i + 1)), DOC_Text(values(i))
        End If
    Next i
    If Len(mTarget) > 0 Then DOC_Attach id, mTarget, coverage, "Manual", CStr(values(19))
Call DOC_Refresh:     changed = False: Application.EnableEvents = oldE: mBusy = oldBusy: DOC_Inchide
    Exit Sub
Fail:
    msg = Err.description
    If changed Then
        On Error Resume Next
        For k = 1 To 5: DOC_Restore k, backups(k): Next k
Call DOC_Refresh:         Call DOC_Protect: Application.EnableEvents = oldE: mBusy = oldBusy: On Error GoTo 0
    End If
    MsgBox msg, vbExclamation, "TQM - Documente"
End Sub
Private Sub DOC_View(ByVal kind As Long, ByVal mode As String, Optional ByVal docID As String = "")
    Dim ws As Worksheet, lr As ListRow, n As Long, count As Long
    Set ws = DOC_Start(mode, docID): count = DOC_Table(kind).ListColumns.count
    ws.Cells(5, 1).Resize(1, count).Value2 = DOC_Table(kind).HeaderRowRange.Value2: n = 6
    For Each lr In DOC_Table(kind).ListRows
        If Len(DOC_Text(lr.Range.Cells(1, 1).Value2)) > 0 Then
            ws.Cells(n, 1).Resize(1, count).Value2 = lr.Range.Value2: n = n + 1
        End If
    Next lr
    ws.Cells(5, 1).Resize(1, count).Interior.Color = RGB(31, 41, 55): ws.Cells(5, 1).Resize(1, count).Font.Color = vbWhite
    ws.Cells(5, 1).Resize(1, count).WrapText = True: ws.rows(5).RowHeight = 42
    ws.Cells(5, 1).Resize(Application.Max(2, n - 5), count).AutoFilter: ws.Columns("A:B").ColumnWidth = 28
    Select Case kind
    Case 2
        ws.Columns("A:B").Hidden = True: ws.Columns("D").Hidden = True: ws.Columns("H").Hidden = True
        ws.Columns("L:M").NumberFormat = "dd.mm.yyyy hh:mm"
        DOC_Button ws, "C3:E3", "Retrage asocierea", "DOC_Retrage": DOC_Button ws, "F3:H3", "Deschide documentul", "DOC_Deschide"
    Case 3
        ws.Columns("A").Hidden = True: ws.Columns("C").Hidden = True: ws.Columns("I").NumberFormat = "dd.mm.yyyy"
        ws.Columns("J").ColumnWidth = 45: ws.Columns("L:M").Hidden = True
        DOC_Button ws, "D3:F3", "Foloseste sursa selectata", "DOC_SursaAleasa": DOC_Button ws, "G3:I3", "Deschide operatiunea", "DOC_DeschideSursa"
    Case 4
        ws.Columns("O:U").Hidden = True: ws.Columns("L").ColumnWidth = 49: ws.Columns("M:N").ColumnWidth = 30
        DOC_Button ws, "C3:E3", "Document pentru dosar", "DOC_NouPentruDosar": DOC_Button ws, "F3:H3", "Preia Primit in Control", "DOC_ControlPrimit"
    Case 5
        ws.Columns("A").Hidden = True: ws.Columns("B").NumberFormat = "dd.mm.yyyy hh:mm": ws.Columns("H:I").ColumnWidth = 50
    End Select
    ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    ActiveWindow.FreezePanes = False: ActiveWindow.SplitRow = 5: ActiveWindow.SplitColumn = 2: ActiveWindow.FreezePanes = True
End Sub
Public Sub DOC_Surse()
    On Error GoTo Fail
Call DOC_Refresh:     DOC_View 3, "SURSE"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub DOC_Asociaza()
    Dim id As String
    On Error GoTo Fail
    id = DOC_Selected(): Call DOC_Refresh: DOC_View 3, "SURSE", id
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub DOC_Asocieri()
    On Error GoTo Fail
Call DOC_Refresh:     DOC_View 2, "ASOCIERI"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub DOC_Dosare()
    On Error GoTo Fail
Call DOC_Refresh:     DOC_View 4, "DOSARE"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub DOC_Jurnal()
    On Error GoTo Fail
Call DOC_Refresh:     DOC_View 5, "JURNAL"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Private Function DOC_LocalSelection(ByVal mode As String, ByVal column As Long) As String
    DOC_CheckForm mode
    If ActiveCell.row < 6 Then Err.Raise vbObjectError + 1057, , "Selectati un rand din lista."
    DOC_LocalSelection = DOC_Text(mForm.Worksheets(1).Cells(ActiveCell.row, column).Value2)
    If Len(DOC_LocalSelection) = 0 Then Err.Raise vbObjectError + 1058, , "Rand gol."
End Function
Private Sub DOC_LinkForm(ByVal id As String, ByVal target As String)
    Dim ws As Worksheet, row As Range, a As Variant
    Set row = DOC_Find(1, id, 12)
    If row Is Nothing Or Not mSources.exists(target) Then Err.Raise vbObjectError + 1059, , "Documentul / sursa nu mai exista."
    a = mSources(target): Set ws = DOC_Start("ASOCIERE", id, target)
    DOC_Button ws, "C3:D3", "Salveaza asocierea", "DOC_SalveazaAsociere"
    DOC_Field ws, 5, "Document", row.Cells(1, 5).Value2, False
    DOC_Field ws, 6, "Tip operatiune", a(1), False: DOC_Field ws, 7, "Referinta", a(3), False
    DOC_Field ws, 8, "Proiect", a(4), False: DOC_Field ws, 9, "Partener", a(5), False
    DOC_Field ws, 10, "Tip document acoperit", row.Cells(1, 2).Value2: DOC_TypeList ws.Range("B10")
    DOC_Field ws, 11, "Observatii", ""
    ws.Range("A13:J13").Merge: ws.Range("A13").Value2 = "Un fisier poate acoperi mai multe operatiuni. Pentru Pachet documente, alegeti categoria acoperita."
    ws.Protect UserInterfaceOnly:=True
End Sub
Public Sub DOC_SursaAleasa()
    Dim target As String, id As String, a As Variant, row As Range
    On Error GoTo Fail
    target = DOC_LocalSelection("SURSE", 1): id = mID: a = mSources(target)
    DOC_Inchide
    If Len(id) > 0 Then
        DOC_LinkForm id, target
    Else
        Set row = DOC_Find(1, DOC_LinkKey(CStr(a(9))), 17)
        If Not row Is Nothing Then id = CStr(row.Cells(1, 12).Value2)
        DOC_EditForm id, target
    End If
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub DOC_NouPentruDosar()
    Dim id As String, target As String
    On Error GoTo Fail
    id = DOC_LocalSelection("DOSARE", 15): target = "Dosar|" & id
Call DOC_Inchide:     DOC_EditForm "", target
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub DOC_SalveazaAsociere()
    Dim k As Long, backups(1 To 5) As Variant, coverage As String, note As String, changed As Boolean, oldE As Boolean, oldBusy As Boolean, msg As String
    On Error GoTo Fail
    DOC_CheckForm "ASOCIERE": coverage = DOC_Text(mForm.Worksheets(1).Range("B10").Value2): note = DOC_Text(mForm.Worksheets(1).Range("B11").Value2)
    If Not DOC_TypeOK(coverage) Then Err.Raise vbObjectError + 1060, , "Alegeti tipul acoperit."
    For k = 1 To 5: backups(k) = DOC_Table(k).DataBodyRange.formula: Next k
    oldE = Application.EnableEvents: oldBusy = mBusy: Application.EnableEvents = False: mBusy = True: changed = True
    DOC_Attach mID, mTarget, coverage, "Manual", note
Call DOC_Refresh:     changed = False: Application.EnableEvents = oldE: mBusy = oldBusy: DOC_Inchide
    Exit Sub
Fail:
    msg = Err.description
    If changed Then
        On Error Resume Next
        For k = 1 To 5: DOC_Restore k, backups(k): Next k
Call DOC_Refresh:         Call DOC_Protect: Application.EnableEvents = oldE: mBusy = oldBusy: On Error GoTo 0
    End If
    MsgBox msg, vbExclamation, "TQM"
End Sub
Public Sub DOC_Retrage()
    Dim id As String, row As Range, backups(1 To 5) As Variant, k As Long, changed As Boolean, oldE As Boolean, oldBusy As Boolean, msg As String
    On Error GoTo Fail
    id = DOC_LocalSelection("ASOCIERI", 1): Set row = DOC_Find(2, id)
    If row Is Nothing Then Err.Raise vbObjectError + 1061, , "Asocierea nu mai exista."
    If row.Cells(1, 6).Value2 <> "Valida" Then Err.Raise vbObjectError + 1062, , "Asocierea este deja retrasa."
    If row.Cells(1, 7).Value2 = "Sursa" Then Err.Raise vbObjectError + 1063, , "Modificati linkul in registrul sursa pentru retragerea asocierii automate."
    For k = 1 To 5: backups(k) = DOC_Table(k).DataBodyRange.formula: Next k
    oldE = Application.EnableEvents: oldBusy = mBusy: Application.EnableEvents = False: mBusy = True: changed = True
    DOC_Table(2).Parent.Unprotect: row.Cells(1, 6).Value2 = "Retrasa": row.Cells(1, 13).Value2 = CDbl(Now)
    DOC_Audit "Asociere", id, "Retragere", "Stare", "Valida", "Retrasa"
Call DOC_Refresh:     changed = False: Application.EnableEvents = oldE: mBusy = oldBusy: DOC_Inchide
    Exit Sub
Fail:
    msg = Err.description
    If changed Then
        On Error Resume Next
        For k = 1 To 5: DOC_Restore k, backups(k): Next k
Call DOC_Refresh:         Call DOC_Protect: Application.EnableEvents = oldE: mBusy = oldBusy: On Error GoTo 0
    End If
    MsgBox msg, vbExclamation, "TQM"
End Sub
Private Sub DOC_OpenLink(ByVal link As String)
    If Not DOC_LinkOK(link) Then Err.Raise vbObjectError + 1064, , "Link lipsa sau invalid."
    ThisWorkbook.FollowHyperlink address:=link, NewWindow:=True
End Sub
Public Sub DOC_Deschide()
    Dim id As String, row As Range
    On Error GoTo Fail
    If ActiveWorkbook Is ThisWorkbook Then id = DOC_Selected() Else id = DOC_LocalSelection("ASOCIERI", 2)
    Set row = DOC_Find(1, id, 12)
    If row Is Nothing Then Err.Raise vbObjectError + 1065, , "Document inexistent."
    DOC_OpenLink CStr(row.Cells(1, 6).Value2)
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM - Deschidere document"
End Sub
Public Sub DOC_DeschideFormular()
    On Error GoTo Fail
    DOC_CheckForm "DOCUMENT": DOC_OpenLink CStr(mForm.Worksheets(1).Range("B10").Value2)
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Private Function DOC_ControlRow(ByVal id As String) As Range
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets("Control_Achizitii")
    For r = 13 To TQM_Control_Cell(ws, ws.rows.count, "G").End(xlUp).row
        If CStr(TQM_Control_Cell(ws, r, "R").Value2) = id Then
            If Not DOC_ControlRow Is Nothing Then Err.Raise vbObjectError + 1066, , "ID dosar duplicat."
            Set DOC_ControlRow = TQM_Control_Cell(ws, r, 1).Resize(1, 26)
        End If
    Next r
End Function
Public Sub DOC_ControlPrimit()
    Dim id As String, row As Range, dossier As Range, cols As Variant, types As Variant, oldValues(0 To 3) As Variant
    Dim i As Long, k As Long, count As Long, oldE As Boolean, oldBusy As Boolean, wasProtected As Boolean, changed As Boolean, msg As String, backups(1 To 5) As Variant
    On Error GoTo Fail
    id = DOC_LocalSelection("DOSARE", 15)
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 1075, , "Registrul este doar pentru citire."
    If DOC_Stamp() <> mStamp Then Err.Raise vbObjectError + 1076, , "Sursele sau documentele s-au modificat. Redeschideti lista dosarelor inainte de preluare."
    DOC_Formulas
    Set row = DOC_ControlRow(id): Set dossier = DOC_Find(4, id, 15)
    If row Is Nothing Or dossier Is Nothing Then Err.Raise vbObjectError + 1067, , "Dosarul nu mai exista."
    If dossier.Cells(1, 7).Value2 <> "Confirmata" Then Err.Raise vbObjectError + 1068, , "Confirmati profilul din Setari Liste mai intai."
    cols = Array(TQM_Control_Col(17), TQM_Control_Col(11), TQM_Control_Col(12), TQM_Control_Col(13)): types = Array("Aviz", "Declaratie conformitate", "Declaratie producator", "Fise tehnice")
    For i = 0 To 3: oldValues(i) = row.Cells(1, CLng(cols(i))).Value2: Next i
    For k = 1 To 5: backups(k) = DOC_Table(k).DataBodyRange.formula: Next k
    oldE = Application.EnableEvents: oldBusy = mBusy: wasProtected = row.Parent.ProtectContents
    Application.EnableEvents = False: mBusy = True: changed = True: row.Parent.Unprotect
    For i = 0 To 3
        count = Application.WorksheetFunction.CountIfs(DOC_Table(2).ListColumns("Tip_entitate").DataBodyRange, "Dosar", DOC_Table(2).ListColumns("ID_entitate").DataBodyRange, id, DOC_Table(2).ListColumns("Tip_acoperit").DataBodyRange, CStr(types(i)), DOC_Table(2).ListColumns("Acopera").DataBodyRange, 1)
        If count > 0 And CStr(row.Cells(1, CLng(cols(i))).Value2) <> "Primit" Then
            row.Cells(1, CLng(cols(i))).Value2 = "Primit"
            DOC_Audit "Dosar", id, "Preluare din arhiva", CStr(types(i)), CStr(oldValues(i)), "Primit"
        End If
    Next i
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_ActualizeazaControl"
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!ActualizeazaDashboard"
Call DOC_Refresh:     changed = False
    If wasProtected Then row.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Application.EnableEvents = oldE: mBusy = oldBusy: DOC_Inchide
    row.Parent.Activate: row.Cells(1, 1).Select
    Exit Sub
Fail:
    msg = Err.description
    If changed Then
        On Error Resume Next
        row.Parent.Unprotect
        For i = 0 To 3: row.Cells(1, CLng(cols(i))).Value2 = oldValues(i): Next i
        For k = 1 To 5: DOC_Restore k, backups(k): Next k
        Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_ActualizeazaControl"
        Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!ActualizeazaDashboard"
        DOC_Refresh
        If wasProtected Then row.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
        Application.EnableEvents = oldE: mBusy = oldBusy: On Error GoTo 0
    End If
    MsgBox msg, vbExclamation, "TQM"
End Sub
Public Sub DOC_DinSelectie()
    Dim ws As Worksheet, lo As ListObject, hit As Range, key As String, target As String, a As Variant, existing As Range, id As String
    On Error GoTo Fail
    If Not ActiveWorkbook Is ThisWorkbook Then Err.Raise vbObjectError + 1069, , "Selectati operatiunea in registrul TQM."
    Set ws = ActiveSheet
    If ws.name = "Control_Achizitii" Then
        If ActiveCell.row < 13 Then Err.Raise vbObjectError + 1070, , "Selectati un rand din Control Achizitii."
        target = "Dosar|" & CStr(ws.Cells(ActiveCell.row, "R").Value2)
    Else
        For Each lo In ws.ListObjects
            Set hit = Intersect(ActiveCell, lo.DataBodyRange)
            If Not hit Is Nothing Then
                key = ""
                Select Case lo.name
                Case "tTQMComenzi": key = "Comanda|" & CStr(ws.Cells(ActiveCell.row, 1).Value2)
                Case "tTQMFacturi": key = "Factura|" & CStr(ws.Cells(ActiveCell.row, 16).Value2)
                Case "tTQMCereri": key = "Cerere|" & CStr(ws.Cells(ActiveCell.row, 1).Value2)
                Case "tTQMNMMateriale": key = "Material|" & CStr(ws.Cells(ActiveCell.row, 11).Value2)
                End Select
                target = key
            End If
        Next lo
    End If
    DOC_Refresh
    If Not mSources.exists(target) Then Err.Raise vbObjectError + 1071, , "Selectati o factura, comanda, cerere, material sau dosar. Pentru alte operatiuni folositi Surse."
    a = mSources(target): Set existing = DOC_Find(1, DOC_LinkKey(CStr(a(9))), 17)
    If Not existing Is Nothing Then id = CStr(existing.Cells(1, 12).Value2)
    DOC_EditForm id, target
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub DOC_DeschideSursa()
    Dim key As String, a As Variant, row As Range, lo As ListObject, lr As ListRow, ws As Worksheet, idColumn As Long, c As Long, n As Long
    On Error GoTo Fail
    key = DOC_LocalSelection("SURSE", 1): a = mSources(key)
    If a(1) = "Dosar" Then
        Set row = DOC_ControlRow(CStr(a(2)))
    Else
        Set lo = DOC_Source(CStr(a(12))): idColumn = 1
        If a(1) = "Factura" Then idColumn = 16
        If a(1) = "Material" Then idColumn = 11
        For Each lr In lo.ListRows
            If CStr(lr.Range.Cells(1, idColumn).Value2) = CStr(a(2)) Then Set row = lr.Range
        Next lr
    End If
    If row Is Nothing Then Err.Raise vbObjectError + 1072, , "Operatiunea nu mai exista."
    DOC_Inchide
    If row.Parent.Visible = xlSheetVisible Then
        ThisWorkbook.Activate: row.Parent.Activate: row.Cells(1, 1).Select
    Else
        Set ws = DOC_Start("OPERATIUNE", "")
        n = 5
        For c = 1 To row.Columns.count
            DOC_Field ws, n, lo.ListColumns(c).name, row.Cells(1, c).Value2, False: n = n + 1
        Next c
        ws.Protect UserInterfaceOnly:=True
    End If
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub

Public Sub DOC_Reguli()
    On Error GoTo Fail
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_ReguliDocumente"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub




Private Function DOC_DataArea(ByVal lo As ListObject) As Range
    Dim body As Range, addedRow As ListRow
    If lo Is Nothing Then Err.Raise vbObjectError + 974, "DOC_DataArea", "Tabel neinitializat."
    Set body = lo.DataBodyRange
    If body Is Nothing Then
        Set addedRow = lo.ListRows.Add(AlwaysInsert:=False)
        Set body = lo.DataBodyRange
    End If
    If body Is Nothing Then Err.Raise vbObjectError + 975, "DOC_DataArea", "Zona de date nu poate fi creata pentru " & lo.name
    Set DOC_DataArea = body
End Function

Private Sub DOC_CalcSetR1C1(ByVal lo As ListObject, ByVal columnName As String, ByVal template As String)
    Dim target As Range, lc As ListColumn, sourceTable As ListObject
    Dim formulaText As String, token As String, targetAddress As String
    Dim sourceName As Variant, body As Range, errNumber As Long, errMessage As String

    On Error GoTo Fail
    Set body = DOC_DataArea(lo)
    Set target = lo.ListColumns(columnName).DataBodyRange
    If target Is Nothing Then Err.Raise vbObjectError + 978, "DOC_CalcSetR1C1", "Coloana nu are zona de date: " & columnName
    targetAddress = target.address(False, False)
    formulaText = template

    ' RC plus coloana absoluta pastreaza referinta la randul curent.
    For Each lc In lo.ListColumns
        token = "[@" & lc.name & "]"
        formulaText = Replace(formulaText, token, "RC" & CStr(lc.Range.column), 1, -1, vbBinaryCompare)
    Next lc

    ' Intervalele sursa sunt refacute la fiecare DOC_Calc, dupa adaugari de randuri.
    For Each sourceName In Split("tTQMDocumente|tTQMDOCLinkuri|tTQMReguliDoc", "|")
        If InStr(1, formulaText, CStr(sourceName) & "[", vbBinaryCompare) > 0 Then
            Set sourceTable = DOC_Source(CStr(sourceName))
            For Each lc In sourceTable.ListColumns
                token = sourceTable.name & "[" & lc.name & "]"
                If InStr(1, formulaText, token, vbBinaryCompare) > 0 Then
                    formulaText = Replace(formulaText, token, DOC_CalcSourceRefR1C1(lc), 1, -1, vbBinaryCompare)
                End If
            Next lc
        End If
    Next sourceName

    If InStr(1, formulaText, "[@", vbBinaryCompare) > 0 Then
        Err.Raise vbObjectError + 979, "DOC_CalcSetR1C1", "Referinta la o coloana inexistenta in formula."
    End If
    If InStr(1, formulaText, "[", vbBinaryCompare) > 0 Then
        Err.Raise vbObjectError + 1103, "DOC_CalcSetR1C1", "Referinta de tabel neconvertita in formula."
    End If
    target.NumberFormat = "General"
    target.FormulaR1C1 = formulaText
    Exit Sub

Fail:
    errNumber = Err.number
    errMessage = Err.description
    Debug.Print "DOC_Calc: " & lo.name & "." & columnName
    Debug.Print formulaText
    Err.Raise errNumber, "DOC_Calc." & lo.name & "." & columnName, _
              errMessage & vbCrLf & "Foaie: " & lo.Parent.name & "; interval: " & targetAddress
End Sub

Private Function DOC_CalcSourceRefR1C1(ByVal lc As ListColumn) As String
    Dim sourceRange As Range
    Set sourceRange = lc.DataBodyRange
    If sourceRange Is Nothing Then
        Set sourceRange = lc.Parent.HeaderRowRange.Cells(1, lc.Index).Offset(1, 0)
    End If
    DOC_CalcSourceRefR1C1 = "'" & Replace(sourceRange.Parent.name, "'", "''") & "'!" & _
                          sourceRange.address(RowAbsolute:=True, ColumnAbsolute:=True, ReferenceStyle:=xlR1C1, External:=False)
End Function

Private Sub DOC_PrepareHeader(ByVal ws As Worksheet)
    Dim sourceCell As Range, mergedArea As Range, copyRange As Range
    Dim backup As Worksheet, candidate As Worksheet, previousSheet As Object
    Dim lastColumn As Long, dirty As Boolean, found As Boolean, suffix As Long
    Dim baseName As String, backupName As String, errorNumber As Long, errorMessage As String
    On Error GoTo Fail
    Set previousSheet = ActiveSheet
    If ws.name <> DOC_SHEET Then Err.Raise vbObjectError + 1104, "DOC_PrepareHeader", "Foaie de interfata nepermisa."
    lastColumn = 23
    For Each sourceCell In ws.Cells(2, 1).Resize(10, lastColumn).Cells
        If sourceCell.MergeCells Then
            Set mergedArea = sourceCell.MergeArea
            If mergedArea.row < 2 Or mergedArea.row + mergedArea.rows.count - 1 > 11 Then
                Err.Raise vbObjectError + 1105, "DOC_PrepareHeader", "Imbinarea " & mergedArea.address(False, False) & " depaseste zona de interfata."
            End If
            If mergedArea.column + mergedArea.Columns.count - 1 > lastColumn Then lastColumn = mergedArea.column + mergedArea.Columns.count - 1
        End If
    Next sourceCell
    Set copyRange = ws.Cells(2, 1).Resize(10, lastColumn)
    For Each sourceCell In copyRange.Cells
        Select Case sourceCell.address(False, False)
        Case "A2", "A3", "A4", "A8", "C8", "F8", "H8", "A9", "C9", "F9", "H9", "A11"
            ' Celule de titlu, status si indicatori rescrise de modul.
        Case Else
            If IsError(sourceCell.Value2) Then
                dirty = True
            ElseIf Len(CStr(sourceCell.formula)) > 0 Then
                dirty = True
            End If
        End Select
    Next sourceCell
    If Not dirty Then Exit Sub

    ' Pastram o copie a intregii zone inainte de curatarea etichetelor vechi.
    baseName = "DOC_UI_" & Format$(Now, "yyyymmdd_hhnnss")
    backupName = baseName
    Do
        found = False
        For Each candidate In ThisWorkbook.Worksheets
            If StrComp(candidate.name, backupName, vbTextCompare) = 0 Then found = True: Exit For
        Next candidate
        If Not found Then Exit Do
        suffix = suffix + 1
        backupName = baseName & "_" & CStr(suffix)
    Loop
    Set backup = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
    backup.name = backupName
    copyRange.Copy Destination:=backup.Range("A2")
    backup.Range("A1").Value2 = "Copie antet " & ws.name & " | " & Format$(Now, "dd.mm.yyyy hh:mm:ss")
    ws.Unprotect
    copyRange.UnMerge
    copyRange.ClearContents
    copyRange.Interior.Color = RGB(255, 255, 255)
    copyRange.Font.Color = RGB(31, 41, 55)
    copyRange.HorizontalAlignment = xlLeft
    copyRange.WrapText = False
    If Not previousSheet Is Nothing Then previousSheet.Activate
    Exit Sub
Fail:
    errorNumber = Err.number: errorMessage = Err.description
    On Error Resume Next
    If Not previousSheet Is Nothing Then previousSheet.Activate
    On Error GoTo 0
    Err.Raise errorNumber, "DOC_PrepareHeader", errorMessage
End Sub

Private Sub DOC_MergeUI(ByVal ws As Worksheet, ByVal areaAddress As String)
    Dim target As Range, sourceCell As Range, mergedArea As Range
    Set target = ws.Range(areaAddress)
    If ws.name <> DOC_SHEET Or target.rows.count <> 1 Or target.row < 2 Or target.row > 11 Then
        Err.Raise vbObjectError + 1106, "DOC_MergeUI", "Zona de interfata nepermisa."
    End If
    If target.Cells(1, 1).MergeCells Then
        If target.Cells(1, 1).MergeArea.address = target.address Then Exit Sub
    End If
    For Each sourceCell In target.Cells
        If sourceCell.MergeCells Then
            Set mergedArea = sourceCell.MergeArea
            If mergedArea.row < 2 Or mergedArea.row + mergedArea.rows.count - 1 > 11 Then
                Err.Raise vbObjectError + 1107, "DOC_MergeUI", "Imbinare in afara interfetei: " & mergedArea.address(False, False)
            End If
        End If
    Next sourceCell
    For Each sourceCell In target.Cells
        If sourceCell.MergeCells Then sourceCell.MergeArea.UnMerge
    Next sourceCell
    For Each sourceCell In target.Cells
        If sourceCell.address <> target.Cells(1, 1).address Then
            If IsError(sourceCell.Value2) Then Err.Raise vbObjectError + 1108, "DOC_MergeUI", "Valoare de eroare in " & sourceCell.address(False, False)
            If Len(CStr(sourceCell.formula)) > 0 Then Err.Raise vbObjectError + 1109, "DOC_MergeUI", "Continut neasteptat in " & sourceCell.address(False, False)
        End If
    Next sourceCell
    target.Merge
End Sub




Public Sub DOC_RFQRefresh()
    Dim eno As Long, msg As String
    If mBusy Then Err.Raise vbObjectError + 2299, "RFQ", "Documentele sunt deja in curs de actualizare."
    On Error GoTo Failed
    mBusy = True: DOC_Refresh: mBusy = False
    Exit Sub
Failed:
    eno = Err.Number: msg = Err.description: mBusy = False
    Err.Raise eno, "DOC_RFQRefresh", msg
End Sub
