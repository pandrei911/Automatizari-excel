Attribute VB_Name = "Module7"
Option Explicit
' TQM Calarasi - Facturi si plati v1. Excel desktop Windows, RON.
' Formulare locale; factura, repartizari si miscari cu ID-uri stabile.
Private Const FP_Sheet As String = "05_FACTURI_SI_PLATI"
Private Const FP_MARK As String = "TQM_FP_V1"
Private mForm As Workbook
Private mMode As String, mInvoice As String, mOther As String, mStamp As String
Private mSourceKind As String, mSource As String
Private Type FP_GUID
    Data1 As Long
    Data2 As Integer
    Data3 As Integer
    Data4(0 To 7) As Byte
End Type
#If VBA7 Then
Private Declare PtrSafe Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As FP_GUID) As Long
#Else
Private Declare Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As FP_GUID) As Long
#End If

Private Function FP_Heads(ByVal kind As Long) As Variant
    Select Case kind
    Case 1: FP_Heads = Split("Nr_factura|Data_factura|Partener|CIF_partener|Tip_factura|Scadenta|Net_RON|TVA_RON|Total_RON|Achitat_RON|Sold_RON|Status_plata|Proiecte|Link_factura|Observatii|ID_factura|ID_factura_originala|Responsabil|Stare|Creat_la|Actualizat_la|Anulat_la|Anulat_de|Motiv_anulare", "|")
    Case 2: FP_Heads = Split("ID_repartizare|ID_factura|Proiect|Net_RON|TVA_RON|Total_RON|Achitat_RON|Sold_RON|ID_comanda|ID_pozitie|ID_receptie|Descriere|Stare|Creat_la|Ordine|ID_repartizare_originala", "|")
    Case 3: FP_Heads = Split("ID_miscare|ID_operatie|ID_factura|ID_repartizare|Proiect|Data|Suma_RON|Tip|Metoda|Document|Responsabil|Observatii|Link|Stare|Creat_la|Anulat_la|Anulat_de|Motiv_anulare|ID_factura_pereche", "|")
    End Select
End Function

Private Function FP_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set FP_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function FP_Table(ByVal kind As Long) As ListObject
    Select Case kind
    Case 1: Set FP_Table = ThisWorkbook.Worksheets(FP_Sheet).ListObjects("tTQMFacturi")
    Case 2: Set FP_Table = ThisWorkbook.Worksheets("_TQM_FP_REP").ListObjects("tTQMFPRepartizari")
    Case 3: Set FP_Table = ThisWorkbook.Worksheets("_TQM_FP_PLATI").ListObjects("tTQMFPPlati")
    End Select
End Function

Private Function FP_SourceTable(ByVal tableName As String, Optional ByVal required As Boolean = True) As ListObject
    Dim ws As Worksheet, lo As ListObject
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            If lo.name = tableName Then Set FP_SourceTable = lo: Exit Function
        Next lo
    Next ws
    If required Then Err.Raise vbObjectError + 501, , "Lipseste tabelul " & tableName & ". Instalati Comenzi furnizori."
End Function

Private Sub FP_Init()
    Dim names As Variant, tables As Variant, hs As Variant, ws As Worksheet, lo As ListObject
    Dim i As Long, k As Long, first As Long
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 502, , "Registrul principal este deschis doar pentru citire."
    names = Array(FP_Sheet, "_TQM_FP_REP", "_TQM_FP_PLATI")
    tables = Array("tTQMFacturi", "tTQMFPRepartizari", "tTQMFPPlati")
    For i = 0 To 2
        Set ws = FP_GetSheet(CStr(names(i)))
        If ws Is Nothing Then
            Set ws = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
            ws.name = names(i)
            If i = 0 Then ws.Range("Z1").Value2 = FP_MARK
        ElseIf i = 0 Then
            If CStr(ws.Range("Z1").Value2) <> FP_MARK Then Err.Raise vbObjectError + 503, , "Foaia Facturi si plati are alta structura. Datele nu au fost modificate."
        End If
        Set lo = Nothing
        On Error Resume Next
        Set lo = ws.ListObjects(CStr(tables(i)))
        On Error GoTo 0
        hs = FP_Heads(i + 1): first = 1: If i = 0 Then first = 12
        If lo Is Nothing Then
            If Application.CountA(ws.Cells(first, 1).Resize(2, UBound(hs) + 1)) > 0 Then Err.Raise vbObjectError + 504, , "Date necunoscute in " & ws.name
            For k = 0 To UBound(hs): ws.Cells(first, k + 1).Value2 = hs(k): Next k
            Set lo = ws.ListObjects.Add(xlSrcRange, ws.Cells(first, 1).Resize(2, UBound(hs) + 1), , xlYes)
            lo.name = tables(i): lo.TableStyle = "TableStyleMedium2"
        End If
        If lo.ListColumns.count <> UBound(hs) + 1 Then Err.Raise vbObjectError + 505, , "Structura invalida in " & lo.name
        For k = 0 To UBound(hs)
            If lo.ListColumns(k + 1).name <> hs(k) Then Err.Raise vbObjectError + 506, , "Coloana modificata in " & lo.name & ": " & hs(k)
        Next k
        If i = 0 Then ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True Else ws.Visible = xlSheetVeryHidden
    Next i
End Sub

Public Sub FP_Instaleaza()
    Dim oldE As Boolean, oldS As Boolean
    Dim ws As Worksheet
    Dim etapa As String
    Dim errNumber As Long, errMessage As String, errSource As String
    Dim protectAtExit As Boolean

    oldE = Application.EnableEvents
    oldS = Application.ScreenUpdating
    On Error GoTo Fail

    Application.EnableEvents = False
    Application.ScreenUpdating = False

    etapa = "Initializare registre - FP_Init"
    FP_Init
    Set ws = ThisWorkbook.Worksheets(FP_Sheet)
    protectAtExit = True

    etapa = "Deprotejare foaie Facturi si plati"
    ws.Unprotect Password:=""

    etapa = "Refacere interfata - FP_Layout"
    FP_Layout ws

    etapa = "Actualizare facturi, repartizari si plati - FP_Calc"
    FP_Calc

    etapa = "Configurare afisare si panouri fixe"
    ws.Select Replace:=True
    With ActiveWindow
        .DisplayGridlines = False
        .Zoom = 85
        .FreezePanes = False
        .SplitRow = 12
        .SplitColumn = 3
        .FreezePanes = True
    End With

    etapa = "Reprotejare foaie Facturi si plati"
    ws.Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=True
    protectAtExit = False

    Application.EnableEvents = oldE
    Application.ScreenUpdating = oldS

    MsgBox "Facturi si plati este instalat. Datele existente au fost pastrate." & vbCrLf & _
           "Formularele sunt locale. Salvati registrul principal cu Ctrl+S.", _
           vbInformation, "TQM"
    Exit Sub

Fail:
    errNumber = Err.number
    errMessage = Err.description
    errSource = Err.source

    On Error Resume Next
    If protectAtExit Then
        If Not ws Is Nothing Then
            ws.Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=True
        End If
    End If
    Application.EnableEvents = oldE
    Application.ScreenUpdating = oldS
    On Error GoTo 0

    FP_Error "Instalarea Facturi si plati s-a oprit." & vbCrLf & _
             "Etapa: " & etapa & vbCrLf & _
             "Eroare: " & CStr(errNumber) & vbCrLf & _
             "Sursa: " & errSource & vbCrLf & _
             "Mesaj: " & errMessage
End Sub
Private Sub FP_Band(ByVal ws As Worksheet, ByVal address As String, ByVal title As String, Optional ByVal size As Long = 10)
    With ws.Range(address)
        .Merge: .Cells(1, 1).NumberFormat = "@": .Cells(1, 1).Value2 = title
        .Font.size = size: .Font.Color = RGB(31, 41, 55): .Font.Bold = (size > 10): .VerticalAlignment = xlCenter
    End With
End Sub

Private Sub FP_Button(ByVal ws As Worksheet, ByVal address As String, ByVal title As String, ByVal macro As String)
    Dim r As Range, sh As Shape
    Set r = ws.Range(address)
    Set sh = ws.Shapes.AddShape(msoShapeRoundedRectangle, r.Left + 2, r.Top + 2, r.width - 4, r.Height - 4)
    sh.name = "FPBTN_" & macro: sh.Fill.ForeColor.RGB = RGB(37, 99, 235): sh.line.Visible = msoFalse
    sh.TextFrame2.TextRange.text = title: sh.TextFrame2.TextRange.Font.name = "Aptos": sh.TextFrame2.TextRange.Font.size = 10
    sh.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = vbWhite: sh.TextFrame2.VerticalAnchor = msoAnchorMiddle
    sh.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    sh.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & macro: sh.Placement = xlFreeFloating
End Sub

Private Sub FP_Card(ByVal ws As Worksheet, ByVal lab As String, ByVal val As String, ByVal title As String, ByVal formula As String, ByVal colour As Long)
    FP_Band ws, lab, title: FP_Band ws, val, "", 18
    ws.Range(lab).Interior.Color = colour: ws.Range(val).Interior.Color = colour
    ws.Range(val).Cells(1, 1).NumberFormat = "#,##0.00": ws.Range(val).Cells(1, 1).formula = formula
End Sub

Private Sub FP_Layout(ByVal ws As Worksheet)
    Dim specs As Variant, v As Variant, widths As Variant, i As Long
    ws.Range("A1:X11").UnMerge: ws.Range("A1:X11").Clear
    ws.Range("A1:X11").Font.name = "Aptos": ws.rows("1:11").RowHeight = 24
    ws.rows(2).RowHeight = 34: ws.rows(9).RowHeight = 34
    FP_Band ws, "A2:L2", "TQM Calarasi - Facturi si plati", 18
    FP_Band ws, "A3:L3", "Facturi repartizate pe proiecte, scadente si plati partiale. Toate sumele sunt in RON."
    specs = Array(Array("A5:B5", "Factura noua", "FP_FacturaNoua"), Array("C5:D5", "Din comanda", "FP_DinComanda"), _
        Array("E5:F5", "Din receptie", "FP_DinReceptie"), Array("G5:H5", "Din Control Achizitii", "FP_DinControl"), _
        Array("I5:J5", "Plata / restituire", "FP_Plata"), Array("K5:L5", "Compenseaza storno", "FP_Compenseaza"), _
        Array("A6:B6", "Factura storno", "FP_Storno"), Array("C6:D6", "Detalii si istoric", "FP_Detalii"), _
        Array("E6:F6", "Anuleaza plata", "FP_AnuleazaPlata"), Array("G6:H6", "Anuleaza factura", "FP_AnuleazaFactura"), _
        Array("I6:J6", "Actualizeaza", "FP_Actualizeaza"), Array("K6:L6", "Registru plati", "FP_RegistruPlati"))
    For i = ws.Shapes.count To 1 Step -1
        If Left$(ws.Shapes(i).name, 6) = "FPBTN_" Then ws.Shapes(i).Delete
    Next i
    For Each v In specs: FP_Button ws, CStr(v(0)), CStr(v(1)), CStr(v(2)): Next v
    FP_Card ws, "A8:C8", "A9:C9", "Facturat net (RON fara TVA)", "=SUMIFS(tTQMFacturi[Net_RON],tTQMFacturi[Stare],""Valida"")", RGB(239, 246, 255)
    FP_Card ws, "D8:F8", "D9:F9", "Sold de plata (RON cu TVA)", "=SUMIFS(tTQMFacturi[Sold_RON],tTQMFacturi[Stare],""Valida"",tTQMFacturi[Sold_RON],"">0"")", RGB(255, 247, 237)
    FP_Card ws, "G8:I8", "G9:I9", "Restante (RON cu TVA)", "=SUMIFS(tTQMFacturi[Sold_RON],tTQMFacturi[Stare],""Valida"",tTQMFacturi[Status_plata],""RESTANTA"")", RGB(254, 242, 242)
    FP_Card ws, "J8:L8", "J9:L9", "Credite la furnizori (RON cu TVA)", "=-SUMIFS(tTQMFacturi[Sold_RON],tTQMFacturi[Stare],""Valida"",tTQMFacturi[Sold_RON],""<0"")", RGB(240, 253, 244)
    FP_Band ws, "A11:L11", "Selectati factura pentru plata, storno sau istoric. Compensarea regularizeaza solduri fara o plata bancara."
    widths = Array(20, 14, 28, 18, 14, 14, 17, 17, 18, 18, 18, 23, 30, 32, 35, 40, 40, 22, 14, 22, 22, 22, 22, 35)
    For i = 0 To UBound(widths): ws.Columns(i + 1).ColumnWidth = widths(i): Next i
    ws.Columns("P:X").Hidden = True: ws.Columns("Z").Hidden = True
    ws.Columns("B").NumberFormat = "dd.mm.yyyy": ws.Columns("F").NumberFormat = "dd.mm.yyyy": ws.Columns("G:K").NumberFormat = "#,##0.00"
    With ws.Range("A12:X12")
        .Font.name = "Aptos": .Font.size = 10: .Font.Bold = True: .Font.Color = vbWhite
        .Interior.Color = RGB(31, 41, 55): .RowHeight = 40: .WrapText = True
        .HorizontalAlignment = xlCenter: .VerticalAlignment = xlCenter
    End With
    ws.Tab.Color = RGB(37, 99, 235)
    With ws.Range("L13:L5012")
        .FormatConditions.Delete
        .FormatConditions.Add Type:=xlExpression, Formula1:="=$L13=""RESTANTA""": .FormatConditions(1).Interior.Color = RGB(254, 242, 242)
        .FormatConditions.Add Type:=xlExpression, Formula1:="=$L13=""SCADENTA AZI""": .FormatConditions(2).Interior.Color = RGB(255, 247, 237)
        .FormatConditions.Add Type:=xlExpression, Formula1:="=$L13=""ACHITATA""": .FormatConditions(3).Interior.Color = RGB(240, 253, 244)
        .FormatConditions.Add Type:=xlExpression, Formula1:="=$L13=""NECONCORDANTA""": .FormatConditions(4).Interior.Color = RGB(254, 202, 202)
    End With
End Sub

Private Function FP_ID(ByVal prefix As String) As String
    Dim g As FP_GUID, t As String, i As Long
    If CoCreateGuid(g) <> 0 Then Err.Raise vbObjectError + 507, , "Nu s-a putut genera un ID unic."
    t = Right$("00000000" & Hex$(g.Data1), 8) & Right$("0000" & Hex$(g.Data2), 4) & Right$("0000" & Hex$(g.Data3), 4)
    For i = 0 To 7: t = t & Right$("00" & Hex$(g.Data4(i)), 2): Next i
    FP_ID = prefix & "-" & t
End Function

Private Function FP_Text(ByVal value As Variant) As String
    If IsError(value) Then Err.Raise vbObjectError + 508, , "Un camp contine o eroare Excel."
    FP_Text = Trim$(CStr(value))
End Function

Private Function FP_Norm(ByVal value As String) As String
    value = LCase$(Trim$(Replace(value, ChrW(160), " ")))
    value = Replace(value, ChrW(259), "a"): value = Replace(value, ChrW(226), "a"): value = Replace(value, ChrW(238), "i")
    value = Replace(value, ChrW(537), "s"): value = Replace(value, ChrW(351), "s")
    value = Replace(value, ChrW(539), "t"): value = Replace(value, ChrW(355), "t")
    Do While InStr(value, "  ") > 0: value = Replace(value, "  ", " "): Loop
    FP_Norm = value
End Function

Private Function FP_CIF(ByVal value As String) As String
    value = UCase$(Replace(Replace(Trim$(value), " ", ""), ".", ""))
    If Left$(value, 2) = "RO" Then value = mID$(value, 3)
    FP_CIF = value
End Function

Private Function FP_Money(ByVal value As Variant, ByVal label As String, Optional ByVal signed As Boolean = False) As Currency
    If IsError(value) Or IsEmpty(value) Then Err.Raise vbObjectError + 509, , label & ": suma este obligatorie."
    If Not IsNumeric(value) Then Err.Raise vbObjectError + 510, , label & ": introduceti o suma numerica."
    If Abs(CDbl(value)) > 1000000000# Then Err.Raise vbObjectError + 511, , label & ": limita acestei versiuni este 1 miliard RON pe suma."
    If Abs(CDbl(value) - Round(CDbl(value), 2)) > 0.000001 Then Err.Raise vbObjectError + 512, , label & ": maximum doua zecimale."
    FP_Money = CCur(value)
    If Not signed And FP_Money < 0 Then Err.Raise vbObjectError + 513, , label & ": folositi valori pozitive. Pentru credit folositi Factura storno."
End Function

Private Function FP_Date(ByVal value As Variant, Optional ByVal future As Boolean = False) As Double
    Dim d As Date
    If IsError(value) Or IsEmpty(value) Then Err.Raise vbObjectError + 514, , "Introduceti data."
    If IsNumeric(value) Then
        If CDbl(value) < 36526 Or CDbl(value) > 2958465 Then Err.Raise vbObjectError + 515, , "Data este invalida."
        d = CDate(value)
    ElseIf IsDate(value) Then
        d = CDate(value)
    Else
        Err.Raise vbObjectError + 516, , "Folositi o data Excel."
    End If
    d = CDate(Int(CDbl(d)))
    If Year(d) < 2000 Or (Not future And d > Date) Then Err.Raise vbObjectError + 517, , "Data nu poate fi anterioara anului 2000 sau viitoare, cu exceptia scadentei."
    FP_Date = CDbl(d)
End Function

Private Function FP_LinkOK(ByVal value As String) As Boolean
    FP_LinkOK = (Len(value) = 0 Or LCase$(Left$(value, 8)) = "https://" Or LCase$(Left$(value, 7)) = "http://" Or _
        Left$(value, 2) = "\\" Or (Len(value) > 2 And mID$(value, 2, 2) = ":\"))
End Function

Private Function FP_Find(ByVal lo As ListObject, ByVal id As String, Optional ByVal column As Long = 1) As Range
    Dim lr As ListRow, found As Range
    For Each lr In lo.ListRows
        If Len(id) > 0 And StrComp(CStr(lr.Range.Cells(1, column).Value2), id, vbTextCompare) = 0 Then
            If Not found Is Nothing Then Err.Raise vbObjectError + 518, , "ID duplicat in " & lo.name
            Set found = lr.Range
        End If
    Next lr
    Set FP_Find = found
End Function

Private Function FP_Add(ByVal lo As ListObject, Optional ByVal idColumn As Long = 1) As Range
    Dim lr As ListRow, wasProtected As Boolean, eno As Long, msg As String
    On Error GoTo Fail
    For Each lr In lo.ListRows
        If Len(CStr(lr.Range.Cells(1, idColumn).Value2)) = 0 Then Set FP_Add = lr.Range: Exit Function
    Next lr
    wasProtected = lo.Parent.ProtectContents
    If wasProtected Then lo.Parent.Unprotect
    Set FP_Add = lo.ListRows.Add.Range
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Exit Function
Fail:
    eno = Err.number: msg = Err.description
    On Error Resume Next
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    On Error GoTo 0
    Err.Raise eno, "FP_Add", msg
End Function

Private Sub FP_Write(ByVal row As Range, ByVal value As Variant)
    Dim i As Long
    For i = 1 To UBound(value)
        If VarType(value(i)) = vbString Then row.Cells(1, i).NumberFormat = "@"
        row.Cells(1, i).Value2 = value(i)
    Next i
End Sub

Private Sub FP_Delete(ByVal lo As ListObject, ByVal column As Long, ByVal id As String)
    Dim i As Long, wasProtected As Boolean, eno As Long, msg As String
    On Error GoTo Fail
    wasProtected = lo.Parent.ProtectContents
    If wasProtected Then lo.Parent.Unprotect
    For i = lo.ListRows.count To 1 Step -1
        If CStr(lo.ListRows(i).Range.Cells(1, column).Value2) = id Then lo.ListRows(i).Delete
    Next i
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Exit Sub
Fail:
    eno = Err.number: msg = Err.description
    On Error Resume Next
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    On Error GoTo 0
    Err.Raise eno, "FP_Delete", msg
End Sub

Private Sub FP_Error(ByVal message As String)
    MsgBox message, vbExclamation, "TQM - Facturi si plati"
End Sub

Private Function FP_FormOpen() As Boolean
    Dim w As Workbook
    If mForm Is Nothing Then Exit Function
    For Each w In Application.Workbooks
        If w Is mForm Then FP_FormOpen = True: Exit Function
    Next w
    Set mForm = Nothing
End Function

Private Function FP_Start(ByVal mode As String) As Boolean
    Dim ws As Worksheet
    If FP_FormOpen Then
        If MsgBox("Inchideti formularul local si renuntati la modificarile nesalvate?", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Function
        mForm.Close SaveChanges:=False
    End If
    Set mForm = Workbooks.Add(xlWBATWorksheet): Set ws = mForm.Worksheets(1): ws.name = "Formular_Facturi"
    ws.Range("A1:O125").Font.name = "Aptos": ws.Range("A1:O125").Font.size = 10: ws.rows("1:125").RowHeight = 25
    ws.Range("A1:O125").NumberFormat = "@"
    ws.rows(1).RowHeight = 32: ws.Columns("A:B").ColumnWidth = 28: ws.Columns("C:E").ColumnWidth = 16
    ws.Columns("F").ColumnWidth = 22: ws.Columns("G").ColumnWidth = 24: ws.Columns("H:I").ColumnWidth = 12
    mMode = mode: mStamp = FP_Stamp()
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 85
    FP_Start = True
End Function

Private Sub FP_Input(ByVal ws As Worksheet, ByVal address As String, Optional ByVal value As Variant)
    With ws.Range(address)
        .Merge: .Interior.Color = RGB(239, 246, 255): .Locked = False
        If Not IsMissing(value) Then .Cells(1, 1).Value2 = value
    End With
End Sub

Public Sub FP_InchideFormular()
    If Not FP_FormOpen Then Exit Sub
    If mMode = "FACTURA" Or mMode = "PLATA" Or mMode = "COMPENSARE" Then
        If MsgBox("Inchideti formularul si renuntati la modificarile nesalvate?", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
    End If
    FP_Close
End Sub

Private Sub FP_Close()
    If FP_FormOpen Then mForm.Close SaveChanges:=False
    Set mForm = Nothing: mMode = "": mStamp = ""
    ThisWorkbook.Worksheets(FP_Sheet).Select Replace:=True
End Sub

Private Function FP_Stamp() As String
    Dim kind As Long, lr As ListRow, c As Long, v As String, result As String, lo As ListObject, names As Variant
    Dim ws As Worksheet, n As Long, cols As Variant, k As Variant
    For kind = 1 To 3
        result = result & "T" & kind & ":"
        For Each lr In FP_Table(kind).ListRows
            For c = 1 To lr.Range.Columns.count
                If (kind <> 1 Or (c < 9 Or c > 13) And c <> 21) And (kind <> 2 Or c < 6 Or c > 8) Then
                    v = CStr(lr.Range.Cells(1, c).Value2): result = result & Len(v) & ":" & v
                End If
            Next c
        Next lr
    Next kind
    names = Array("tTQMComenzi", "tTQMCFPoz", "tTQMCFRec")
    For Each k In names
        Set lo = FP_SourceTable(CStr(k), False)
        If Not lo Is Nothing Then
            result = result & CStr(k) & ":"
            For Each lr In lo.ListRows
                For c = 1 To lr.Range.Columns.count
                    If Not lr.Range.Cells(1, c).HasFormula Then
                        v = CStr(lr.Range.Cells(1, c).Value2): result = result & Len(v) & ":" & v
                    End If
                Next c
            Next lr
        End If
    Next k
    Set ws = FP_GetSheet("Control_Achizitii")
    If Not ws Is Nothing Then
        cols = Array(3, 4, 5, 6, 7, 9, 18)
        For n = 13 To TQM_Control_Cell(ws, ws.rows.count, 1).End(xlUp).row
            For Each k In cols
                v = CStr(ws.Cells(n, CLng(k)).Value2): result = result & Len(v) & ":" & v
            Next k
        Next n
    End If
    FP_Stamp = result
End Function

Private Sub FP_Conflict()
    If FP_Stamp() <> mStamp Then Err.Raise vbObjectError + 519, , "Datele s-au modificat dupa deschiderea formularului. Nu au fost suprascrise. Inchideti si redeschideti formularul."
End Sub

Private Sub FP_Calc()
    Dim lo As ListObject, lr As ListRow, rep As ListRow, projects As Object, v As Variant, text As String
    Dim oldE As Boolean, eno As Long, msg As String
    Dim calcSheets(1 To 3) As Worksheet
    Dim restoreProtection(1 To 3) As Boolean
    Dim savedFiltering(1 To 3) As Boolean
    Dim i As Long, stage As String, errSource As String
    oldE = Application.EnableEvents
    On Error GoTo Fail
    Application.EnableEvents = False
    stage = "Pregatire foi pentru calcul"
    For i = 1 To 3
        Set calcSheets(i) = FP_Table(i).Parent
        If calcSheets(i).ProtectContents Or calcSheets(i).ProtectDrawingObjects Or calcSheets(i).ProtectScenarios Then
            savedFiltering(i) = calcSheets(i).Protection.AllowFiltering
            calcSheets(i).Unprotect Password:=""
            restoreProtection(i) = True
        End If
    Next i
    stage = "Formatare si calcul registru facturi"
    Set lo = FP_Table(1)
    If Not lo.DataBodyRange Is Nothing Then
        lo.ListColumns("Total_RON").DataBodyRange.Resize(, 3).NumberFormat = "#,##0.00"
        lo.ListColumns("Status_plata").DataBodyRange.NumberFormat = "General"
        FP_CalcSetR1C1 lo, "Total_RON", "=IF([@ID_factura]="""","""",ROUND([@Net_RON]+[@TVA_RON],2))"
        FP_CalcSetR1C1 lo, "Achitat_RON", "=IF([@ID_factura]="""","""",ROUND(SUMIFS(tTQMFPPlati[Suma_RON],tTQMFPPlati[ID_factura],[@ID_factura],tTQMFPPlati[Stare],""Valida""),2))"
        FP_CalcSetR1C1 lo, "Sold_RON", "=IF([@ID_factura]="""","""",IF([@Stare]=""Anulata"",0,ROUND([@Total_RON]-[@Achitat_RON],2)))"
        FP_CalcSetR1C1 lo, "Status_plata", "=IF([@ID_factura]="""","""",IF([@Stare]=""Anulata"",""ANULATA"",IF([@Total_RON]*[@Sold_RON]<0,""NECONCORDANTA"",IF([@Sold_RON]=0,IF([@Total_RON]<0,""REGULARIZATA"",""ACHITATA""),IF([@Total_RON]<0,""CREDIT FURNIZOR"",IF([@Scadenta]<TODAY(),""RESTANTA"",IF([@Scadenta]=TODAY(),""SCADENTA AZI"",IF([@Achitat_RON]>0,""PARTIALA"",""NEACHITATA""))))))))"
        stage = "Actualizare proiecte asociate facturilor"
        For Each lr In lo.ListRows
            If Len(CStr(lr.Range.Cells(1, 16).Value2)) > 0 Then
                Set projects = CreateObject("Scripting.Dictionary")
                For Each rep In FP_Table(2).ListRows
                    If CStr(rep.Range.Cells(1, 2).Value2) = CStr(lr.Range.Cells(1, 16).Value2) And CStr(rep.Range.Cells(1, 13).Value2) = "Valida" Then
                        text = CStr(rep.Range.Cells(1, 3).Value2)
                        If Not projects.exists(text) Then projects.Add text, True
                    End If
                Next rep
                text = "": For Each v In projects.keys: If Len(text) = 0 Then text = CStr(v) Else text = text & "; " & CStr(v)
                Next v
                lr.Range.Cells(1, 13).NumberFormat = "@": lr.Range.Cells(1, 13).Value2 = text
            End If
        Next lr
        lo.ListColumns("Net_RON").DataBodyRange.Resize(, 5).NumberFormat = "#,##0.00"
        lo.Parent.Calculate
    End If
    stage = "Formatare si calcul repartizari"
    Set lo = FP_Table(2)
    If Not lo.DataBodyRange Is Nothing Then
        lo.ListColumns("Total_RON").DataBodyRange.Resize(, 3).NumberFormat = "#,##0.00"
        FP_CalcSetR1C1 lo, "Total_RON", "=IF([@ID_repartizare]="""","""",ROUND([@Net_RON]+[@TVA_RON],2))"
        FP_CalcSetR1C1 lo, "Achitat_RON", "=IF([@ID_repartizare]="""","""",ROUND(SUMIFS(tTQMFPPlati[Suma_RON],tTQMFPPlati[ID_repartizare],[@ID_repartizare],tTQMFPPlati[Stare],""Valida""),2))"
        FP_CalcSetR1C1 lo, "Sold_RON", "=IF([@ID_repartizare]="""","""",IF([@Stare]=""Anulata"",0,ROUND([@Total_RON]-[@Achitat_RON],2)))"
        lo.ListColumns("Net_RON").DataBodyRange.Resize(, 5).NumberFormat = "#,##0.00": lo.Parent.Calculate
    End If
    stage = "Formatare registru plati"
    FP_Table(3).ListColumns("Suma_RON").Range.NumberFormat = "#,##0.00"
    FP_Table(3).ListColumns("Data").Range.NumberFormat = "dd.mm.yyyy"
    stage = "Sincronizare proiecte si bugete"
    FP_PBSync
    stage = "Sincronizare documente"
    FP_DOCSync
    stage = "Restabilire protectie foi"
    For i = 1 To 3
        If restoreProtection(i) Then
            calcSheets(i).Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=savedFiltering(i)
            restoreProtection(i) = False
        End If
    Next i
    Application.EnableEvents = oldE
    Exit Sub
Fail:
    eno = Err.number: msg = Err.description: errSource = Err.source
    On Error Resume Next
    For i = 1 To 3
        If restoreProtection(i) Then
            calcSheets(i).Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=savedFiltering(i)
        End If
    Next i
    Application.EnableEvents = oldE
    On Error GoTo 0
    If Len(errSource) = 0 Then errSource = "FP_Calc"
    Err.Raise eno, errSource, "Etapa FP_Calc: " & stage & vbCrLf & _
              "Eroare: " & CStr(eno) & vbCrLf & "Sursa: " & errSource & vbCrLf & msg
End Sub

Private Sub FP_CalcSetR1C1(ByVal lo As ListObject, ByVal columnName As String, ByVal template As String)
    Dim target As Range, lc As ListColumn, sourceTable As ListObject
    Dim formulaText As String, token As String, targetAddress As String
    Dim i As Long, errNumber As Long, errMessage As String

    On Error GoTo Fail
    Set target = lo.ListColumns(columnName).DataBodyRange
    If target Is Nothing Then Exit Sub
    targetAddress = target.address(False, False)
    formulaText = template

    ' RC plus coloana absoluta pastreaza referinta la randul curent.
    For Each lc In lo.ListColumns
        token = "[@" & lc.name & "]"
        formulaText = Replace(formulaText, token, "RC" & CStr(lc.Range.column), 1, -1, vbBinaryCompare)
    Next lc

    ' Intervalele sursa sunt refacute la fiecare FP_Calc, dupa adaugari de randuri.
    For i = 1 To 3
        Set sourceTable = FP_Table(i)
        For Each lc In sourceTable.ListColumns
            token = sourceTable.name & "[" & lc.name & "]"
            If InStr(1, formulaText, token, vbBinaryCompare) > 0 Then
                formulaText = Replace(formulaText, token, FP_CalcSourceRefR1C1(lc), 1, -1, vbBinaryCompare)
            End If
        Next lc
    Next i

    If InStr(1, formulaText, "[@", vbBinaryCompare) > 0 Then
        Err.Raise vbObjectError + 599, "FP_CalcSetR1C1", "Referinta la o coloana inexistenta in formula."
    End If
    target.FormulaR1C1 = formulaText
    Exit Sub

Fail:
    errNumber = Err.number
    errMessage = Err.description
    Debug.Print "FP_Calc: " & lo.name & "." & columnName
    Debug.Print formulaText
    Err.Raise errNumber, "FP_Calc." & lo.name & "." & columnName, _
              errMessage & vbCrLf & "Foaie: " & lo.Parent.name & "; interval: " & targetAddress
End Sub

Private Function FP_CalcSourceRefR1C1(ByVal lc As ListColumn) As String
    Dim sourceRange As Range
    Set sourceRange = lc.DataBodyRange
    If sourceRange Is Nothing Then
        Set sourceRange = lc.Parent.HeaderRowRange.Cells(1, lc.Index).Offset(1, 0)
    End If
    FP_CalcSourceRefR1C1 = "'" & Replace(sourceRange.Parent.name, "'", "''") & "'!" & _
                          sourceRange.address(RowAbsolute:=True, ColumnAbsolute:=True, ReferenceStyle:=xlR1C1, External:=False)
End Function
Private Function FP_Selected() As String
    Dim lo As ListObject, hit As Range, i As Long
    If Not ActiveWorkbook Is ThisWorkbook Then Err.Raise vbObjectError + 520, , "Selectati factura in registrul principal."
    If ActiveSheet.name <> FP_Sheet Then Err.Raise vbObjectError + 521, , "Deschideti Facturi si plati."
    Set lo = FP_Table(1)
    If lo.DataBodyRange Is Nothing Then Err.Raise vbObjectError + 522, , "Nu exista facturi."
    Set hit = Intersect(ActiveCell, lo.DataBodyRange)
    If hit Is Nothing Then Err.Raise vbObjectError + 523, , "Selectati un rand din tabelul de facturi."
    i = ActiveCell.row - lo.HeaderRowRange.row: FP_Selected = CStr(lo.ListRows(i).Range.Cells(1, 16).Value2)
    If Len(FP_Selected) = 0 Then Err.Raise vbObjectError + 524, , "Randul selectat este gol."
End Function

Private Function FP_Invoice(ByVal id As String, Optional ByVal active As Boolean = True) As Range
    Dim row As Range
    Set row = FP_Find(FP_Table(1), id, 16)
    If row Is Nothing Then Err.Raise vbObjectError + 525, , "Factura nu exista."
    If active And CStr(row.Cells(1, 19).Value2) <> "Valida" Then Err.Raise vbObjectError + 526, , "Factura este anulata."
    Set FP_Invoice = row
End Function

Private Function FP_SamePartner(ByVal a As Range, ByVal b As Range) As Boolean
    Dim ac As String, bc As String
    ac = FP_CIF(CStr(a.Cells(1, 4).Value2)): bc = FP_CIF(CStr(b.Cells(1, 4).Value2))
    If Len(ac) > 0 And Len(bc) > 0 Then FP_SamePartner = (ac = bc) Else FP_SamePartner = (FP_Norm(CStr(a.Cells(1, 3).Value2)) = FP_Norm(CStr(b.Cells(1, 3).Value2)))
End Function

Public Sub FP_Actualizeaza()
    On Error GoTo Fail
Call FP_Init:     Call FP_Calc: FP_CheckLedger
    Exit Sub
Fail: FP_Error Err.description
End Sub

Private Function FP_Allocated(ByVal column As Long, ByVal source As String, ByVal amountColumn As Long, Optional ByVal position As String = "") As Currency
    Dim lr As ListRow
    For Each lr In FP_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 13).Value2) = "Valida" And CStr(lr.Range.Cells(1, column).Value2) = source Then
            If Len(position) = 0 Or CStr(lr.Range.Cells(1, 10).Value2) = position Then FP_Allocated = FP_Allocated + CCur(lr.Range.Cells(1, amountColumn).Value2)
        End If
    Next lr
End Function

Private Function FP_SourceNet(ByVal kind As String, ByVal source As Range, ByVal pos As Range) As Currency
    Dim basis As Currency, leftOrder As Currency, leftSource As Currency
    basis = CCur(Application.WorksheetFunction.Round((CDbl(pos.Cells(1, 7).Value2) - CDbl(pos.Cells(1, 11).Value2)) * CDbl(pos.Cells(1, 8).Value2) * (1 - CDbl(pos.Cells(1, 9).Value2) / 100), 2))
    leftOrder = basis - FP_Allocated(10, CStr(pos.Cells(1, 1).Value2), 4)
    If kind = "RECEPTIE" Then
        basis = CCur(Application.WorksheetFunction.Round(CDbl(source.Cells(1, 6).Value2) * CDbl(pos.Cells(1, 8).Value2) * (1 - CDbl(pos.Cells(1, 9).Value2) / 100), 2))
        leftSource = basis - FP_Allocated(11, CStr(source.Cells(1, 1).Value2), 4, CStr(pos.Cells(1, 1).Value2))
        If leftSource < leftOrder Then leftOrder = leftSource
    End If
    If leftOrder < 0 Then leftOrder = 0
    FP_SourceNet = leftOrder
End Function

Public Sub FP_DinComanda()
    FP_ChooseSource "COMANDA"
End Sub
Public Sub FP_DinReceptie()
    FP_ChooseSource "RECEPTIE"
End Sub
Public Sub FP_DinControl()
    FP_ChooseSource "CONTROL"
End Sub

Private Sub FP_ChooseSource(ByVal kind As String)
    Dim ws As Worksheet, ctl As Worksheet, lr As ListRow, pos As Range, order As Range, source As Range
    Dim seen As Object, n As Long, r As Long, hs As Variant, i As Long, key As String, val As Currency, allocated As Currency
    On Error GoTo Fail
Call FP_Init:     Call FP_Calc: FP_CheckLedger
    If Not FP_Start("SURSA_" & kind) Then Exit Sub
    mSourceKind = kind: Set ws = mForm.Worksheets(1)
    FP_Band ws, "A1:G1", "TQM - Selectati sursa facturii: " & kind, 16
    FP_Button ws, "A3:C3", "Pregateste factura", "FP_PreiaSursa": FP_Button ws, "D3:F3", "Inchide lista", "FP_InchideFormular"
    hs = Split("Comanda / Registru|Document|Data|Partener|Proiect|Net orientativ RON|Referinta|ID_sursa", "|")
    For i = 0 To UBound(hs): ws.Cells(5, i + 1).Value2 = hs(i): Next i
    n = 6: Set seen = CreateObject("Scripting.Dictionary")
    Select Case kind
    Case "COMANDA"
        For Each lr In FP_SourceTable("tTQMComenzi").ListRows
            If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 And CStr(lr.Range.Cells(1, 9).Value2) <> "Anulata" Then
                val = 0
                For Each source In FP_SourceTable("tTQMCFPoz").DataBodyRange.rows
                    If CStr(source.Cells(1, 2).Value2) = CStr(lr.Range.Cells(1, 1).Value2) Then val = val + FP_SourceNet(kind, source, source)
                Next source
                ws.Cells(n, 1).Value2 = lr.Range.Cells(1, 2).Value2: ws.Cells(n, 3).Value2 = lr.Range.Cells(1, 3).Value2
                ws.Cells(n, 4).Value2 = lr.Range.Cells(1, 4).Value2: ws.Cells(n, 5).Value2 = lr.Range.Cells(1, 5).Value2
                ws.Cells(n, 6).Value2 = val: ws.Cells(n, 7).Value2 = "Valori ramase orientative; verificati factura."
                ws.Cells(n, 8).Value2 = lr.Range.Cells(1, 1).Value2: n = n + 1
            End If
        Next lr
    Case "RECEPTIE"
        For Each lr In FP_SourceTable("tTQMCFRec").ListRows
            If CStr(lr.Range.Cells(1, 7).Value2) = "Valida" Then
                key = CStr(lr.Range.Cells(1, 1).Value2)
                If Not seen.exists(key) Then
                    seen.Add key, n
                    Set order = FP_Find(FP_SourceTable("tTQMComenzi"), CStr(lr.Range.Cells(1, 3).Value2))
                    If order Is Nothing Then Err.Raise vbObjectError + 527, , "Receptie fara comanda."
                    ws.Cells(n, 1).Value2 = order.Cells(1, 2).Value2: ws.Cells(n, 2).Value2 = lr.Range.Cells(1, 5).Value2
                    ws.Cells(n, 3).Value2 = lr.Range.Cells(1, 4).Value2: ws.Cells(n, 4).Value2 = order.Cells(1, 4).Value2
                    ws.Cells(n, 5).Value2 = order.Cells(1, 5).Value2: ws.Cells(n, 6).Value2 = 0
                    ws.Cells(n, 7).Value2 = "TVA se completeaza conform facturii.": ws.Cells(n, 8).Value2 = key: n = n + 1
                End If
                Set pos = FP_Find(FP_SourceTable("tTQMCFPoz"), CStr(lr.Range.Cells(1, 2).Value2))
                If pos Is Nothing Then Err.Raise vbObjectError + 528, , "Receptie fara pozitie de comanda."
                r = CLng(seen(key)): ws.Cells(r, 6).Value2 = CCur(ws.Cells(r, 6).Value2) + FP_SourceNet(kind, lr.Range, pos)
            End If
        Next lr
    Case "CONTROL"
        Set ctl = FP_GetSheet("Control_Achizitii")
        If ctl Is Nothing Then Err.Raise vbObjectError + 529, , "Lipseste Control_Achizitii."
        If CStr(TQM_Control_Cell(ctl, 12, 3).Value2) <> "Nr. Factura / Aviz" Or CStr(TQM_Control_Cell(ctl, 12, 7).Value2) <> "Partener" Then Err.Raise vbObjectError + 530, , "Control_Achizitii are alte coloane; preluarea automata a fost oprita."
        For r = 13 To TQM_Control_Cell(ctl, ctl.rows.count, 1).End(xlUp).row
            key = FP_Norm(CStr(TQM_Control_Cell(ctl, r, 9).Value2))
            If InStr(key, "factura") > 0 And InStr(key, "aviz") = 0 And Len(CStr(TQM_Control_Cell(ctl, r, 3).Value2)) > 0 Then
                ws.Cells(n, 1).Value2 = TQM_Control_Cell(ctl, r, 1).Value2: ws.Cells(n, 2).Value2 = TQM_Control_Cell(ctl, r, 3).Value2
                ws.Cells(n, 3).Value2 = TQM_Control_Cell(ctl, r, 4).Value2: ws.Cells(n, 4).Value2 = TQM_Control_Cell(ctl, r, 7).Value2
                ws.Cells(n, 5).Value2 = TQM_Control_Cell(ctl, r, 6).Value2: ws.Cells(n, 6).Value2 = TQM_Control_Cell(ctl, r, 5).Value2
                ws.Cells(n, 7).Value2 = "Preluare din registrul documentelor": ws.Cells(n, 8).Value2 = TQM_Control_Cell(ctl, r, 18).Value2: n = n + 1
            End If
        Next r
    End Select
    If n = 6 Then FP_Close: MsgBox "Nu exista surse disponibile pentru aceasta selectie.", vbInformation, "TQM": Exit Sub
    ws.Range("A5:G5").Interior.Color = RGB(31, 41, 55): ws.Range("A5:G5").Font.Color = vbWhite: ws.Range("A5:G5").WrapText = True
    ws.Columns("C").NumberFormat = "dd.mm.yyyy": ws.Columns("F").NumberFormat = "#,##0.00"
    ws.Columns("C").ColumnWidth = 14: ws.Columns("D:E").ColumnWidth = 28: ws.Columns("F").ColumnWidth = 22: ws.Columns("G").ColumnWidth = 46
    ws.Columns("H").Hidden = True: ws.rows(5).RowHeight = 34
    ws.Range("A5:G" & n - 1).AutoFilter: ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    ActiveWindow.SplitRow = 5: ActiveWindow.FreezePanes = True: ws.Range("A6").Select
    Exit Sub
Fail: FP_Error Err.description
End Sub

Public Sub FP_PreiaSursa()
    Dim ws As Worksheet, kind As String, source As String
    On Error GoTo Fail
    If Not FP_FormOpen Then Err.Raise vbObjectError + 531, , "Lista surselor nu mai este deschisa."
    If Not ActiveWorkbook Is mForm Or Left$(mMode, 6) <> "SURSA_" Then Err.Raise vbObjectError + 532, , "Selectati sursa din lista locala."
    Set ws = mForm.Worksheets(1)
    If ActiveCell.row < 6 Then Err.Raise vbObjectError + 533, , "Selectati un rand din lista."
    source = CStr(ws.Cells(ActiveCell.row, 8).Value2)
    If Len(source) = 0 Then Err.Raise vbObjectError + 534, , "Randul selectat este gol."
    Call FP_Conflict:     kind = mSourceKind: FP_Close
    FP_OpenInvoice kind, source, ""
    Exit Sub
Fail: FP_Error Err.description
End Sub

Public Sub FP_FacturaNoua()
    FP_OpenInvoice "MANUAL", "", ""
End Sub

Public Sub FP_Storno()
    Dim id As String, inv As Range
    On Error GoTo Fail
Call FP_Init:     Call FP_Calc: FP_CheckLedger: id = FP_Selected(): Set inv = FP_Invoice(id)
    If CStr(inv.Cells(1, 5).Value2) <> "Factura" Then Err.Raise vbObjectError + 535, , "Selectati factura pozitiva pe care o corecteaza documentul storno."
    FP_OpenInvoice "STORNO", "", id
    Exit Sub
Fail: FP_Error Err.description
End Sub

Private Sub FP_FormLine(ByVal ws As Worksheet, ByVal n As Long, ByVal description As String, ByVal project As String, ByVal net As Currency, ByVal tax As Variant)
    ws.Cells(n, 1).NumberFormat = "@": ws.Cells(n, 1).Value2 = description
    ws.Cells(n, 2).NumberFormat = "@": ws.Cells(n, 2).Value2 = project: ws.Cells(n, 3).Value2 = net
    If Not IsEmpty(tax) Then ws.Cells(n, 4).Value2 = tax
End Sub

Private Sub FP_OpenInvoice(ByVal kind As String, ByVal sourceId As String, ByVal original As String)
    Dim ws As Worksheet, ctl As Worksheet, order As Range, pos As Range, inv As Range, lr As ListRow
    Dim n As Long, net As Currency, tax As Currency, i As Long, source As Range, hs As Variant, label As String
    On Error GoTo Fail
Call FP_Init:     Call FP_Calc: FP_CheckLedger
    If Not FP_Start("FACTURA") Then Exit Sub
    mSourceKind = kind: mSource = sourceId: mOther = original: mInvoice = ""
    Set ws = mForm.Worksheets(1)
    FP_Band ws, "A1:I1", "TQM - Factura (formular local)", 16
    FP_Button ws, "A3:C3", "Salveaza factura", "FP_SalveazaFactura": FP_Button ws, "D3:F3", "Inchide formularul", "FP_InchideFormular"
    FP_Button ws, "G3:I3", "Alege partener", "NM_AlegePartener"
    FP_Button ws, "G19:I19", "Alege proiect", "NM_AlegeProiect"
    ws.Range("A5").Value2 = "Numar factura": ws.Range("E5").Value2 = "Tip document"
    ws.Range("A6").Value2 = "Data facturii": ws.Range("E6").Value2 = "Scadenta"
    ws.Range("A7").Value2 = "Partener": ws.Range("A8").Value2 = "CIF partener": ws.Range("E8").Value2 = "Responsabil"
    ws.Range("A9").Value2 = "Link factura": ws.Range("A10").Value2 = "Observatii"
    ws.Range("A11").Value2 = "Factura originala": ws.Range("A12").Value2 = "Sursa preluarii"
    FP_Input ws, "B5:D5": ws.Range("B5").NumberFormat = "@"
    FP_Input ws, "B6:D6", CDbl(Date): FP_Input ws, "F6:I6", CDbl(Date + CLng(FP_SLParam("FACTURA_SCADENTA_ZILE", 30)))
    FP_Input ws, "B7:I7": FP_Input ws, "B8:D8": FP_Input ws, "F8:I8", Application.UserName
    FP_Input ws, "B9:I9": FP_Input ws, "B10:I10": ws.Range("B8").NumberFormat = "@"
    ws.Range("B6").NumberFormat = "dd.mm.yyyy": ws.Range("F6").NumberFormat = "dd.mm.yyyy"
    FP_Band ws, "F5:I5", "Factura": FP_Band ws, "B11:I11", "": FP_Band ws, "B12:I12", kind
    FP_Band ws, "A14:C14", "Net (RON fara TVA)": FP_Band ws, "D14:F14", "TVA (RON)": FP_Band ws, "G14:I14", "Total (RON cu TVA)"
    FP_Band ws, "A15:C15", "", 18: FP_Band ws, "D15:F15", "", 18: FP_Band ws, "G15:I15", "", 18
    ws.Range("A15:I15").NumberFormat = "#,##0.00": ws.rows(15).RowHeight = 34
    ws.Range("A15").formula = "=ROUND(SUM(C21:C120),2)": ws.Range("D15").formula = "=ROUND(SUM(D21:D120),2)": ws.Range("G15").formula = "=ROUND(SUM(E21:E120),2)"
    FP_Band ws, "A17:I18", "Completati TVA pentru fiecare pozitie, inclusiv zero. Valorile preluate sunt orientative; verificati sumele din factura."
    ws.Range("A17:I18").WrapText = True
    hs = Split("Descriere|Proiect / obiectiv|Net RON|TVA RON|Total RON|Comanda|Document sursa", "|")
    For i = 0 To UBound(hs): ws.Cells(20, i + 1).Value2 = hs(i): Next i
    ws.Range("A21:D120").Locked = False: ws.Range("A21:D120").Interior.Color = RGB(239, 246, 255)
    ws.Range("A21:B120").NumberFormat = "@": ws.Range("C21:E120").NumberFormat = "#,##0.00"
    ws.Range("E21:E120").FormulaR1C1 = "=IF(COUNTA(RC[-4]:RC[-1])=0,"""",IF(OR(RC[-2]="""",RC[-1]=""""),""TVA / net lipsa"",ROUND(RC[-2]+RC[-1],2)))"
    n = 21
    Select Case kind
    Case "COMANDA", "RECEPTIE"
        If kind = "COMANDA" Then
            Set order = FP_Find(FP_SourceTable("tTQMComenzi"), sourceId)
        Else
            For Each lr In FP_SourceTable("tTQMCFRec").ListRows
                If CStr(lr.Range.Cells(1, 1).Value2) = sourceId And CStr(lr.Range.Cells(1, 7).Value2) = "Valida" Then
                    Set order = FP_Find(FP_SourceTable("tTQMComenzi"), CStr(lr.Range.Cells(1, 3).Value2)): Exit For
                End If
            Next lr
        End If
        If order Is Nothing Then Err.Raise vbObjectError + 536, , "Sursa selectata nu mai exista."
        If CStr(order.Cells(1, 9).Value2) = "Anulata" Then Err.Raise vbObjectError + 537, , "Comanda este anulata."
        ws.Range("B7").Value2 = order.Cells(1, 4).Value2: ws.Range("B7:I7").Locked = True
        FP_Band ws, "B12:I12", kind & " - " & CStr(order.Cells(1, 2).Value2)
        For Each lr In FP_SourceTable(IIf(kind = "COMANDA", "tTQMCFPoz", "tTQMCFRec")).ListRows
            Set source = lr.Range: Set pos = Nothing
            If kind = "COMANDA" Then
                If CStr(source.Cells(1, 2).Value2) = sourceId Then Set pos = source
            Else
                If CStr(source.Cells(1, 1).Value2) = sourceId And CStr(source.Cells(1, 7).Value2) = "Valida" Then Set pos = FP_Find(FP_SourceTable("tTQMCFPoz"), CStr(source.Cells(1, 2).Value2))
            End If
            If Not pos Is Nothing Then
                If n > 120 Then Err.Raise vbObjectError + 538, , "Sursa depaseste 100 de pozitii. Inregistrati factura manual in mai putine repartizari."
                net = FP_SourceNet(kind, source, pos)
                FP_FormLine ws, n, CStr(pos.Cells(1, 4).Value2) & " " & CStr(pos.Cells(1, 5).Value2), CStr(pos.Cells(1, 16).Value2), net, Empty
                ws.Cells(n, 6).Value2 = order.Cells(1, 2).Value2: ws.Cells(n, 12).Value2 = order.Cells(1, 1).Value2: ws.Cells(n, 13).Value2 = pos.Cells(1, 1).Value2
                If kind = "RECEPTIE" Then ws.Cells(n, 7).Value2 = source.Cells(1, 5).Value2: ws.Cells(n, 14).Value2 = sourceId
                n = n + 1
            End If
        Next lr
        If kind = "COMANDA" Then
            net = CCur(order.Cells(1, 15).Value2) + CCur(order.Cells(1, 16).Value2) - FP_Allocated(9, sourceId, 4)
            For Each lr In FP_Table(2).ListRows
                If CStr(lr.Range.Cells(1, 9).Value2) = sourceId And Len(CStr(lr.Range.Cells(1, 10).Value2)) > 0 And CStr(lr.Range.Cells(1, 13).Value2) = "Valida" Then net = net + CCur(lr.Range.Cells(1, 4).Value2)
            Next lr
            If net > 0 Then
                If n > 120 Then Err.Raise vbObjectError + 538, , "Materialele si costurile suplimentare depasesc 100 de repartizari. Inregistrati manual factura, agregand pozitiile pe proiect."
                FP_FormLine ws, n, "Transport / alte costuri", CStr(order.Cells(1, 5).Value2), net, Empty
                ws.Cells(n, 6).Value2 = order.Cells(1, 2).Value2: ws.Cells(n, 12).Value2 = sourceId
            End If
        End If
    Case "CONTROL"
        Set ctl = FP_GetSheet("Control_Achizitii")
        i = TQM_Control_RowID(sourceId): ws.Range("B5").Value2 = TQM_Control_Cell(ctl, i, 3).Value2: ws.Range("B6").Value2 = TQM_Control_Cell(ctl, i, 4).Value2
        ws.Range("F6").Value2 = FP_Date(TQM_Control_Cell(ctl, i, 4).Value2) + CLng(FP_SLParam("FACTURA_SCADENTA_ZILE", 30)): ws.Range("B7").Value2 = TQM_Control_Cell(ctl, i, 7).Value2
        net = FP_Money(TQM_Control_Cell(ctl, i, 5).Value2, "Valoare din Control Achizitii")
        FP_FormLine ws, n, "Factura preluata din Control Achizitii", CStr(TQM_Control_Cell(ctl, i, 6).Value2), net, Empty
        FP_Band ws, "B12:I12", "Control Achizitii - Dosar " & sourceId
    Case "STORNO"
        Set inv = FP_Invoice(original): FP_Band ws, "F5:I5", "Storno"
        ws.Range("B7").Value2 = inv.Cells(1, 3).Value2: ws.Range("B8").Value2 = inv.Cells(1, 4).Value2
        ws.Range("B7:I7").Locked = True: ws.Range("B8:D8").Locked = True
        FP_Band ws, "B11:I11", CStr(inv.Cells(1, 1).Value2) & " / " & Format$(inv.Cells(1, 2).Value2, "dd.mm.yyyy")
        For Each lr In FP_Table(2).ListRows
            If CStr(lr.Range.Cells(1, 2).Value2) = original And CStr(lr.Range.Cells(1, 13).Value2) = "Valida" Then
                net = CCur(lr.Range.Cells(1, 4).Value2) + FP_Allocated(16, CStr(lr.Range.Cells(1, 1).Value2), 4)
                tax = CCur(lr.Range.Cells(1, 5).Value2) + FP_Allocated(16, CStr(lr.Range.Cells(1, 1).Value2), 5)
                If net > 0 Or tax > 0 Then
                    If n > 120 Then Err.Raise vbObjectError + 539, , "Factura originala depaseste 100 de repartizari."
                    FP_FormLine ws, n, CStr(lr.Range.Cells(1, 12).Value2), CStr(lr.Range.Cells(1, 3).Value2), net, tax
                    ws.Cells(n, 12).Value2 = lr.Range.Cells(1, 9).Value2: ws.Cells(n, 13).Value2 = lr.Range.Cells(1, 10).Value2
                    ws.Cells(n, 14).Value2 = lr.Range.Cells(1, 11).Value2: ws.Cells(n, 15).Value2 = lr.Range.Cells(1, 1).Value2
                    ws.Cells(n, 2).Locked = True: n = n + 1
                End If
            End If
        Next lr
        If n = 21 Then Err.Raise vbObjectError + 540, , "Factura este deja corectata integral prin documente storno."
        FP_Band ws, "A17:I18", "Storno: introduceti magnitudini pozitive pentru net si TVA. In registru vor fi salvate cu minus. Proiectul ramane cel al repartizarii originale."
    End Select
    ws.Columns("L:O").Hidden = True: ws.Range("A20:G20").Interior.Color = RGB(31, 41, 55): ws.Range("A20:G20").Font.Color = vbWhite
    ws.Range("A20:G20").WrapText = True: ws.rows(20).RowHeight = 34: ws.Protect UserInterfaceOnly:=True
    ActiveWindow.SplitRow = 3: ActiveWindow.FreezePanes = True: ws.Range("B5").Select
    Exit Sub
Fail: FP_Error Err.description
End Sub

Private Sub FP_CheckDuplicate(ByVal number As String, ByVal dat As Double, ByVal partner As String, ByVal cif As String, ByVal kind As String)
    Dim lr As ListRow, same As Boolean
    For Each lr In FP_Table(1).ListRows
        If CStr(lr.Range.Cells(1, 19).Value2) = "Valida" And FP_Norm(CStr(lr.Range.Cells(1, 1).Value2)) = FP_Norm(number) And CStr(lr.Range.Cells(1, 5).Value2) = kind Then
            If Year(CDate(lr.Range.Cells(1, 2).Value2)) = Year(CDate(dat)) Then
                same = FP_Norm(CStr(lr.Range.Cells(1, 3).Value2)) = FP_Norm(partner)
                If Len(FP_CIF(cif)) > 0 And Len(FP_CIF(CStr(lr.Range.Cells(1, 4).Value2))) > 0 Then same = same Or FP_CIF(cif) = FP_CIF(CStr(lr.Range.Cells(1, 4).Value2))
                If same Then Err.Raise vbObjectError + 541, , "Exista deja o factura valida cu acest numar, partener, tip si an."
            End If
        End If
    Next lr
End Sub

Public Sub FP_SalveazaFactura()
    Dim ws As Worksheet, h(1 To 24) As Variant, a(1 To 16) As Variant, records As New Collection, v As Variant
    Dim id As String, number As String, partner As String, cif As String, kind As String, doc As String, person As String
    Dim dat As Double, due As Double, net As Currency, tax As Currency, tn As Currency, tt As Currency, sg As Long
    Dim n As Long, i As Long, pos As Range, source As Range, orig As Range, order As Range, row As Range, seen As Object
    Dim oldE As Boolean, oldS As Boolean, writing As Boolean, msg As String
    On Error GoTo Fail
    If Not FP_FormOpen Then Err.Raise vbObjectError + 542, , "Formularul nu mai este deschis."
    If Not ActiveWorkbook Is mForm Or mMode <> "FACTURA" Then Err.Raise vbObjectError + 543, , "Salvati din formularul facturii."
Call FP_Init:     Call FP_Calc: FP_CheckLedger: FP_Conflict: Set ws = mForm.Worksheets(1)
    number = FP_Text(ws.Range("B5").Value2): partner = FP_Text(ws.Range("B7").Value2): cif = FP_Text(ws.Range("B8").Value2)
    person = FP_Text(ws.Range("F8").Value2): doc = FP_Text(ws.Range("B9").Value2)
    If Len(number) = 0 Or Len(partner) = 0 Or Len(person) = 0 Then Err.Raise vbObjectError + 544, , "Numar factura, Partener si Responsabil sunt obligatorii."
    If Not FP_LinkOK(doc) Then Err.Raise vbObjectError + 545, , "Linkul facturii este invalid."
    dat = FP_Date(ws.Range("B6").Value2): due = FP_Date(ws.Range("F6").Value2, True)
    If due < dat Then Err.Raise vbObjectError + 546, , "Scadenta nu poate fi anterioara datei facturii."
    sg = 1: kind = "Factura"
    If mSourceKind = "STORNO" Then
        sg = -1: kind = "Storno": Set orig = FP_Invoice(mOther)
        If dat < CDbl(orig.Cells(1, 2).Value2) Then Err.Raise vbObjectError + 547, , "Storno nu poate avea data anterioara facturii originale."
    End If
    FP_NMPartner partner, cif, (mSourceKind <> "MANUAL" And Len(mSourceKind) > 0)
    FP_CheckDuplicate number, dat, partner, cif, kind
    id = FP_ID("FA"): Set seen = CreateObject("Scripting.Dictionary")
    For n = 21 To 120
        If Application.CountA(ws.Cells(n, 1).Resize(1, 4)) > 0 Then
            net = FP_Money(ws.Cells(n, 3).Value2, "Net la randul " & n): tax = FP_Money(ws.Cells(n, 4).Value2, "TVA la randul " & n)
            If net <> 0 Or tax <> 0 Then
                If Len(FP_Text(ws.Cells(n, 2).Value2)) = 0 Then Err.Raise vbObjectError + 548, , "Completati proiectul la randul " & n & ". Folositi General pentru cheltuieli nerepartizate unui santier."
                For i = 1 To 16: a(i) = "": Next i
                a(1) = FP_ID("RP"): a(2) = id: a(3) = FP_Text(ws.Cells(n, 2).Value2): a(4) = sg * net: a(5) = sg * tax
                a(9) = ws.Cells(n, 12).Value2: a(10) = ws.Cells(n, 13).Value2: a(11) = ws.Cells(n, 14).Value2
                a(12) = FP_Text(ws.Cells(n, 1).Value2): a(13) = "Valida": a(14) = CDbl(Now): a(15) = records.count + 1: a(16) = ws.Cells(n, 15).Value2
                If sg = -1 Then
                    Set row = FP_Find(FP_Table(2), CStr(a(16)))
                    If row Is Nothing Then Err.Raise vbObjectError + 549, , "Storno trebuie repartizat pe pozitiile facturii originale."
                    If CStr(row.Cells(1, 2).Value2) <> mOther Or CStr(row.Cells(1, 13).Value2) <> "Valida" Or CStr(row.Cells(1, 3).Value2) <> CStr(a(3)) Then Err.Raise vbObjectError + 550, , "Repartizarea originala s-a modificat."
                    If seen.exists(CStr(a(16))) Then Err.Raise vbObjectError + 551, , "Repartizare originala repetata in storno."
                    seen.Add CStr(a(16)), True
                    If net > CCur(row.Cells(1, 4).Value2) + FP_Allocated(16, CStr(a(16)), 4) Or tax > CCur(row.Cells(1, 5).Value2) + FP_Allocated(16, CStr(a(16)), 5) Then Err.Raise vbObjectError + 552, , "Storno depaseste netul sau TVA ramase ale repartizarii originale."
                ElseIf Len(CStr(a(9))) > 0 Then
                    Set order = FP_Find(FP_SourceTable("tTQMComenzi"), CStr(a(9)))
                    If order Is Nothing Then Err.Raise vbObjectError + 553, , "Comanda sursa nu mai exista."
                    If CStr(order.Cells(1, 9).Value2) = "Anulata" Or FP_Norm(CStr(order.Cells(1, 4).Value2)) <> FP_Norm(partner) Then Err.Raise vbObjectError + 554, , "Comanda este anulata sau are alt furnizor."
                    If Len(CStr(a(10))) > 0 Then
                        Set pos = FP_Find(FP_SourceTable("tTQMCFPoz"), CStr(a(10)))
                        If pos Is Nothing Then Err.Raise vbObjectError + 555, , "Pozitia sursa nu mai exista."
                        If CStr(pos.Cells(1, 2).Value2) <> CStr(a(9)) Then Err.Raise vbObjectError + 556, , "Pozitia apartine altei comenzi."
                    End If
                    If Len(CStr(a(11))) > 0 Then
                        Set source = Nothing
                        For Each row In FP_SourceTable("tTQMCFRec").DataBodyRange.rows
                            If CStr(row.Cells(1, 1).Value2) = CStr(a(11)) And CStr(row.Cells(1, 2).Value2) = CStr(a(10)) And CStr(row.Cells(1, 7).Value2) = "Valida" Then Set source = row: Exit For
                        Next row
                        If source Is Nothing Then Err.Raise vbObjectError + 557, , "Receptia sursa nu mai este valida."
                    End If
                End If
                FP_NMProject CStr(a(3)), a
                tn = tn + sg * net: tt = tt + sg * tax: records.Add a
            End If
        End If
    Next n
    If records.count = 0 Then Err.Raise vbObjectError + 558, , "Nu exista sume de salvat."
    tn = FP_Money(tn, "Net total", True): tt = FP_Money(tt, "TVA total", True)
    For i = 1 To 24: h(i) = "": Next i
    h(1) = number: h(2) = dat: h(3) = partner: h(4) = cif: h(5) = kind: h(6) = due: h(7) = tn: h(8) = tt
    h(14) = doc: h(15) = FP_Text(ws.Range("B10").Value2): h(16) = id: h(17) = mOther: h(18) = person: h(19) = "Valida"
    h(20) = CDbl(Now): h(21) = CDbl(Now): h(22) = Empty
    If mSourceKind = "CONTROL" Then h(15) = CStr(h(15)) & " | " & CStr(ws.Range("B12").Value2)
    FP_Conflict
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: writing = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    Set row = FP_Add(FP_Table(1), 16): FP_Write row, h
    For Each v In records: Set row = FP_Add(FP_Table(2)): FP_Write row, v: Next v
Call FP_Calc:     FP_CheckLedger
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS: writing = False
    Call FP_Close:     MsgBox "Factura a fost inregistrata: " & number & vbCrLf & "Ctrl+S salveaza registrul principal.", vbInformation, "TQM"
    Exit Sub
Fail:
    msg = Err.description
    If writing Then
        On Error Resume Next
        FP_Delete FP_Table(2), 2, id: FP_Delete FP_Table(1), 16, id: FP_Calc
        Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
        On Error GoTo 0
    End If
    FP_Error msg
End Sub

Private Function FP_Paid(ByVal invoice As String, Optional ByVal repartition As String = "") As Currency
    Dim lr As ListRow
    For Each lr In FP_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 14).Value2) = "Valida" And CStr(lr.Range.Cells(1, 3).Value2) = invoice Then
            If Len(repartition) = 0 Or CStr(lr.Range.Cells(1, 4).Value2) = repartition Then FP_Paid = FP_Paid + CCur(lr.Range.Cells(1, 7).Value2)
        End If
    Next lr
End Function

Private Function FP_Balance(ByVal inv As Range) As Currency
    FP_Balance = CCur(inv.Cells(1, 7).Value2) + CCur(inv.Cells(1, 8).Value2) - FP_Paid(CStr(inv.Cells(1, 16).Value2))
End Function

Private Sub FP_CheckLedger()
    Dim lr As ListRow, rep As ListRow, inv As Range, other As Range, original As Range, source As Range
    Dim kind As Long, lo As ListObject, seen As Object, idCol As Long, id As String, net As Currency, tax As Currency, face As Currency, paid As Currency
    Dim amount As Currency, total As Currency, bal As Currency, operations As Object, pairs As Object, partners As Object, key As Variant, op As String
    For kind = 1 To 3
        Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare: Set lo = FP_Table(kind): idCol = 1: If kind = 1 Then idCol = 16
        For Each lr In lo.ListRows
            id = CStr(lr.Range.Cells(1, idCol).Value2)
            If Len(id) > 0 Then
                If seen.exists(id) Then Err.Raise vbObjectError + 559, , "ID duplicat in " & lo.name
                seen.Add id, True
            End If
        Next lr
    Next kind
    For Each lr In FP_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 13).Value2) = "Valida" Then
            Set inv = FP_Invoice(CStr(lr.Range.Cells(1, 2).Value2))
            net = FP_Money(lr.Range.Cells(1, 4).Value2, "Net repartizat", True): tax = FP_Money(lr.Range.Cells(1, 5).Value2, "TVA repartizat", True)
            face = net + tax: paid = FP_Paid(CStr(inv.Cells(1, 16).Value2), CStr(lr.Range.Cells(1, 1).Value2))
            If face = 0 Or Len(FP_Text(lr.Range.Cells(1, 3).Value2)) = 0 Then Err.Raise vbObjectError + 560, , "Repartizare fara suma sau proiect."
            If CStr(inv.Cells(1, 5).Value2) = "Factura" Then
                If net < 0 Or tax < 0 Or paid < 0 Or paid > face Then Err.Raise vbObjectError + 561, , "Repartizare pozitiva cu sold sau semn necorelat."
            ElseIf CStr(inv.Cells(1, 5).Value2) = "Storno" Then
                If net > 0 Or tax > 0 Or paid > 0 Or paid < face Then Err.Raise vbObjectError + 562, , "Repartizare storno cu sold sau semn necorelat."
                Set original = FP_Invoice(CStr(inv.Cells(1, 17).Value2))
                Set source = FP_Find(FP_Table(2), CStr(lr.Range.Cells(1, 16).Value2))
                If source Is Nothing Then Err.Raise vbObjectError + 563, , "Storno fara repartizare originala."
                If CStr(source.Cells(1, 2).Value2) <> CStr(original.Cells(1, 16).Value2) Or CStr(source.Cells(1, 13).Value2) <> "Valida" Or CStr(source.Cells(1, 3).Value2) <> CStr(lr.Range.Cells(1, 3).Value2) Then Err.Raise vbObjectError + 564, , "Storno repartizat pe alta factura sau alt proiect."
                If Not FP_SamePartner(inv, original) Or CStr(original.Cells(1, 5).Value2) <> "Factura" Then Err.Raise vbObjectError + 565, , "Storno are alt partener sau alta factura originala."
                If CCur(source.Cells(1, 4).Value2) + FP_Allocated(16, CStr(source.Cells(1, 1).Value2), 4) < 0 Or CCur(source.Cells(1, 5).Value2) + FP_Allocated(16, CStr(source.Cells(1, 1).Value2), 5) < 0 Then Err.Raise vbObjectError + 566, , "Storno cumulat depaseste repartizarea originala."
            Else
                Err.Raise vbObjectError + 567, , "Tip factura necunoscut."
            End If
        End If
    Next lr
    For Each lr In FP_Table(1).ListRows
        If CStr(lr.Range.Cells(1, 19).Value2) = "Valida" Then
            net = 0: tax = 0: id = CStr(lr.Range.Cells(1, 16).Value2)
            For Each rep In FP_Table(2).ListRows
                If CStr(rep.Range.Cells(1, 2).Value2) = id And CStr(rep.Range.Cells(1, 13).Value2) = "Valida" Then
                    net = net + CCur(rep.Range.Cells(1, 4).Value2): tax = tax + CCur(rep.Range.Cells(1, 5).Value2)
                End If
            Next rep
            If net <> CCur(lr.Range.Cells(1, 7).Value2) Or tax <> CCur(lr.Range.Cells(1, 8).Value2) Or net + tax = 0 Then Err.Raise vbObjectError + 568, , "Totalul facturii nu corespunde repartizarilor: " & CStr(lr.Range.Cells(1, 1).Value2)
        End If
    Next lr
    Set operations = CreateObject("Scripting.Dictionary"): Set pairs = CreateObject("Scripting.Dictionary"): Set partners = CreateObject("Scripting.Dictionary")
    For Each lr In FP_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 14).Value2) = "Valida" Then
            id = CStr(lr.Range.Cells(1, 3).Value2): Set inv = FP_Invoice(id)
            Set source = FP_Find(FP_Table(2), CStr(lr.Range.Cells(1, 4).Value2))
            If source Is Nothing Then Err.Raise vbObjectError + 569, , "Plata fara repartizare."
            If CStr(source.Cells(1, 2).Value2) <> id Or CStr(source.Cells(1, 13).Value2) <> "Valida" Or CStr(source.Cells(1, 3).Value2) <> CStr(lr.Range.Cells(1, 5).Value2) Then Err.Raise vbObjectError + 570, , "Plata repartizata pe alt proiect sau alta factura."
            amount = FP_Money(lr.Range.Cells(1, 7).Value2, "Suma miscarii", True)
            face = CCur(inv.Cells(1, 7).Value2) + CCur(inv.Cells(1, 8).Value2)
            If amount = 0 Or Sgn(amount) <> Sgn(face) Then Err.Raise vbObjectError + 571, , "Plata are semn necorelat cu factura."
            Select Case CStr(lr.Range.Cells(1, 8).Value2)
            Case "Plata": If face < 0 Then Err.Raise vbObjectError + 572, , "Plata pozitiva legata de storno."
            Case "Restituire": If face > 0 Then Err.Raise vbObjectError + 573, , "Restituire legata de factura pozitiva."
            Case "Compensare"
                op = CStr(lr.Range.Cells(1, 2).Value2): Set other = FP_Invoice(CStr(lr.Range.Cells(1, 19).Value2))
                If Not FP_SamePartner(inv, other) Or CStr(other.Cells(1, 16).Value2) = id Then Err.Raise vbObjectError + 574, , "Compensare intre facturi incompatibile."
                If Sgn(CCur(other.Cells(1, 7).Value2) + CCur(other.Cells(1, 8).Value2)) = Sgn(face) Then Err.Raise vbObjectError + 575, , "Compensarea necesita o factura si un storno."
                If Not operations.exists(op) Then
                    operations.Add op, CCur(0): pairs.Add op, id & "|" & CStr(other.Cells(1, 16).Value2)
                    partners.Add op, CStr(other.Cells(1, 16).Value2) & "|" & id
                End If
                key = id & "|" & CStr(other.Cells(1, 16).Value2)
                If CStr(key) <> CStr(pairs(op)) And CStr(key) <> CStr(partners(op)) Then Err.Raise vbObjectError + 576, , "Compensare cu mai mult de doua facturi."
                operations(op) = CCur(operations(op)) + amount
            Case Else: Err.Raise vbObjectError + 577, , "Tip de miscare financiara necunoscut."
            End Select
        End If
    Next lr
    For Each key In operations.keys
        If CCur(operations(key)) <> 0 Then Err.Raise vbObjectError + 578, , "Compensarea nu este echilibrata."
    Next key
End Sub

Public Sub FP_Plata()
    Dim id As String
    On Error GoTo Fail
Call FP_Init:     Call FP_Calc: FP_CheckLedger: id = FP_Selected()
    FP_OpenSettlement id, "", "PLATA"
    Exit Sub
Fail: FP_Error Err.description
End Sub

Public Sub FP_Compenseaza()
    Dim id As String, inv As Range, lr As ListRow, ws As Worksheet, n As Long, i As Long, heads As Variant
    On Error GoTo Fail
Call FP_Init:     Call FP_Calc: FP_CheckLedger: id = FP_Selected(): Set inv = FP_Invoice(id)
    If FP_Balance(inv) <= 0 Then Err.Raise vbObjectError + 579, , "Selectati o factura pozitiva cu sold de plata."
    If Not FP_Start("CREDIT") Then Exit Sub
    mInvoice = id: Set ws = mForm.Worksheets(1)
    FP_Band ws, "A1:G1", "TQM - Alegeti storno pentru compensare cu " & CStr(inv.Cells(1, 1).Value2), 16
    FP_Button ws, "A3:C3", "Pregateste compensarea", "FP_PreiaCredit": FP_Button ws, "D3:F3", "Inchide lista", "FP_InchideFormular"
    heads = Split("Nr_storno|Data|Partener|Credit disponibil RON|Factura originala|Proiecte|Observatii|ID_factura", "|")
    For i = 0 To UBound(heads): ws.Cells(5, i + 1).Value2 = heads(i): Next i
    n = 6
    For Each lr In FP_Table(1).ListRows
        If CStr(lr.Range.Cells(1, 19).Value2) = "Valida" And CStr(lr.Range.Cells(1, 5).Value2) = "Storno" Then
            If FP_SamePartner(inv, lr.Range) And FP_Balance(lr.Range) < 0 Then
                ws.Cells(n, 1).Value2 = lr.Range.Cells(1, 1).Value2: ws.Cells(n, 2).Value2 = lr.Range.Cells(1, 2).Value2
                ws.Cells(n, 3).Value2 = lr.Range.Cells(1, 3).Value2: ws.Cells(n, 4).Value2 = -FP_Balance(lr.Range)
                ws.Cells(n, 5).Value2 = FP_Invoice(CStr(lr.Range.Cells(1, 17).Value2)).Cells(1, 1).Value2
                ws.Cells(n, 6).Value2 = lr.Range.Cells(1, 13).Value2: ws.Cells(n, 7).Value2 = lr.Range.Cells(1, 15).Value2
                ws.Cells(n, 8).Value2 = lr.Range.Cells(1, 16).Value2: n = n + 1
            End If
        End If
    Next lr
    If n = 6 Then FP_Close: MsgBox "Nu exista credite storno disponibile pentru acest partener.", vbInformation, "TQM": Exit Sub
    ws.Columns("B").NumberFormat = "dd.mm.yyyy": ws.Columns("D").NumberFormat = "#,##0.00"
    ws.Columns("B").ColumnWidth = 14: ws.Columns("C:G").ColumnWidth = 28: ws.Columns("H").Hidden = True
    ws.Range("A5:G5").Interior.Color = RGB(31, 41, 55): ws.Range("A5:G5").Font.Color = vbWhite
    ws.Range("A5:G5").WrapText = True: ws.rows(5).RowHeight = 34: ws.Protect UserInterfaceOnly:=True
    ActiveWindow.SplitRow = 5: ActiveWindow.FreezePanes = True: ws.Range("A6").Select
    Exit Sub
Fail: FP_Error Err.description
End Sub

Public Sub FP_PreiaCredit()
    Dim id As String, other As String
    On Error GoTo Fail
    If Not FP_FormOpen Then Err.Raise vbObjectError + 580, , "Lista creditelor nu mai este deschisa."
    If Not ActiveWorkbook Is mForm Or mMode <> "CREDIT" Or ActiveCell.row < 6 Then Err.Raise vbObjectError + 581, , "Selectati storno din lista locala."
    other = CStr(mForm.Worksheets(1).Cells(ActiveCell.row, 8).Value2)
    If Len(other) = 0 Then Err.Raise vbObjectError + 582, , "Randul selectat este gol."
    Call FP_Conflict:     id = mInvoice: FP_Close: FP_OpenSettlement id, other, "COMPENSARE"
    Exit Sub
Fail: FP_Error Err.description
End Sub

Private Sub FP_OpenSettlement(ByVal id As String, ByVal otherId As String, ByVal mode As String)
    Dim ws As Worksheet, inv As Range, other As Range, amount As Currency, title As String
    On Error GoTo Fail
    Set inv = FP_Invoice(id): amount = Abs(FP_Balance(inv))
    If amount = 0 Then Err.Raise vbObjectError + 583, , "Factura are sold zero."
    title = "Plata"
    If CCur(inv.Cells(1, 7).Value2) + CCur(inv.Cells(1, 8).Value2) < 0 Then title = "Restituire de la furnizor"
    If mode = "COMPENSARE" Then
        Set other = FP_Invoice(otherId)
        If Not FP_SamePartner(inv, other) Or FP_Balance(inv) <= 0 Or FP_Balance(other) >= 0 Then Err.Raise vbObjectError + 584, , "Solduri incompatibile pentru compensare."
        If -FP_Balance(other) < amount Then amount = -FP_Balance(other)
        title = "Compensare storno"
    End If
    If Not FP_Start(mode) Then Exit Sub
    mInvoice = id: mOther = otherId: Set ws = mForm.Worksheets(1)
    FP_Band ws, "A1:I1", "TQM - " & title & " (formular local)", 16
    FP_Button ws, "A3:C3", "Salveaza operatia", "FP_SalveazaPlata": FP_Button ws, "D3:F3", "Inchide formularul", "FP_InchideFormular"
    ws.Range("A5").Value2 = "Factura": FP_Band ws, "B5:I5", CStr(inv.Cells(1, 1).Value2) & " - " & CStr(inv.Cells(1, 3).Value2)
    ws.Range("A6").Value2 = "Sold RON cu TVA": FP_Band ws, "B6:D6", "": ws.Range("B6").NumberFormat = "#,##0.00": ws.Range("B6").Value2 = FP_Balance(inv)
    If mode = "COMPENSARE" Then
        ws.Range("A7").Value2 = "Storno": FP_Band ws, "B7:I7", CStr(other.Cells(1, 1).Value2) & " - credit disponibil " & Format$(-FP_Balance(other), "#,##0.00") & " RON"
    End If
    ws.Range("A8").Value2 = "Suma (pozitiva)": FP_Input ws, "B8:D8", amount
    ws.Range("A9").Value2 = "Data": FP_Input ws, "B9:D9", CDbl(Date)
    ws.Range("A10").Value2 = "Metoda": FP_Input ws, "B10:I10", FP_SLParam("PLATA_METODA_IMPLICITA", "OP")
    If mode <> "COMPENSARE" Then FP_SLList ws.Range("B10"), "METODA_PLATA"
    If mode = "COMPENSARE" Then ws.Range("B10").Value2 = "Compensare": ws.Range("B10:I10").Locked = True
    ws.Range("A11").Value2 = "Document": FP_Input ws, "B11:I11"
    ws.Range("A12").Value2 = "Responsabil": FP_Input ws, "B12:I12", Application.UserName
    ws.Range("A13").Value2 = "Observatii": FP_Input ws, "B13:I13"
    ws.Range("A14").Value2 = "Link document": FP_Input ws, "B14:I14"
    ws.Range("B8").NumberFormat = "#,##0.00": ws.Range("B9").NumberFormat = "dd.mm.yyyy": ws.Range("B11").NumberFormat = "@"
    FP_Band ws, "A16:I17", "Operatia este o inregistrare in registru. Confirmati documentul real. Suma se repartizeaza automat pe soldurile proiectelor, exact la ban."
    ws.Range("A16:I17").WrapText = True: ws.Protect UserInterfaceOnly:=True: ws.Range("B8").Select
    Exit Sub
Fail: FP_Error Err.description
End Sub

Private Sub FP_SplitSettlement(ByVal invoiceID As String, ByVal amount As Currency, ByVal op As String, ByVal kind As String, ByVal otherId As String, ByVal meta As Variant, ByVal records As Collection)
    Dim inv As Range, lr As ListRow, ids As New Collection, projects As New Collection, caps As New Collection, shares As New Collection
    Dim v(1 To 19) As Variant, total As Currency, cap As Currency, targetCents As Currency, capCents As Currency, totalCents As Currency
    Dim share As Currency, assigned As Currency, remaining As Currency, sign As Long, i As Long, k As Long, vshare As Variant
    Set inv = FP_Invoice(invoiceID): total = Abs(FP_Balance(inv)): sign = Sgn(amount)
    If Abs(amount) > total Or amount = 0 Then Err.Raise vbObjectError + 585, , "Suma depaseste soldul facturii sau este zero."
    For Each lr In FP_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = invoiceID And CStr(lr.Range.Cells(1, 13).Value2) = "Valida" Then
            cap = Abs(CCur(lr.Range.Cells(1, 4).Value2) + CCur(lr.Range.Cells(1, 5).Value2) - FP_Paid(invoiceID, CStr(lr.Range.Cells(1, 1).Value2)))
            If cap > 0 Then ids.Add CStr(lr.Range.Cells(1, 1).Value2): projects.Add CStr(lr.Range.Cells(1, 3).Value2): caps.Add cap
        End If
    Next lr
    targetCents = Abs(amount) * 100: totalCents = total * 100
    For i = 1 To ids.count
        capCents = CCur(caps(i)) * 100
        share = CCur(Fix(CDec(targetCents) * CDec(capCents) / CDec(totalCents))) / 100
        shares.Add share: assigned = assigned + share
    Next i
    remaining = Abs(amount) - assigned
    Do While remaining > 0
        assigned = 0
        For i = 1 To ids.count
            share = CCur(shares(i))
            If share < CCur(caps(i)) And remaining > 0 Then
                share = share + CCur(0.01): shares.Remove i
                If i > shares.count Then shares.Add share Else shares.Add share, before:=i
                remaining = remaining - CCur(0.01): assigned = assigned + CCur(0.01)
            End If
        Next i
        If assigned = 0 Then Err.Raise vbObjectError + 586, , "Suma nu se poate repartiza pe soldurile proiectelor."
    Loop
    For i = 1 To ids.count
        share = CCur(shares(i))
        If share > 0 Then
            For k = 1 To 19: v(k) = "": Next k
            v(1) = FP_ID("PF"): v(2) = op: v(3) = invoiceID: v(4) = ids(i): v(5) = projects(i): v(6) = meta(1)
            v(7) = sign * share: v(8) = kind: v(9) = meta(2): v(10) = meta(3): v(11) = meta(4): v(12) = meta(5): v(13) = meta(6)
            v(14) = "Valida": v(15) = CDbl(Now): v(16) = Empty: v(19) = otherId: records.Add v
        End If
    Next i
End Sub

Public Sub FP_SalveazaPlata()
    Dim ws As Worksheet, inv As Range, other As Range, amount As Currency, bal As Currency, meta(1 To 6) As Variant
    Dim records As New Collection, v As Variant, row As Range, kind As String, op As String, oldE As Boolean, oldS As Boolean, writing As Boolean, msg As String
    On Error GoTo Fail
    If Not FP_FormOpen Then Err.Raise vbObjectError + 587, , "Formularul nu mai este deschis."
    If Not ActiveWorkbook Is mForm Or (mMode <> "PLATA" And mMode <> "COMPENSARE") Then Err.Raise vbObjectError + 588, , "Salvati din formularul platii sau compensarii."
Call FP_Init:     Call FP_Calc: FP_CheckLedger: FP_Conflict: Set ws = mForm.Worksheets(1): Set inv = FP_Invoice(mInvoice)
    amount = FP_Money(ws.Range("B8").Value2, "Suma"): bal = FP_Balance(inv)
    If amount = 0 Or amount > Abs(bal) Then Err.Raise vbObjectError + 589, , "Suma trebuie sa fie pozitiva si cel mult egala cu soldul facturii."
    meta(1) = FP_Date(ws.Range("B9").Value2): meta(2) = FP_Text(ws.Range("B10").Value2): meta(3) = FP_Text(ws.Range("B11").Value2)
    If mMode <> "COMPENSARE" Then FP_SLCheck "METODA_PLATA", CStr(meta(2))
    meta(4) = FP_Text(ws.Range("B12").Value2): meta(5) = FP_Text(ws.Range("B13").Value2): meta(6) = FP_Text(ws.Range("B14").Value2)
    If Len(CStr(meta(2))) = 0 Or Len(CStr(meta(3))) = 0 Or Len(CStr(meta(4))) = 0 Then Err.Raise vbObjectError + 590, , "Metoda, Document si Responsabil sunt obligatorii."
    If Not FP_LinkOK(CStr(meta(6))) Then Err.Raise vbObjectError + 591, , "Link document invalid."
    op = FP_ID("OPF")
    If mMode = "COMPENSARE" Then
        Set other = FP_Invoice(mOther)
        If Not FP_SamePartner(inv, other) Or bal <= 0 Or FP_Balance(other) >= 0 Or amount > -FP_Balance(other) Then Err.Raise vbObjectError + 592, , "Compensarea depaseste creditul disponibil sau facturile sunt incompatibile."
        If CDbl(meta(1)) < CDbl(inv.Cells(1, 2).Value2) Or CDbl(meta(1)) < CDbl(other.Cells(1, 2).Value2) Then Err.Raise vbObjectError + 594, , "Compensarea nu poate fi anterioara documentelor compensate."
        meta(2) = "Compensare"
        FP_CheckPaymentDuplicate mInvoice, "Compensare", meta
        FP_SplitSettlement mInvoice, amount, op, "Compensare", mOther, meta, records
        FP_SplitSettlement mOther, -amount, op, "Compensare", mInvoice, meta, records
    Else
        If CDbl(meta(1)) < CDbl(inv.Cells(1, 2).Value2) Then Err.Raise vbObjectError + 607, , "Plata sau restituirea nu poate fi anterioara facturii. Avansurile necesita o evidenta separata."
        If FP_Norm(CStr(meta(2))) = "compensare" Then Err.Raise vbObjectError + 593, , "Pentru compensare folositi butonul Compenseaza storno."
        kind = "Plata": If bal < 0 Then kind = "Restituire": amount = -amount
        FP_CheckPaymentDuplicate mInvoice, kind, meta
        FP_SplitSettlement mInvoice, amount, op, kind, "", meta, records
    End If
    FP_Conflict
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: writing = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    For Each v In records: Set row = FP_Add(FP_Table(3)): FP_Write row, v: Next v
Call FP_Calc:     FP_CheckLedger
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS: writing = False
    Call FP_Close:     MsgBox "Operatia financiara a fost inregistrata." & vbCrLf & "ID operatie: " & op & vbCrLf & "Ctrl+S salveaza registrul principal.", vbInformation, "TQM"
    Exit Sub
Fail:
    msg = Err.description
    If writing Then
        On Error Resume Next
        FP_Delete FP_Table(3), 2, op: Call FP_Calc: Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
        On Error GoTo 0
    End If
    FP_Error msg
End Sub

Private Sub FP_CheckPaymentDuplicate(ByVal id As String, ByVal kind As String, ByVal meta As Variant)
    Dim lr As ListRow
    For Each lr In FP_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 14).Value2) = "Valida" And CStr(lr.Range.Cells(1, 3).Value2) = id And CStr(lr.Range.Cells(1, 8).Value2) = kind Then
            If CDbl(lr.Range.Cells(1, 6).Value2) = CDbl(meta(1)) And FP_Norm(CStr(lr.Range.Cells(1, 9).Value2)) = FP_Norm(CStr(meta(2))) And FP_Norm(CStr(lr.Range.Cells(1, 10).Value2)) = FP_Norm(CStr(meta(3))) Then _
                Err.Raise vbObjectError + 595, , "Exista deja o operatie valida cu aceeasi factura, data, metoda si document. Verificati istoricul pentru a evita dublarea."
        End If
    Next lr
End Sub

Private Function FP_OrderNumber(ByVal id As String) As String
    Dim lo As ListObject, row As Range
    If Len(id) = 0 Then Exit Function
    FP_OrderNumber = id: Set lo = FP_SourceTable("tTQMComenzi", False)
    If Not lo Is Nothing Then
        Set row = FP_Find(lo, id)
        If Not row Is Nothing Then FP_OrderNumber = CStr(row.Cells(1, 2).Value2)
    End If
End Function

Private Function FP_ReceiptDocument(ByVal id As String) As String
    Dim lo As ListObject, lr As ListRow
    If Len(id) = 0 Then Exit Function
    FP_ReceiptDocument = id: Set lo = FP_SourceTable("tTQMCFRec", False)
    If lo Is Nothing Then Exit Function
    For Each lr In lo.ListRows
        If CStr(lr.Range.Cells(1, 1).Value2) = id Then
            FP_ReceiptDocument = CStr(lr.Range.Cells(1, 5).Value2)
            If CStr(lr.Range.Cells(1, 7).Value2) <> "Valida" Then FP_ReceiptDocument = FP_ReceiptDocument & " (sursa anulata)"
            Exit Function
        End If
    Next lr
End Function

Public Sub FP_Detalii()
    Dim id As String, inv As Range, lr As ListRow, ws As Worksheet, hs As Variant, i As Long, n As Long, firstPay As Long
    Dim cash As Currency, comp As Currency
    On Error GoTo Fail
Call FP_Init:     Call FP_Calc: id = FP_Selected(): Set inv = FP_Invoice(id, False)
    If Not FP_Start("ISTORIC") Then Exit Sub
    Set ws = mForm.Worksheets(1)
    FP_Band ws, "A1:K1", "TQM - " & CStr(inv.Cells(1, 5).Value2) & " " & CStr(inv.Cells(1, 1).Value2) & " - " & CStr(inv.Cells(1, 3).Value2), 16
    FP_Button ws, "A3:C3", "Inchide raportul", "FP_InchideFormular"
    FP_Band ws, "D3:K3", "Raport local generat la " & Format$(Now, "dd.mm.yyyy hh:nn") & ". Redeschideti pentru date actualizate."
    For Each lr In FP_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 3).Value2) = id And CStr(lr.Range.Cells(1, 14).Value2) = "Valida" Then
            If CStr(lr.Range.Cells(1, 8).Value2) = "Compensare" Then comp = comp + CCur(lr.Range.Cells(1, 7).Value2) Else cash = cash + CCur(lr.Range.Cells(1, 7).Value2)
        End If
    Next lr
    FP_Band ws, "A5:B5", "Total RON cu TVA": FP_Band ws, "C5:D5", "Stins RON": FP_Band ws, "E5:F5", "Sold RON"
    FP_Band ws, "G5:H5", "Plati / restituiri RON": FP_Band ws, "I5:J5", "Compensari RON"
    FP_Band ws, "A6:B6", "": FP_Band ws, "C6:D6", "": FP_Band ws, "E6:F6", "": FP_Band ws, "G6:H6", "": FP_Band ws, "I6:J6", ""
    ws.Range("A6:J6").NumberFormat = "#,##0.00"
    ws.Range("A6").Value2 = CCur(inv.Cells(1, 7).Value2) + CCur(inv.Cells(1, 8).Value2)
    ws.Range("C6").Value2 = FP_Paid(id): ws.Range("E6").Value2 = inv.Cells(1, 11).Value2: ws.Range("G6").Value2 = cash: ws.Range("I6").Value2 = comp
    FP_Band ws, "A7:K7", "Status: " & CStr(inv.Cells(1, 12).Value2) & " | Scadenta: " & Format$(inv.Cells(1, 6).Value2, "dd.mm.yyyy") & " | Link factura: " & CStr(inv.Cells(1, 14).Value2)
    hs = Split("Proiect|Net RON|TVA RON|Total RON|Stins RON|Sold RON|Comanda|Receptie / document|Descriere|Stare", "|")
    For i = 0 To UBound(hs): ws.Cells(9, i + 1).Value2 = hs(i): Next i
    n = 10
    For Each lr In FP_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = id Then
            ws.Cells(n, 1).Value2 = lr.Range.Cells(1, 3).Value2
            For i = 2 To 6: ws.Cells(n, i).Value2 = lr.Range.Cells(1, i + 2).Value2: Next i
            ws.Cells(n, 7).Value2 = FP_OrderNumber(CStr(lr.Range.Cells(1, 9).Value2)): ws.Cells(n, 8).Value2 = FP_ReceiptDocument(CStr(lr.Range.Cells(1, 11).Value2))
            ws.Cells(n, 9).Value2 = lr.Range.Cells(1, 12).Value2: ws.Cells(n, 10).Value2 = lr.Range.Cells(1, 13).Value2: n = n + 1
        End If
    Next lr
    ws.Range("B10:F" & n).NumberFormat = "#,##0.00": n = n + 2
    FP_Band ws, "A" & n & ":K" & n, "Istoric plati, restituiri si compensari. Copiati ID_operatie pentru anulare.", 12
    n = n + 1: firstPay = n
    hs = Split("ID_operatie|Data|Tip|Proiect|Suma RON|Metoda|Document|Responsabil|Stare|Observatii / Anulare|Link", "|")
    For i = 0 To UBound(hs): ws.Cells(n, i + 1).Value2 = hs(i): Next i
    n = n + 1
    For Each lr In FP_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 3).Value2) = id Then
            ws.Cells(n, 1).Value2 = lr.Range.Cells(1, 2).Value2: ws.Cells(n, 2).Value2 = lr.Range.Cells(1, 6).Value2
            ws.Cells(n, 3).Value2 = lr.Range.Cells(1, 8).Value2: ws.Cells(n, 4).Value2 = lr.Range.Cells(1, 5).Value2
            ws.Cells(n, 5).Value2 = lr.Range.Cells(1, 7).Value2: ws.Cells(n, 6).Value2 = lr.Range.Cells(1, 9).Value2
            ws.Cells(n, 7).Value2 = lr.Range.Cells(1, 10).Value2: ws.Cells(n, 8).Value2 = lr.Range.Cells(1, 11).Value2
            ws.Cells(n, 9).Value2 = lr.Range.Cells(1, 14).Value2: ws.Cells(n, 10).Value2 = CStr(lr.Range.Cells(1, 12).Value2) & " " & CStr(lr.Range.Cells(1, 18).Value2)
            ws.Cells(n, 11).Value2 = lr.Range.Cells(1, 13).Value2: n = n + 1
        End If
    Next lr
    ws.Range("A9:J9").Interior.Color = RGB(31, 41, 55): ws.Range("A9:J9").Font.Color = vbWhite: ws.Range("A9:J9").WrapText = True: ws.rows(9).RowHeight = 34
    ws.Range("A" & firstPay & ":K" & firstPay).Interior.Color = RGB(31, 41, 55): ws.Range("A" & firstPay & ":K" & firstPay).Font.Color = vbWhite
    ws.Range("A" & firstPay & ":K" & firstPay).WrapText = True: ws.rows(firstPay).RowHeight = 34
    ws.Range("B" & firstPay + 1 & ":B" & n).NumberFormat = "dd.mm.yyyy": ws.Range("E" & firstPay + 1 & ":E" & n).NumberFormat = "#,##0.00"
    ws.Columns("A").ColumnWidth = 42: ws.Columns("B").ColumnWidth = 14: ws.Columns("C:H").ColumnWidth = 22
    ws.Columns("I").ColumnWidth = 22: ws.Columns("J:K").ColumnWidth = 38: ws.Protect UserInterfaceOnly:=True
    ActiveWindow.SplitRow = 9: ActiveWindow.FreezePanes = True
    Exit Sub
Fail: FP_Error Err.description
End Sub

Public Sub FP_AnuleazaPlata()
    Dim id As String, answer As Variant, reason As Variant, op As String, stamp As String, lr As ListRow, row As Range
    Dim backs As Object, v As Variant, found As Boolean, oldE As Boolean, oldS As Boolean, writing As Boolean, msg As String
    On Error GoTo Fail
Call FP_Init:     Call FP_Calc: FP_CheckLedger: id = FP_Selected(): stamp = FP_Stamp()
    answer = Application.InputBox("Introduceti ID_operatie din Detalii si istoric. Se anuleaza toate repartizarile operatiei; la compensare, ambele facturi.", "TQM - Anulare operatie financiara", Type:=2)
    If VarType(answer) = vbBoolean Then Exit Sub
    op = Trim$(CStr(answer)): Set backs = CreateObject("Scripting.Dictionary")
    For Each lr In FP_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = op And CStr(lr.Range.Cells(1, 14).Value2) = "Valida" Then
            backs.Add CStr(lr.Range.Cells(1, 1).Value2), lr.Range.formula
            If CStr(lr.Range.Cells(1, 3).Value2) = id Then found = True
        End If
    Next lr
    If Not found Then Err.Raise vbObjectError + 596, , "Operatia nu este valida sau nu apartine facturii selectate."
    reason = Application.InputBox("Motivul anularii:", "TQM", Type:=2)
    If VarType(reason) = vbBoolean Then Exit Sub
    If Len(Trim$(CStr(reason))) = 0 Then Err.Raise vbObjectError + 597, , "Motivul este obligatoriu."
    If MsgBox("Anulati intreaga operatie si redeschideti soldurile? Inregistrarea nu executa o anulare bancara.", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
    If FP_Stamp() <> stamp Then Err.Raise vbObjectError + 598, , "Datele s-au modificat in timpul confirmarii. Reluati anularea."
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: writing = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    For Each v In backs.keys
        Set row = FP_Find(FP_Table(3), CStr(v))
        row.Cells(1, 14).Value2 = "Anulata": row.Cells(1, 16).Value2 = CDbl(Now): row.Cells(1, 17).Value2 = Application.UserName: row.Cells(1, 18).Value2 = CStr(reason)
    Next v
Call FP_Calc:     FP_CheckLedger
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS: writing = False
    MsgBox "Operatia a fost anulata in registru. Istoricul este pastrat. Ctrl+S salveaza registrul principal.", vbInformation, "TQM"
    Exit Sub
Fail:
    msg = Err.description
    If writing Then
        On Error Resume Next
        For Each v In backs.keys: Set row = FP_Find(FP_Table(3), CStr(v)): row.formula = backs(v): Next v
Call FP_Calc:         Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
        On Error GoTo 0
    End If
    FP_Error msg
End Sub

Public Sub FP_AnuleazaFactura()
    Dim id As String, inv As Range, lr As ListRow, row As Range, reason As Variant, stamp As String, backs As Object, oldH As Variant, v As Variant
    Dim oldE As Boolean, oldS As Boolean, writing As Boolean, msg As String
    On Error GoTo Fail
Call FP_Init:     Call FP_Calc: FP_CheckLedger: id = FP_Selected(): Set inv = FP_Invoice(id): stamp = FP_Stamp()
    For Each lr In FP_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 3).Value2) = id And CStr(lr.Range.Cells(1, 14).Value2) = "Valida" Then Err.Raise vbObjectError + 599, , "Factura are plati, restituiri sau compensari valide. Pentru o corectie reala folositi storno; pentru o eroare de introducere anulati mai intai operatiile eronate."
    Next lr
    For Each lr In FP_Table(1).ListRows
        If CStr(lr.Range.Cells(1, 17).Value2) = id And CStr(lr.Range.Cells(1, 19).Value2) = "Valida" Then Err.Raise vbObjectError + 600, , "Factura are documente storno valide. Nu se poate anula baza acestora."
    Next lr
    reason = Application.InputBox("Motivul anularii in registru:", "TQM - Anulare factura", Type:=2)
    If VarType(reason) = vbBoolean Then Exit Sub
    If Len(Trim$(CStr(reason))) = 0 Then Err.Raise vbObjectError + 601, , "Motivul este obligatoriu."
    If MsgBox("Anulati factura in registru? Datele raman in istoric. Aceasta actiune nu emite un document storno.", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
    If FP_Stamp() <> stamp Then Err.Raise vbObjectError + 602, , "Datele s-au modificat. Reluati anularea."
    Set backs = CreateObject("Scripting.Dictionary"): oldH = inv.formula
    For Each lr In FP_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = id And CStr(lr.Range.Cells(1, 13).Value2) = "Valida" Then backs.Add CStr(lr.Range.Cells(1, 1).Value2), lr.Range.formula
    Next lr
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: writing = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    inv.Cells(1, 19).Value2 = "Anulata": inv.Cells(1, 21).Value2 = CDbl(Now): inv.Cells(1, 22).Value2 = CDbl(Now)
    inv.Cells(1, 23).Value2 = Application.UserName: inv.Cells(1, 24).Value2 = CStr(reason)
    For Each v In backs.keys: Set row = FP_Find(FP_Table(2), CStr(v)): row.Cells(1, 13).Value2 = "Anulata": Next v
Call FP_Calc:     FP_CheckLedger
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS: writing = False
    MsgBox "Factura a fost anulata in registru. Istoricul este pastrat. Ctrl+S salveaza registrul principal.", vbInformation, "TQM"
    Exit Sub
Fail:
    msg = Err.description
    If writing Then
        On Error Resume Next
        inv.formula = oldH
        For Each v In backs.keys: Set row = FP_Find(FP_Table(2), CStr(v)): row.formula = backs(v): Next v
Call FP_Calc:         Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
        On Error GoTo 0
    End If
    FP_Error msg
End Sub

Public Sub FP_RegistruPlati()
    Dim ws As Worksheet, lr As ListRow, inv As Range, other As Range, n As Long, hs As Variant, i As Long, cash As Currency, comp As Currency
    On Error GoTo Fail
Call FP_Init:     FP_Calc
    If Not FP_Start("ISTORIC") Then Exit Sub
    Set ws = mForm.Worksheets(1)
    FP_Band ws, "A1:N1", "TQM - Registru plati, restituiri si compensari", 16
    FP_Button ws, "A3:C3", "Inchide raportul", "FP_InchideFormular"
    FP_Band ws, "D3:N3", "Raport local generat la " & Format$(Now, "dd.mm.yyyy hh:nn") & ". Totalurile de sus includ toate operatiile valide, indiferent de filtrul din tabel."
    For Each lr In FP_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 14).Value2) = "Valida" Then
            If CStr(lr.Range.Cells(1, 8).Value2) = "Compensare" Then
                If CCur(lr.Range.Cells(1, 7).Value2) > 0 Then comp = comp + CCur(lr.Range.Cells(1, 7).Value2)
            Else
                cash = cash + CCur(lr.Range.Cells(1, 7).Value2)
            End If
        End If
    Next lr
    FP_Band ws, "A5:C5", "Plati minus restituiri (RON)": FP_Band ws, "D5:F5", "Compensari pe facturi pozitive (RON)"
    FP_Band ws, "A6:C6", "": FP_Band ws, "D6:F6", "": ws.Range("A6:F6").NumberFormat = "#,##0.00"
    ws.Range("A6").Value2 = cash: ws.Range("D6").Value2 = comp
    hs = Split("ID_operatie|Nr_factura|Partener|Data|Proiect|Suma RON|Tip|Metoda|Document|Responsabil|Stare|Factura pereche|Observatii / Anulare|Link", "|")
    For i = 0 To UBound(hs): ws.Cells(8, i + 1).Value2 = hs(i): Next i
    n = 9
    For Each lr In FP_Table(3).ListRows
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then
            Set inv = FP_Invoice(CStr(lr.Range.Cells(1, 3).Value2), False)
            ws.Cells(n, 1).Value2 = lr.Range.Cells(1, 2).Value2: ws.Cells(n, 2).Value2 = inv.Cells(1, 1).Value2
            ws.Cells(n, 3).Value2 = inv.Cells(1, 3).Value2: ws.Cells(n, 4).Value2 = lr.Range.Cells(1, 6).Value2
            ws.Cells(n, 5).Value2 = lr.Range.Cells(1, 5).Value2: ws.Cells(n, 6).Value2 = lr.Range.Cells(1, 7).Value2
            ws.Cells(n, 7).Value2 = lr.Range.Cells(1, 8).Value2: ws.Cells(n, 8).Value2 = lr.Range.Cells(1, 9).Value2
            ws.Cells(n, 9).Value2 = lr.Range.Cells(1, 10).Value2: ws.Cells(n, 10).Value2 = lr.Range.Cells(1, 11).Value2
            ws.Cells(n, 11).Value2 = lr.Range.Cells(1, 14).Value2
            If Len(CStr(lr.Range.Cells(1, 19).Value2)) > 0 Then
                Set other = FP_Invoice(CStr(lr.Range.Cells(1, 19).Value2), False): ws.Cells(n, 12).Value2 = other.Cells(1, 1).Value2
            End If
            ws.Cells(n, 13).Value2 = CStr(lr.Range.Cells(1, 12).Value2) & " " & CStr(lr.Range.Cells(1, 18).Value2)
            ws.Cells(n, 14).Value2 = lr.Range.Cells(1, 13).Value2: n = n + 1
        End If
    Next lr
    ws.Columns("A").ColumnWidth = 42: ws.Columns("B:C").ColumnWidth = 24: ws.Columns("D").ColumnWidth = 14
    ws.Columns("E").ColumnWidth = 28: ws.Columns("F:H").ColumnWidth = 18: ws.Columns("I:J").ColumnWidth = 24
    ws.Columns("K:L").ColumnWidth = 18: ws.Columns("M:N").ColumnWidth = 36
    ws.Range("D9:D" & n).NumberFormat = "dd.mm.yyyy": ws.Range("F9:F" & n).NumberFormat = "#,##0.00"
    ws.Range("A8:N8").Interior.Color = RGB(31, 41, 55): ws.Range("A8:N8").Font.Color = vbWhite
    ws.Range("A8:N8").WrapText = True: ws.rows(8).RowHeight = 34
    ws.Range("A8:N" & n).AutoFilter: ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    ActiveWindow.SplitRow = 8: ActiveWindow.SplitColumn = 2: ActiveWindow.FreezePanes = True
    Exit Sub
Fail: FP_Error Err.description
End Sub

Private Sub FP_NMPartner(ByVal labelName As String, ByVal cif As String, ByVal historical As Boolean)
    Dim ws As Worksheet
    Set ws = FP_GetSheet("06_NOMENCLATOARE")
    If ws Is Nothing Then Exit Sub
    If mSourceKind = "CONTROL" Then
        historical = (FP_Norm(labelName) = FP_Norm(CStr(TQM_Control_Cell(ThisWorkbook.Worksheets("Control_Achizitii"), TQM_Control_RowID(mSource), 7).Value2)))
    End If
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_ValidatePartner", labelName, cif, historical
End Sub
Private Sub FP_NMProject(ByVal labelName As String, ByVal line As Variant)
    Dim ws As Worksheet, prior As Range, historical As Boolean
    Set ws = FP_GetSheet("06_NOMENCLATOARE")
    If ws Is Nothing Then Exit Sub
    If mSourceKind = "STORNO" Then
        historical = True
    ElseIf Len(CStr(line(10))) > 0 Then
        Set prior = FP_Find(FP_SourceTable("tTQMCFPoz"), CStr(line(10)))
        If Not prior Is Nothing Then historical = (CStr(prior.Cells(1, 16).Value2) = labelName)
    ElseIf Len(CStr(line(9))) > 0 Then
        Set prior = FP_Find(FP_SourceTable("tTQMComenzi"), CStr(line(9)))
        If Not prior Is Nothing Then historical = (CStr(prior.Cells(1, 5).Value2) = labelName)
    ElseIf mSourceKind = "CONTROL" Then
        historical = (CStr(TQM_Control_Cell(ThisWorkbook.Worksheets("Control_Achizitii"), TQM_Control_RowID(mSource), 6).Value2) = labelName)
    End If
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_ValidateProject", labelName, historical
End Sub

Private Function FP_SLParam(ByVal key As String, ByVal fallback As Variant) As Variant
    Dim ws As Worksheet
    Set ws = FP_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then
        FP_SLParam = fallback
    Else
        FP_SLParam = Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_Param", key, fallback)
    End If
End Function
Private Sub FP_SLList(ByVal target As Range, ByVal group As String)
    Dim ws As Worksheet
    Set ws = FP_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then Exit Sub
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_ApplyList", target, group
End Sub
Private Sub FP_SLCheck(ByVal group As String, ByVal value As String)
    Dim ws As Worksheet
    Set ws = FP_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then Exit Sub
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_CheckValue", group, value
End Sub

Private Sub FP_PBSync()
    On Error Resume Next
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!PB_Sync"
    On Error GoTo 0
End Sub

Private Sub FP_DOCSync()
    On Error Resume Next
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!DOC_Sync"
    On Error GoTo 0
End Sub



Public Sub FP_RFQRefresh()
    FP_Init
    FP_Calc
    FP_CheckLedger
End Sub
