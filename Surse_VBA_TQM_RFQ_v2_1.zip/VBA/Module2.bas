Attribute VB_Name = "Module2"
Option Explicit
' TQM Setari Liste v1. Configurare locala; reguli interne confirmate explicit.
Private Const SL_Sheet As String = "07_SETARI_LISTE"
Private Const SL_MARK As String = "TQM_SL_V1"
Private mForm As Workbook
Private mKind As Long, mViewKind As Long, mID As String, mStamp As String
Private Type SL_GUID
    Data1 As Long
    Data2 As Integer
    Data3 As Integer
    Data4(0 To 7) As Byte
End Type
#If VBA7 Then
Private Declare PtrSafe Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As SL_GUID) As Long
#Else
Private Declare Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As SL_GUID) As Long
#End If

Private Function SL_Heads(ByVal kind As Long) As Variant
    Select Case kind
    Case 1: SL_Heads = Split("Cod_setare|Denumire|Valoare|Tip|UM|Utilizare|Revizie|Actualizat_la|Actualizat_de|ID_setare", "|")
    Case 2: SL_Heads = Split("ID_lista|Grupa|Valoare|Activ|Ordine|Sistem|Observatii|Revizie|Actualizat_la|Actualizat_de", "|")
    Case 3: SL_Heads = Split("Cheie_regula|Tip_partener|Tip_intrare|Aviz|Decl_conformitate|Decl_producator|Fise_tehnice|Stare|Observatii|Revizie|Actualizat_la|Actualizat_de|ID_regula", "|")
    Case 4: SL_Heads = Split("ID_eveniment|Data|Utilizator|Entitate|ID_inregistrare|Actiune|Revizie|Camp|Valoare_veche|Valoare_noua", "|")
    End Select
End Function
Private Function SL_Names() As Variant
    SL_Names = Array(SL_Sheet, "_TQM_SL_LISTE", "_TQM_SL_REGULI", "_TQM_SL_LOG")
End Function
Private Function SL_Groups() As Variant
    SL_Groups = Split("TIP_PARTENER_CONTROL|TIP_INTRARE|STATUT_DOCUMENT|CANAL_COMANDA|STARE_COMANDA|PRIORITATE|CONFORM_TEHNIC|STARE_NOMENCLATOR|TIP_PARTENER_NM|TIP_LOCATIE|METODA_PLATA|UM|CATEGORIE|DA_NU|STARE_REGULA", "|")
End Function
Private Function SL_Seed(ByVal kind As Long) As Collection
    Dim result As New Collection
    Select Case kind
    Case 1
        result.Add Array("COMANDA_TERMEN_ZILE", "Termen implicit comand" & ChrW(259), 7, "Intreg", "zile", "Comenzi furnizori: data comenzii + termen", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SP-83510113-6D9C-4A71-A229-CE3B5E01385B")
        result.Add Array("CERERE_TERMEN_ZILE", "Termen implicit cerere", 7, "Intreg", "zile", "Cereri: data necesar" & ChrW(259) & " pe " & ChrW(537) & "antier", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SP-450BA395-ACCE-4519-B469-6346D452BD23")
        result.Add Array("OFERTA_VALABILA_ZILE", "Valabilitate implicit" & ChrW(259) & " ofert" & ChrW(259), 30, "Intreg", "zile", "Oferte noi: valabil" & ChrW(259) & " p" & ChrW(226) & "n" & ChrW(259) & " la", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SP-9DD739A5-A99D-4CDF-9CF1-6491D632AC5C")
        result.Add Array("OFERTA_LIVRARE_ZILE", "Livrare implicit" & ChrW(259) & " ofert" & ChrW(259), 2, "Intreg", "zile", "Oferte noi: data estimat" & ChrW(259) & " a livr" & ChrW(259) & "rii", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SP-20F3DDD2-5026-4919-BEEA-C32ABE05683E")
        result.Add Array("FACTURA_SCADENTA_ZILE", "Scaden" & ChrW(539) & ChrW(259) & " implicit" & ChrW(259) & " factur" & ChrW(259), 30, "Intreg", "zile", "Facturi noi " & ChrW(537) & "i preluate din Control Achizi" & ChrW(539) & "ii", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SP-89E4CA9B-2CE8-4D20-9087-5402C4F8E55A")
        result.Add Array("STOC_LOCATIE_IMPLICITA", "Loca" & ChrW(539) & "ie implicit" & ChrW(259) & " recep" & ChrW(539) & "ie", "Depozit", "Text", "", "Recep" & ChrW(539) & "ii " & ChrW(537) & "i stoc ini" & ChrW(539) & "ial; loca" & ChrW(539) & "ia se valideaz" & ChrW(259) & " " & ChrW(238) & "n Nomenclatoare", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SP-3D852AE3-890E-48B8-91D1-C4FE926BEC9E")
        result.Add Array("PLATA_METODA_IMPLICITA", "Metod" & ChrW(259) & " implicit" & ChrW(259) & " plat" & ChrW(259), "OP", "Lista", "", "Pl" & ChrW(259) & ChrW(539) & "i " & ChrW(537) & "i restituiri; compensarea are flux separat", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SP-5B892B5E-865A-472C-B720-5DE670453E77")
    Case 2
        result.Add Array("SL-37CEDAFF-042B-4A07-BB79-0AC98ED75593", "TIP_PARTENER_CONTROL", "Furnizor", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-A392D2BB-44A1-4E6B-B6A5-FBCE9F0C7AE5", "TIP_PARTENER_CONTROL", "Producator", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-3F9F701C-81E4-4322-9F68-2AB5766C78AC", "TIP_PARTENER_CONTROL", "Prestator", "Da", 3, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-8429B234-0C2C-48BE-ACDA-4974FEB17AE6", "TIP_PARTENER_CONTROL", "Alt partener", "Da", 4, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-1E168F10-CFB0-44E5-BB4F-57B0DD075D8A", "TIP_INTRARE", "Factura", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-6295E22B-7C54-42DC-8003-4981DCB50423", "TIP_INTRARE", "Doar Aviz (Fara Factura)", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-BDF2F329-B1AE-49E8-B323-E889E2AF0E56", "STATUT_DOCUMENT", "Primit", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-302D8A08-688B-4517-8F57-6CE24505AC22", "STATUT_DOCUMENT", "Lipsa", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-0E04DE70-86C5-4BBC-B0F5-D4D21581BC2B", "STATUT_DOCUMENT", "N/A", "Da", 3, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-A5D95965-416B-4931-9CF0-6921CD6ED08F", "CANAL_COMANDA", "Ferma", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-AF7A7344-66AE-41A7-AA17-ED331832AEA6", "CANAL_COMANDA", "Online", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-64881A0B-DA0B-4986-A94B-ABD9795F2346", "STARE_COMANDA", "Ciorna", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-0B3ABC12-933B-4FF8-B7BC-9C6777DCC27B", "STARE_COMANDA", "Trimisa", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-1758927A-D016-4B75-8A5E-3CE068FFB936", "STARE_COMANDA", "Confirmata", "Da", 3, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-542475CD-5E48-4F91-8643-7F595AB15E7B", "PRIORITATE", "Normala", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-BD21A1A6-DF84-4A97-A21F-0E758C441EB5", "PRIORITATE", "Ridicata", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-9D4262D9-BC15-4DA2-8FCB-A0624D91AEA9", "PRIORITATE", "Urgenta", "Da", 3, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-5C6E8926-6597-48C2-B6AB-E512EE01AA55", "CONFORM_TEHNIC", "Da", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-E39104D8-58A1-4C94-9E3A-C471A6BC6C61", "CONFORM_TEHNIC", "Nu", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-968C5E6A-058C-4255-97ED-A26AF13E948F", "CONFORM_TEHNIC", "De verificat", "Da", 3, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-D4360A5B-D46B-4FCB-ADE5-C6039E2A1BF5", "STARE_NOMENCLATOR", "Activ", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-2E2115A4-1696-4099-8900-A2D00528947B", "STARE_NOMENCLATOR", "Inactiv", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-8AD15D5D-5C03-421C-9A7B-2A6862EE923C", "STARE_NOMENCLATOR", "De verificat", "Da", 3, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-60F24614-B302-403C-81FA-8AB783384215", "TIP_PARTENER_NM", "Furnizor", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-86FB38C5-981E-4982-A4F2-87FBB686CCDF", "TIP_PARTENER_NM", "Producator", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-44342B4C-5DE6-4305-8F9B-0DA117DA34C1", "TIP_PARTENER_NM", "Prestator", "Da", 3, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-1F3BB8F0-8E52-427F-BA8B-D0DEAB1E8AC4", "TIP_PARTENER_NM", "Alt partener", "Da", 4, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-8849A846-F5B7-436E-B5C9-4F00CE99C4ED", "TIP_PARTENER_NM", "Client", "Da", 5, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-2118E45D-BF52-4990-82D6-556A54F5D06E", "TIP_PARTENER_NM", "Mixt", "Da", 6, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-EA79F473-BD7E-4FB0-B6D6-0516B8E1A707", "TIP_LOCATIE", "Depozit", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-37303F14-E887-48E0-9527-3B596904FE4F", "TIP_LOCATIE", "Santier", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-5C6A889E-C8D5-47D8-9704-6BE63804B857", "TIP_LOCATIE", "Alta locatie", "Da", 3, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-F1A6266B-4858-49FA-8731-7B597DB4AB38", "METODA_PLATA", "OP", "Da", 1, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-EF9D9BA9-248A-444A-B94B-025B3474BC0C", "METODA_PLATA", "Numerar", "Da", 2, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-7A132816-4A6A-4C19-B487-7AB8F78A3FDC", "METODA_PLATA", "Card", "Da", 3, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-0BC01293-8293-47C7-A0F8-BB23C79CCFAC", "METODA_PLATA", "Alta", "Da", 4, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-CD6311C3-A0C0-4185-8DCF-15B18D504634", "UM", "m", "Da", 1, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-DBA84972-9BEA-4043-9F07-71FC540D39C5", "UM", "buc", "Da", 2, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-06AEE1EA-1FCF-45B4-BEA9-9DEA6E4B338A", "UM", "set", "Da", 3, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-C7C6083D-4400-48E4-959C-98E04A332464", "UM", "kg", "Da", 4, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-3C483F36-A2DC-4E62-ACE5-D5A8771C175F", "UM", "l", "Da", 5, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-BA3BD4CD-359C-4DE1-87E1-BA093A19675B", "CATEGORIE", "Cabluri", "Da", 1, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-720E93D6-5ACD-436F-8F21-2480656031C1", "CATEGORIE", "Aparataj", "Da", 2, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-81591194-425E-48B2-A36B-BAFC803C89C1", "CATEGORIE", "Accesorii cabluri", "Da", 3, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-83F3ABDF-6F92-489C-99A2-865C2BEA4096", "CATEGORIE", "Tablouri electrice", "Da", 4, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-40CA9CCE-4D24-46CB-A726-DC4286BD1FCF", "CATEGORIE", "Prindere " & ChrW(537) & "i montaj", "Da", 5, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-EF775153-4B2F-4D77-9418-66FBB343CD5D", "CATEGORIE", "Comunica" & ChrW(539) & "ii " & ChrW(537) & "i IT", "Da", 6, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-E952E442-1F59-4EE1-9AC2-398E5EF2C8C4", "CATEGORIE", ChrW(206) & "mp" & ChrW(259) & "m" & ChrW(226) & "ntare " & ChrW(537) & "i protec" & ChrW(539) & "ie", "Da", 7, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-D15AD7A9-8406-4BAA-BA79-4A7CB32E44D4", "CATEGORIE", "Consumabile electrice", "Da", 8, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-DF3026DC-489A-4666-B98E-0518CD3BEEEB", "CATEGORIE", "Unelte " & ChrW(537) & "i echipamente", "Da", 9, "Nu", "Cod stabil; dezactivarea p" & ChrW(259) & "streaz" & ChrW(259) & " istoricul.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-F0AF4E0B-0921-49D5-A35A-444C8D6A8EB0", "DA_NU", "Da", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-E8465A82-C8B5-4DEA-90B3-7CFB477231EE", "DA_NU", "Nu", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-D9F166CC-98D2-4585-A062-815D5850B082", "STARE_REGULA", "De confirmat", "Da", 1, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
        result.Add Array("SL-7B886790-B694-4DC6-A4E2-ACFCBFBFC5C1", "STARE_REGULA", "Confirmata", "Da", 2, "Da", "Valoare de sistem folosit" & ChrW(259) & " de macro-uri.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259))
    Case 3
        result.Add Array("Furnizor|Factura", "Furnizor", "Factura", "Nu", "Da", "Nu", "Nu", "De confirmat", "Propunere de lucru. Confirma" & ChrW(539) & "i cerin" & ChrW(539) & "ele interne " & ChrW(238) & "nainte de utilizare.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SR-BD5BFA2B-9A6D-4838-8E21-89E7B295A38B")
        result.Add Array("Furnizor|Doar Aviz", "Furnizor", "Doar Aviz", "Da", "Da", "Nu", "Nu", "De confirmat", "Propunere de lucru. Confirma" & ChrW(539) & "i cerin" & ChrW(539) & "ele interne " & ChrW(238) & "nainte de utilizare.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SR-C15C8880-A8A3-4B5E-9161-30B4B9E1FACB")
        result.Add Array("Producator|Factura", "Producator", "Factura", "Nu", "Nu", "Da", "Nu", "De confirmat", "Propunere de lucru. Confirma" & ChrW(539) & "i cerin" & ChrW(539) & "ele interne " & ChrW(238) & "nainte de utilizare.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SR-BE91A01A-8E45-4E02-A8E8-8BE65260196C")
        result.Add Array("Producator|Doar Aviz", "Producator", "Doar Aviz", "Da", "Nu", "Da", "Nu", "De confirmat", "Propunere de lucru. Confirma" & ChrW(539) & "i cerin" & ChrW(539) & "ele interne " & ChrW(238) & "nainte de utilizare.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SR-379E1896-99EB-4116-A006-C94A0F10D257")
        result.Add Array("Prestator|Factura", "Prestator", "Factura", "Nu", "Nu", "Nu", "Nu", "De confirmat", "Propunere de lucru. Confirma" & ChrW(539) & "i cerin" & ChrW(539) & "ele interne " & ChrW(238) & "nainte de utilizare.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SR-66D64FF6-6A38-4591-A2B7-49534E4F0E3C")
        result.Add Array("Prestator|Doar Aviz", "Prestator", "Doar Aviz", "Da", "Nu", "Nu", "Nu", "De confirmat", "Propunere de lucru. Confirma" & ChrW(539) & "i cerin" & ChrW(539) & "ele interne " & ChrW(238) & "nainte de utilizare.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SR-3422B8F2-0B8F-461C-99C0-C92A412018E9")
        result.Add Array("Alt partener|Factura", "Alt partener", "Factura", "Nu", "Nu", "Nu", "Nu", "De confirmat", "Propunere de lucru. Confirma" & ChrW(539) & "i cerin" & ChrW(539) & "ele interne " & ChrW(238) & "nainte de utilizare.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SR-8629798C-C7B8-4AAA-A6DE-2D345133F857")
        result.Add Array("Alt partener|Doar Aviz", "Alt partener", "Doar Aviz", "Da", "Nu", "Nu", "Nu", "De confirmat", "Propunere de lucru. Confirma" & ChrW(539) & "i cerin" & ChrW(539) & "ele interne " & ChrW(238) & "nainte de utilizare.", 1, 46304#, "Configurare ini" & ChrW(539) & "ial" & ChrW(259), "SR-3FF9C422-ECD5-4EAD-9C6B-30ABCFA0D49F")
    End Select
    Set SL_Seed = result
End Function
Private Sub SL_EnsureStructure()
    Dim names As Variant, tableNames As Variant, k As Long, ws As Worksheet, lo As ListObject, hs As Variant, n As Long
    Dim seed As Collection, value As Variant, row As Range, firstRow As Long, created As Boolean
    names = SL_Names(): tableNames = Array("tTQMSetari", "tTQMListe", "tTQMReguliDoc", "tTQMSLJurnal")
    If ThisWorkbook.readonly Or ThisWorkbook.ProtectStructure Then Err.Raise vbObjectError + 819, , "Fisierul trebuie sa fie editabil, cu structura neprotejata."
    Set ws = SL_GetSheet(SL_Sheet)
    If Not ws Is Nothing Then
        If CStr(ws.Range("L1").Value2) <> SL_MARK Then Err.Raise vbObjectError + 818, , "Foaia Setari Liste contine alta structura. Nu a fost modificata."
    End If
    For k = 1 To 4
        Set ws = SL_GetSheet(CStr(names(k - 1)))
        If ws Is Nothing Then
            Set ws = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
            ws.name = CStr(names(k - 1)): hs = SL_Heads(k): firstRow = IIf(k = 1, 12, 1)
            ws.Cells(firstRow, 1).Resize(1, UBound(hs) + 1).Value2 = hs
            Set lo = ws.ListObjects.Add(xlSrcRange, ws.Cells(firstRow, 1).Resize(2, UBound(hs) + 1), , xlYes)
            lo.name = CStr(tableNames(k - 1)): lo.TableStyle = "TableStyleMedium2"
            Set seed = SL_Seed(k): n = firstRow + 1
            For Each value In seed
                If n > lo.Range.rows.count + firstRow - 1 Then lo.ListRows.Add
                Set row = ws.Cells(n, 1).Resize(1, UBound(hs) + 1): row.NumberFormat = "@": row.Value2 = value
                If k = 1 Then row.Cells(1, 10).Value2 = SL_ID("SP")
                If k = 2 Then row.Cells(1, 1).Value2 = SL_ID("SL")
                If k = 3 Then row.Cells(1, 13).Value2 = SL_ID("SR")
                n = n + 1
            Next value
            ws.Cells.Font.name = "Aptos": ws.Cells.Font.size = 10: ws.rows.RowHeight = 26: ws.Columns.ColumnWidth = 24
            ws.Cells(firstRow, 1).Resize(1, UBound(hs) + 1).Interior.Color = RGB(31, 41, 55)
            ws.Cells(firstRow, 1).Resize(1, UBound(hs) + 1).Font.Color = vbWhite
            ws.rows(firstRow).RowHeight = 42: ws.rows(firstRow).WrapText = True
            If k = 1 Then
                created = True: ws.Range("L1").Value2 = SL_MARK
                SL_Band ws, "A2:F2", "TQM Calarasi - Setari Liste": ws.Range("A2").Font.size = 18
                SL_Band ws, "A3:F3", "Parametri comuni, liste dropdown si reguli pentru documente."
                SL_Band ws, "A4:F4", "Regulile sunt propuneri interne; confirmati fiecare profil inainte de utilizare."
                SL_Band ws, "A11:F11", "Selectati un parametru din tabel si apasati Editeaza parametru."
                ws.Columns("A:B").ColumnWidth = 34: ws.Columns("F").ColumnWidth = 60: ws.Columns("C").ColumnWidth = 20
                ws.Columns("D").ColumnWidth = 12: ws.Columns("E").ColumnWidth = 9
                ws.Range("A13:F19").WrapText = True: ws.rows("13:19").RowHeight = 46
                ws.Range("C13:C17").NumberFormat = "0": ws.Range("H13:H19").NumberFormat = "dd.mm.yyyy hh:mm"
                SL_Band ws, "A8:B8", "Parametri comuni": SL_Band ws, "A9:B9", ""
                SL_Band ws, "C8:D8", "Valori active in liste": SL_Band ws, "C9:D9", ""
                SL_Band ws, "E8:F8", "Profiluri de confirmat": SL_Band ws, "E9:F9", ""
                ws.Range("A8:F9").Interior.Color = RGB(239, 246, 255): ws.rows(9).RowHeight = 36
                ws.Range("A9:F9").Font.size = 18: ws.Range("A9:F9").Font.Bold = True
            Else
                If k = 2 Then ws.Columns("I").NumberFormat = "dd.mm.yyyy hh:mm"
                If k = 3 Then ws.Columns("K").NumberFormat = "dd.mm.yyyy hh:mm"
                ws.Visible = xlSheetVeryHidden
            End If
        End If
    Next k
    If created Then
        Set ws = SL_GetSheet(SL_Sheet)
        ws.Range("A9").formula = "=COUNTA(tTQMSetari[Cod_setare])"
        ws.Range("C9").formula = "=COUNTIF(tTQMListe[Activ],""Da"")"
        ws.Range("E9").formula = "=COUNTIF(tTQMReguliDoc[Stare],""De confirmat"")"
    End If
End Sub
Private Function SL_GetSheet(ByVal labelName As String) As Worksheet
    On Error Resume Next
    Set SL_GetSheet = ThisWorkbook.Worksheets(labelName)
    On Error GoTo 0
End Function
Private Function SL_Table(ByVal kind As Long) As ListObject
    Dim names As Variant, tables As Variant
    names = SL_Names(): tables = Array("tTQMSetari", "tTQMListe", "tTQMReguliDoc", "tTQMSLJurnal")
    Set SL_Table = ThisWorkbook.Worksheets(CStr(names(kind - 1))).ListObjects(CStr(tables(kind - 1)))
End Function
Private Function SL_ID(ByVal prefix As String) As String
    Dim g As SL_GUID, i As Long, tail As String
    If CoCreateGuid(g) <> 0 Then Err.Raise vbObjectError + 820, , "Nu s-a putut crea identificatorul."
    For i = 0 To 7: tail = tail & Right$("0" & Hex$(g.Data4(i)), 2): Next i
    SL_ID = prefix & "-" & Right$("00000000" & Hex$(g.Data1), 8) & "-" & Right$("0000" & Hex$(g.Data2), 4) & "-" & Right$("0000" & Hex$(g.Data3), 4) & "-" & Left$(tail, 4) & "-" & VBA.mID$(tail, 5)
End Function
Private Function SL_Text(ByVal value As Variant) As String
    If IsError(value) Then Err.Raise vbObjectError + 821, , "Un camp contine o eroare Excel."
    SL_Text = Trim$(CStr(value))
End Function
Private Function SL_Find(ByVal kind As Long, ByVal key As String, Optional ByVal column As Long = 1) As Range
    Dim lr As ListRow, found As Range
    For Each lr In SL_Table(kind).ListRows
        If StrComp(SL_Text(lr.Range.Cells(1, column).Value2), key, vbTextCompare) = 0 And Len(key) > 0 Then
            If Not found Is Nothing Then Err.Raise vbObjectError + 822, , "Cheie duplicata in Setari Liste: " & key
            Set found = lr.Range
        End If
    Next lr
    Set SL_Find = found
End Function
Private Function SL_Add(ByVal kind As Long) As Range
    Dim lr As ListRow, lo As ListObject, wasProtected As Boolean, errorText As String
    On Error GoTo Fail
    Set lo = SL_Table(kind)
    For Each lr In lo.ListRows
        If Application.CountA(lr.Range) = 0 Then Set SL_Add = lr.Range: Exit Function
    Next lr
    wasProtected = lo.Parent.ProtectContents: lo.Parent.Unprotect
    Set SL_Add = lo.ListRows.Add.Range
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Exit Function
Fail:
    errorText = Err.description
    On Error Resume Next
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    On Error GoTo 0
    Err.Raise vbObjectError + 817, , errorText
End Function
Private Function SL_RowStamp(ByVal row As Range) As String
    Dim cell As Range, v As String, result As String
    For Each cell In row.Cells
        v = CStr(cell.Value2): result = result & CStr(Len(v)) & ":" & v
    Next cell
    SL_RowStamp = result
End Function
Public Function SL_Stamp() As String
    Dim k As Long, lr As ListRow, result As String
    If SL_GetSheet(SL_Sheet) Is Nothing Then Exit Function
    For k = 1 To 3
        For Each lr In SL_Table(k).ListRows
            result = result & SL_RowStamp(lr.Range)
        Next lr
    Next k
    SL_Stamp = result
End Function
Private Sub SL_CheckStructure()
    Dim names As Variant, k As Long, hs As Variant, c As Long, ws As Worksheet, lo As ListObject
    names = SL_Names()
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 823, , "Fisierul principal este doar pentru citire."
    For k = 1 To 4
        Set ws = SL_GetSheet(CStr(names(k - 1)))
        If ws Is Nothing Then Err.Raise vbObjectError + 824, , "Lipseste structura Setari Liste. Folositi fisierul integrat livrat."
        Set lo = SL_Table(k): hs = SL_Heads(k)
        If lo.ListColumns.count <> UBound(hs) + 1 Then Err.Raise vbObjectError + 825, , "Structura incompatibila: " & ws.name
        For c = 0 To UBound(hs)
            If lo.ListColumns(c + 1).name <> hs(c) Then Err.Raise vbObjectError + 826, , "Antet modificat: " & hs(c)
        Next c
        ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Next k
    If CStr(SL_GetSheet(SL_Sheet).Range("L1").Value2) <> SL_MARK Then Err.Raise vbObjectError + 827, , "Versiune incompatibila Setari Liste."
End Sub
Public Function SL_Param(ByVal key As String, ByVal fallback As Variant) As Variant
    Dim row As Range, v As Variant
    If SL_GetSheet(SL_Sheet) Is Nothing Then SL_Param = fallback: Exit Function
    Set row = SL_Find(1, key)
    If row Is Nothing Then Err.Raise vbObjectError + 828, , "Lipseste parametrul " & key
    v = row.Cells(1, 3).Value2
    If CStr(row.Cells(1, 4).Value2) = "Intreg" Then
        If Not IsNumeric(v) Then Err.Raise vbObjectError + 829, , "Parametrul trebuie sa fie numeric: " & key
        If CDbl(v) < 0 Or CDbl(v) > 3650 Or CDbl(v) <> Fix(CDbl(v)) Then Err.Raise vbObjectError + 830, , "Termenul trebuie sa fie un intreg intre 0 si 3650."
    ElseIf Len(SL_Text(v)) = 0 Then
        Err.Raise vbObjectError + 831, , "Parametru necompletat: " & key
    End If
    SL_Param = v
End Function
Public Sub SL_CheckValue(ByVal group As String, ByVal value As String)
    Dim lr As ListRow, n As Long
    If SL_GetSheet(SL_Sheet) Is Nothing Then Exit Sub
    For Each lr In SL_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = group And StrComp(CStr(lr.Range.Cells(1, 3).Value2), value, vbTextCompare) = 0 Then
            If CStr(lr.Range.Cells(1, 4).Value2) = "Da" Then n = n + 1
        End If
    Next lr
    If n <> 1 Then Err.Raise vbObjectError + 832, , "Valoare inexistenta, inactiva sau duplicata in lista " & group & ": " & value
End Sub
Public Sub SL_ApplyList(ByVal target As Range, ByVal group As String)
    Dim wb As Workbook, cache As Worksheet, lr As ListRow, g As Variant, col As Long, n As Long
    Dim names As Variant, nm As String, values() As String, orders() As Double, seen As Object
    Dim i As Long, j As Long, swapValue As String, swapOrder As Double, found As Boolean
    Dim cacheProtected As Boolean, targetProtected As Boolean, cacheChanged As Boolean, validationChanged As Boolean
    Dim oldCache As Variant, oldRows As Long, oldName As String, hadName As Boolean
    Dim oldType As Long, oldFormula As String, hadValidation As Boolean, oldIgnore As Boolean, oldDrop As Boolean, oldError As Boolean
    Dim eno As Long, message As String, v As Variant
    On Error GoTo Fail
    If SL_GetSheet(SL_Sheet) Is Nothing Then Exit Sub
    group = UCase$(Trim$(group)): names = SL_Groups()
    For Each g In names
        col = col + 1
        If CStr(g) = group Then found = True: Exit For
    Next g
    If Not found Then Err.Raise vbObjectError + 833, , "Lista necunoscuta: " & group
    Set wb = target.Worksheet.Parent
    If wb.readonly Then Err.Raise vbObjectError + 881, , "Formularul destinatie este doar pentru citire."
    Set seen = CreateObject("Scripting.Dictionary"): seen.CompareMode = vbTextCompare
    ReDim values(1 To Application.Max(1, SL_Table(2).ListRows.count))
    ReDim orders(1 To Application.Max(1, SL_Table(2).ListRows.count))
    For Each lr In SL_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = group And CStr(lr.Range.Cells(1, 4).Value2) = "Da" Then
            swapValue = SL_Text(lr.Range.Cells(1, 3).Value2): v = lr.Range.Cells(1, 5).Value2
            If Len(swapValue) = 0 Then Err.Raise vbObjectError + 882, , "Valoare activa goala in " & group
            If seen.exists(swapValue) Then Err.Raise vbObjectError + 883, , "Valoare activa duplicata in " & group
            If Not IsNumeric(v) Then Err.Raise vbObjectError + 884, , "Ordine nenumerica in " & group
            If CDbl(v) < 0 Or CDbl(v) > 99999 Or CDbl(v) <> Fix(CDbl(v)) Then Err.Raise vbObjectError + 885, , "Ordine invalida in " & group
            seen.Add swapValue, True: n = n + 1: values(n) = swapValue: orders(n) = CDbl(v)
        End If
    Next lr
    If n = 0 Then Err.Raise vbObjectError + 834, , "Lista nu are valori active: " & group
    For i = 1 To n - 1
        For j = i + 1 To n
            If orders(j) < orders(i) Or (orders(j) = orders(i) And StrComp(values(j), values(i), vbTextCompare) < 0) Then
                swapValue = values(i): values(i) = values(j): values(j) = swapValue
                swapOrder = orders(i): orders(i) = orders(j): orders(j) = swapOrder
            End If
        Next j
    Next i
    ' Validation is complete before any cache or validation rule is changed.
    If wb Is ThisWorkbook Then
        Set cache = SL_GetSheet("_TQM_SL_LISTE"): col = col + 12
    Else
        On Error Resume Next: Set cache = wb.Worksheets("_TQM_LISTE_LOCALE"): On Error GoTo Fail
        If cache Is Nothing Then
            Set cache = wb.Worksheets.Add(after:=wb.Worksheets(wb.Worksheets.count))
            cache.name = "_TQM_LISTE_LOCALE": cache.Visible = xlSheetVeryHidden
        End If
    End If
    nm = "TQM_SL_" & group
    oldRows = Application.Max(1, cache.Cells(cache.rows.count, col).End(xlUp).row)
    oldCache = cache.Cells(1, col).Resize(oldRows, 1).Value2
    cacheProtected = cache.ProtectContents: targetProtected = target.Worksheet.ProtectContents
    On Error Resume Next
    Err.Clear: oldName = wb.names(nm).RefersTo: hadName = (Err.number = 0)
    Err.Clear: oldType = target.Validation.Type: hadValidation = (Err.number = 0 And oldType = xlValidateList)
    If hadValidation Then
        oldFormula = target.Validation.Formula1: oldIgnore = target.Validation.IgnoreBlank
        oldDrop = target.Validation.InCellDropdown: oldError = target.Validation.ShowError
    End If
    Err.Clear: On Error GoTo Fail
    cache.Unprotect: cacheChanged = True
    cache.Columns(col).ClearContents: cache.Cells(1, col).Value2 = group
    For i = 1 To n: cache.Cells(i + 1, col).NumberFormat = "@": cache.Cells(i + 1, col).Value2 = values(i): Next i
    wb.names.Add name:=nm, RefersTo:="='" & Replace(cache.name, "'", "''") & "'!" & cache.Cells(2, col).Resize(n, 1).address
    target.Worksheet.Unprotect: validationChanged = True
    With target.Validation
        .Delete: .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:="=" & nm
        .IgnoreBlank = True: .InCellDropdown = True: .ShowError = True: .errorMessage = "Alegeti o valoare activa din lista."
    End With
    If cacheProtected Then cache.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    If targetProtected Then target.Worksheet.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Exit Sub
Fail:
    eno = Err.number: message = Err.description
    On Error Resume Next
    If cacheChanged Then
        cache.Unprotect: cache.Columns(col).ClearContents: cache.Cells(1, col).Resize(oldRows, 1).Value2 = oldCache
        If hadName Then wb.names.Add name:=nm, RefersTo:=oldName Else wb.names(nm).Delete
    End If
    If validationChanged Then
        target.Worksheet.Unprotect: target.Validation.Delete
        If hadValidation Then
            target.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:=oldFormula
            target.Validation.IgnoreBlank = oldIgnore: target.Validation.InCellDropdown = oldDrop: target.Validation.ShowError = oldError
        End If
    End If
    If Not cache Is Nothing Then
        If cacheProtected Then cache.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    End If
    If targetProtected Then target.Worksheet.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    On Error GoTo 0
    Err.Raise eno, "SL_ApplyList", message
End Sub
Public Sub SL_ActualizeazaControl()
    Dim ws As Worksheet, lastRow As Long, r As Long, ids As Object, key As String, f As Variant, c As Variant
    If SL_GetSheet(SL_Sheet) Is Nothing Then Exit Sub
    Set ws = SL_GetSheet("Control_Achizitii")
    If ws Is Nothing Then Exit Sub
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 835, , "Control Achizitii nu se poate actualiza in modul doar citire."
    lastRow = Application.Max(500, TQM_Control_Cell(ws, ws.rows.count, "G").End(xlUp).row)
    If CStr(ws.Range("R11").Value2) <> "TQM_SL_CONTROL_V1" Then
        If Application.CountA(ws.Range("R12:Z" & lastRow)) > 0 Then Err.Raise vbObjectError + 816, , "Coloanele Q:Y din Control contin date necunoscute. Nu au fost suprascrise."
    End If
    ws.Unprotect: ws.Range("R11").Value2 = "TQM_SL_CONTROL_V1"
    ws.Range("Z12").Value2 = "Status aviz"
    ws.Range("R12:Y12").Value2 = Array("ID_dosar", "Cheie_regula", "Stare_regula", "Cere_aviz", "Cere_conformitate", "Cere_producator", "Cere_fise", "Lipsa_calculata")
    Set ids = CreateObject("Scripting.Dictionary"): ids.CompareMode = vbTextCompare
    For r = 13 To lastRow
        If Len(SL_Text(TQM_Control_Cell(ws, r, "G").Value2)) > 0 Then
            key = SL_Text(TQM_Control_Cell(ws, r, "R").Value2)
            If Len(key) = 0 Then key = SL_ID("DS"): TQM_Control_Cell(ws, r, "R").NumberFormat = "@": TQM_Control_Cell(ws, r, "R").Value2 = key
            If ids.exists(key) Then Err.Raise vbObjectError + 836, , "ID de dosar duplicat. Opriti editarea si verificati randurile."
            ids.Add key, True
        End If
    Next r
    TQM_Control_Range(ws, "S13").formula = TQM_Control_LocalFormula("=IF(G13="""","""",IF(LEFT(LOWER(H13),4)=""furn"",""Furnizor"",IF(LEFT(LOWER(H13),4)=""prod"",""Producator"",IF(LEFT(LOWER(H13),4)=""pres"",""Prestator"",IF(LEFT(LOWER(H13),3)=""alt"",""Alt partener"",H13))))&""|""&IF(LEFT(LOWER(I13),4)=""doar"",""Doar Aviz"",IF(LEFT(LOWER(I13),4)=""fact"",""Factura"",I13)))")
    If lastRow > 13 Then TQM_Control_Range(ws, "S13:S" & lastRow).FillDown
    TQM_Control_Range(ws, "T13").formula = TQM_Control_LocalFormula("=IF(G13="""","""",IF(COUNTIF(tTQMReguliDoc[Cheie_regula],S13)<>1,""REGULA NECONFIGURATA"",IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],S13,tTQMReguliDoc[Stare],""Confirmata"")=1,""Confirmata"",""De confirmat"")))")
    If lastRow > 13 Then TQM_Control_Range(ws, "T13:T" & lastRow).FillDown
    TQM_Control_Range(ws, "U13").formula = TQM_Control_LocalFormula("=IF(OR(G13="""",T13<>""Confirmata""),0,IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],S13,tTQMReguliDoc[Aviz],""Da"")=1,1,0))")
    If lastRow > 13 Then TQM_Control_Range(ws, "U13:U" & lastRow).FillDown
    TQM_Control_Range(ws, "V13").formula = TQM_Control_LocalFormula("=IF(OR(G13="""",T13<>""Confirmata""),0,IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],S13,tTQMReguliDoc[Decl_conformitate],""Da"")=1,1,0))")
    If lastRow > 13 Then TQM_Control_Range(ws, "V13:V" & lastRow).FillDown
    TQM_Control_Range(ws, "W13").formula = TQM_Control_LocalFormula("=IF(OR(G13="""",T13<>""Confirmata""),0,IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],S13,tTQMReguliDoc[Decl_producator],""Da"")=1,1,0))")
    If lastRow > 13 Then TQM_Control_Range(ws, "W13:W" & lastRow).FillDown
    TQM_Control_Range(ws, "X13").formula = TQM_Control_LocalFormula("=IF(OR(G13="""",T13<>""Confirmata""),0,IF(COUNTIFS(tTQMReguliDoc[Cheie_regula],S13,tTQMReguliDoc[Fise_tehnice],""Da"")=1,1,0))")
    If lastRow > 13 Then TQM_Control_Range(ws, "X13:X" & lastRow).FillDown
    TQM_Control_Range(ws, "J13").formula = TQM_Control_LocalFormula("=IF(G13="""","""",IF(T13<>""Confirmata"",""DE CONFIRMAT"",IF(U13=1,""OBLIGATORIU AVIZ"",""NU"")))")
    If lastRow > 13 Then TQM_Control_Range(ws, "J13:J" & lastRow).FillDown
    TQM_Control_Range(ws, "Y13").formula = TQM_Control_LocalFormula("=IF(G13="""","""",IF(T13<>""Confirmata"",""Confirmati regulile documentelor; "",IF(AND(U13=1,Q13<>""Primit""),""Aviz; "","""")&IF(AND(V13=1,K13<>""Primit""),""Declaratie conformitate; "","""")&IF(AND(W13=1,L13<>""Primit""),""Declaratie producator; "","""")&IF(AND(X13=1,M13<>""Primit""),""Fise tehnice; "","""")))")
    If lastRow > 13 Then TQM_Control_Range(ws, "Y13:Y" & lastRow).FillDown
    TQM_Control_Range(ws, "O13").formula = TQM_Control_LocalFormula("=IF(G13="""","""",IF(Y13="""","""",LEFT(Y13,LEN(Y13)-2)))")
    If lastRow > 13 Then TQM_Control_Range(ws, "O13:O" & lastRow).FillDown
    TQM_Control_Range(ws, "N13").formula = TQM_Control_LocalFormula("=IF(G13="""","""",IF(O13="""",""DOSAR COMPLET"",""INCOMPLET - VERIFICARE DOCUMENTE""))")
    If lastRow > 13 Then TQM_Control_Range(ws, "N13:N" & lastRow).FillDown
    ws.Columns("N:AA").Hidden = True
    TQM_Control_KeepFilters ws, lastRow
    SL_ApplyList ws.Range("B6:D6"), "TIP_PARTENER_CONTROL"
    SL_ApplyList ws.Range("B7:D7"), "TIP_INTRARE"
    SL_ApplyList ws.Range("B8:D10"), "STATUT_DOCUMENT"
    ws.Calculate
    SL_DOCSync
End Sub
Private Sub SL_Button(ByVal ws As Worksheet, ByVal address As String, ByVal caption As String, ByVal macro As String)
    Dim rg As Range, shp As Shape
    Set rg = ws.Range(address)
    Set shp = ws.Shapes.AddShape(msoShapeRoundedRectangle, rg.Left + 2, rg.Top + 2, rg.width - 4, rg.Height - 4)
    shp.name = "TQM_SL_" & macro: shp.Fill.ForeColor.RGB = RGB(37, 99, 235): shp.line.Visible = msoFalse
    shp.TextFrame2.TextRange.text = caption: shp.TextFrame2.TextRange.Font.size = 10
    shp.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = vbWhite
    shp.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & macro
End Sub
Public Sub SL_Instaleaza()
    Dim ws As Worksheet, i As Long
    On Error GoTo Fail
    Call SL_EnsureStructure:     SL_CheckStructure: Set ws = SL_GetSheet(SL_Sheet): ws.Unprotect
    For i = ws.Shapes.count To 1 Step -1
        If Left$(ws.Shapes(i).name, 7) = "TQM_SL_" Then ws.Shapes(i).Delete
    Next i
    SL_Button ws, "A5:B5", "Editeaza parametru", "SL_EditeazaParametru"
    SL_Button ws, "C5:D5", "Liste dropdown", "SL_Liste"
    SL_Button ws, "E5:F5", "Reguli documente", "SL_ReguliDocumente"
    SL_Button ws, "A6:B6", "Documente dosar", "SL_DocumenteDosar"
    SL_Button ws, "C6:D6", "Jurnal modificari", "SL_Jurnal"
    SL_Button ws, "E6:F6", "Actualizeaza", "SL_Actualizeaza"
    ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Call SL_ActualizeazaControl:     ThisWorkbook.Activate: ws.Activate
    MsgBox "Setari Liste este activ. Confirmati cele 8 profiluri de documente din Reguli documente.", vbInformation, "TQM"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM - Setari Liste"
End Sub
Public Sub SL_Actualizeaza()
    On Error GoTo Fail
    Call SL_CheckStructure:     SL_ActualizeazaControl: Application.Calculate
    MsgBox "Listele si regulile documentelor au fost actualizate.", vbInformation, "TQM"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM - Setari Liste"
End Sub
Private Sub SL_Band(ByVal ws As Worksheet, ByVal address As String, ByVal title As String)
    ws.Range(address).Merge: ws.Range(address).Value2 = title
End Sub
Private Sub SL_Input(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal labelName As String, ByVal value As Variant, Optional ByVal unlocked As Boolean = True)
    ws.Cells(rowNo, 1).Value2 = labelName
    SL_Band ws, "B" & rowNo & ":I" & rowNo, ""
    ws.Cells(rowNo, 2).NumberFormat = "@": ws.Cells(rowNo, 2).Value2 = value
    ws.Range("B" & rowNo & ":I" & rowNo).Locked = Not unlocked
    If unlocked Then ws.Range("B" & rowNo & ":I" & rowNo).Interior.Color = RGB(239, 246, 255)
End Sub
Private Sub SL_Start(ByVal title As String, ByVal kind As Long)
    Dim wb As Workbook, ws As Worksheet
    SL_CheckStructure
    If Not mForm Is Nothing Then
        For Each wb In Workbooks
            If wb Is mForm Then
                If mKind > 0 Then Err.Raise vbObjectError + 837, , "Inchideti sau salvati formularul Setari Liste deja deschis."
                mForm.Close SaveChanges:=False: Exit For
            End If
        Next wb
    End If
    Set mForm = Workbooks.Add(xlWBATWorksheet): Set ws = mForm.Worksheets(1)
    ws.name = "Formular_Setari": mKind = kind: mStamp = SL_Stamp()
    ws.Cells.Font.name = "Aptos": ws.Cells.Font.size = 11: ws.rows.RowHeight = 28
    ws.Columns("A").ColumnWidth = 29: ws.Columns("B:I").ColumnWidth = 13
    ws.Cells.Locked = True: ActiveWindow.DisplayGridlines = False
    SL_Band ws, "A1:I1", "TQM - " & title & " (formular local)": ws.Range("A1").Font.size = 16: ws.rows(1).RowHeight = 36
    If kind > 0 Then SL_Button ws, "A3:C3", "Salveaza", "SL_Salveaza"
    SL_Button ws, "D3:F3", "Inchide", "SL_InchideFormular"
End Sub
Public Sub SL_InchideFormular()
    On Error GoTo Fail
    If Not mForm Is Nothing Then mForm.Close SaveChanges:=False
    Set mForm = Nothing: mKind = 0: mViewKind = 0: mID = "": mStamp = ""
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Private Sub SL_View(ByVal kind As Long, ByVal title As String)
    Dim ws As Worksheet, lo As ListObject, hs As Variant, n As Long, lr As ListRow
    SL_Start title, 0: mViewKind = kind: Set ws = mForm.Worksheets(1): Set lo = SL_Table(kind): hs = SL_Heads(kind)
    If kind = 2 Or kind = 3 Then SL_Button ws, "A3:C3", "Editeaza randul ales", "SL_EditeazaSelectia"
    If kind = 2 Then SL_Button ws, "G3:I3", "Valoare noua", "SL_ListaNoua"
    ws.Cells(5, 1).Resize(1, UBound(hs) + 1).Value2 = hs: n = 6
    For Each lr In lo.ListRows
        If Len(SL_Text(lr.Range.Cells(1, 1).Value2)) > 0 Then
            ws.Cells(n, 1).Resize(1, lo.ListColumns.count).NumberFormat = "@"
            ws.Cells(n, 1).Resize(1, lo.ListColumns.count).Value2 = lr.Range.Value2: n = n + 1
        End If
    Next lr
    ws.rows(5).Interior.Color = RGB(31, 41, 55): ws.rows(5).Font.Color = vbWhite: ws.rows(5).RowHeight = 42: ws.rows(5).WrapText = True
    ws.Range(ws.Cells(5, 1), ws.Cells(Application.Max(6, n - 1), lo.ListColumns.count)).AutoFilter
    ws.Columns("A:M").ColumnWidth = 23: ws.Columns("G").ColumnWidth = 48
    If kind = 2 Then ws.Columns("I").NumberFormat = "dd.mm.yyyy hh:mm"
    If kind = 3 Then ws.Columns("K").NumberFormat = "dd.mm.yyyy hh:mm": ws.Columns("I").ColumnWidth = 48
    If kind = 4 Then ws.Columns("B").NumberFormat = "dd.mm.yyyy hh:mm": ws.Columns("I:J").ColumnWidth = 42
    ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    ws.Range("B6").Select: ActiveWindow.FreezePanes = False: ActiveWindow.SplitRow = 5: ActiveWindow.FreezePanes = True
End Sub
Public Sub SL_Liste()
    On Error GoTo Fail
    SL_View 2, "Liste dropdown": Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub SL_ReguliDocumente()
    On Error GoTo Fail
    SL_View 3, "Reguli documente": Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub SL_Jurnal()
    On Error GoTo Fail
    SL_View 4, "Jurnal configurare": Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub SL_EditeazaParametru()
    Dim row As Range, ws As Worksheet, idx As Long, key As String
    On Error GoTo Fail
    If Not ActiveWorkbook Is ThisWorkbook Then Err.Raise vbObjectError + 838, , "Selectati parametrul in fisierul principal."
    If ActiveSheet.name <> SL_Sheet Then Err.Raise vbObjectError + 839, , "Deschideti Setari Liste si selectati un parametru din tabel."
    If Intersect(ActiveCell, SL_Table(1).DataBodyRange) Is Nothing Then Err.Raise vbObjectError + 840, , "Selectati un rand din tabelul de parametri."
    idx = ActiveCell.row - SL_Table(1).HeaderRowRange.row: Set row = SL_Table(1).ListRows(idx).Range: key = CStr(row.Cells(1, 1).Value2)
    SL_Start "Editeaza parametru", 1: mID = key: Set ws = mForm.Worksheets(1)
    SL_Input ws, 5, "Cod setare", key, False: SL_Input ws, 6, "Valoare", row.Cells(1, 3).Value2
    SL_Input ws, 8, "Utilizare", row.Cells(1, 6).Value2, False: ws.rows(8).RowHeight = 56: ws.Range("B8:I8").WrapText = True
    If CStr(row.Cells(1, 4).Value2) = "Intreg" Then ws.Range("B6").NumberFormat = "0"
    If key = "PLATA_METODA_IMPLICITA" Then SL_ApplyList ws.Range("B6"), "METODA_PLATA"
    ws.Protect UserInterfaceOnly:=True: ws.Range("B6").Select: Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub SL_EditeazaSelectia()
    Dim kind As Long, key As String, row As Range, ws As Worksheet, c As Long, hs As Variant
    On Error GoTo Fail
    If mForm Is Nothing Then Err.Raise vbObjectError + 841, , "Deschideti lista de configurare."
    If Not ActiveWorkbook Is mForm Or mKind <> 0 Then Err.Raise vbObjectError + 842, , "Selectati un rand din lista locala."
    kind = mViewKind
    If kind <> 2 And kind <> 3 Then Err.Raise vbObjectError + 843, , "Jurnalul este doar pentru consultare."
    If ActiveCell.row < 6 Then Err.Raise vbObjectError + 844, , "Selectati un rand de date."
    key = CStr(ActiveSheet.Cells(ActiveCell.row, 1).Value2): Set row = SL_Find(kind, key)
    If row Is Nothing Then Err.Raise vbObjectError + 845, , "Inregistrarea nu mai exista. Redeschideti lista."
    If SL_Stamp() <> mStamp Then Err.Raise vbObjectError + 846, , "Configurarea s-a modificat. Redeschideti lista."
    SL_Start IIf(kind = 2, "Editeaza valoare lista", "Editeaza regula documente"), kind: mID = key: Set ws = mForm.Worksheets(1)
    If kind = 2 Then
        SL_Input ws, 5, "Grupa", row.Cells(1, 2).Value2, False: SL_Input ws, 6, "Valoare stabila", row.Cells(1, 3).Value2, False
        SL_Input ws, 7, "Activ (Da/Nu)", row.Cells(1, 4).Value2, (CStr(row.Cells(1, 6).Value2) <> "Da")
        SL_Input ws, 8, "Ordine", row.Cells(1, 5).Value2: ws.Range("B8").NumberFormat = "0"
        SL_Input ws, 9, "Observatii", row.Cells(1, 7).Value2
        SL_ApplyList ws.Range("B7"), "DA_NU"
    Else
        SL_Input ws, 5, "Profil", key, False
        hs = SL_Heads(3)
        For c = 4 To 8: SL_Input ws, c + 2, CStr(hs(c - 1)), row.Cells(1, c).Value2: Next c
        SL_ApplyList ws.Range("B6:B9"), "DA_NU": SL_ApplyList ws.Range("B10"), "STARE_REGULA"
        SL_Input ws, 11, "Observatii", row.Cells(1, 9).Value2
        SL_Band ws, "A13:I14", "Confirmata = cerinte interne verificate. Schimbarea regulii recalculeaza toate dosarele din acest profil."
        ws.Range("A13:I14").WrapText = True
    End If
    ws.Protect UserInterfaceOnly:=True: ws.Range("B8").Select: Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub SL_ListaNoua()
    Dim ws As Worksheet
    On Error GoTo Fail
    SL_Start "Valoare noua in lista", 2: mID = "": Set ws = mForm.Worksheets(1)
    SL_Input ws, 5, "Grupa", "UM": SL_Input ws, 6, "Valoare", ""
    SL_Input ws, 7, "Activ (Da/Nu)", "Da": SL_Input ws, 8, "Ordine", 100: ws.Range("B8").NumberFormat = "0"
    SL_Input ws, 9, "Observatii", ""
    SL_ApplyList ws.Range("B7"), "DA_NU"
    SL_Band ws, "A11:I12", "Liste extensibile: UM, CATEGORIE si METODA_PLATA. Valorile existente se dezactiveaza, fara redenumire sau stergere."
    ws.Range("A11:I12").WrapText = True: ws.Protect UserInterfaceOnly:=True: ws.Range("B6").Select: Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Private Function SL_ControlRow(ByVal id As String) As Range
    Dim ws As Worksheet, lastRow As Long, r As Long, found As Range
    Set ws = SL_GetSheet("Control_Achizitii"): lastRow = TQM_Control_Cell(ws, ws.rows.count, "G").End(xlUp).row
    For r = 13 To lastRow
        If CStr(TQM_Control_Cell(ws, r, "R").Value2) = id And Len(id) > 0 Then
            If Not found Is Nothing Then Err.Raise vbObjectError + 847, , "ID dosar duplicat."
            Set found = TQM_Control_Cell(ws, r, 1).Resize(1, 26)
        End If
    Next r
    Set SL_ControlRow = found
End Function
Public Sub SL_DocumenteDosar()
    Dim ws As Worksheet, row As Range, id As String, r As Long, inputNo As Variant
    On Error GoTo Fail
    Call SL_CheckStructure:     SL_ActualizeazaControl: Set ws = SL_GetSheet("Control_Achizitii")
    If ActiveWorkbook Is ThisWorkbook And ActiveSheet.name = "Control_Achizitii" Then
        r = ActiveCell.row
    Else
        inputNo = Application.InputBox("Numarul din coloana Nr. a dosarului din Control Achizitii:", "Documente dosar", Type:=1)
        If VarType(inputNo) = vbBoolean Then Exit Sub
        For r = 13 To TQM_Control_Cell(ws, ws.rows.count, "G").End(xlUp).row
            If CStr(TQM_Control_Cell(ws, r, "A").Value2) = CStr(inputNo) Then Exit For
        Next r
    End If
    If r < 13 Or Len(CStr(TQM_Control_Cell(ws, r, "G").Value2)) = 0 Then Err.Raise vbObjectError + 848, , "Selectati un dosar existent."
    id = CStr(TQM_Control_Cell(ws, r, "R").Value2): Set row = SL_ControlRow(id)
    SL_Start "Documente dosar", 4: mID = id: mStamp = mStamp & SL_RowStamp(row): Set ws = mForm.Worksheets(1)
    SL_Input ws, 5, "Dosar", CStr(row.Cells(1, TQM_Control_Col(3)).Value2) & " / " & CStr(row.Cells(1, TQM_Control_Col(7)).Value2), False
    SL_Input ws, 6, "Status aviz", row.Cells(1, TQM_Control_Col(17)).Value2
    SL_Input ws, 7, "Declaratie conformitate", row.Cells(1, TQM_Control_Col(11)).Value2
    SL_Input ws, 8, "Declaratie producator", row.Cells(1, TQM_Control_Col(12)).Value2
    SL_Input ws, 9, "Fise tehnice", row.Cells(1, TQM_Control_Col(13)).Value2
    For r = 6 To 9
        If Len(SL_Text(ws.Cells(r, 2).Value2)) = 0 Then ws.Cells(r, 2).Value2 = "Lipsa"
    Next r
    SL_ApplyList ws.Range("B6:B9"), "STATUT_DOCUMENT"
    SL_Band ws, "A11:I12", "Primit se bifeaza numai dupa verificarea documentului. N/A nu satisface un document obligatoriu."
    ws.Range("A11:I12").WrapText = True: ws.Protect UserInterfaceOnly:=True: ws.Range("B6").Select: Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Private Sub SL_Audit(ByVal kind As Long, ByVal id As String, ByVal before As Variant, ByVal row As Range, ByVal eventID As String, ByVal revision As Long)
    Dim c As Long, oldVal As String, newVal As String, item As Range, hs As Variant
    hs = SL_Heads(kind)
    For c = 1 To row.Columns.count
        oldVal = "": If Not IsEmpty(before) Then oldVal = CStr(before(1, c))
        newVal = CStr(row.Cells(1, c).Value2)
        If oldVal <> newVal Then
            Set item = SL_Add(4): item.NumberFormat = "@"
            item.Value2 = Array(eventID, CDbl(Now), Application.UserName, Choose(kind, "Parametru", "Lista", "Regula"), id, "Modificare", revision, hs(c - 1), oldVal, newVal)
            item.Cells(1, 2).NumberFormat = "dd.mm.yyyy hh:mm": item.Cells(1, 7).NumberFormat = "0"
        End If
    Next c
End Sub
Private Sub SL_DocAudit(ByVal id As String, ByVal before As Variant, ByVal row As Range, ByVal eventID As String)
    Dim c As Variant, item As Range, labels As Object
    Set labels = CreateObject("Scripting.Dictionary")
    labels.Add 11, "Declaratie conformitate": labels.Add 12, "Declaratie producator": labels.Add 13, "Fise tehnice": labels.Add 17, "Status aviz"
    For Each c In Array(11, 12, 13, 17)
        If CStr(before(1, TQM_Control_Col(c))) <> CStr(row.Cells(1, TQM_Control_Col(c)).Value2) Then
            Set item = SL_Add(4): item.NumberFormat = "@"
            item.Value2 = Array(eventID, CDbl(Now), Application.UserName, "Dosar", id, "Actualizare documente", 0, CStr(labels(CLng(c))), CStr(before(1, TQM_Control_Col(c))), CStr(row.Cells(1, TQM_Control_Col(c)).Value2))
            item.Cells(1, 2).NumberFormat = "dd.mm.yyyy hh:mm"
        End If
    Next c
End Sub
Public Sub SL_Salveaza()
    Dim ws As Worksheet, row As Range, old As Variant, values As Variant, v As Variant, key As String, group As String, state As String
    Dim lr As ListRow, revision As Long, eventID As String, c As Variant, added As Boolean, changed As Boolean, oldEvents As Boolean
    Dim errorText As String, flag As String, activeCount As Long
    oldEvents = Application.EnableEvents
    On Error GoTo Fail
    If mForm Is Nothing Then Err.Raise vbObjectError + 849, , "Nu este deschis un formular."
    If Not ActiveWorkbook Is mForm Or mKind < 1 Then Err.Raise vbObjectError + 850, , "Salvati din formularul local activ."
    Call SL_CheckStructure:     Set ws = mForm.Worksheets(1)
    If mKind = 4 Then
        Set row = SL_ControlRow(mID)
        If row Is Nothing Then Err.Raise vbObjectError + 851, , "Dosarul a fost sters."
        If SL_Stamp() & SL_RowStamp(row) <> mStamp Then Err.Raise vbObjectError + 852, , "Dosarul sau regulile s-au modificat. Redeschideti formularul."
        For c = 6 To 9
            SL_CheckValue "STATUT_DOCUMENT", SL_Text(ws.Cells(c, 2).Value2)
        Next c
        old = row.Value2: eventID = SL_ID("EV"): Application.EnableEvents = False: changed = True
        row.Cells(1, TQM_Control_Col(17)).NumberFormat = "@": row.Cells(1, TQM_Control_Col(17)).Value2 = SL_CanonicalValue("STATUT_DOCUMENT", SL_Text(ws.Range("B6").Value2))
        For c = 7 To 9: row.Cells(1, TQM_Control_Col(c + 4)).Value2 = SL_CanonicalValue("STATUT_DOCUMENT", SL_Text(ws.Cells(c, 2).Value2)): Next c
        SL_DocAudit mID, old, row, eventID
    Else
        If SL_Stamp() <> mStamp Then Err.Raise vbObjectError + 853, , "Configurarea s-a modificat in alta sesiune. Redeschideti formularul."
        If Len(mID) > 0 Then Set row = SL_Find(mKind, mID)
        If row Is Nothing And Len(mID) > 0 Then Err.Raise vbObjectError + 854, , "Inregistrarea nu mai exista."
        If Not row Is Nothing Then old = row.Value2: values = old
        Select Case mKind
        Case 1
            v = SL_Text(ws.Range("B6").Value2)
            If CStr(row.Cells(1, 4).Value2) = "Intreg" Then
                If Not IsNumeric(v) Then Err.Raise vbObjectError + 855, , "Introduceti un numar intreg intre 0 si 3650."
                If CDbl(v) < 0 Or CDbl(v) > 3650 Or CDbl(v) <> Fix(CDbl(v)) Then Err.Raise vbObjectError + 856, , "Termen invalid."
                v = CLng(v)
            ElseIf Len(v) = 0 Then
                Err.Raise vbObjectError + 857, , "Valoarea este obligatorie."
            End If
            If mID = "PLATA_METODA_IMPLICITA" Then v = SL_CanonicalValue("METODA_PLATA", CStr(v))
            If mID = "STOC_LOCATIE_IMPLICITA" Then Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_ResolveLocation", CStr(v)
            values(1, 3) = v: revision = CLng(values(1, 7)) + 1
            values(1, 7) = revision: values(1, 8) = CDbl(Now): values(1, 9) = Application.UserName
        Case 2
            group = UCase$(SL_Text(ws.Range("B5").Value2)): key = SL_Text(ws.Range("B6").Value2)
            flag = SL_CanonicalValue("DA_NU", SL_Text(ws.Range("B7").Value2)): v = ws.Range("B8").Value2
            If flag <> "Da" And flag <> "Nu" Then Err.Raise vbObjectError + 858, , "Activ trebuie sa fie Da sau Nu."
            If Not IsNumeric(v) Then Err.Raise vbObjectError + 859, , "Ordinea trebuie sa fie numerica."
            If CDbl(v) < 0 Or CDbl(v) > 99999 Or CDbl(v) <> Fix(CDbl(v)) Then Err.Raise vbObjectError + 860, , "Ordine: intreg intre 0 si 99999."
            If row Is Nothing Then
                If group <> "UM" And group <> "CATEGORIE" And group <> "METODA_PLATA" Then Err.Raise vbObjectError + 861, , "Grupa de sistem nu permite valori noi."
                If Len(key) = 0 Or Len(key) > 100 Or Left$(key, 1) = "=" Then Err.Raise vbObjectError + 862, , "Valoare noua invalida."
                If group = "METODA_PLATA" And StrComp(key, "Compensare", vbTextCompare) = 0 Then Err.Raise vbObjectError + 863, , "Compensarea are flux separat; nu este o metoda de plata manuala."
                ReDim values(1 To 1, 1 To 10)
                values(1, 1) = SL_ID("SL"): values(1, 2) = group: values(1, 3) = key: values(1, 6) = "Nu": revision = 1
            Else
                If key <> CStr(old(1, 3)) Or group <> CStr(old(1, 2)) Then Err.Raise vbObjectError + 864, , "Grupa si valoarea sunt stabile. Adaugati o valoare noua."
                If CStr(old(1, 6)) = "Da" And flag <> "Da" Then Err.Raise vbObjectError + 865, , "Codurile de sistem raman active."
                revision = CLng(old(1, 8)) + 1
            End If
            For Each lr In SL_Table(2).ListRows
                If CStr(lr.Range.Cells(1, 2).Value2) = group And CStr(lr.Range.Cells(1, 1).Value2) <> mID Then
                    If StrComp(CStr(lr.Range.Cells(1, 3).Value2), key, vbTextCompare) = 0 Then Err.Raise vbObjectError + 866, , "Valoare duplicata in grupa."
                    If CStr(lr.Range.Cells(1, 4).Value2) = "Da" Then activeCount = activeCount + 1
                End If
            Next lr
            If flag = "Nu" And activeCount = 0 Then Err.Raise vbObjectError + 867, , "Lista trebuie sa pastreze cel putin o valoare activa."
            If group = "METODA_PLATA" And flag = "Nu" And StrComp(key, CStr(SL_Param("PLATA_METODA_IMPLICITA", "OP")), vbTextCompare) = 0 Then Err.Raise vbObjectError + 868, , "Schimbati mai intai metoda implicita de plata."
            values(1, 4) = flag: values(1, 5) = CLng(v): values(1, 7) = SL_Text(ws.Range("B9").Value2)
            values(1, 8) = revision: values(1, 9) = CDbl(Now): values(1, 10) = Application.UserName
        Case 3
            For c = 4 To 7
                flag = SL_CanonicalValue("DA_NU", SL_Text(ws.Cells(c + 2, 2).Value2))
                If flag <> "Da" And flag <> "Nu" Then Err.Raise vbObjectError + 869, , "Fiecare cerinta trebuie sa fie Da sau Nu."
                values(1, c) = flag
            Next c
            state = SL_CanonicalValue("STARE_REGULA", SL_Text(ws.Range("B10").Value2))
            If state <> "De confirmat" And state <> "Confirmata" Then Err.Raise vbObjectError + 870, , "Stare: De confirmat sau Confirmata."
            values(1, 8) = state: values(1, 9) = SL_Text(ws.Range("B11").Value2)
            revision = CLng(values(1, 10)) + 1: values(1, 10) = revision: values(1, 11) = CDbl(Now): values(1, 12) = Application.UserName
        End Select
        If SL_Stamp() <> mStamp Then Err.Raise vbObjectError + 871, , "Configurarea s-a modificat inainte de salvare."
        Application.EnableEvents = False: eventID = SL_ID("EV")
        If row Is Nothing Then Set row = SL_Add(mKind): added = True
        changed = True: row.NumberFormat = "@": row.Value2 = values
        If mKind = 1 Then
            row.Cells(1, 7).NumberFormat = "0": row.Cells(1, 8).NumberFormat = "dd.mm.yyyy hh:mm"
            If CStr(row.Cells(1, 4).Value2) = "Intreg" Then row.Cells(1, 3).NumberFormat = "0"
        ElseIf mKind = 2 Then
            row.Cells(1, 5).NumberFormat = "0": row.Cells(1, 8).NumberFormat = "0": row.Cells(1, 9).NumberFormat = "dd.mm.yyyy hh:mm"
        Else
            row.Cells(1, 10).NumberFormat = "0": row.Cells(1, 11).NumberFormat = "dd.mm.yyyy hh:mm"
        End If
        SL_Audit mKind, CStr(row.Cells(1, 1).Value2), old, row, eventID, revision
    End If
    Call SL_ActualizeazaControl:     Application.Calculate: Application.EnableEvents = oldEvents
    changed = False: SL_InchideFormular
    MsgBox "Modificarile au fost salvate in registre. Salvati fisierul principal in Excel.", vbInformation, "TQM"
    Exit Sub
Fail:
    errorText = Err.description
    On Error Resume Next
    If changed Then
        If mKind = 4 Then
            For Each c In Array(11, 12, 13, 17): row.Cells(1, TQM_Control_Col(c)).Value2 = old(1, TQM_Control_Col(c)): Next c
        ElseIf added Then
            row.ClearContents
        Else
            row.Value2 = old
        End If
        SL_Table(4).Parent.Unprotect
        For c = SL_Table(4).ListRows.count To 1 Step -1
            If CStr(SL_Table(4).ListRows(c).Range.Cells(1, 1).Value2) = eventID Then SL_Table(4).ListRows(c).Delete
        Next c
        SL_Table(4).Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
        SL_ActualizeazaControl
    End If
    Application.EnableEvents = oldEvents
    On Error GoTo 0
    MsgBox errorText, vbExclamation, "TQM - Setari Liste"
End Sub

Private Sub SL_DOCSync()
    On Error Resume Next
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!DOC_Sync"
    On Error GoTo 0
End Sub

Public Function SL_CanonicalValue(ByVal group As String, ByVal value As String) As String
    Dim lr As ListRow, n As Long, result As String
    group = UCase$(Trim$(group)): value = SL_Text(value)
    If SL_GetSheet(SL_Sheet) Is Nothing Then SL_CanonicalValue = value: Exit Function
    For Each lr In SL_Table(2).ListRows
        If StrComp(CStr(lr.Range.Cells(1, 2).Value2), group, vbTextCompare) = 0 And StrComp(SL_Text(lr.Range.Cells(1, 3).Value2), value, vbTextCompare) = 0 Then
            If CStr(lr.Range.Cells(1, 4).Value2) = "Da" Then n = n + 1: result = SL_Text(lr.Range.Cells(1, 3).Value2)
        End If
    Next lr
    If n <> 1 Then Err.Raise vbObjectError + 880, , "Valoare inexistenta, inactiva sau duplicata: " & group & " / " & value
    SL_CanonicalValue = result
End Function

