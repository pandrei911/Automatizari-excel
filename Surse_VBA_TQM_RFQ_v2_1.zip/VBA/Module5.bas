Attribute VB_Name = "Module5"
Option Explicit

' TQM Calarasi - Comenzi furnizori v1, Excel desktop Windows.
' Formularul este un registru TEMPORAR local. Datele sunt in ThisWorkbook.
' Importati acest modul prin File > Import File. Nu necesita VBProject access.

Private Const CF_SHEET As String = "03_COMENZI_FURNIZORI"
Private Const CF_POS As String = "_TQM_CF_POZ"
Private Const CF_REC As String = "_TQM_CF_REC"
Private Const CF_MAIN_TABLE As String = "tTQMComenzi"
Private Const CF_POS_TABLE As String = "tTQMCFPoz"
Private Const CF_REC_TABLE As String = "tTQMCFRec"
Private Const CF_MARK As String = "TQM_CF_V1"
Private Const CF_FIRST As Long = 15
Private Const CF_LAST As Long = 114
Private mLocal As Workbook
Private mMode As String
Private mOrder As String
Private mStamp As String

Private Type CF_GUID
    Data1 As Long
    Data2 As Integer
    Data3 As Integer
    Data4(0 To 7) As Byte
End Type
#If VBA7 Then
Private Declare PtrSafe Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As CF_GUID) As Long
#Else
Private Declare Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As CF_GUID) As Long
#End If

Public Sub CF_Instaleaza()
    Dim oldE As Boolean, oldS As Boolean
    Dim ws As Worksheet
    Dim etapa As String
    Dim errNumber As Long, errMessage As String, errSource As String
    Dim protectAtExit As Boolean

    oldE = Application.EnableEvents
    oldS = Application.ScreenUpdating
    On Error GoTo Fail

    Application.EnableEvents = False
    Application.ScreenUpdating = False

    etapa = "Initializare registre - CF_Init"
    CF_Init
    Set ws = ThisWorkbook.Worksheets(CF_SHEET)
    protectAtExit = True

    etapa = "Deprotejare foaie Comenzi furnizori"
    ws.Unprotect Password:=""

    etapa = "Refacere interfata - CF_Layout"
    CF_Layout ws

    etapa = "Actualizare formule si legaturi - CF_Calc"
    CF_Calc

    etapa = "Configurare afisare si panouri fixe"
    ws.Activate
    With ActiveWindow
        .DisplayGridlines = False
        .FreezePanes = False
        .SplitRow = 12
        .SplitColumn = 2
        .FreezePanes = True
        .Zoom = 85
    End With

    etapa = "Reprotejare foaie Comenzi furnizori"
    ws.Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=True
    protectAtExit = False

    Application.EnableEvents = oldE
    Application.ScreenUpdating = oldS

    MsgBox "Modulul Comenzi furnizori este instalat. Datele existente au fost pastrate." & vbCrLf & _
           "Apasati Comanda noua sau Din oferte aprobate. Salvati fisierul .xlsm cu Ctrl+S.", _
           vbInformation, "TQM"
    Exit Sub

Fail:
    errNumber = Err.number
    errMessage = Err.description
    errSource = Err.source

    On Error Resume Next
    If protectAtExit Then
        If Not ws Is Nothing Then
            ws.Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=True
        End If
    End If
    Application.EnableEvents = oldE
    Application.ScreenUpdating = oldS
    On Error GoTo 0

    CF_Error "Instalarea Comenzi furnizori s-a oprit." & vbCrLf & _
             "Etapa: " & etapa & vbCrLf & _
             "Eroare: " & CStr(errNumber) & vbCrLf & _
             "Sursa: " & errSource & vbCrLf & _
             "Mesaj: " & errMessage
End Sub

Private Function CF_Heads(ByVal kind As Long) As Variant
    Select Case kind
    Case 1
        CF_Heads = Split("ID_comanda|Nr_comanda|Data_comanda|Furnizor|Proiect|Canal|Responsabil|Termen|Stare|Nr_pozitii|Valoare_net_RON|De_primit_RON|Livrare|Pozitii_intarziate|Transport_RON|Alte_costuri_RON|Referinta|Link_document|Observatii|Revizie|Actualizat_de|Actualizat_la", "|")
    Case 2
        CF_Heads = Split("ID_pozitie|ID_comanda|Cod_material|Material|Specificatie|UM|Cant_comandata|Pret_unitar|Discount_pct|Cant_primita|Cant_anulata|Cant_ramasa|Val_initiala|Val_de_primit|Termen_livrare|Proiect|ID_cerere|ID_oferta|Observatii", "|")
    Case 3
        CF_Heads = Split("ID_receptie|ID_pozitie|ID_comanda|Data|Document|Cantitate|Stare|Link|Creat_de|Creat_la|Motiv_anulare", "|")
    End Select
End Function

Private Sub CF_Init()
    Dim ws As Worksheet, p As Worksheet, r As Worksheet, lo As ListObject
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 301, , "Fisierul principal este deschis doar pentru citire."
    Set ws = CF_GetSheet(CF_SHEET)
    If ws Is Nothing Then
        Set ws = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
        ws.name = CF_SHEET: ws.Range("X1").Value2 = CF_MARK
    ElseIf CStr(ws.Range("X1").Value2) <> CF_MARK Then
        Err.Raise vbObjectError + 302, , "Exista deja o foaie Comenzi furnizori cu alta structura. Nu a fost modificata."
    End If
    Set p = CF_GetSheet(CF_POS)
    If p Is Nothing Then
        Set p = ThisWorkbook.Worksheets.Add(after:=ws): p.name = CF_POS
    End If
    Set r = CF_GetSheet(CF_REC)
    If r Is Nothing Then
        Set r = ThisWorkbook.Worksheets.Add(after:=p): r.name = CF_REC
    End If
    Set lo = CF_EnsureTable(ws, CF_MAIN_TABLE, 12, CF_Heads(1))
    Set lo = CF_EnsureTable(p, CF_POS_TABLE, 1, CF_Heads(2))
    Set lo = CF_EnsureTable(r, CF_REC_TABLE, 1, CF_Heads(3))
    ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    p.Visible = xlSheetVeryHidden: r.Visible = xlSheetVeryHidden
End Sub

Private Function CF_GetSheet(ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set CF_GetSheet = ThisWorkbook.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Function CF_EnsureTable(ByVal ws As Worksheet, ByVal tableName As String, ByVal rowNo As Long, ByVal heads As Variant) As ListObject
    Dim lo As ListObject, i As Long, n As Long
    On Error Resume Next
    Set lo = ws.ListObjects(tableName)
    On Error GoTo 0
    n = UBound(heads) + 1
    If lo Is Nothing Then
        If Application.CountA(ws.Cells(rowNo, 1).Resize(2, n)) > 0 Then _
            Err.Raise vbObjectError + 303, , "Date necunoscute in foaia " & ws.name & ". Instalarea a fost oprita."
        For i = 0 To UBound(heads): ws.Cells(rowNo, i + 1).Value2 = heads(i): Next i
        Set lo = ws.ListObjects.Add(xlSrcRange, ws.Cells(rowNo, 1).Resize(2, n), , xlYes)
        lo.name = tableName: lo.TableStyle = "TableStyleMedium2"
    Else
        If lo.ListColumns.count <> n Then Err.Raise vbObjectError + 304, , "Structura tabelului " & tableName & " nu corespunde versiunii 1."
        For i = 0 To UBound(heads)
            If lo.ListColumns(i + 1).name <> heads(i) Then Err.Raise vbObjectError + 305, , "Coloana modificata in " & tableName & ": " & heads(i)
        Next i
    End If
    Set CF_EnsureTable = lo
End Function

Private Function CF_Table(ByVal kind As Long) As ListObject
    Select Case kind
    Case 1: Set CF_Table = ThisWorkbook.Worksheets(CF_SHEET).ListObjects(CF_MAIN_TABLE)
    Case 2: Set CF_Table = ThisWorkbook.Worksheets(CF_POS).ListObjects(CF_POS_TABLE)
    Case 3: Set CF_Table = ThisWorkbook.Worksheets(CF_REC).ListObjects(CF_REC_TABLE)
    End Select
End Function

Private Sub CF_Layout(ByVal ws As Worksheet)
    Dim specs As Variant, a As Variant, i As Long, shp As Shape, widths As Variant
    ws.Range("A1:V11").UnMerge
    ws.Range("A1:V11").Clear
    ws.Range("A1:V11").Font.name = "Aptos": ws.Range("A1:V11").Font.size = 10
    CF_Band ws, "A2:M2", "TQM Calarasi - Comenzi furnizori", RGB(255, 255, 255), 18
    CF_Band ws, "A3:M3", "Comenzi ferme si online, cu mai multe materiale si livrari partiale", RGB(255, 255, 255), 10
    CF_Band ws, "A11:O11", "Selectati un rand si apasati actiunea dorita. Formularul este local sesiunii Excel.", RGB(255, 255, 255), 10
    specs = Array(Array("A5:B5", "Comanda noua", "CF_ComandaNoua"), Array("C5:D5", "Din oferte aprobate", "CF_DinOferte"), _
                  Array("E5:F5", "Deschide comanda", "CF_Deschide"), Array("G5:H5", "Receptie partiala", "CF_Receptie"), _
                  Array("I5:J5", "Anuleaza restul", "CF_AnuleazaRest"), Array("K5:L5", "Export PDF", "CF_ExportPDF"), _
                  Array("A6:B6", "Istoric receptii", "CF_Istoric"), Array("C6:D6", "Anuleaza receptie", "CF_AnuleazaReceptie"), _
                  Array("E6:F6", "Actualizeaza", "CF_Actualizeaza"))
    For i = ws.Shapes.count To 1 Step -1
        If Left$(ws.Shapes(i).name, 6) = "CFBTN_" Then ws.Shapes(i).Delete
    Next i
    For Each a In specs
        CF_Button ws, CStr(a(0)), CStr(a(1)), CStr(a(2))
    Next a
    CF_Card ws, "A8:C8", "A9:C9", "Comenzi inregistrate", "=COUNTIFS(tTQMComenzi[ID_comanda],""<>"")", RGB(239, 246, 255)
    CF_Card ws, "E8:G8", "E9:G9", "Comenzi de primit", _
        "=COUNTIFS(tTQMComenzi[Stare],""Trimisa"",tTQMComenzi[Livrare],""DE PRIMIT"")+COUNTIFS(tTQMComenzi[Stare],""Trimisa"",tTQMComenzi[Livrare],""LIVRARE PARTIALA"")+COUNTIFS(tTQMComenzi[Stare],""Confirmata"",tTQMComenzi[Livrare],""DE PRIMIT"")+COUNTIFS(tTQMComenzi[Stare],""Confirmata"",tTQMComenzi[Livrare],""LIVRARE PARTIALA"")", RGB(240, 253, 244)
    CF_Card ws, "I8:K8", "I9:K9", "Comenzi intarziate", "=COUNTIFS(tTQMComenzi[Pozitii_intarziate],"">0"")", RGB(254, 242, 242)
    CF_Card ws, "M8:O8", "M9:O9", "Materiale de primit (RON fara TVA)", "=SUMIFS(tTQMComenzi[De_primit_RON],tTQMComenzi[Stare],""Trimisa"")+SUMIFS(tTQMComenzi[De_primit_RON],tTQMComenzi[Stare],""Confirmata"")", RGB(255, 247, 237)
    ws.Range("M9").NumberFormat = "#,##0.00"
    widths = Array(16, 19, 14, 28, 25, 14, 19, 14, 17, 12, 19, 19, 24, 16, 17, 18, 24, 30, 35, 12, 20, 22)
    For i = 0 To UBound(widths): ws.Columns(i + 1).ColumnWidth = widths(i): Next i
    ws.rows("1:11").RowHeight = 23: ws.rows(12).RowHeight = 42
    With ws.Range("A12:V12")
        .Interior.Color = RGB(31, 41, 55): .Font.Color = vbWhite: .Font.Bold = True
        .Font.name = "Aptos": .Font.size = 10: .WrapText = True
        .VerticalAlignment = xlCenter: .HorizontalAlignment = xlCenter
    End With
    ws.Columns("C").NumberFormat = "dd.mm.yyyy": ws.Columns("H").NumberFormat = "dd.mm.yyyy"
    ws.Columns("K:L").NumberFormat = "#,##0.00": ws.Columns("O:P").NumberFormat = "#,##0.00"
    ws.Columns("V").NumberFormat = "dd.mm.yyyy hh:mm"
    ws.Tab.Color = RGB(37, 99, 235)
    With ws.Range("M13:M5012")
        .FormatConditions.Delete
        .FormatConditions.Add Type:=xlExpression, Formula1:="=$M13=""LIVRARE PARTIALA"""
        .FormatConditions(1).Interior.Color = RGB(255, 247, 237)
        .FormatConditions.Add Type:=xlExpression, Formula1:="=$M13=""PRIMITA INTEGRAL"""
        .FormatConditions(2).Interior.Color = RGB(240, 253, 244)
    End With
    With ws.Range("N13:N5012")
        .FormatConditions.Delete
        .FormatConditions.Add Type:=xlExpression, Formula1:="=$N13>0"
        .FormatConditions(1).Interior.Color = RGB(254, 242, 242)
        .FormatConditions(1).Font.Color = RGB(185, 28, 28)
    End With
End Sub

Private Sub CF_Band(ByVal ws As Worksheet, ByVal address As String, ByVal title As String, ByVal colour As Long, ByVal size As Long)
    With ws.Range(address)
        .Merge: .Value2 = title: .Interior.Color = colour: .Font.size = size
        .Font.Color = RGB(31, 41, 55): .Font.Bold = (size > 10): .VerticalAlignment = xlCenter
    End With
End Sub

Private Sub CF_Card(ByVal ws As Worksheet, ByVal labelRange As String, ByVal valueRange As String, ByVal title As String, ByVal formula As String, ByVal colour As Long)
    CF_Band ws, labelRange, title, colour, 10
    CF_Band ws, valueRange, "", colour, 18
    ws.Range(valueRange).Cells(1, 1).formula = formula
End Sub

Private Sub CF_Button(ByVal ws As Worksheet, ByVal address As String, ByVal title As String, ByVal macro As String)
    Dim rg As Range, sh As Shape
    Set rg = ws.Range(address)
    Set sh = ws.Shapes.AddShape(msoShapeRoundedRectangle, rg.Left + 2, rg.Top + 2, rg.width - 4, rg.Height - 4)
    sh.name = "CFBTN_" & macro
    sh.Fill.ForeColor.RGB = RGB(37, 99, 235): sh.line.Visible = msoFalse
    sh.TextFrame2.TextRange.text = title
    sh.TextFrame2.TextRange.Font.name = "Aptos": sh.TextFrame2.TextRange.Font.size = 10
    sh.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = vbWhite
    sh.TextFrame2.VerticalAnchor = msoAnchorMiddle
    sh.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    sh.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & macro
    sh.Placement = xlFreeFloating
End Sub

Private Function CF_NewID(ByVal prefix As String) As String
    Dim g As CF_GUID, t As String, i As Long
    If CoCreateGuid(g) <> 0 Then Err.Raise vbObjectError + 306, , "Nu s-a putut genera identificatorul unic."
    t = Right$("00000000" & Hex$(g.Data1), 8) & Right$("0000" & Hex$(g.Data2), 4) & Right$("0000" & Hex$(g.Data3), 4)
    For i = 0 To 7: t = t & Right$("00" & Hex$(g.Data4(i)), 2): Next i
    CF_NewID = prefix & "-" & t
End Function

Private Function CF_Find(ByVal lo As ListObject, ByVal key As String, Optional ByVal col As Long = 1) As Range
    Dim row As ListRow, found As Range
    For Each row In lo.ListRows
        If StrComp(CStr(row.Range.Cells(1, col).Value2), key, vbTextCompare) = 0 And Len(key) > 0 Then
            If Not found Is Nothing Then Err.Raise vbObjectError + 307, , "Identificator duplicat in " & lo.name & ": " & key
            Set found = row.Range
        End If
    Next row
    Set CF_Find = found
End Function

Private Function CF_Add(ByVal lo As ListObject) As Range
    Dim row As ListRow, wasProtected As Boolean, eno As Long, msg As String
    On Error GoTo Fail
    For Each row In lo.ListRows
        If Len(CStr(row.Range.Cells(1, 1).Value2)) = 0 Then
            Set CF_Add = row.Range: Exit Function
        End If
    Next row
    wasProtected = lo.Parent.ProtectContents
    If wasProtected Then lo.Parent.Unprotect
    Set CF_Add = lo.ListRows.Add.Range
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Exit Function
Fail:
    eno = Err.number: msg = Err.description
    On Error Resume Next
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    On Error GoTo 0
    Err.Raise eno, "CF_Add", msg
End Function

Private Function CF_Selected() As String
    Dim lo As ListObject, hit As Range, idx As Long
    Set lo = CF_Table(1)
    If Not ActiveWorkbook Is ThisWorkbook Then Err.Raise vbObjectError + 308, , "Selectati comanda in fisierul principal."
    If ActiveSheet.name <> CF_SHEET Then Err.Raise vbObjectError + 309, , "Deschideti foaia Comenzi furnizori si selectati un rand din registru."
    If lo.DataBodyRange Is Nothing Then Err.Raise vbObjectError + 310, , "Nu exista comenzi in registru."
    Set hit = Intersect(ActiveCell, lo.DataBodyRange)
    If hit Is Nothing Then Err.Raise vbObjectError + 311, , "Selectati o celula din randul comenzii."
    idx = ActiveCell.row - lo.HeaderRowRange.row
    CF_Selected = CStr(lo.ListRows(idx).Range.Cells(1, 1).Value2)
    If Len(CF_Selected) = 0 Then Err.Raise vbObjectError + 312, , "Randul selectat este gol."
End Function

Private Sub CF_Error(ByVal message As String)
    MsgBox message, vbExclamation, "TQM - Comenzi furnizori"
End Sub

Private Sub CF_Calc()
    Dim lo As ListObject, oldE As Boolean, errNumber As Long, errMessage As String
    Dim calcSheets(1 To 3) As Worksheet
    Dim restoreProtection(1 To 3) As Boolean
    Dim savedFiltering(1 To 3) As Boolean
    Dim i As Long, stage As String, errSource As String
    oldE = Application.EnableEvents
    On Error GoTo Fail
    Application.EnableEvents = False
    stage = "Pregatire foi pentru scrierea formulelor"
    For i = 1 To 3
        Set calcSheets(i) = CF_Table(i).Parent
        If calcSheets(i).ProtectContents Or calcSheets(i).ProtectDrawingObjects Or calcSheets(i).ProtectScenarios Then
            savedFiltering(i) = calcSheets(i).Protection.AllowFiltering
            calcSheets(i).Unprotect Password:=""
            restoreProtection(i) = True
        End If
    Next i
    stage = "Formule pozitii comanda"
    Set lo = CF_Table(2)
    If Not lo.DataBodyRange Is Nothing Then
        CF_CalcSetR1C1 lo, "Cant_primita", "=IF([@ID_pozitie]="""","""",SUMIFS(tTQMCFRec[Cantitate],tTQMCFRec[ID_pozitie],[@ID_pozitie],tTQMCFRec[Stare],""Valida""))"
        CF_CalcSetR1C1 lo, "Cant_ramasa", "=IF([@ID_pozitie]="""","""",MAX(0,ROUND([@Cant_comandata]-[@Cant_primita]-[@Cant_anulata],6)))"
        CF_CalcSetR1C1 lo, "Val_initiala", "=IF([@ID_pozitie]="""","""",ROUND([@Cant_comandata]*[@Pret_unitar]*(1-[@Discount_pct]/100),2))"
        CF_CalcSetR1C1 lo, "Val_de_primit", "=IF([@ID_pozitie]="""","""",ROUND([@Cant_ramasa]*[@Pret_unitar]*(1-[@Discount_pct]/100),2))"
        stage = "Format Termen_livrare"
        lo.ListColumns("Termen_livrare").DataBodyRange.NumberFormat = "dd.mm.yyyy"
        lo.Parent.Calculate
    End If
    stage = "Formule registru comenzi"
    Set lo = CF_Table(1)
    If Not lo.DataBodyRange Is Nothing Then
        CF_CalcSetR1C1 lo, "Nr_pozitii", "=IF([@ID_comanda]="""","""",COUNTIFS(tTQMCFPoz[ID_comanda],[@ID_comanda]))"
        CF_CalcSetR1C1 lo, "Valoare_net_RON", "=IF([@ID_comanda]="""","""",SUMIFS(tTQMCFPoz[Val_initiala],tTQMCFPoz[ID_comanda],[@ID_comanda])+[@Transport_RON]+[@Alte_costuri_RON])"
        CF_CalcSetR1C1 lo, "De_primit_RON", "=IF([@ID_comanda]="""","""",SUMIFS(tTQMCFPoz[Val_de_primit],tTQMCFPoz[ID_comanda],[@ID_comanda]))"
        CF_CalcSetR1C1 lo, "Livrare", "=IF([@ID_comanda]="""","""",IF([@Nr_pozitii]=0,""FARA POZITII"",IF([@Stare]=""Ciorna"",""CIORNA"",IF(COUNTIFS(tTQMCFPoz[ID_comanda],[@ID_comanda],tTQMCFPoz[Cant_ramasa],"">0"")=0,IF(SUMIFS(tTQMCFPoz[Cant_anulata],tTQMCFPoz[ID_comanda],[@ID_comanda])>0,IF(SUMIFS(tTQMCFPoz[Cant_primita],tTQMCFPoz[ID_comanda],[@ID_comanda])>0,""INCHISA PARTIAL"",""ANULATA""),""PRIMITA INTEGRAL""),IF(SUMIFS(tTQMCFPoz[Cant_primita],tTQMCFPoz[ID_comanda],[@ID_comanda])>0,""LIVRARE PARTIALA"",""DE PRIMIT"")))))"
        CF_CalcSetR1C1 lo, "Pozitii_intarziate", "=IF([@ID_comanda]="""","""",IF(OR([@Stare]=""Trimisa"",[@Stare]=""Confirmata""),COUNTIFS(tTQMCFPoz[ID_comanda],[@ID_comanda],tTQMCFPoz[Termen_livrare],""<""&TODAY(),tTQMCFPoz[Cant_ramasa],"">0""),0))"
        stage = "Format Data_comanda"
        lo.ListColumns("Data_comanda").DataBodyRange.NumberFormat = "dd.mm.yyyy"
        stage = "Format Termen"
        lo.ListColumns("Termen").DataBodyRange.NumberFormat = "dd.mm.yyyy"
        stage = "Format Actualizat_la"
        lo.ListColumns("Actualizat_la").DataBodyRange.NumberFormat = "dd.mm.yyyy hh:mm"
        stage = "Format Valoare_net_RON"
        lo.ListColumns("Valoare_net_RON").DataBodyRange.NumberFormat = "#,##0.00"
        stage = "Format De_primit_RON"
        lo.ListColumns("De_primit_RON").DataBodyRange.NumberFormat = "#,##0.00"
    End If
    stage = "Recalculare foi Comenzi furnizori"
    CF_Table(3).Parent.Calculate: CF_Table(2).Parent.Calculate: CF_Table(1).Parent.Calculate
    stage = "Sincronizare proiecte si bugete"
    CF_PBSync
    stage = "Sincronizare documente"
    CF_DOCSync
    stage = "Restabilire protectie foi"
    For i = 1 To 3
        If restoreProtection(i) Then
            calcSheets(i).Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=savedFiltering(i)
            restoreProtection(i) = False
        End If
    Next i
    Application.EnableEvents = oldE
    Exit Sub
Fail:
    errNumber = Err.number: errMessage = Err.description: errSource = Err.source
    On Error Resume Next
    For i = 1 To 3
        If restoreProtection(i) Then
            calcSheets(i).Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=savedFiltering(i)
        End If
    Next i
    Application.EnableEvents = oldE
    On Error GoTo 0
    If Len(errSource) = 0 Then errSource = "CF_Calc"
    Err.Raise errNumber, errSource, "Etapa CF_Calc: " & stage & vbCrLf & errMessage
End Sub

Private Sub CF_CalcSetR1C1(ByVal lo As ListObject, ByVal columnName As String, ByVal template As String)
    Dim target As Range, lc As ListColumn, sourceTable As ListObject
    Dim formulaText As String, token As String, targetAddress As String
    Dim i As Long, errNumber As Long, errMessage As String

    On Error GoTo Fail
    Set target = lo.ListColumns(columnName).DataBodyRange
    If target Is Nothing Then Exit Sub
    targetAddress = target.address(False, False)
    formulaText = template

    ' RC plus coloana absoluta pastreaza referinta la randul curent.
    For Each lc In lo.ListColumns
        token = "[@" & lc.name & "]"
        formulaText = Replace(formulaText, token, "RC" & CStr(lc.Range.column), 1, -1, vbBinaryCompare)
    Next lc

    ' Intervalele sursa sunt refacute la fiecare CF_Calc, dupa adaugari de randuri.
    For i = 1 To 3
        Set sourceTable = CF_Table(i)
        For Each lc In sourceTable.ListColumns
            token = sourceTable.name & "[" & lc.name & "]"
            If InStr(1, formulaText, token, vbBinaryCompare) > 0 Then
                formulaText = Replace(formulaText, token, CF_CalcSourceRefR1C1(lc), 1, -1, vbBinaryCompare)
            End If
        Next lc
    Next i

    If InStr(1, formulaText, "[@", vbBinaryCompare) > 0 Then
        Err.Raise vbObjectError + 390, "CF_CalcSetR1C1", "Referinta la o coloana inexistenta in formula."
    End If
    target.FormulaR1C1 = formulaText
    Exit Sub

Fail:
    errNumber = Err.number
    errMessage = Err.description
    Debug.Print "CF_Calc: " & lo.name & "." & columnName
    Debug.Print formulaText
    Err.Raise errNumber, "CF_Calc." & lo.name & "." & columnName, _
              errMessage & vbCrLf & "Foaie: " & lo.Parent.name & "; interval: " & targetAddress
End Sub

Private Function CF_CalcSourceRefR1C1(ByVal lc As ListColumn) As String
    Dim sourceRange As Range
    Set sourceRange = lc.DataBodyRange
    If sourceRange Is Nothing Then
        Set sourceRange = lc.Parent.HeaderRowRange.Cells(1, lc.Index).Offset(1, 0)
    End If
    CF_CalcSourceRefR1C1 = "'" & Replace(sourceRange.Parent.name, "'", "''") & "'!" & _
                          sourceRange.address(RowAbsolute:=True, ColumnAbsolute:=True, ReferenceStyle:=xlR1C1, External:=False)
End Function

Public Sub CF_Actualizeaza()
    On Error GoTo Fail
    Call CF_Init:     CF_Calc
    Exit Sub
Fail: CF_Error Err.description
End Sub

Private Sub CF_Touch(ByVal id As String)
    Dim h As Range
    Set h = CF_Find(CF_Table(1), id)
    If h Is Nothing Then Err.Raise vbObjectError + 361, , "Comanda nu exista."
    h.Cells(1, 20).Value2 = CLng(h.Cells(1, 20).Value2) + 1
    h.Cells(1, 21).Value2 = Application.UserName: h.Cells(1, 22).Value2 = CDbl(Now)
End Sub

Public Sub CF_Receptie()
    Dim id As String, h As Range, ws As Worksheet, lr As ListRow, n As Long, heads As Variant, i As Long
    On Error GoTo Fail
    Call CF_Init:     CF_Calc: id = CF_Selected(): Set h = CF_Find(CF_Table(1), id)
    If CStr(h.Cells(1, 9).Value2) <> "Trimisa" And CStr(h.Cells(1, 9).Value2) <> "Confirmata" Then _
        Err.Raise vbObjectError + 362, , "Receptionati numai o comanda Trimisa sau Confirmata."
    If CStr(h.Cells(1, 13).Value2) = "PRIMITA INTEGRAL" Or CStr(h.Cells(1, 13).Value2) = "INCHISA PARTIAL" Then _
        Err.Raise vbObjectError + 363, , "Comanda nu mai are cantitati de primit."
    If Not CF_StartLocal("RECEPTIE", id) Then Exit Sub
    Set ws = mLocal.Worksheets(1)
    ws.Range("A1:I115").Font.name = "Aptos": ws.Range("A1:I115").Font.size = 10
    ws.Range("A1:I115").RowHeight = 25
    CF_Band ws, "A1:I1", "TQM - Receptie " & CStr(h.Cells(1, 2).Value2), RGB(255, 255, 255), 16
    CF_Button ws, "A3:C3", "Salveaza receptia", "CF_SalveazaReceptie"
    CF_Button ws, "D3:F3", "Inchide formularul", "CF_InchideFormular"
    ws.Range("A5").Value2 = "Data receptiei": CF_Input ws, "B5:C5", CDbl(Date)
    ws.Range("E5").Value2 = "Nr. aviz/document": CF_Input ws, "F5:I5"
    ws.Range("A6").Value2 = "Link document": CF_Input ws, "B6:I6"
    CF_Band ws, "A7:I7", "Introduceti in Primesc acum numai cantitatea din aceasta livrare. Nu se opereaza stocul in acest modul.", RGB(255, 247, 237), 10
    heads = Split("ID_pozitie|Material|UM|Comandat|Primit|Anulat|Ramas|Primesc acum|Proiect", "|")
    For i = 0 To UBound(heads): ws.Cells(9, i + 1).Value2 = heads(i): Next i
    With ws.Range("A9:I9")
        .Interior.Color = RGB(31, 41, 55): .Font.Color = vbWhite: .Font.Bold = True: .WrapText = True
    End With
    ws.Columns("A").ColumnWidth = 18: ws.Columns("B").ColumnWidth = 36
    ws.Columns("C").ColumnWidth = 9: ws.Columns("D:H").ColumnWidth = 14: ws.Columns("I").ColumnWidth = 28
    n = 10
    For Each lr In CF_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = id And Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then
            If CDbl(lr.Range.Cells(1, 12).Value2) > 0 Then
                ws.Cells(n, 1).Value2 = lr.Range.Cells(1, 1).Value2
                ws.Cells(n, 2).Value2 = lr.Range.Cells(1, 4).Value2: ws.Cells(n, 3).Value2 = lr.Range.Cells(1, 6).Value2
                ws.Cells(n, 4).Value2 = lr.Range.Cells(1, 7).Value2: ws.Cells(n, 5).Value2 = lr.Range.Cells(1, 10).Value2
                ws.Cells(n, 6).Value2 = lr.Range.Cells(1, 11).Value2: ws.Cells(n, 7).Value2 = lr.Range.Cells(1, 12).Value2
                ws.Cells(n, 8).Value2 = 0: ws.Cells(n, 9).Value2 = lr.Range.Cells(1, 16).Value2
                ws.Cells(n, 8).Locked = False: ws.Cells(n, 8).Interior.Color = RGB(239, 246, 255)
                n = n + 1
            End If
        End If
    Next lr
    ws.Range("B5").NumberFormat = "dd.mm.yyyy": ws.Range("D10:H110").NumberFormat = "#,##0.######"
    ws.Range("A9").Value2 = "": ws.Range("A10:A109").Font.Color = vbWhite
    ws.Protect UserInterfaceOnly:=True
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 90
    ActiveWindow.SplitRow = 9: ActiveWindow.SplitColumn = 2: ActiveWindow.FreezePanes = True
    ws.Range("H10").Select
    Exit Sub
Fail: CF_Error Err.description
End Sub

Public Sub CF_SalveazaReceptie()
    Dim ws As Worksheet, h As Range, pos As Range, row As Range, lr As ListRow
    Dim receipt As String, doc As String, link As String, dat As Double, n As Long, qty As Double, key As String
    Dim records As New Collection, item As Variant, v(1 To 11) As Variant, oldH As Variant
    Dim oldE As Boolean, oldS As Boolean, writing As Boolean, message As String, i As Long, orderID As String
    On Error GoTo Fail
    CF_CheckLocal "RECEPTIE": CF_Init: CF_Calc: Set ws = mLocal.Worksheets(1)
    orderID = mOrder: Set h = CF_Find(CF_Table(1), orderID)
    dat = CF_DateNum(ws.Range("B5").Value2, "Data receptiei")
    doc = CF_Text(ws.Range("F5").Value2): link = CF_Text(ws.Range("B6").Value2)
    If Len(doc) = 0 Then Err.Raise vbObjectError + 364, , "Introduceti Nr. aviz/document."
    If Not CF_LinkOK(link) Then Err.Raise vbObjectError + 365, , "Link document invalid."
    If dat < CDbl(h.Cells(1, 3).Value2) Or dat > CDbl(Date) Then Err.Raise vbObjectError + 366, , "Data receptiei trebuie sa fie intre data comenzii si astazi."
    If CStr(h.Cells(1, 9).Value2) <> "Trimisa" And CStr(h.Cells(1, 9).Value2) <> "Confirmata" Then Err.Raise vbObjectError + 367, , "Starea comenzii nu permite receptii."
    For Each lr In CF_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 3).Value2) = orderID And CStr(lr.Range.Cells(1, 7).Value2) = "Valida" Then
            If StrComp(CStr(lr.Range.Cells(1, 5).Value2), doc, vbTextCompare) = 0 And CDbl(lr.Range.Cells(1, 4).Value2) = dat Then _
                Err.Raise vbObjectError + 368, , "Acest document si aceasta data sunt deja inregistrate pentru comanda. Verificati istoricul."
        End If
    Next lr
    receipt = CF_NewID("RC")
    For n = 10 To 109
        key = CF_Text(ws.Cells(n, 1).Value2)
        If Len(key) > 0 Then
            qty = CF_Num(ws.Cells(n, 8).Value2, "Primesc acum, rand " & n)
            If Abs(qty - Round(qty, 6)) > 0.00000001 Then Err.Raise vbObjectError + 369, , "Cantitatea accepta maximum 6 zecimale."
            If qty > 0 Then
                Set pos = CF_Find(CF_Table(2), key)
                If pos Is Nothing Then Err.Raise vbObjectError + 370, , "Pozitia nu mai exista."
                If CStr(pos.Cells(1, 2).Value2) <> orderID Then Err.Raise vbObjectError + 371, , "Pozitia apartine altei comenzi."
                If qty - CDbl(pos.Cells(1, 12).Value2) > 0.00000001 Then Err.Raise vbObjectError + 372, , "Rand " & n & ": cantitatea depaseste restul de primit."
                For i = 1 To 11: v(i) = Empty: Next i
                v(1) = receipt: v(2) = key: v(3) = orderID: v(4) = dat: v(5) = doc: v(6) = qty
                v(7) = "Valida": v(8) = link: v(9) = Application.UserName: v(10) = CDbl(Now): v(11) = ""
                records.Add v
            End If
        End If
    Next n
    If records.count = 0 Then Err.Raise vbObjectError + 373, , "Nu ati introdus nicio cantitate de primit."
    Call CF_ConflictCheck:     Set h = CF_Find(CF_Table(1), orderID): oldH = h.formula
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: writing = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    For Each item In records: Set row = CF_Add(CF_Table(3)): CF_Write row, item: Next item
    CF_Touch orderID: CF_Calc
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS: writing = False
    CF_CloseLocal
    Set row = CF_Find(CF_Table(1), orderID): Application.Goto row.Cells(1, 2), False
    MsgBox "Receptia a fost inregistrata pentru " & records.count & " pozitii." & vbCrLf & "ID receptie: " & receipt & vbCrLf & "Ctrl+S salveaza fisierul principal.", vbInformation, "TQM"
    Exit Sub
Fail:
    message = Err.description
    If writing Then
        On Error Resume Next
        For i = CF_Table(3).ListRows.count To 1 Step -1
            If CStr(CF_Table(3).ListRows(i).Range.Cells(1, 1).Value2) = receipt Then CF_Table(3).ListRows(i).Delete
        Next i
        h.formula = oldH: CF_Calc
        Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
        On Error GoTo 0
    End If
    CF_Error message
End Sub

Public Sub CF_AnuleazaRest()
    Dim id As String, h As Range, lr As ListRow, oldH As Variant, oldP As Collection, reason As Variant
    Dim oldE As Boolean, oldS As Boolean, writing As Boolean, message As String, count As Long, item As Variant, row As Range, stamp As String
    On Error GoTo Fail
    Call CF_Init:     CF_Calc: id = CF_Selected(): Set h = CF_Find(CF_Table(1), id): stamp = CF_Stamp(id)
    For Each lr In CF_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = id Then
            If CDbl(lr.Range.Cells(1, 12).Value2) > 0 Then count = count + 1
        End If
    Next lr
    If count = 0 Then Err.Raise vbObjectError + 374, , "Comanda nu mai are cantitati de anulat."
    reason = Application.InputBox("Motivul anularii cantitatilor ramase:", "TQM - Anulare rest", Type:=2)
    If VarType(reason) = vbBoolean Then Exit Sub
    If Len(Trim$(CStr(reason))) = 0 Then Err.Raise vbObjectError + 375, , "Introduceti motivul anularii."
    If MsgBox("Anulati cantitatile ramase pentru " & count & " pozitii? Cantitatile deja primite se pastreaza.", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
    CF_Calc
    If CF_Stamp(id) <> stamp Then Err.Raise vbObjectError + 379, , "Comanda s-a modificat in timpul confirmarii. Reluati anularea."
    Set h = CF_Find(CF_Table(1), id): Set oldP = CF_BackupLines(id): oldH = h.formula
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: writing = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    For Each lr In CF_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = id Then
            lr.Range.Cells(1, 11).Value2 = CDbl(lr.Range.Cells(1, 11).Value2) + CDbl(lr.Range.Cells(1, 12).Value2)
        End If
    Next lr
    If Not CF_HasValidReceipts(id) Then h.Cells(1, 9).Value2 = "Anulata"
    h.Cells(1, 19).Value2 = CStr(h.Cells(1, 19).Value2) & " | Rest anulat " & Format$(Now, "dd.mm.yyyy hh:nn") & ": " & CStr(reason)
    CF_Touch id: CF_Calc
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS: writing = False
    MsgBox "Cantitatile ramase au fost anulate. Receptiile existente sunt pastrate. Ctrl+S salveaza fisierul.", vbInformation, "TQM"
    Exit Sub
Fail:
    message = Err.description
    If writing Then
        On Error Resume Next
        CF_DeleteLines id
        For Each item In oldP: Set row = CF_Add(CF_Table(2)): row.formula = item: Next item
        h.formula = oldH: CF_Calc
        Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
        On Error GoTo 0
    End If
    CF_Error message
End Sub

Private Function CF_HasValidReceipts(ByVal id As String) As Boolean
    Dim lr As ListRow
    For Each lr In CF_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 3).Value2) = id And CStr(lr.Range.Cells(1, 7).Value2) = "Valida" Then CF_HasValidReceipts = True: Exit Function
    Next lr
End Function

Public Sub CF_Istoric()
    Dim id As String, ws As Worksheet, lr As ListRow, pos As Range, n As Long, i As Long, heads As Variant
    On Error GoTo Fail
    Call CF_Init:     CF_Calc: id = CF_Selected()
    If Not CF_StartLocal("ISTORIC", id) Then Exit Sub
    Set ws = mLocal.Worksheets(1)
    CF_Band ws, "A1:L1", "TQM - Istoric receptii", RGB(255, 255, 255), 16
    CF_Button ws, "A3:C3", "Inchide istoricul", "CF_InchideFormular"
    heads = Split("ID_receptie|Data|Document|Material|UM|Cantitate|Stare|Proiect|Creat de|Creat la|Link|Motiv anulare", "|")
    For i = 0 To UBound(heads): ws.Cells(5, i + 1).Value2 = heads(i): Next i
    n = 6
    For Each lr In CF_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 3).Value2) = id Then
            Set pos = CF_Find(CF_Table(2), CStr(lr.Range.Cells(1, 2).Value2))
            If pos Is Nothing Then Err.Raise vbObjectError + 376, , "Receptie fara pozitie asociata: " & lr.Range.Cells(1, 1).Value2
            ws.Cells(n, 1).Value2 = lr.Range.Cells(1, 1).Value2: ws.Cells(n, 2).Value2 = lr.Range.Cells(1, 4).Value2
            ws.Cells(n, 3).Value2 = lr.Range.Cells(1, 5).Value2: ws.Cells(n, 4).Value2 = pos.Cells(1, 4).Value2
            ws.Cells(n, 5).Value2 = pos.Cells(1, 6).Value2: ws.Cells(n, 6).Value2 = lr.Range.Cells(1, 6).Value2
            ws.Cells(n, 7).Value2 = lr.Range.Cells(1, 7).Value2: ws.Cells(n, 8).Value2 = pos.Cells(1, 16).Value2
            ws.Cells(n, 9).Value2 = lr.Range.Cells(1, 9).Value2: ws.Cells(n, 10).Value2 = lr.Range.Cells(1, 10).Value2
            ws.Cells(n, 11).Value2 = lr.Range.Cells(1, 8).Value2: ws.Cells(n, 12).Value2 = lr.Range.Cells(1, 11).Value2
            n = n + 1
        End If
    Next lr
    ws.Range("A5:L5").Interior.Color = RGB(31, 41, 55): ws.Range("A5:L5").Font.Color = vbWhite
    ws.Range("A1:L" & n).Font.name = "Aptos": ws.Range("A5:L" & n).Font.size = 10
    ws.Range("A5:L" & n).RowHeight = 24: ws.Columns("A:L").ColumnWidth = 22
    ws.Columns("A").ColumnWidth = 42: ws.Columns("D").ColumnWidth = 32
    ws.Columns("B").NumberFormat = "dd.mm.yyyy": ws.Columns("J").NumberFormat = "dd.mm.yyyy hh:mm"
    If n = 6 Then ws.Range("A6").Value2 = "Nu exista receptii."
    ws.Range("A5:L" & n).AutoFilter: ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    ActiveWindow.DisplayGridlines = False: ActiveWindow.SplitRow = 5: ActiveWindow.FreezePanes = True
    Exit Sub
Fail: CF_Error Err.description
End Sub

Public Sub CF_AnuleazaReceptie()
    Dim id As String, receipt As Variant, reason As Variant, lr As ListRow, h As Range
    Dim backs As New Collection, indices As New Collection, i As Long, found As Boolean, message As String, oldH As Variant
    Dim oldE As Boolean, oldS As Boolean, writing As Boolean, stamp As String
    On Error GoTo Fail
    Call CF_Init:     CF_Calc: id = CF_Selected(): stamp = CF_Stamp(id)
    receipt = Application.InputBox("Introduceti ID_receptie din Istoric receptii. Toate pozitiile acelei receptii vor fi anulate.", "TQM - Corectie receptie", Type:=2)
    If VarType(receipt) = vbBoolean Then Exit Sub
    receipt = Trim$(CStr(receipt))
    reason = Application.InputBox("Motivul corectiei:", "TQM", Type:=2)
    If VarType(reason) = vbBoolean Then Exit Sub
    If Len(Trim$(CStr(reason))) = 0 Then Err.Raise vbObjectError + 377, , "Motivul este obligatoriu."
    For i = 1 To CF_Table(3).ListRows.count
        Set lr = CF_Table(3).ListRows(i)
        If CStr(lr.Range.Cells(1, 1).Value2) = receipt And CStr(lr.Range.Cells(1, 3).Value2) = id And CStr(lr.Range.Cells(1, 7).Value2) = "Valida" Then
            backs.Add lr.Range.formula: indices.Add i: found = True
        End If
    Next i
    If Not found Then Err.Raise vbObjectError + 378, , "Nu exista receptie valida cu acest ID pentru comanda selectata."
    If MsgBox("Anulati receptia si recalculati cantitatile ramase? Istoricul se pastreaza.", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
    CF_Calc
    If CF_Stamp(id) <> stamp Then Err.Raise vbObjectError + 380, , "Comanda s-a modificat in timpul confirmarii. Reluati corectia."
    CF_STBeforeVoid CStr(receipt)
    Set h = CF_Find(CF_Table(1), id): oldH = h.formula
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: writing = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    For i = 1 To indices.count
        Set lr = CF_Table(3).ListRows(CLng(indices(i)))
        lr.Range.Cells(1, 7).Value2 = "Anulata"
        lr.Range.Cells(1, 11).Value2 = CStr(reason) & " | " & Application.UserName & " | " & Format$(Now, "dd.mm.yyyy hh:nn")
    Next i
    CF_Touch id: CF_Calc
    CF_STApplyVoid CStr(receipt), CStr(reason)
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS: writing = False
    MsgBox "Receptia a fost anulata. Daca trebuie, introduceti apoi receptia corecta. Ctrl+S salveaza fisierul.", vbInformation, "TQM"
    Exit Sub
Fail:
    message = Err.description
    If writing Then
        On Error Resume Next
        For i = 1 To indices.count: CF_Table(3).ListRows(CLng(indices(i))).Range.formula = backs(i): Next i
        h.formula = oldH: CF_Calc
        Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
        On Error GoTo 0
    End If
    CF_Error message
End Sub

Public Sub CF_ExportPDF()
    Dim id As String, h As Range, lr As ListRow, doc As Workbook, ws As Worksheet, path As Variant, n As Long, i As Long
    Dim heads As Variant, message As String, fileName As String
    On Error GoTo Fail
    Call CF_Init:     CF_Calc: id = CF_Selected(): Set h = CF_Find(CF_Table(1), id)
    fileName = CStr(h.Cells(1, 2).Value2)
    For i = 1 To Len(fileName)
        If InStr("\/:*?""<>|", mID$(fileName, i, 1)) > 0 Then Mid$(fileName, i, 1) = "_"
    Next i
    path = Application.GetSaveAsFilename(InitialFileName:="Comanda_" & fileName & ".pdf", FileFilter:="PDF (*.pdf), *.pdf")
    If VarType(path) = vbBoolean Then Exit Sub
    Set doc = Workbooks.Add(xlWBATWorksheet): Set ws = doc.Worksheets(1)
    ws.Range("A1:I110").Font.name = "Aptos": ws.Range("A1:I110").Font.size = 10
    CF_Band ws, "A1:I1", "TQM Calarasi - Comanda furnizor", vbWhite, 16
    CF_Band ws, "A3:I3", "Nr. " & h.Cells(1, 2).Value2 & " / " & Format$(h.Cells(1, 3).Value2, "dd.mm.yyyy") & " - " & h.Cells(1, 9).Value2, vbWhite, 12
    CF_Band ws, "A4:I4", "Furnizor: " & h.Cells(1, 4).Value2, vbWhite, 10
    CF_Band ws, "A5:I5", "Responsabil: " & h.Cells(1, 7).Value2 & " | Referinta: " & h.Cells(1, 17).Value2, vbWhite, 10
    heads = Split("Nr.|Material / specificatie|UM|Cant. initiala|Pret unitar|Discount %|Valoare net|Termen|Proiect", "|")
    For i = 0 To UBound(heads): ws.Cells(7, i + 1).Value2 = heads(i): Next i
    n = 8
    For Each lr In CF_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = id Then
            ws.Cells(n, 1).Value2 = n - 7
            ws.Cells(n, 2).Value2 = lr.Range.Cells(1, 4).Value2 & vbLf & lr.Range.Cells(1, 5).Value2
            ws.Cells(n, 3).Value2 = lr.Range.Cells(1, 6).Value2: ws.Cells(n, 4).Value2 = lr.Range.Cells(1, 7).Value2
            ws.Cells(n, 5).Value2 = lr.Range.Cells(1, 8).Value2: ws.Cells(n, 6).Value2 = lr.Range.Cells(1, 9).Value2
            ws.Cells(n, 7).Value2 = lr.Range.Cells(1, 13).Value2: ws.Cells(n, 8).Value2 = lr.Range.Cells(1, 15).Value2
            ws.Cells(n, 9).Value2 = lr.Range.Cells(1, 16).Value2: n = n + 1
        End If
    Next lr
    ws.Cells(n + 1, 6).Value2 = "Transport": ws.Cells(n + 1, 7).Value2 = h.Cells(1, 15).Value2
    ws.Cells(n + 2, 6).Value2 = "Alte costuri": ws.Cells(n + 2, 7).Value2 = h.Cells(1, 16).Value2
    ws.Cells(n + 3, 6).Value2 = "Total fara TVA": ws.Cells(n + 3, 7).Value2 = h.Cells(1, 11).Value2
    CF_Band ws, "A" & (n + 5) & ":I" & (n + 5), "Documentul prezinta cantitatile si valoarea initiale. Livrare curenta: " & h.Cells(1, 13).Value2, vbWhite, 10
    CF_Band ws, "A" & (n + 6) & ":I" & (n + 7), "Observatii: " & h.Cells(1, 19).Value2, vbWhite, 10
    ws.Columns("A").ColumnWidth = 6: ws.Columns("B").ColumnWidth = 42: ws.Columns("C").ColumnWidth = 8
    ws.Columns("D:G").ColumnWidth = 15: ws.Columns("H").ColumnWidth = 14: ws.Columns("I").ColumnWidth = 25
    ws.Range("B8:B" & n).WrapText = True: ws.Range("I8:I" & n).WrapText = True
    ws.Range("A7:I7").Interior.Color = RGB(31, 41, 55): ws.Range("A7:I7").Font.Color = vbWhite
    ws.Range("A7:I7").WrapText = True: ws.rows(7).RowHeight = 32
    ws.Range("A8:I" & n).rows.AutoFit
    ws.Columns("D:G").NumberFormat = "#,##0.00": ws.Columns("H").NumberFormat = "dd.mm.yyyy"
    ws.Range("F" & (n + 3) & ":G" & (n + 3)).Font.Bold = True
    With ws.PageSetup
        .Orientation = xlLandscape: .PaperSize = xlPaperA4
        .Zoom = False: .FitToPagesWide = 1: .FitToPagesTall = False
        .PrintArea = "$A$1:$I$" & (n + 8): .PrintTitleRows = "$7:$7"
        .CenterHorizontally = True: .CenterFooter = "Pagina &P din &N"
        .LeftMargin = Application.CentimetersToPoints(1): .RightMargin = Application.CentimetersToPoints(1)
    End With
    ws.ExportAsFixedFormat Type:=xlTypePDF, fileName:=CStr(path), Quality:=xlQualityStandard
    doc.Close SaveChanges:=False: Set doc = Nothing
    ThisWorkbook.Worksheets(CF_SHEET).Activate
    MsgBox "PDF exportat: " & CStr(path), vbInformation, "TQM"
    Exit Sub
Fail:
    message = Err.description
    On Error Resume Next
    If Not doc Is Nothing Then doc.Close SaveChanges:=False
    On Error GoTo 0
    CF_Error message
End Sub

Private Function CF_LocalOpen() As Boolean
    Dim w As Workbook
    If mLocal Is Nothing Then Exit Function
    For Each w In Application.Workbooks
        If w Is mLocal Then CF_LocalOpen = True: Exit Function
    Next w
    Set mLocal = Nothing
End Function

Private Function CF_StartLocal(ByVal mode As String, ByVal id As String) As Boolean
    If CF_LocalOpen Then
        If MsgBox("Este deschis deja un formular local. Inchideti-l si renuntati la modificarile nesalvate?", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Function
        mLocal.Close SaveChanges:=False
    End If
    Set mLocal = Workbooks.Add(xlWBATWorksheet)
    mLocal.Worksheets(1).name = "Formular_TQM"
    mMode = mode: mOrder = id
    If Len(id) > 0 Then mStamp = CF_Stamp(id) Else mStamp = ""
    CF_StartLocal = True
End Function

Public Sub CF_InchideFormular()
    If Not CF_LocalOpen Then Exit Sub
    If mMode <> "ISTORIC" And mMode <> "VIZUALIZARE" Then
        If MsgBox("Inchideti formularul si renuntati la modificarile nesalvate?", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
    End If
    CF_CloseLocal
End Sub

Private Sub CF_CloseLocal()
    If CF_LocalOpen Then mLocal.Close SaveChanges:=False
    Set mLocal = Nothing: mMode = "": mOrder = "": mStamp = ""
    ThisWorkbook.Worksheets(CF_SHEET).Activate
End Sub

Public Sub CF_ComandaNoua()
    On Error GoTo Fail
    CF_Init
    If Not CF_StartLocal("NOU", "") Then Exit Sub
    CF_OrderForm
    Exit Sub
Fail: CF_Error Err.description
End Sub

Private Function CF_Num(ByVal value As Variant, ByVal label As String, Optional ByVal positive As Boolean = False) As Double
    If IsError(value) Or IsEmpty(value) Then Err.Raise vbObjectError + 314, , label & ": introduceti o valoare numerica."
    If VarType(value) = vbString Then
        If Len(Trim$(value)) = 0 Then Err.Raise vbObjectError + 315, , label & ": camp obligatoriu."
    End If
    If Not IsNumeric(value) Then Err.Raise vbObjectError + 316, , label & ": valoare numerica invalida."
    CF_Num = CDbl(value)
    If CF_Num < 0 Or (positive And CF_Num <= 0) Then Err.Raise vbObjectError + 317, , label & ": valoare in afara intervalului permis."
End Function

Private Function CF_DateNum(ByVal value As Variant, ByVal label As String) As Double
    Dim d As Date
    If IsError(value) Or IsEmpty(value) Then Err.Raise vbObjectError + 318, , label & ": introduceti o data."
    If IsNumeric(value) Then
        If CDbl(value) < 36526 Or CDbl(value) > 73415 Then Err.Raise vbObjectError + 319, , label & ": data trebuie sa fie intre anii 2000 si 2100."
        d = CDate(value)
    ElseIf IsDate(value) Then
        d = CDate(value)
    Else
        Err.Raise vbObjectError + 320, , label & ": folositi o data Excel, de exemplu 09.10.2026."
    End If
    CF_DateNum = Int(CDbl(d))
End Function

Private Function CF_Text(ByVal value As Variant) As String
    If IsError(value) Then Err.Raise vbObjectError + 321, , "Exista o eroare Excel intr-un camp introdus."
    CF_Text = Trim$(CStr(value))
End Function

Private Function CF_LinkOK(ByVal value As String) As Boolean
    CF_LinkOK = (Len(value) = 0 Or LCase$(Left$(value, 8)) = "https://" Or LCase$(Left$(value, 7)) = "http://" Or _
                 Left$(value, 2) = "\\" Or (Len(value) > 2 And mID$(value, 2, 2) = ":\"))
End Function

Private Function CF_Matrix(ByVal value As Variant) As Variant
    Dim result() As Variant, i As Long
    ReDim result(1 To 1, 1 To UBound(value))
    For i = 1 To UBound(value): result(1, i) = value(i): Next i
    CF_Matrix = result
End Function

Private Sub CF_Write(ByVal target As Range, ByVal value As Variant)
    Dim i As Long
    For i = 1 To UBound(value)
        If VarType(value(i)) = vbString Then target.Cells(1, i).NumberFormat = "@"
        target.Cells(1, i).Value2 = value(i)
    Next i
End Sub

Private Function CF_Stamp(ByVal id As String) As String
    Dim h As Range, lo As ListObject, lr As ListRow, result As String, i As Long, v As String
    Set h = CF_Find(CF_Table(1), id)
    If h Is Nothing Then Err.Raise vbObjectError + 322, , "Comanda nu mai exista."
    For i = 1 To 22
        If i < 10 Or i > 14 Then
            v = CStr(h.Cells(1, i).Value2): result = result & Len(v) & ":" & v
        End If
    Next i
    For Each lr In CF_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = id Then
            For i = 1 To 19
                If i <> 10 And i <> 12 And i <> 13 And i <> 14 Then
                    v = CStr(lr.Range.Cells(1, i).Value2): result = result & Len(v) & ":" & v
                End If
            Next i
        End If
    Next lr
    For Each lr In CF_Table(3).ListRows
        If CStr(lr.Range.Cells(1, 3).Value2) = id Then
            For i = 1 To 11
                v = CStr(lr.Range.Cells(1, i).Value2): result = result & Len(v) & ":" & v
            Next i
        End If
    Next lr
    CF_Stamp = result
End Function

Private Sub CF_ConflictCheck()
    If Len(mOrder) = 0 Then Exit Sub
    If CF_Stamp(mOrder) <> mStamp Then Err.Raise vbObjectError + 323, , _
        "Comanda a fost modificata dupa deschiderea formularului. Datele din registru nu au fost suprascrise. Inchideti si redeschideti comanda."
End Sub

Private Function CF_HasReceipts(ByVal id As String) As Boolean
    Dim lr As ListRow
    For Each lr In CF_Table(3).ListRows
        ' Even voided receipts retain historical links; positions must stay stable.
        If CStr(lr.Range.Cells(1, 3).Value2) = id Then CF_HasReceipts = True: Exit Function
    Next lr
End Function

Private Function CF_BackupLines(ByVal id As String) As Collection
    Dim lr As ListRow, result As New Collection
    For Each lr In CF_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = id Then result.Add lr.Range.formula
    Next lr
    Set CF_BackupLines = result
End Function

Private Sub CF_DeleteLines(ByVal id As String)
    Dim lo As ListObject, i As Long
    Set lo = CF_Table(2)
    For i = lo.ListRows.count To 1 Step -1
        If CStr(lo.ListRows(i).Range.Cells(1, 2).Value2) = id Then lo.ListRows(i).Delete
    Next i
End Sub

Private Sub CF_CheckLocal(ByVal mode As String)
    If Not CF_LocalOpen Then Err.Raise vbObjectError + 324, , "Formularul local nu mai este deschis."
    If Not ActiveWorkbook Is mLocal Then Err.Raise vbObjectError + 325, , "Salvati din fereastra formularului local."
    If mMode <> mode Then Err.Raise vbObjectError + 326, , "Actiunea nu este permisa in acest formular."
End Sub

Public Sub CF_SalveazaComanda()
    Dim ws As Worksheet, h As Range, row As Range, oldH As Variant, oldP As Collection
    Dim lines As New Collection, ids As Object, requests As Object, n As Long, i As Long
    Dim v(1 To 19) As Variant, hv(1 To 22) As Variant, item As Variant, id As String, key As String
    Dim oldE As Boolean, oldS As Boolean, writing As Boolean, isNew As Boolean, message As String, existing As Range, projectName As String
    On Error GoTo Fail
    If mMode <> "NOU" And mMode <> "EDIT" Then Err.Raise vbObjectError + 327, , "Formularul nu este editabil."
    CF_CheckLocal mMode: CF_Init: CF_Calc
    Set ws = mLocal.Worksheets(1): isNew = (mMode = "NOU")
    hv(2) = CF_Text(ws.Range("B5").Value2): hv(3) = CF_DateNum(ws.Range("G5").Value2, "Data comenzii")
    hv(4) = CF_Text(ws.Range("B6").Value2): hv(5) = CF_Text(ws.Range("B7").Value2)
    hv(6) = CF_Text(ws.Range("K5").Value2): hv(7) = CF_Text(ws.Range("K6").Value2)
    hv(8) = CF_DateNum(ws.Range("G7").Value2, "Termen implicit"): hv(9) = CF_Text(ws.Range("K7").Value2)
    hv(15) = Application.WorksheetFunction.Round(CF_Num(ws.Range("B8").Value2, "Transport"), 2)
    hv(16) = Application.WorksheetFunction.Round(CF_Num(ws.Range("G8").Value2, "Alte costuri"), 2)
    hv(17) = CF_Text(ws.Range("K8").Value2): hv(18) = CF_Text(ws.Range("B9").Value2): hv(19) = CF_Text(ws.Range("B10").Value2)
    If Len(hv(2)) = 0 Or Len(hv(4)) = 0 Or Len(hv(7)) = 0 Then Err.Raise vbObjectError + 328, , "Completati Nr. comanda, Furnizor si Responsabil."
    If hv(6) <> "Ferma" And hv(6) <> "Online" Then Err.Raise vbObjectError + 329, , "Canal: alegeti Ferma sau Online."
    If hv(9) <> "Ciorna" And hv(9) <> "Trimisa" And hv(9) <> "Confirmata" Then Err.Raise vbObjectError + 330, , "Stare: Ciorna, Trimisa sau Confirmata."
    If hv(8) < hv(3) Then Err.Raise vbObjectError + 331, , "Termenul implicit este anterior datei comenzii."
    If Not CF_LinkOK(hv(18)) Then Err.Raise vbObjectError + 332, , "Linkul trebuie sa fie https/http, cale de retea sau cale Windows."
    CF_NMCheckPartner CStr(hv(4)), Not isNew
    If isNew Then id = CF_NewID("CF") Else id = mOrder
    hv(1) = id: hv(21) = Application.UserName: hv(22) = CDbl(Now)
    Set ids = CreateObject("Scripting.Dictionary"): ids.CompareMode = vbTextCompare
    Set requests = CreateObject("Scripting.Dictionary"): requests.CompareMode = vbTextCompare
    For n = CF_FIRST To CF_LAST
        If Application.CountA(ws.Range(ws.Cells(n, 2), ws.Cells(n, 8))) > 0 Or Len(CF_Text(ws.Cells(n, 13).Value2)) > 0 Then
            For i = 1 To 19: v(i) = Empty: Next i
            v(1) = CF_Text(ws.Cells(n, 1).Value2)
            If isNew And Len(v(1)) > 0 Then Err.Raise vbObjectError + 333, , "ID pozitie trebuie sa fie gol pentru o comanda noua."
            If Len(v(1)) = 0 Then v(1) = CF_NewID("CP")
            If ids.exists(v(1)) Then Err.Raise vbObjectError + 334, , "ID pozitie duplicat in formular."
            ids.Add v(1), True
            Set existing = CF_Find(CF_Table(2), CStr(v(1)))
            If Not existing Is Nothing Then
                If isNew Or CStr(existing.Cells(1, 2).Value2) <> id Then Err.Raise vbObjectError + 335, , "ID pozitie apartine altei comenzi."
            End If
            v(2) = id: v(3) = CF_Text(ws.Cells(n, 2).Value2): v(4) = CF_Text(ws.Cells(n, 3).Value2)
            v(5) = CF_Text(ws.Cells(n, 4).Value2): v(6) = CF_Text(ws.Cells(n, 5).Value2)
            If Len(v(4)) = 0 Or Len(v(6)) = 0 Then Err.Raise vbObjectError + 336, , "Randul " & n & ": Material si UM sunt obligatorii."
            v(7) = CF_Num(ws.Cells(n, 6).Value2, "Cantitate la randul " & n, True)
            If Abs(v(7) - Round(v(7), 6)) > 0.00000001 Then Err.Raise vbObjectError + 337, , "Cantitatea accepta maximum 6 zecimale."
            v(8) = CF_Num(ws.Cells(n, 7).Value2, "Pret la randul " & n)
            If Len(CF_Text(ws.Cells(n, 8).Value2)) = 0 Then v(9) = 0 Else v(9) = CF_Num(ws.Cells(n, 8).Value2, "Discount la randul " & n)
            If v(9) > 100 Then Err.Raise vbObjectError + 338, , "Discountul trebuie sa fie intre 0 si 100."
            v(11) = 0
            If Len(CF_Text(ws.Cells(n, 9).Value2)) = 0 Then v(15) = hv(8) Else v(15) = CF_DateNum(ws.Cells(n, 9).Value2, "Termen la randul " & n)
            If v(15) < hv(3) Then Err.Raise vbObjectError + 339, , "Randul " & n & ": termen anterior datei comenzii."
            v(16) = CF_Text(ws.Cells(n, 10).Value2): If Len(v(16)) = 0 Then v(16) = hv(5)
            If Len(v(16)) = 0 Then Err.Raise vbObjectError + 340, , "Randul " & n & ": completati proiectul sau locatia (ex. Depozit)."
            v(17) = CF_Text(ws.Cells(n, 11).Value2): v(18) = CF_Text(ws.Cells(n, 12).Value2)
            v(19) = CF_Text(ws.Cells(n, 13).Value2)
            If Len(v(17)) > 0 Or Len(v(18)) > 0 Then
                If Len(RFQ_Parent(CStr(v(17)))) > 0 Then
                    If requests.exists(CStr(v(17)) & "|" & CStr(v(18))) Then Err.Raise vbObjectError + 341, , "Aceeasi atribuire apare de doua ori in formular."
                    requests.Add CStr(v(17)) & "|" & CStr(v(18)), True
                Else
                    If requests.exists(v(17)) Then Err.Raise vbObjectError + 341, , "Aceeasi cerere apare de doua ori in formular."
                    requests.Add v(17), True
                End If
                CF_CheckApproved v, CStr(hv(4)), id
            End If
            CF_NMCheckMaterial v, Not existing Is Nothing
            CF_NMCheckProject CStr(v(16)), v
            lines.Add v
        End If
    Next n
    If lines.count = 0 Then Err.Raise vbObjectError + 342, , "Adaugati cel putin un material."
    RFQ_CheckOrderPlan hv, lines, id
    For Each item In lines
        If Len(projectName) = 0 Then
            projectName = CStr(item(16))
        ElseIf projectName <> CStr(item(16)) Then
            projectName = "Mai multe proiecte": Exit For
        End If
    Next item
    hv(5) = projectName
    For Each row In CF_Table(1).DataBodyRange.rows
        If CStr(row.Cells(1, 1).Value2) <> id And Len(CStr(row.Cells(1, 1).Value2)) > 0 Then
            If StrComp(CStr(row.Cells(1, 2).Value2), hv(2), vbTextCompare) = 0 And StrComp(CStr(row.Cells(1, 4).Value2), hv(4), vbTextCompare) = 0 Then _
                Err.Raise vbObjectError + 343, , "Exista deja aceasta combinatie Nr. comanda + Furnizor."
        End If
    Next row
    ' Compare the current shared records immediately before committing.
    CF_ConflictCheck
    If Not isNew Then
        If CF_HasReceipts(id) Then Err.Raise vbObjectError + 344, , "Intre timp au fost inregistrate receptii. Comanda nu mai poate fi rescrisa."
        Set h = CF_Find(CF_Table(1), id): oldH = h.formula: Set oldP = CF_BackupLines(id)
        hv(20) = CLng(h.Cells(1, 20).Value2) + 1
    Else
        hv(20) = 1
    End If
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: writing = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    If isNew Then Set h = CF_Add(CF_Table(1)) Else CF_DeleteLines id
    CF_Write h, hv
    For Each item In lines
        Set row = CF_Add(CF_Table(2)): CF_Write row, item
    Next item
    CF_Calc
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS: writing = False
    CF_CloseLocal
    Set row = CF_Find(CF_Table(1), id): Application.Goto row.Cells(1, 2), False
    MsgBox "Comanda a fost salvata in registru: " & hv(2) & vbCrLf & lines.count & " pozitii. Ctrl+S salveaza fisierul principal.", vbInformation, "TQM"
    Exit Sub
Fail:
    message = Err.description
    If writing Then
        On Error Resume Next
        CF_DeleteLines id
        If isNew Then
            If Not h Is Nothing Then h.ClearContents
        Else
            h.formula = oldH
            For Each item In oldP
                Set row = CF_Add(CF_Table(2)): row.formula = item
            Next item
        End If
        CF_Calc
        Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
        On Error GoTo 0
    End If
    CF_Error message
End Sub

Private Function CF_Source(ByVal tableName As String) As ListObject
    Dim ws As Worksheet, lo As ListObject
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            If lo.name = tableName Then Set CF_Source = lo: Exit Function
        Next lo
    Next ws
    Err.Raise vbObjectError + 345, , "Lipseste tabelul " & tableName & " din modulul Cereri si oferte."
End Function

Private Sub CF_Approved(ByVal requestID As String, ByRef request As Range, ByRef offer As Range)
    Dim rt As ListObject, ot As ListObject, offerID As String
    Set rt = CF_Source("tTQMCereri"): Set ot = CF_Source("tTQMOferte")
    ot.Parent.Calculate: rt.Parent.Calculate
    Set request = CF_Find(rt, requestID)
    If request Is Nothing Then Err.Raise vbObjectError + 346, , "Cererea nu exista: " & requestID
    If CStr(request.Cells(1, rt.ListColumns("Status").Index).Value2) <> "APROBATA" Then Err.Raise vbObjectError + 347, , "Cererea nu este aprobata valid: " & requestID
    offerID = CStr(request.Cells(1, rt.ListColumns("ID_oferta_aprobata").Index).Value2)
    Set offer = CF_Find(ot, offerID)
    If offer Is Nothing Then Err.Raise vbObjectError + 348, , "Oferta aprobata nu exista: " & offerID
    If StrComp(CStr(offer.Cells(1, ot.ListColumns("ID_cerere").Index).Value2), requestID, vbTextCompare) <> 0 Then Err.Raise vbObjectError + 349, , "Oferta este legata de alta cerere."
    If Not IsNumeric(offer.Cells(1, ot.ListColumns("Eligibila").Index).Value2) Then Err.Raise vbObjectError + 350, , "Oferta nu este eligibila."
    If CDbl(offer.Cells(1, ot.ListColumns("Eligibila").Index).Value2) <> 1 Then Err.Raise vbObjectError + 351, , "Oferta nu mai este eligibila."
    If Len(CStr(request.Cells(1, rt.ListColumns("Amprenta_aprobarii").Index).Value2)) = 0 Or _
       CStr(request.Cells(1, rt.ListColumns("Amprenta_aprobarii").Index).Value2) <> CStr(offer.Cells(1, ot.ListColumns("Amprenta_oferta").Index).Value2) Then _
        Err.Raise vbObjectError + 352, , "Oferta s-a modificat. Reconfirmati aprobarea in Cereri si oferte."
End Sub

Private Function CF_SrcVal(ByVal row As Range, ByVal columnName As String) As Variant
    CF_SrcVal = row.Cells(1, row.ListObject.ListColumns(columnName).Index).Value2
End Function

Private Sub CF_CheckApproved(ByVal line As Variant, ByVal supplier As String, ByVal exceptID As String)
    Dim req As Range, off As Range, lr As ListRow
    If Len(RFQ_Parent(CStr(line(17)))) > 0 Then RFQ_CheckOrderLine line, supplier, exceptID: Exit Sub
    CF_Approved CStr(line(17)), req, off
    If CStr(line(18)) <> CStr(CF_SrcVal(off, "ID_oferta")) Then Err.Raise vbObjectError + 353, , "ID oferta diferit de oferta aprobata."
    If supplier <> CStr(CF_SrcVal(off, "Furnizor")) Then Err.Raise vbObjectError + 354, , "Furnizorul difera de oferta aprobata."
    If CStr(line(4)) <> CStr(CF_SrcVal(req, "Material")) Or CStr(line(5)) <> CStr(CF_SrcVal(req, "Specificatie")) Or _
       CStr(line(16)) <> CStr(CF_SrcVal(req, "Proiect")) Then Err.Raise vbObjectError + 355, , "Materialul, specificatia sau proiectul difera de cererea aprobata."
    If CStr(line(6)) <> CStr(CF_SrcVal(off, "UM")) Or Abs(CDbl(line(7)) - CF_Num(CF_SrcVal(off, "Cantitate"), "Cantitate oferta", True)) > 0.00000001 Or _
       Abs(CDbl(line(8)) - CF_Num(CF_SrcVal(off, "Pret_unitar"), "Pret oferta")) > 0.00000001 Or _
       Abs(CDbl(line(9)) - 100 * CF_Num(CF_SrcVal(off, "Discount_pct"), "Discount oferta")) > 0.00000001 Then _
        Err.Raise vbObjectError + 356, , "Cantitatea, UM, pretul sau discountul difera de oferta aprobata. Actualizati si aprobati oferta sursa."
    If CDbl(line(15)) <> CF_DateNum(CF_SrcVal(off, "Data_livrare"), "Termen oferta aprobata") Then _
        Err.Raise vbObjectError + 381, , "Termenul de livrare difera de oferta aprobata. Actualizati si aprobati oferta sursa."
    For Each lr In CF_Table(2).ListRows
        If StrComp(CStr(lr.Range.Cells(1, 17).Value2), CStr(line(17)), vbTextCompare) = 0 And StrComp(CStr(lr.Range.Cells(1, 2).Value2), exceptID, vbTextCompare) <> 0 Then
            If CDbl(lr.Range.Cells(1, 7).Value2) - CDbl(lr.Range.Cells(1, 11).Value2) > 0.00000001 Then _
                Err.Raise vbObjectError + 357, , "Cererea este deja intr-o alta comanda activa sau receptionata: " & line(17)
        End If
    Next lr
End Sub

Public Sub CF_DinOferte()
    Dim answer As Variant, requestIDs As Variant, id As Variant, req As Range, off As Range
    Dim ws As Worksheet, supplier As String, n As Long, transport As Double, other As Double, selected As Object
    On Error GoTo Fail
    CF_Init
    answer = Application.InputBox("Pentru circuitul nou: numarul comun RFQ (ex. RFQ-2026-0001), pentru comenzi grupate pe furnizor. Pentru cereri vechi: ID_cerere aprobate, separate prin virgula.", "TQM - Din oferte aprobate", Type:=2)
    If VarType(answer) = vbBoolean Then Exit Sub
    If Len(RFQ_Resolve(Trim$(CStr(answer)))) > 0 Then
        n = RFQ_GenerateOrders(RFQ_Resolve(Trim$(CStr(answer))))
        MsgBox n & " comenzi Ciorna generate, grupate pe furnizor. Deschideti-le pentru verificare si trimitere.", vbInformation, "TQM"
        Exit Sub
    End If
    requestIDs = Split(CStr(answer), ","): Set selected = CreateObject("Scripting.Dictionary"): selected.CompareMode = vbTextCompare
    If UBound(requestIDs) + 1 > 100 Then Err.Raise vbObjectError + 358, , "Maximum 100 cereri intr-o comanda."
    ' Validate all sources before opening/replacing an existing local form.
    For Each id In requestIDs
        id = Trim$(CStr(id))
        If Len(id) = 0 Or selected.exists(id) Then Err.Raise vbObjectError + 359, , "ID cerere gol sau repetat."
        selected.Add id, True: CF_Approved CStr(id), req, off
        If Len(supplier) = 0 Then supplier = CStr(CF_SrcVal(off, "Furnizor"))
        If supplier <> CStr(CF_SrcVal(off, "Furnizor")) Then Err.Raise vbObjectError + 360, , "Selectati cereri cu acelasi furnizor aprobat."
    Next id
    If Not CF_StartLocal("NOU", "") Then Exit Sub
    Call CF_OrderForm:     Set ws = mLocal.Worksheets(1): ws.Range("B6").Value2 = supplier
    n = CF_FIRST
    For Each id In requestIDs
        CF_Approved Trim$(CStr(id)), req, off
        ws.Cells(n, 3).Value2 = CF_SrcVal(req, "Material"): ws.Cells(n, 4).Value2 = CF_SrcVal(req, "Specificatie")
        ws.Cells(n, 5).Value2 = CF_SrcVal(off, "UM"): ws.Cells(n, 6).Value2 = CF_SrcVal(off, "Cantitate")
        ws.Cells(n, 7).Value2 = CF_SrcVal(off, "Pret_unitar"): ws.Cells(n, 8).Value2 = 100 * CF_Num(CF_SrcVal(off, "Discount_pct"), "Discount")
        ws.Cells(n, 9).Value2 = CF_SrcVal(off, "Data_livrare"): ws.Cells(n, 10).Value2 = CF_SrcVal(req, "Proiect")
        ws.Cells(n, 11).Value2 = CF_SrcVal(req, "ID_cerere"): ws.Cells(n, 12).Value2 = CF_SrcVal(off, "ID_oferta")
        transport = transport + CF_Num(CF_SrcVal(off, "Transport_RON"), "Transport oferta")
        other = other + CF_Num(CF_SrcVal(off, "Alte_costuri_RON"), "Alte costuri oferta")
        If n = CF_FIRST Then
            ws.Range("B7").Value2 = CF_SrcVal(req, "Proiect")
            ws.Range("G7").Value2 = CF_SrcVal(off, "Data_livrare")
        ElseIf CStr(ws.Range("B7").Value2) <> CStr(CF_SrcVal(req, "Proiect")) Then
            ws.Range("B7").Value2 = "Mai multe proiecte"
        End If
        n = n + 1
    Next id
    ws.Range("B8").Value2 = transport: ws.Range("G8").Value2 = other
    ws.Range("K8").Value2 = "Din oferte aprobate"
    ws.Range("B10").Value2 = "Verificati transportul cumulat si alte costuri inainte de salvare."
    MsgBox "Datele ofertelor aprobate au fost preluate." & vbCrLf & "Verificati transportul: suma ofertelor poate include aceeasi livrare de mai multe ori." & vbCrLf & _
           "Starea Ciorna nu inseamna ca ati transmis comanda furnizorului.", vbInformation, "TQM"
    Exit Sub
Fail: CF_Error Err.description
End Sub

Private Sub CF_Input(ByVal ws As Worksheet, ByVal address As String, Optional ByVal value As Variant)
    With ws.Range(address)
        .Merge: .Interior.Color = RGB(239, 246, 255): .Locked = False
        If Not IsMissing(value) Then .Cells(1, 1).Value2 = value
    End With
End Sub

Private Sub CF_OrderForm()
    Dim ws As Worksheet, i As Long, names As Variant, wid As Variant
    Set ws = mLocal.Worksheets(1)
    ws.Range("A1:M115").Font.name = "Aptos": ws.Range("A1:M115").Font.size = 10
    ws.Range("A1:M115").RowHeight = 24
    CF_Band ws, "A1:M1", "TQM - Formular local comanda", RGB(255, 255, 255), 16
    CF_Button ws, "A3:C3", "Salveaza in registru", "CF_SalveazaComanda"
    CF_Button ws, "D3:F3", "Inchide formularul", "CF_InchideFormular"
    CF_Button ws, "G3:I3", "Alege material", "NM_AlegeMaterial"
    CF_Button ws, "J3:M3", "Alege partener", "NM_AlegePartener"
    CF_Button ws, "J11:M11", "Alege proiect", "NM_AlegeProiect"
    ws.Range("A5").Value2 = "Nr. comanda": CF_Input ws, "B5:D5", "C-" & Format$(Now, "yyyymmdd-hhnnss")
    ws.Range("F5").Value2 = "Data comenzii": CF_Input ws, "G5:H5", CDbl(Date)
    ws.Range("J5").Value2 = "Canal": CF_Input ws, "K5:M5", "Ferma"
    ws.Range("A6").Value2 = "Furnizor": CF_Input ws, "B6:H6"
    ws.Range("J6").Value2 = "Responsabil": CF_Input ws, "K6:M6", Application.UserName
    ws.Range("A7").Value2 = "Proiect implicit": CF_Input ws, "B7:D7"
    ws.Range("F7").Value2 = "Termen implicit": CF_Input ws, "G7:H7", CDbl(Date + CLng(CF_SLParam("COMANDA_TERMEN_ZILE", 7)))
    ws.Range("J7").Value2 = "Stare": CF_Input ws, "K7:M7", "Ciorna"
    ws.Range("A8").Value2 = "Transport RON": CF_Input ws, "B8:D8", 0
    ws.Range("F8").Value2 = "Alte costuri RON": CF_Input ws, "G8:H8", 0
    ws.Range("J8").Value2 = "Referinta": CF_Input ws, "K8:M8"
    ws.Range("A9").Value2 = "Link document": CF_Input ws, "B9:H9"
    ws.Range("J9").Value2 = "ID comanda"
    ws.Range("K9:M9").Merge: ws.Range("K9").Value2 = mOrder
    ws.Range("A10").Value2 = "Observatii": CF_Input ws, "B10:M10"
    CF_Band ws, "A12:M12", "Completati un rand pentru fiecare material. RON fara TVA. Discount: 10 inseamna 10%. Maximum 100 pozitii.", RGB(255, 247, 237), 10
    names = Split("ID_pozitie|Cod material|Material|Specificatie|UM|Cantitate|Pret unitar RON|Discount %|Termen|Proiect|ID_cerere|ID_oferta|Observatii", "|")
    For i = 0 To UBound(names): ws.Cells(14, i + 1).Value2 = names(i): Next i
    ws.Range("B15:M114").Locked = False: ws.Range("B15:M114").Interior.Color = RGB(239, 246, 255)
    ws.Range("A14:M14").Interior.Color = RGB(31, 41, 55): ws.Range("A14:M14").Font.Color = vbWhite
    ws.Range("A14:M14").Font.Bold = True: ws.Range("A14:M14").WrapText = True: ws.rows(14).RowHeight = 34
    wid = Array(16, 16, 28, 24, 9, 12, 17, 12, 14, 24, 17, 17, 30)
    For i = 0 To UBound(wid): ws.Columns(i + 1).ColumnWidth = wid(i): Next i
    ' Keep columns visible: hiding A would also hide the form field labels.
    ws.Columns("K:L").ColumnWidth = 1
    ws.Range("A14").Value2 = "": ws.Range("K14:L14").ClearContents
    ws.Range("A15:A114").Font.Color = vbWhite
    ws.Range("K15:L114").Font.Color = vbWhite: ws.Range("K15:L114").Interior.Color = vbWhite
    ws.Range("K15:L114").Locked = True
    ws.Range("G5").NumberFormat = "dd.mm.yyyy": ws.Range("G7").NumberFormat = "dd.mm.yyyy"
    ws.Range("I15:I114").NumberFormat = "dd.mm.yyyy"
    ws.Range("F15:F114").NumberFormat = "#,##0.######"
    ws.Range("G15:G114").NumberFormat = "#,##0.00####": ws.Range("H15:H114").NumberFormat = "0.00"
    ws.Range("B5").NumberFormat = "@": ws.Range("B9").NumberFormat = "@"
    ws.Range("B15:B114").NumberFormat = "@"
    CF_List ws.Range("K5"), "Ferma,Online"
    CF_SLList ws.Range("K5"), "CANAL_COMANDA"
    CF_List ws.Range("K7"), "Ciorna,Trimisa,Confirmata"
    CF_SLList ws.Range("K7"), "STARE_COMANDA"
    ws.Protect UserInterfaceOnly:=True
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 85
    ActiveWindow.SplitRow = 3: ActiveWindow.SplitColumn = 2: ActiveWindow.FreezePanes = True
    ws.Range("B6").Select
End Sub

Private Sub CF_List(ByVal rg As Range, ByVal values As String)
    Dim sep As String
    sep = Application.International(xlListSeparator)
    rg.Validation.Delete
    rg.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:=Replace(values, ",", sep)
    rg.Validation.ShowError = True
End Sub

Public Sub CF_Deschide()
    Dim id As String, h As Range, lr As ListRow, v As Variant, ws As Worksheet, n As Long, readonly As Boolean
    On Error GoTo Fail
    Call CF_Init:     CF_Calc: id = CF_Selected()
    Set h = CF_Find(CF_Table(1), id)
    readonly = CF_HasReceipts(id) Or CStr(h.Cells(1, 9).Value2) = "Anulata" Or _
               CStr(h.Cells(1, 13).Value2) = "INCHISA PARTIAL" Or RFQ_OrderCancelled(id)
    If readonly Then
        If Not CF_StartLocal("VIZUALIZARE", id) Then Exit Sub
    Else
        If Not CF_StartLocal("EDIT", id) Then Exit Sub
    End If
    Call CF_OrderForm:     Set ws = mLocal.Worksheets(1)
    ws.Range("B5").Value2 = h.Cells(1, 2).Value2: ws.Range("G5").Value2 = h.Cells(1, 3).Value2
    ws.Range("B6").Value2 = h.Cells(1, 4).Value2: ws.Range("B7").Value2 = h.Cells(1, 5).Value2
    ws.Range("K5").Value2 = h.Cells(1, 6).Value2: ws.Range("K6").Value2 = h.Cells(1, 7).Value2
    ws.Range("G7").Value2 = h.Cells(1, 8).Value2: ws.Range("K7").Value2 = h.Cells(1, 9).Value2
    ws.Range("B8").Value2 = h.Cells(1, 15).Value2: ws.Range("G8").Value2 = h.Cells(1, 16).Value2
    ws.Range("K8").Value2 = h.Cells(1, 17).Value2: ws.Range("B9").Value2 = h.Cells(1, 18).Value2
    ws.Range("B10").Value2 = h.Cells(1, 19).Value2
    n = CF_FIRST
    For Each lr In CF_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = id Then
            If n > CF_LAST Then Err.Raise vbObjectError + 313, , "Comanda depaseste 100 pozitii."
            v = lr.Range.Value2
            ws.Cells(n, 1).Value2 = v(1, 1): ws.Cells(n, 2).Value2 = v(1, 3)
            ws.Cells(n, 3).Value2 = v(1, 4): ws.Cells(n, 4).Value2 = v(1, 5): ws.Cells(n, 5).Value2 = v(1, 6)
            ws.Cells(n, 6).Value2 = v(1, 7): ws.Cells(n, 7).Value2 = v(1, 8): ws.Cells(n, 8).Value2 = v(1, 9)
            ws.Cells(n, 9).Value2 = v(1, 15): ws.Cells(n, 10).Value2 = v(1, 16)
            ws.Cells(n, 11).Value2 = v(1, 17): ws.Cells(n, 12).Value2 = v(1, 18): ws.Cells(n, 13).Value2 = v(1, 19)
            n = n + 1
        End If
    Next lr
    If readonly Then
        ws.Cells.Locked = True
        ws.Shapes("CFBTN_CF_SalveazaComanda").Delete
        ws.Range("A12").Value2 = "Vizualizare: comanda are receptii sau a fost inchisa. Cantitatile primite sunt in Istoric receptii."
    End If
    Exit Sub
Fail: CF_Error Err.description
End Sub


' Stock hooks use Application.Run, so CF still compiles as a standalone module.
Private Sub CF_STBeforeVoid(ByVal receipt As String)
    Dim ws As Worksheet, result As Variant, msg As String
    Set ws = CF_GetSheet("04_LIVRARI_SI_STOC")
    If ws Is Nothing Then Exit Sub
    On Error GoTo Fail
    result = Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!ST_ValidateReceiptVoid", receipt)
    If VarType(result) <> vbBoolean Then Err.Raise vbObjectError + 381, , "Verificarea stocului nu a returnat confirmarea."
    If Not CBool(result) Then Err.Raise vbObjectError + 382, , "Anularea receptiei nu este permisa de stoc."
    Exit Sub
Fail:
    msg = Err.description
    Err.Raise vbObjectError + 383, "CF_STBeforeVoid", "Receptia nu a fost anulata. Verificarea Livrari si stoc: " & msg
End Sub

Private Sub CF_STApplyVoid(ByVal receipt As String, ByVal reason As String)
    Dim ws As Worksheet, result As Variant
    Set ws = CF_GetSheet("04_LIVRARI_SI_STOC")
    If ws Is Nothing Then Exit Sub
    result = Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!ST_ApplyReceiptVoid", receipt, reason)
    If VarType(result) <> vbBoolean Then Err.Raise vbObjectError + 384, , "Corectia de stoc nu a returnat confirmarea."
    If Not CBool(result) Then Err.Raise vbObjectError + 385, , "Corectia de stoc a fost refuzata."
End Sub

Private Sub CF_NMCheckMaterial(ByVal line As Variant, ByVal historical As Boolean)
    Dim ws As Worksheet, prior As Range, result As Variant, c As Long
    Set ws = CF_GetSheet("06_NOMENCLATOARE")
    If ws Is Nothing Then Exit Sub
    If historical Then
        Set prior = CF_Find(CF_Table(2), CStr(line(1)))
        If prior Is Nothing Then
            historical = False
        Else
            For c = 3 To 6
                If CStr(prior.Cells(1, c).Value2) <> CStr(line(c)) Then historical = False
            Next c
        End If
    End If
    result = Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_ResolveMaterial", CStr(line(3)), CStr(line(4)), CStr(line(5)), CStr(line(6)), historical)
End Sub
Private Sub CF_NMCheckPartner(ByVal labelName As String, ByVal historical As Boolean)
    Dim ws As Worksheet, prior As Range
    Set ws = CF_GetSheet("06_NOMENCLATOARE")
    If ws Is Nothing Then Exit Sub
    If historical Then
        Set prior = CF_Find(CF_Table(1), mOrder)
        If prior Is Nothing Then
            historical = False
        ElseIf CStr(prior.Cells(1, 4).Value2) <> labelName Then
            historical = False
        End If
    End If
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_ValidatePartner", labelName, "", historical
End Sub
Private Sub CF_NMCheckProject(ByVal labelName As String, ByVal line As Variant)
    Dim ws As Worksheet, prior As Range, historical As Boolean
    Set ws = CF_GetSheet("06_NOMENCLATOARE")
    If ws Is Nothing Then Exit Sub
    Set prior = CF_Find(CF_Table(2), CStr(line(1)))
    If Not prior Is Nothing Then historical = (CStr(prior.Cells(1, 16).Value2) = labelName)
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_ValidateProject", labelName, historical
End Sub

Private Function CF_SLParam(ByVal key As String, ByVal fallback As Variant) As Variant
    Dim ws As Worksheet
    Set ws = CF_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then
        CF_SLParam = fallback
    Else
        CF_SLParam = Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_Param", key, fallback)
    End If
End Function
Private Sub CF_SLList(ByVal target As Range, ByVal group As String)
    Dim ws As Worksheet
    Set ws = CF_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then Exit Sub
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_ApplyList", target, group
End Sub
Private Sub CF_SLCheck(ByVal group As String, ByVal value As String)
    Dim ws As Worksheet
    Set ws = CF_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then Exit Sub
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_CheckValue", group, value
End Sub

Private Sub CF_PBSync()
    On Error Resume Next
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!PB_Sync"
    On Error GoTo 0
End Sub

Private Sub CF_DOCSync()
    On Error Resume Next
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!DOC_Sync"
    On Error GoTo 0
End Sub



Public Sub CF_RFQRefresh()
    CF_Init
    CF_Calc
End Sub
