Attribute VB_Name = "Module1"
Option Explicit

Private Const NUME_FOAIE As String = "Control_Achizitii"
Private Const PRIMUL_RAND As Long = 13

Private mDetails As Workbook
Private mDetailID As String
Private mDetailStamp As String

' ============================================================
' TQM CALARASI
' CONTROL ACHIZITII / DOCUMENTE
'
' VERSIUNEA 2026 - UI / UX
'
' Fara email partener
' Dashboard modern
' Statusuri colorate
' Butoane separate
' Pastreaza datele existente
' ============================================================


' ============================================================
' 1. CREARE / ACTUALIZARE INTERFATA
' ============================================================

Public Sub CreeazaSistemTQM()

    Dim ws As Worksheet
    Dim raspuns As VbMsgBoxResult
    Dim oldE As Boolean, oldS As Boolean, oldA As Boolean, formValues As Variant, fi As Long
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: oldA = Application.DisplayAlerts
    On Error GoTo Fail
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 2001, , "Registrul este doar pentru citire."

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False

    On Error Resume Next
    Set ws = ThisWorkbook.Worksheets(NUME_FOAIE)
    On Error GoTo Fail

    If ws Is Nothing Then

        Set ws = ThisWorkbook.Worksheets.Add( _
            after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))

        ws.name = NUME_FOAIE

    Else

        raspuns = MsgBox( _
            "Foaia Control_Achizitii exista deja." & vbCrLf & vbCrLf & _
            "Interfata va fi actualizata la versiunea 2026." & vbCrLf & _
            "Datele existente vor fi pastrate." & vbCrLf & vbCrLf & _
            "Continui?", _
            vbYesNo + vbQuestion, _
            "TQM Calarasi 2026")

        If raspuns = vbNo Then

            Application.DisplayAlerts = oldA
            Application.EnableEvents = oldE
            Application.ScreenUpdating = oldS

            Exit Sub

        End If

    End If

    Application.DisplayAlerts = oldA

    ' ========================================================
    ' CURATARE INTERFATA
    ' ========================================================

    TQM_Control_Prepare ws
    On Error Resume Next

    ws.AutoFilterMode = False

    formValues = ws.Range("B5:B11").Value2
    TQM_Control_Prepare ws
    ws.Range("A1:Q11").UnMerge
    ws.Range("A1:Q11").ClearContents

    On Error GoTo Fail


    ' ========================================================
    ' MIGRARE DATE DIN VERSIUNEA VECHE
    ' ========================================================

    TQM_Control_Prepare ws


    ' ========================================================
    ' TITLU PRINCIPAL
    ' ========================================================

    With ws.Range("A1:M1")

        .Merge

        .value = "TQM CALARASI"

        .Font.name = "Aptos Display"
        .Font.size = 22
        .Font.Bold = True

        .Font.Color = RGB(255, 255, 255)

        .Interior.Color = RGB(31, 41, 55)

        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter

        .RowHeight = 42

    End With


    ' ========================================================
    ' SUBTITLU
    ' ========================================================

    With ws.Range("A2:M2")

        .Merge

        .value = ("CONTROL ACHIZITII  " & ChrW(8226) & "  REGISTRU DOCUMENTE  " & ChrW(8226) & "  MONITORIZARE DOSARE")

        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Bold = True

        .Font.Color = RGB(75, 85, 99)

        .Interior.Color = RGB(243, 244, 246)

        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter

        .RowHeight = 23

    End With


    ' ========================================================
    ' FORMULAR
    ' ========================================================

    With ws.Range("A4:D4")

        .Merge

        .value = ("ADAUGA " & ChrW(206) & "NREGISTRARE")

        .Font.name = "Aptos"
        .Font.size = 13
        .Font.Bold = True

        .Font.Color = RGB(31, 41, 55)

        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter

    End With


    ws.Range("A5").value = "Partener"
    ws.Range("A6").value = "Tip partener"
    ws.Range("A7").value = "Tip intrare"
    ws.Range("A8").value = "Declaratie conformitate"
    ws.Range("A9").value = "Declaratie producator"
    ws.Range("A10").value = "Retete / Fise tehnice"
    ws.Range("A11").value = "Observatii"


    With ws.Range("A5:A11")

        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Bold = True

        .Font.Color = RGB(55, 65, 81)

        .VerticalAlignment = xlCenter

    End With


    ' ========================================================
    ' ZONA INPUT
    ' ========================================================

    With ws.Range("B5:D11")

        .Interior.Color = RGB(249, 250, 251)

        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(209, 213, 219)

        .Font.name = "Aptos"
        .Font.size = 10

        .VerticalAlignment = xlCenter

    End With


    ws.Range("B5:D5").Merge
    ws.Range("B6:D6").Merge
    ws.Range("B7:D7").Merge
    ws.Range("B8:D8").Merge
    ws.Range("B9:D9").Merge
    ws.Range("B10:D10").Merge
    ws.Range("B11:D11").Merge


    ws.rows("5:11").RowHeight = 28


    ' ========================================================
    ' LISTA TIP PARTENER
    ' ========================================================

    With ws.Range("B6").Validation

        .Delete

        .Add Type:=xlValidateList, _
             AlertStyle:=xlValidAlertStop, _
             Formula1:="Furnizor,Producator,Prestator,Alt partener"

    End With


    ' ========================================================
    ' LISTA TIP INTRARE
    ' ========================================================

    With ws.Range("B7").Validation

        .Delete

        .Add Type:=xlValidateList, _
             AlertStyle:=xlValidAlertStop, _
             Formula1:="Factura,Doar Aviz (Fara Factura)"

    End With


    ' ========================================================
    ' DECLARATIE CONFORMITATE
    ' ========================================================

    With ws.Range("B8").Validation

        .Delete

        .Add Type:=xlValidateList, _
             AlertStyle:=xlValidAlertStop, _
             Formula1:="Primit,Lipsa,N/A"

    End With


    ' ========================================================
    ' DECLARATIE PRODUCATOR
    ' ========================================================

    With ws.Range("B9").Validation

        .Delete

        .Add Type:=xlValidateList, _
             AlertStyle:=xlValidAlertStop, _
             Formula1:="Primit,Lipsa,N/A"

    End With


    ' ========================================================
    ' RETETE / FISE
    ' ========================================================

    With ws.Range("B10").Validation

        .Delete

        .Add Type:=xlValidateList, _
             AlertStyle:=xlValidAlertStop, _
             Formula1:="Primit,Lipsa,N/A"

    End With


    ' ========================================================
    ' DASHBOARD
    ' ========================================================

    With ws.Range("F4:M4")

        .Merge

        .value = "DASHBOARD"

        .Font.name = "Aptos"
        .Font.size = 13
        .Font.Bold = True

        .Font.Color = RGB(31, 41, 55)

        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter

    End With


    ' ========================================================
    ' CARD TOTAL
    ' ========================================================

    With ws.Range("F5:G7")

        .Merge

        .Interior.Color = RGB(239, 246, 255)

        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(191, 219, 254)

        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter

    End With


    ' ========================================================
    ' CARD COMPLETE
    ' ========================================================

    With ws.Range("H5:I7")

        .Merge

        .Interior.Color = RGB(240, 253, 244)

        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(187, 247, 208)

        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter

    End With


    ' ========================================================
    ' CARD INCOMPLETE
    ' ========================================================

    With ws.Range("J5:K7")

        .Merge

        .Interior.Color = RGB(254, 242, 242)

        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(254, 202, 202)

        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter

    End With


    ' ========================================================
    ' CARD AVIZE
    ' ========================================================

    With ws.Range("L5:M7")

        .Merge

        .Interior.Color = RGB(255, 247, 237)

        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(254, 215, 170)

        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter

    End With


    ' ========================================================
    ' ACTIUNI
    ' ========================================================

    With ws.Range("F9:M9")

        .Merge

        .value = "ACTIUNI"

        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Bold = True

        .Font.Color = RGB(75, 85, 99)

        .HorizontalAlignment = xlLeft

    End With


    ' ========================================================
    ' BUTOANE
    ' ========================================================

    CreeazaButoane2026 ws


    ' ========================================================
    ' ANTET TABEL
    ' ========================================================

    ws.Range("A12").value = "Nr."
    ws.Range("B12").value = "Data"
    ws.Range("C12").value = "Partener"
    ws.Range("D12").value = "Tip partener"
    ws.Range("E12").value = "Intrare"
    ws.Range("F12").value = "Aviz necesar?"
    ws.Range("G12").value = "Declaratie conformitate"
    ws.Range("H12").value = "Declaratie producator"
    ws.Range("I12").value = "Retete / Fise"
    ws.Range("J12").value = "Status dosar"
    ws.Range("K12").value = "Documente lipsa"
    ws.Range("L12").value = "Observatii"
    ws.Range("M12").value = "Actiune"


    With ws.Range("A12:M12")

        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Bold = True

        .Font.Color = RGB(255, 255, 255)

        .Interior.Color = RGB(55, 65, 81)

        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter

        .WrapText = True

        .Borders.LineStyle = xlContinuous
        .Borders.Color = RGB(75, 85, 99)

        .RowHeight = 40

    End With


    ' ========================================================
    ' FORMATARE TABEL
    ' ========================================================

    FormateazaRegistru2026 ws


    ' ========================================================
    ' DASHBOARD
    ' ========================================================

    ActualizeazaDashboard


    ' ========================================================
    ' FILTRU
    ' ========================================================

    If ws.AutoFilterMode Then
        ws.AutoFilterMode = False
    End If

    ws.Range("A12:Z" & Application.Max(500, TQM_Control_LastRow(ws))).AutoFilter
    ws.Columns("N:AA").Hidden = True


    ' ========================================================
    ' FIXARE ANTET
    ' ========================================================

    ws.Activate

    ActiveWindow.FreezePanes = False

    ActiveWindow.SplitColumn = 4
    ActiveWindow.SplitRow = 12
    ws.Range("A13").Select

    ActiveWindow.FreezePanes = True


    For fi = 1 To 7: ws.Cells(fi + 4, 2).Value2 = formValues(fi, 1): Next fi
    Application.Calculate

    Application.EnableEvents = oldE
    Application.ScreenUpdating = oldS


    MsgBox "TQM Calarasi a fost actualizat la interfata 2026.", _
           vbInformation, _
           "TQM Calarasi"

    Exit Sub
Fail:
    Application.DisplayAlerts = oldA: Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
    MsgBox "Control Achizitii: " & Err.description, vbExclamation, "TQM"
End Sub


' ============================================================
' 2. MIGRARE VERSIUNE VECHE FARA EMAIL
' ============================================================

Private Sub MigreazaStructuraFaraEmail(ByVal ws As Worksheet)

    Dim ultimaLinie As Long
    Dim r As Long

    ' Daca vechiul antet contine Email partener,
    ' mutam coloanele E:M cu o pozitie la stanga.

    If LCase(Trim(ws.Range("D12").value)) = LCase("Email partener") Then

        ultimaLinie = ws.Cells(ws.rows.count, "C").End(xlUp).row

        If ultimaLinie >= PRIMUL_RAND Then

            For r = PRIMUL_RAND To ultimaLinie

                ws.Cells(r, "D").value = ws.Cells(r, "E").value
                ws.Cells(r, "E").value = ws.Cells(r, "F").value
                ws.Cells(r, "F").value = ws.Cells(r, "G").value
                ws.Cells(r, "G").value = ws.Cells(r, "H").value
                ws.Cells(r, "H").value = ws.Cells(r, "I").value
                ws.Cells(r, "I").value = ws.Cells(r, "J").value
                ws.Cells(r, "J").value = ws.Cells(r, "K").value
                ws.Cells(r, "K").value = ws.Cells(r, "L").value
                ws.Cells(r, "L").value = ws.Cells(r, "M").value
                ws.Cells(r, "M").ClearContents

            Next r

        End If

    End If

End Sub


' ============================================================
' 3. ADAUGARE IN REGISTRU
' ============================================================

Public Sub AdaugaInRegistru()

    Dim ws As Worksheet
    Dim r As Long
    Dim oldE As Boolean, written As Boolean, message As String, form As Variant, fi As Long, sameForm As Boolean
    oldE = Application.EnableEvents
    On Error GoTo Fail

    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 2002, , "Registrul este doar pentru citire."
    Set ws = ThisWorkbook.Worksheets(NUME_FOAIE)
    TQM_Control_Ready ws


    If Trim(ws.Range("B5").value) = "" Then

        MsgBox "Completeaza numele partenerului.", _
               vbExclamation, _
               "TQM Calarasi"

        Exit Sub

    End If


    TQM_Control_CheckInput ws
    form = ws.Range("B5:B11").Value2
    r = TQM_Control_LastRow(ws) + 1
    Application.EnableEvents = False
    If Len(CStr(ws.Cells(r, "C").Value2)) > 0 Or Len(CStr(ws.Cells(r, "R").Value2)) > 0 Then Err.Raise vbObjectError + 2035, , "Randul destinat salvarii a fost ocupat. Reluati. "
    written = True


    If r < PRIMUL_RAND Then
        r = PRIMUL_RAND
    End If


    ws.Cells(r, "A").value = r - PRIMUL_RAND + 1
    ws.Cells(r, "B").value = Date
    ws.Cells(r, "C").value = form(1, 1)
    ws.Cells(r, "D").value = form(2, 1)
    ws.Cells(r, "E").value = form(3, 1)


    ws.Cells(r, "F").formula = _
        "=IF(E" & r & "=""Doar Aviz (Fara Factura)""," & _
        """OBLIGATORIU AVIZ"",""NU"")"


    ws.Cells(r, "G").value = form(4, 1)
    ws.Cells(r, "H").value = form(5, 1)
    ws.Cells(r, "I").value = form(6, 1)


    ws.Cells(r, "L").value = form(7, 1)


    ws.Cells(r, "B").NumberFormat = "dd.mm.yyyy"


    FormateazaRegistru2026 ws


    ActualizeazaDashboard
    Application.EnableEvents = oldE
    written = False
    sameForm = True
    For fi = 1 To 7
        If CStr(ws.Cells(fi + 4, 2).Value2) <> CStr(form(fi, 1)) Then sameForm = False
    Next fi
    If sameForm Then GolesteFormularFaraMesaj


    MsgBox (ChrW(206) & "nregistrarea a fost adaugata."), _
           vbInformation, _
           "TQM Calarasi"

    Exit Sub
Fail:
    message = Err.description
    On Error Resume Next
    If written Then
        If CStr(ws.Cells(r, "C").Value2) = CStr(form(1, 1)) Then ws.Range("A" & r & ":Z" & r).ClearContents
    End If
    Application.EnableEvents = oldE
    On Error GoTo 0
    MsgBox "Inregistrarea nu a fost salvata: " & message, vbExclamation, "TQM"
End Sub


' ============================================================
' 4. GOLIRE FORMULAR
' ============================================================

Public Sub GolesteFormular()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets("Control_Achizitii")

    On Error GoTo Eroare

    ws.Range("B5").MergeArea.ClearContents
    ws.Range("B6").MergeArea.ClearContents
    ws.Range("B7").MergeArea.ClearContents
    ws.Range("B8").MergeArea.ClearContents
    ws.Range("B9").MergeArea.ClearContents
    ws.Range("B10").MergeArea.ClearContents
    ws.Range("B11").MergeArea.ClearContents

    MsgBox "Formularul a fost golit.", vbInformation, "TQM CALARASI"

    Exit Sub

Eroare:

    MsgBox "Eroare la golirea formularului: " & Err.description, _
           vbCritical, _
           "TQM CALARASI"

End Sub


Private Sub GolesteFormularFaraMesaj()

    Dim ws As Worksheet

    Set ws = ThisWorkbook.Worksheets("Control_Achizitii")

    On Error Resume Next

    ws.Range("B5").MergeArea.ClearContents
    ws.Range("B6").MergeArea.ClearContents
    ws.Range("B7").MergeArea.ClearContents
    ws.Range("B8").MergeArea.ClearContents
    ws.Range("B9").MergeArea.ClearContents
    ws.Range("B10").MergeArea.ClearContents
    ws.Range("B11").MergeArea.ClearContents

    On Error GoTo 0

End Sub


' ============================================================
' 5. DASHBOARD
' ============================================================

Public Sub ActualizeazaDashboard()
    Dim ws As Worksheet, lastRow As Long
    Set ws = ThisWorkbook.Worksheets(NUME_FOAIE)
    TQM_Control_Refresh ws
    lastRow = Application.Max(500, TQM_Control_LastRow(ws))
    ws.Range("F5").Formula = "=""TOTAL " & ChrW(206) & "NREGISTRARI""&CHAR(13)&CHAR(10)&COUNTA($C$13:$C$" & lastRow & ")"
    ws.Range("H5").Formula = "=""DOSARE COMPLETE""&CHAR(13)&CHAR(10)&COUNTIF($J$13:$J$" & lastRow & ",""DOSAR COMPLET"")"
    ws.Range("J5").Formula = "=""DOSARE INCOMPLETE""&CHAR(13)&CHAR(10)&(COUNTA($C$13:$C$" & lastRow & ")-COUNTIF($J$13:$J$" & lastRow & ",""DOSAR COMPLET""))"
    ws.Range("L5").Formula = "=""AVIZE OBLIGATORII""&CHAR(13)&CHAR(10)&COUNTIF($F$13:$F$" & lastRow & ",""OBLIGATORIU AVIZ"")"
    With ws.Range("F5:M7")
        .Font.Name = "Aptos"
        .Font.Size = 11
        .Font.Bold = True
    End With
End Sub

' ============================================================
' 6. FORMATARE REGISTRU
' ============================================================

Private Sub FormateazaRegistru2026(ByVal ws As Worksheet)

    Dim ultimaLinie As Long
    Dim r As Long


    ultimaLinie = ws.Cells( _
        ws.rows.count, _
        "C").End(xlUp).row


    If ultimaLinie < PRIMUL_RAND Then
        ultimaLinie = PRIMUL_RAND
    End If


    ' ========================================================
    ' LATIMI COLOANE
    ' ========================================================

    ws.Columns("A").ColumnWidth = 6
    ws.Columns("B").ColumnWidth = 12
    ws.Columns("C").ColumnWidth = 25
    ws.Columns("D").ColumnWidth = 17
    ws.Columns("E").ColumnWidth = 23
    ws.Columns("F").ColumnWidth = 19
    ws.Columns("G").ColumnWidth = 22
    ws.Columns("H").ColumnWidth = 21
    ws.Columns("I").ColumnWidth = 18
    ws.Columns("J").ColumnWidth = 31
    ws.Columns("K").ColumnWidth = 30
    ws.Columns("L").ColumnWidth = 34
    ws.Columns("M").ColumnWidth = 14


    ' ========================================================
    ' FORMATARE GENERALA
    ' ========================================================

    With ws.Range("A13:M" & Application.Max(500, TQM_Control_LastRow(ws)))

        .Font.name = "Aptos"
        .Font.size = 10

        .VerticalAlignment = xlCenter

        .WrapText = True

        .Borders.LineStyle = xlContinuous

        .Borders.Color = RGB(229, 231, 235)

    End With


    ws.Range("B13:B" & Application.Max(500, TQM_Control_LastRow(ws))).NumberFormat = "dd.mm.yyyy"


    ' ========================================================
    ' FORMATARE RANDURI EXISTENTE
    ' ========================================================

    For r = PRIMUL_RAND To ultimaLinie

        If Trim(ws.Cells(r, "C").value) <> "" Then

            FormateazaRand2026 ws, r

        End If

    Next r


    ' ========================================================
    ' CONDITIONAL FORMATTING
    ' ========================================================

    ws.Range("F13:F" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Delete
    ws.Range("G13:I" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Delete
    ws.Range("J13:J" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Delete
    ws.Range("K13:K" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Delete


    ' ========================================================
    ' OBLIGATORIU AVIZ
    ' ========================================================

    With ws.Range("F13:F" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Add( _
        Type:=xlTextString, _
        String:="OBLIGATORIU AVIZ", _
        TextOperator:=xlContains)

        .Font.Bold = True
        .Font.Color = RGB(154, 52, 18)
        .Interior.Color = RGB(255, 237, 213)

    End With


    ' ========================================================
    ' NU - ROSU
    ' ========================================================

    With ws.Range("F13:I" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Add( _
        Type:=xlTextString, _
        String:="NU", _
        TextOperator:=xlContains)

        .Font.Bold = True
        .Font.Color = RGB(185, 28, 28)
        .Interior.Color = RGB(254, 242, 242)

    End With


    ' ========================================================
    ' LIPSA - ROSU
    ' ========================================================

    With ws.Range("G13:I" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Add( _
        Type:=xlTextString, _
        String:="Lipsa", _
        TextOperator:=xlContains)

        .Font.Bold = True
        .Font.Color = RGB(185, 28, 28)
        .Interior.Color = RGB(254, 242, 242)

    End With


    ' ========================================================
    ' PRIMIT - VERDE
    ' ========================================================

    With ws.Range("G13:I" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Add( _
        Type:=xlTextString, _
        String:="Primit", _
        TextOperator:=xlContains)

        .Font.Bold = True
        .Font.Color = RGB(22, 101, 52)
        .Interior.Color = RGB(240, 253, 244)

    End With


    ' ========================================================
    ' N/A - GRI
    ' ========================================================

    With ws.Range("G13:I" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Add( _
        Type:=xlTextString, _
        String:="N/A", _
        TextOperator:=xlContains)

        .Font.Color = RGB(107, 114, 128)
        .Interior.Color = RGB(243, 244, 246)

    End With


    ' ========================================================
    ' DOSAR COMPLET
    ' ========================================================

    With ws.Range("J13:J" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Add( _
        Type:=xlTextString, _
        String:="DOSAR COMPLET", _
        TextOperator:=xlContains)

        .Font.Bold = True
        .Font.Color = RGB(22, 101, 52)
        .Interior.Color = RGB(220, 252, 231)

    End With


    ' ========================================================
    ' INCOMPLET
    ' ========================================================

    With ws.Range("J13:J" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Add( _
        Type:=xlTextString, _
        String:="INCOMPLET", _
        TextOperator:=xlContains)

        .Font.Bold = True
        .Font.Color = RGB(185, 28, 28)
        .Interior.Color = RGB(254, 226, 226)

    End With


    ' ========================================================
    ' DOCUMENTE LIPSA
    ' ========================================================

    With ws.Range("K13:K" & Application.Max(500, TQM_Control_LastRow(ws))).FormatConditions.Add( _
        Type:=xlTextString, _
        String:="Declaratie", _
        TextOperator:=xlContains)

        .Font.Bold = True
        .Font.Color = RGB(154, 52, 18)
        .Interior.Color = RGB(255, 247, 237)

    End With

End Sub


' ============================================================
' 7. FORMATARE RAND
' ============================================================

Private Sub FormateazaRand2026(ByVal ws As Worksheet, ByVal r As Long)

    With ws.Range("A" & r & ":M" & r)

        .RowHeight = 34

        .Borders.LineStyle = xlContinuous

        .Borders.Color = RGB(229, 231, 235)

        .VerticalAlignment = xlCenter

        .WrapText = True

    End With


    ws.Cells(r, "A").HorizontalAlignment = xlCenter

    ws.Cells(r, "B").HorizontalAlignment = xlCenter

    ws.Cells(r, "F").HorizontalAlignment = xlCenter

    ws.Cells(r, "J").HorizontalAlignment = xlCenter

End Sub


' ============================================================
' 8. BUTOANE MODERNE
' ============================================================

Private Sub CreeazaButoane2026(ByVal ws As Worksheet)

    Dim shp As Shape
    Dim stanga As Double
    Dim sus As Double


    ' Sterge butoanele vechi

    On Error Resume Next

    For Each shp In ws.Shapes

        If Left(shp.name, 4) = "TQM_" Then
            shp.Delete
        End If

    Next shp

    On Error GoTo 0


    ' ========================================================
    ' BUTON ADAUGA
    ' ========================================================

    stanga = ws.Range("F10").Left
    sus = ws.Range("F10").Top

    Set shp = ws.Shapes.AddShape(5, stanga, sus, 110, 28)

    With shp

        .name = "TQM_Adauga"

        .TextFrame.Characters.text = "ADAUGA"

        .OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!TQM_Control_Adauga"

        .Fill.ForeColor.RGB = RGB(22, 101, 52)

        .line.ForeColor.RGB = RGB(22, 101, 52)

        .TextFrame.Characters.Font.Color = RGB(255, 255, 255)

        .TextFrame.Characters.Font.Bold = True

        .TextFrame.Characters.Font.size = 10

    End With


    ' ========================================================
    ' BUTON GOLESTE
    ' ========================================================

    stanga = ws.Range("H10").Left

    Set shp = ws.Shapes.AddShape(5, stanga, sus, 110, 28)

    With shp

        .name = "TQM_Goleste"

        .TextFrame.Characters.text = "GOLESTE"

        .OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!TQM_Control_Goleste"

        .Fill.ForeColor.RGB = RGB(107, 114, 128)

        .line.ForeColor.RGB = RGB(107, 114, 128)

        .TextFrame.Characters.Font.Color = RGB(255, 255, 255)

        .TextFrame.Characters.Font.Bold = True

        .TextFrame.Characters.Font.size = 10

    End With


    ' ========================================================
    ' BUTON STERGE
    ' ========================================================

    stanga = ws.Range("J10").Left

    Set shp = ws.Shapes.AddShape(5, stanga, sus, 110, 28)

    With shp

        .name = "TQM_Sterge"

        .TextFrame.Characters.text = ("STERGE R" & ChrW(194) & "ND")

        .OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!TQM_Control_Sterge"

        .Fill.ForeColor.RGB = RGB(185, 28, 28)

        .line.ForeColor.RGB = RGB(185, 28, 28)

        .TextFrame.Characters.Font.Color = RGB(255, 255, 255)

        .TextFrame.Characters.Font.Bold = True

        .TextFrame.Characters.Font.size = 10

    End With


End Sub


' ============================================================
' 9. STERGERE RAND
' ============================================================

Public Sub StergeRand()

    Dim ws As Worksheet
    Dim r As Long
    Dim ultimaLinie As Long
    Dim i As Long
    Dim raspuns As VbMsgBoxResult
    Dim selectedID As String


    On Error GoTo Fail
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 2003, , "Registrul este doar pentru citire."
    If Not ActiveWorkbook Is ThisWorkbook Then Err.Raise vbObjectError + 2004, , "Selectati registrul principal."
    If ActiveSheet.name <> NUME_FOAIE Then Err.Raise vbObjectError + 2005, , "Selectati inregistrarea in Control Achizitii."
    Set ws = ThisWorkbook.Worksheets(NUME_FOAIE)
    TQM_Control_Ready ws


    r = ActiveCell.row


    If r < PRIMUL_RAND Then

        MsgBox ("Selecteaza o " & ChrW(238) & "nregistrare din tabel."), _
               vbExclamation, _
               "TQM Calarasi"

        Exit Sub

    End If


    If Trim(ws.Cells(r, "C").value) = "" Then

        MsgBox ("R" & ChrW(226) & "ndul selectat este gol."), _
               vbExclamation, _
               "TQM Calarasi"

        Exit Sub

    End If


    selectedID = CStr(ws.Cells(r, "R").Value2)
    raspuns = MsgBox( _
        ("Sigur vrei sa stergi aceasta " & ChrW(238) & "nregistrare?") & vbCrLf & vbCrLf & _
        "Partener: " & ws.Cells(r, "C").value, _
        vbYesNo + vbQuestion, _
        "Confirmare stergere")


    If raspuns = vbNo Then Exit Sub


    If Len(selectedID) > 0 Then r = TQM_Control_RowID(selectedID)
    TQM_Control_CheckDelete selectedID
    ws.rows(r).Delete


    ultimaLinie = ws.Cells( _
        ws.rows.count, _
        "C").End(xlUp).row


    If ultimaLinie >= PRIMUL_RAND Then

        For i = PRIMUL_RAND To ultimaLinie

            ws.Cells(i, "A").value = _
                i - PRIMUL_RAND + 1

        Next i

    End If


    ActualizeazaDashboard


    MsgBox (ChrW(206) & "nregistrarea a fost stearsa."), _
           vbInformation, _
           "TQM Calarasi"

    Exit Sub
Fail:
    MsgBox Err.description, vbExclamation, "TQM"
End Sub


Public Function TQM_Control_Col(ByVal legacy As Variant) As Long
    Dim n As Long, i As Long, a As Variant, text As String
    If IsNumeric(legacy) Then
        n = CLng(legacy)
    Else
        text = UCase$(CStr(legacy))
        For i = 1 To Len(text): n = n * 26 + Asc(mID$(text, i, 1)) - 64: Next i
    End If
    a = Array(1, 2, 14, 15, 16, 17, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 26, 18, 19, 20, 21, 22, 23, 24, 25)
    If n < 1 Or n > 25 Then Err.Raise vbObjectError + 2010, , "Coloana Control necunoscuta."
    TQM_Control_Col = CLng(a(n - 1))
End Function
Public Sub TQM_Control_Ready(ByVal ws As Worksheet)
    If CStr(ws.Range("AA11").Value2) <> "TQM_CONTROL_13_V2" Then Err.Raise vbObjectError + 2011, , "Rulati CreeazaSistemTQM pentru migrarea Controlului."
End Sub
Private Function TQM_Control_Letter(ByVal n As Long) As String
    Do While n > 0
        TQM_Control_Letter = Chr$(65 + (n - 1) Mod 26) & TQM_Control_Letter
        n = (n - 1) \ 26
    Loop
End Function
Public Function TQM_Control_Cell(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal legacy As Variant) As Range
    TQM_Control_Ready ws
    Set TQM_Control_Cell = ws.Cells(rowNo, TQM_Control_Col(legacy))
End Function
Public Function TQM_Control_LocalFormula(ByVal value As String) As String
    Dim rx As Object, matches As Object, m As Object, i As Long, replacement As String
    Set rx = CreateObject("VBScript.RegExp"): rx.Global = True
    rx.Pattern = "(\$?)([A-Z]{1,2})(\$?[0-9]+)"
    Set matches = rx.Execute(value)
    For i = matches.count - 1 To 0 Step -1
        Set m = matches(i)
        replacement = m.SubMatches(0) & TQM_Control_Letter(TQM_Control_Col(CStr(m.SubMatches(1)))) & m.SubMatches(2)
        value = Left$(value, m.FirstIndex) & replacement & mID$(value, m.FirstIndex + m.Length + 1)
    Next i
    TQM_Control_LocalFormula = value
End Function
Public Function TQM_Control_Range(ByVal ws As Worksheet, ByVal legacyAddress As String) As Range
    TQM_Control_Ready ws
    Set TQM_Control_Range = ws.Range(TQM_Control_LocalFormula(legacyAddress))
End Function
Public Function TQM_Control_Formula(ByVal value As String) As String
    Dim rx As Object, ms As Object, m As Object, i As Long
    Set rx = CreateObject("VBScript.RegExp"): rx.Global = True
    rx.Pattern = "'Control_Achizitii'!(\$?[A-Z]{1,2}\$?[0-9]+(:\$?[A-Z]{1,2}\$?[0-9]+)?)"
    Set ms = rx.Execute(value)
    For i = ms.count - 1 To 0 Step -1
        Set m = ms(i)
        value = Left$(value, m.FirstIndex) & "'Control_Achizitii'!" & TQM_Control_LocalFormula(CStr(m.SubMatches(0))) & mID$(value, m.FirstIndex + m.Length + 1)
    Next i
    TQM_Control_Formula = value
End Function
Public Function TQM_Control_LastRow(ByVal ws As Worksheet) As Long
    TQM_Control_LastRow = Application.Max(12, ws.Cells(ws.rows.count, "C").End(xlUp).row)
End Function
Private Sub TQM_Control_Prepare(ByVal ws As Worksheet)
    Dim old As Variant, data() As Variant, last As Long, r As Long, c As Long
    If CStr(ws.Range("AA11").Value2) = "TQM_CONTROL_13_V2" Then Exit Sub
    If CStr(ws.Range("C12").Value2) = "Nr. Factura / Aviz" And CStr(ws.Range("G12").Value2) = "Partener" Then
        last = Application.Max(13, ws.Cells(ws.rows.count, "G").End(xlUp).row)
        If Application.CountA(ws.Range("Z12:AA" & last)) > 0 Then Err.Raise vbObjectError + 2012, , "Date necunoscute in Z:AA. Migrarea a fost oprita."
        old = ws.Range("A13:Y" & last).Value2: ReDim data(1 To UBound(old, 1), 1 To 26)
        For r = 1 To UBound(old, 1)
            For c = 1 To 25: data(r, TQM_Control_Col(c)) = old(r, c): Next c
        Next r
        ws.Range("A13:Z" & last).Value2 = data
    Else
        If Len(CStr(ws.Range("C12").Value2)) > 0 And CStr(ws.Range("C12").Value2) <> "Partener" Then Err.Raise vbObjectError + 2013, , "Structura Control necunoscuta. Datele au fost pastrate."
        If Application.CountA(ws.Range("N12:AA" & Application.Max(13, TQM_Control_LastRow(ws)))) > 0 Then Err.Raise vbObjectError + 2014, , "Metadate necunoscute in Control."
    End If
    ws.Range("N12:Z12").Value2 = Array("Nr. Factura / Aviz", "Data facturii", "Valoare (RON fara TVA)", "Lucrare / Obiectiv", "ID_dosar", "Cheie_regula", "Stare_regula", "Cere_aviz", "Cere_conformitate", "Cere_producator", "Cere_fise", "Lipsa_calculata", "Status aviz")
    ws.Range("AA11").Value2 = "TQM_CONTROL_13_V2"
    ws.Range("R11").Value2 = "TQM_SL_CONTROL_V1"
    ws.Columns("N:AA").Hidden = True
End Sub
Private Sub TQM_Control_Refresh(ByVal ws As Worksheet)
    Dim config As Worksheet, last As Long
    TQM_Control_Ready ws
    On Error Resume Next: Set config = ThisWorkbook.Worksheets("07_SETARI_LISTE"): On Error GoTo 0
    If Not config Is Nothing Then
        Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_ActualizeazaControl"
    Else
        last = Application.Max(13, TQM_Control_LastRow(ws))
        ws.Range("J13:J" & last).FormulaR1C1 = "=IF(RC3="""","""",""INCOMPLET - VERIFICARE DOCUMENTE"")"
        ws.Range("K13:K" & last).FormulaR1C1 = "=IF(RC3="""","""",""Confirmati regulile documentelor"")"
    End If
    ws.Calculate
End Sub
Private Sub TQM_Control_CheckInput(ByVal ws As Worksheet)
    Dim i As Long, v As String, config As Worksheet, group As String
    On Error Resume Next: Set config = ThisWorkbook.Worksheets("07_SETARI_LISTE"): On Error GoTo 0
    For i = 6 To 10
        v = Trim$(CStr(ws.Cells(i, 2).Value2))
        If Not config Is Nothing Then
            If i = 6 Then
                group = "TIP_PARTENER_CONTROL"
            ElseIf i = 7 Then
                group = "TIP_INTRARE"
            Else
                group = "STATUT_DOCUMENT"
            End If
            v = CStr(Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_CanonicalValue", group, v))
            ws.Cells(i, 2).Value2 = v
        End If
        If i = 6 Then
            If InStr(1, "|Furnizor|Producator|Prestator|Alt partener|", "|" & v & "|", vbTextCompare) = 0 Or Len(v) = 0 Then Err.Raise vbObjectError + 2015, , "Alegeti tipul partenerului."
        ElseIf i = 7 Then
            If v <> "Factura" And v <> "Doar Aviz (Fara Factura)" Then Err.Raise vbObjectError + 2016, , "Alegeti tipul intrarii."
        Else
            If v <> "Primit" And v <> "Lipsa" And v <> "N/A" Then Err.Raise vbObjectError + 2017, , "Completati statusurile documentelor."
        End If
    Next i
End Sub
Public Function TQM_Control_RowID(ByVal id As String) As Long
    Dim ws As Worksheet, r As Long
    Set ws = ThisWorkbook.Worksheets(NUME_FOAIE): TQM_Control_Ready ws
    For r = 13 To TQM_Control_LastRow(ws)
        If CStr(ws.Cells(r, "R").Value2) = id And Len(id) > 0 Then
            If TQM_Control_RowID > 0 Then Err.Raise vbObjectError + 2018, , "ID dosar duplicat."
            TQM_Control_RowID = r
        End If
    Next r
    If TQM_Control_RowID = 0 Then Err.Raise vbObjectError + 2019, , "Dosarul nu mai exista."
End Function
Private Sub TQM_Control_CheckDelete(ByVal id As String)
    Dim ws As Worksheet, lo As ListObject, row As ListRow
    If Len(id) = 0 Then Exit Sub
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            If lo.name = "tTQMDOCLinkuri" Then
                For Each row In lo.ListRows
                    If CStr(row.Range.Cells(1, 3).Value2) = "Dosar" And CStr(row.Range.Cells(1, 4).Value2) = id Then Err.Raise vbObjectError + 2020, , "Dosarul are documente asociate. Pastrati inregistrarea pentru trasabilitate."
                Next row
            ElseIf lo.name = "tTQMFacturi" Then
                For Each row In lo.ListRows
                    If InStr(1, CStr(row.Range.Cells(1, 15).Value2), id, vbBinaryCompare) > 0 Then Err.Raise vbObjectError + 2021, , "Dosarul este folosit de o factura. Pastrati inregistrarea."
                Next row
            End If
        Next lo
    Next ws
End Sub
Private Function TQM_Control_RowStamp(ByVal r As Long) As String
    Dim c As Long, v As String, ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(NUME_FOAIE)
    For c = 1 To 26
        v = CStr(ws.Cells(r, c).Value2)
        TQM_Control_RowStamp = TQM_Control_RowStamp & Len(v) & ":" & v & ";"
    Next c
End Function
Public Sub TQM_Control_DetaliiFactura()
       Dim ws As Worksheet
    Dim wsForm As Worksheet
    Dim r As Long
    Dim i As Long
    Dim button As Shape
    Dim labels As Variant, selectedID As String
    On Error GoTo Fail
    If Not ActiveWorkbook Is ThisWorkbook Then Err.Raise vbObjectError + 2022, , "Selectati registrul principal."
    If ActiveSheet.name <> NUME_FOAIE Then Err.Raise vbObjectError + 2023, , "Selectati un dosar in Control Achizitii."
    Set ws = ThisWorkbook.Worksheets(NUME_FOAIE): r = ActiveCell.row
    If r < 13 Or Len(CStr(ws.Cells(r, "C").Value2)) = 0 Then Err.Raise vbObjectError + 2024, , "Selectati un dosar existent."
    ActualizeazaDashboard
    selectedID = CStr(ws.Cells(r, "R").Value2)
    If Len(selectedID) = 0 Then Err.Raise vbObjectError + 2025, , "Instalati Setari Liste pentru identificatorii dosarelor."
    If Not mDetails Is Nothing Then
        On Error Resume Next: mDetails.Activate
        If Err.number = 0 Then On Error GoTo Fail: Err.Raise vbObjectError + 2026, , "Inchideti formularul local existent."
        Err.Clear: Set mDetails = Nothing: On Error GoTo Fail
    End If
    mDetailID = selectedID
    mDetailStamp = TQM_Control_RowStamp(r)
    Set mDetails = Workbooks.Add(xlWBATWorksheet): Set wsForm = mDetails.Worksheets(1)
    wsForm.Range("A1:D1").Merge: wsForm.Range("A1").Value2 = "Detalii factura / aviz - " & CStr(ws.Cells(r, "C").Value2)
    wsForm.Columns("A").ColumnWidth = 28: wsForm.Columns("B:D").ColumnWidth = 18
    wsForm.Cells.Font.name = "Aptos": wsForm.rows("1:8").RowHeight = 28
    labels = Array("Nr. Factura / Aviz", "Data facturii", "Valoare RON fara TVA", "Lucrare / Obiectiv")
    For i = 3 To 6
        wsForm.Range("B" & i & ":D" & i).Merge
        wsForm.Cells(i, 1).Value2 = labels(i - 3)
        wsForm.Cells(i, 2).Value2 = ws.Cells(r, i + 11).Value2
    Next i
    wsForm.Range("B4").NumberFormat = "dd.mm.yyyy": wsForm.Range("B5").NumberFormat = "#,##0.00"
    wsForm.Range("A7:D7").Merge: wsForm.Range("A7").Value2 = "Campurile sunt libere. Salvarea actualizeaza dosarul selectat."
    Set button = wsForm.Shapes.AddShape(5, wsForm.Range("A8").Left, wsForm.Range("A8").Top, 120, 28)
    button.TextFrame.Characters.text = "Salveaza detalii"
    button.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!TQM_Control_SalveazaDetalii"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub TQM_Control_SalveazaDetalii()
    Dim ws As Worksheet, wsForm As Worksheet, r As Long, old As Variant, data(1 To 1, 1 To 4) As Variant
    Dim i As Long, v As Variant, changed As Boolean, oldE As Boolean, message As String
    oldE = Application.EnableEvents
    On Error GoTo Fail
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 2027, , "Registrul este doar pentru citire."
    If mDetails Is Nothing Then Err.Raise vbObjectError + 2028, , "Deschideti formularul de detalii."
    If Not ActiveWorkbook Is mDetails Then Err.Raise vbObjectError + 2029, , "Folositi formularul local activ."
    Set wsForm = mDetails.Worksheets(1): Set ws = ThisWorkbook.Worksheets(NUME_FOAIE)
    r = TQM_Control_RowID(mDetailID)
    If TQM_Control_RowStamp(r) <> mDetailStamp Then Err.Raise vbObjectError + 2030, , "Dosarul s-a modificat. Redeschideti formularul."
    For i = 1 To 4: data(1, i) = wsForm.Cells(i + 2, 2).Value2: Next i
    v = data(1, 2)
    If Len(CStr(v)) > 0 Then
        If IsNumeric(v) Then
            If CDbl(v) < 1 Or CDbl(v) > 2958465 Then Err.Raise vbObjectError + 2031, , "Data facturii este invalida."
            data(1, 2) = CDbl(dateValue(CDate(v)))
        Else
            If Not IsDate(v) Then Err.Raise vbObjectError + 2032, , "Data facturii este invalida."
            data(1, 2) = CDbl(dateValue(CDate(v)))
        End If
    End If
    v = data(1, 3)
    If Len(CStr(v)) > 0 Then
        If Not IsNumeric(v) Then Err.Raise vbObjectError + 2033, , "Valoarea trebuie sa fie numerica."
        If CDbl(v) < 0 Then Err.Raise vbObjectError + 2034, , "Valoarea nu poate fi negativa."
        data(1, 3) = CDbl(v)
    End If
    old = ws.Cells(r, 14).Resize(1, 4).Value2
    Application.EnableEvents = False: changed = True
    ws.Cells(r, 14).Resize(1, 4).Value2 = data
    ws.Cells(r, 15).NumberFormat = "dd.mm.yyyy": ws.Cells(r, 16).NumberFormat = "#,##0.00"
    Call ActualizeazaDashboard:     changed = False
    Application.EnableEvents = oldE
    mDetails.Close SaveChanges:=False: Set mDetails = Nothing
    ThisWorkbook.Activate: ws.Activate
    Exit Sub
Fail:
    message = Err.description
    On Error Resume Next
    If changed Then ws.Cells(r, 14).Resize(1, 4).Value2 = old
    Application.EnableEvents = oldE
    On Error GoTo 0
    MsgBox message, vbExclamation, "TQM"
End Sub

Public Sub TQM_Control_Adauga()
    AdaugaInRegistru
End Sub
Public Sub TQM_Control_Goleste()
    GolesteFormular
End Sub
Public Sub TQM_Control_Sterge()
    StergeRand
End Sub




' Extend the register without losing existing filter criteria.
Public Sub TQM_Control_KeepFilters(ByVal ws As Worksheet, ByVal lastRow As Long)
    Dim af As AutoFilter, i As Long, n As Long
    Dim enabled() As Boolean, first() As Variant, second() As Variant
    Dim hasFirst() As Boolean, hasSecond() As Boolean, operators() As Long
    Dim oldRange As Range
    If ws.AutoFilterMode Then
        Set af = ws.AutoFilter
        Set oldRange = af.Range
        If oldRange.Row = 12 And oldRange.Column = 1 And oldRange.Columns.Count = 26 Then
            If oldRange.Row + oldRange.Rows.Count - 1 >= lastRow Then Exit Sub
            n = af.Filters.Count
            ReDim enabled(1 To n), first(1 To n), second(1 To n)
            ReDim hasFirst(1 To n), hasSecond(1 To n), operators(1 To n)
            For i = 1 To n
                enabled(i) = af.Filters(i).On
                If enabled(i) Then
                    operators(i) = af.Filters(i).Operator
                    On Error Resume Next
                    Err.Clear: first(i) = af.Filters(i).Criteria1: hasFirst(i) = (Err.Number = 0)
                    Err.Clear: second(i) = af.Filters(i).Criteria2: hasSecond(i) = (Err.Number = 0)
                    Err.Clear
                    On Error GoTo 0
                    If Not hasFirst(i) And Not hasSecond(i) Then
                        Err.Raise vbObjectError + 2036, , "Filtrul nu poate fi pastrat. Eliminati-l manual si reluati actualizarea."
                    End If
                End If
            Next i
        Else
            Err.Raise vbObjectError + 2037, , "Zona filtrata este diferita de registrul Control. Datele si filtrele au fost pastrate."
        End If
        ws.AutoFilterMode = False
    End If
    ws.Range("A12:Z" & lastRow).AutoFilter
    For i = 1 To n
        If enabled(i) Then
            If hasFirst(i) And hasSecond(i) Then
                ws.Range("A12:Z" & lastRow).AutoFilter Field:=i, Criteria1:=first(i), Operator:=operators(i), Criteria2:=second(i)
            ElseIf hasFirst(i) Then
                If operators(i) = 0 Then
                    ws.Range("A12:Z" & lastRow).AutoFilter Field:=i, Criteria1:=first(i)
                Else
                    ws.Range("A12:Z" & lastRow).AutoFilter Field:=i, Criteria1:=first(i), Operator:=operators(i)
                End If
            Else
                ws.Range("A12:Z" & lastRow).AutoFilter Field:=i, Operator:=operators(i), Criteria2:=second(i)
            End If
        End If
    Next i
End Sub
