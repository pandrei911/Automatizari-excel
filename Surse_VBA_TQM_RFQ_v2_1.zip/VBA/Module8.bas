Attribute VB_Name = "Module8"
Option Explicit
' TQM: buget net RON pe intreaga durata; plati si solduri cu TVA.
' Formulare locale. Detectarea modificarilor nu ofera tranzactii atomice intre sesiuni.
Private Const PB_SHEET As String = "08_PROIECTE_BUGETE"
Private mForm As Workbook, mMode As String, mID As String, mStamp As String
Private mUpdating As Boolean, mGood As Boolean
Private mProjects As Object, mNames As Object, mOrders As Object, mPositions As Object
Private mInvoices As Object, mReps As Object, mPayments As Object, mLinks As Object
Private mGroups As Object, mUnknown As Object, mReceived As Object
Private Type PB_GUID
    Data1 As Long
    Data2 As Integer
    Data3 As Integer
    Data4(0 To 7) As Byte
End Type
#If VBA7 Then
Private Declare PtrSafe Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As PB_GUID) As Long
#Else
Private Declare Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As PB_GUID) As Long
#End If
Private Function PB_SName(ByVal kind As Long) As String
    Select Case kind
    Case 1: PB_SName = "08_PROIECTE_BUGETE"
    Case 2: PB_SName = "_TQM_PB_BU"
    Case 3: PB_SName = "_TQM_PB_POS"
    Case 4: PB_SName = "_TQM_PB_COM"
    Case 5: PB_SName = "_TQM_PB_FACT"
    Case 6: PB_SName = "_TQM_PB_LEG"
    Case 7: PB_SName = "_TQM_PB_NUME"
    Case 8: PB_SName = "_TQM_PB_LOG"
    End Select
End Function
Private Function PB_TName(ByVal kind As Long) As String
    Select Case kind
    Case 1: PB_TName = "tTQMProiecteBugete"
    Case 2: PB_TName = "tTQMPBBugete"
    Case 3: PB_TName = "tTQMPBPozitii"
    Case 4: PB_TName = "tTQMPBComenzi"
    Case 5: PB_TName = "tTQMPBFacturi"
    Case 6: PB_TName = "tTQMPBLegaturi"
    Case 7: PB_TName = "tTQMPBNume"
    Case 8: PB_TName = "tTQMPBJurnal"
    End Select
End Function
Private Function PB_Heads(ByVal kind As Long) As Variant
    Select Case kind
    Case 1: PB_Heads = Split("Cod_proiect|Proiect|Buget_aprobat_net_RON|Facturat_net_RON|Comenzi_nefacturate_net_RON|Expunere_net_RON|Disponibil_net_RON|Utilizare_pct|Actiune|De_primit_net_RON|Plati_efective_cu_TVA_RON|Sold_cu_TVA_RON|Restante_cu_TVA_RON|TVA_facturat_RON|Facturat_cu_TVA_RON|Compensari_cu_TVA_RON|Credit_cu_TVA_RON|Nr_semnale_de_clarificat|Nr_legaturi_doar_comanda|Buget_propus_net_RON|Stare_proiect|ID_proiect|Responsabil|Actualizat_la", "|")
    Case 2: PB_Heads = Split("ID_buget|ID_proiect|Revizie|Buget_net_RON|Stare|Data|Aprobat_de|Motiv|Creat_la|Actualizat_de|ID_buget_precedent", "|")
    Case 3: PB_Heads = Split("ID_pozitie|ID_comanda|ID_proiect|Proiect|Material|Cant_comandata|Cant_anulata|Cant_primita|Pret_unitar|Discount_pct|Activa|Angajat_net_RON|Nefacturat_direct_RON|De_primit_net_RON|Facturat_direct_RON|Cheie_comanda_proiect|Nr_comanda", "|")
    Case 4: PB_Heads = Split("Cheie_comanda_proiect|ID_comanda|ID_proiect|Proiect|Nr_comanda|Activa|Costuri_suplimentare_RON|Materiale_angajate_RON|Materiale_nefacturate_RON|Facturat_fara_pozitie_RON|Nefacturat_RON|De_primit_RON|Nr_clarificari", "|")
    Case 5: PB_Heads = Split("ID_repartizare|ID_factura|ID_proiect|Proiect|Nr_factura|Data_factura|Scadenta|Net_RON|TVA_RON|Total_RON|Achitat_RON|Sold_RON|ID_comanda_legatura|ID_pozitie_legatura|ID_proiect_angajament|Cheie_comanda_proiect|Clasificare|Clarificare|Doar_comanda|Descriere|ID_repartizare_originala|Plati_efective_RON|Compensari_RON|Restante_RON|Credit_RON", "|")
    Case 6: PB_Heads = Split("ID_repartizare|Clasificare|ID_comanda|ID_pozitie|ID_proiect_angajament|Observatii|ID_legatura|Revizie|Actualizat_la|Actualizat_de", "|")
    Case 7: PB_Heads = Split("Denumire_folosita|Sursa|ID_sursa|Camp", "|")
    Case 8: PB_Heads = Split("ID_eveniment|Data|Utilizator|Entitate|ID_inregistrare|Actiune|Revizie|Camp|Valoare_veche|Valoare_noua", "|")
    End Select
End Function
Private Function PB_SourceHeads(ByVal name As String) As Variant
    Select Case name
    Case "tTQMNMProiecte": PB_SourceHeads = Split("ID_proiect|Cod_proiect|Denumire|Client|Adresa|Manager|Responsabil|Stare|Observatii|Revizie|Actualizat_la|Actualizat_de", "|")
    Case "tTQMComenzi": PB_SourceHeads = Split("ID_comanda|Nr_comanda|Data_comanda|Furnizor|Proiect|Canal|Responsabil|Termen|Stare|Nr_pozitii|Valoare_net_RON|De_primit_RON|Livrare|Pozitii_intarziate|Transport_RON|Alte_costuri_RON|Referinta|Link_document|Observatii|Revizie|Actualizat_de|Actualizat_la", "|")
    Case "tTQMCFPoz": PB_SourceHeads = Split("ID_pozitie|ID_comanda|Cod_material|Material|Specificatie|UM|Cant_comandata|Pret_unitar|Discount_pct|Cant_primita|Cant_anulata|Cant_ramasa|Val_initiala|Val_de_primit|Termen_livrare|Proiect|ID_cerere|ID_oferta|Observatii", "|")
    Case "tTQMCFRec": PB_SourceHeads = Split("ID_receptie|ID_pozitie|ID_comanda|Data|Document|Cantitate|Stare|Link|Creat_de|Creat_la|Motiv_anulare", "|")
    Case "tTQMFacturi": PB_SourceHeads = Split("Nr_factura|Data_factura|Partener|CIF_partener|Tip_factura|Scadenta|Net_RON|TVA_RON|Total_RON|Achitat_RON|Sold_RON|Status_plata|Proiecte|Link_factura|Observatii|ID_factura|ID_factura_originala|Responsabil|Stare|Creat_la|Actualizat_la|Anulat_la|Anulat_de|Motiv_anulare", "|")
    Case "tTQMFPRepartizari": PB_SourceHeads = Split("ID_repartizare|ID_factura|Proiect|Net_RON|TVA_RON|Total_RON|Achitat_RON|Sold_RON|ID_comanda|ID_pozitie|ID_receptie|Descriere|Stare|Creat_la|Ordine|ID_repartizare_originala", "|")
    Case "tTQMFPPlati": PB_SourceHeads = Split("ID_miscare|ID_operatie|ID_factura|ID_repartizare|Proiect|Data|Suma_RON|Tip|Metoda|Document|Responsabil|Observatii|Link|Stare|Creat_la|Anulat_la|Anulat_de|Motiv_anulare|ID_factura_pereche", "|")
    End Select
End Function
Private Function PB_Dict() As Object
    Set PB_Dict = CreateObject("Scripting.Dictionary"): PB_Dict.CompareMode = vbTextCompare
End Function
Private Function PB_Text(ByVal v As Variant) As String
    If IsError(v) Then Err.Raise vbObjectError + 900, , "O sursa contine o eroare Excel."
    PB_Text = Trim$(CStr(v))
End Function
Private Function PB_Norm(ByVal v As Variant) As String
    Dim a As Variant, b As Variant, i As Long
    PB_Norm = UCase$(Replace(PB_Text(v), ChrW(160), " "))
    a = Array(258, 194, 206, 536, 350, 538, 354): b = Array("A", "A", "I", "S", "S", "T", "T")
    For i = 0 To UBound(a): PB_Norm = Replace(PB_Norm, ChrW(a(i)), b(i)): Next i
    Do While InStr(PB_Norm, "  ") > 0: PB_Norm = Replace(PB_Norm, "  ", " "): Loop
End Function
Private Function PB_Num(ByVal v As Variant) As Double
    If Len(PB_Text(v)) = 0 Then Exit Function
    If Not IsNumeric(v) Then Err.Raise vbObjectError + 901, , "Valoare numerica invalida in sursa."
    PB_Num = CDbl(v)
End Function
Private Function PB_ID(ByVal prefix As String) As String
    Dim g As PB_GUID, s As String, i As Long
    If CoCreateGuid(g) <> 0 Then Err.Raise vbObjectError + 902, , "Nu s-a putut genera un ID."
    s = Right$("00000000" & Hex$(g.Data1), 8) & "-" & Right$("0000" & Hex$(g.Data2), 4) & "-" & Right$("0000" & Hex$(g.Data3), 4) & "-"
    For i = 0 To 7
        If i = 2 Then s = s & "-"
        s = s & Right$("00" & Hex$(g.Data4(i)), 2)
    Next i
    PB_ID = prefix & "-" & s
End Function
Private Function PB_Source(ByVal name As String) As ListObject
    Dim ws As Worksheet, lo As ListObject
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            If lo.name = name Then Set PB_Source = lo: Exit Function
        Next lo
    Next ws
    Err.Raise vbObjectError + 903, , "Lipseste tabelul " & name & ". Instalati modulele precedente."
End Function
Private Function PB_Table(ByVal kind As Long) As ListObject
    Set PB_Table = PB_Source(PB_TName(kind))
End Function
Private Function PB_Read(ByVal name As String, ByVal idColumn As Long) As Object
    Dim lo As ListObject, lr As ListRow, a As Variant, c As Long, id As String
    Set PB_Read = PB_Dict(): Set lo = PB_Source(name)
    For Each lr In lo.ListRows
        id = PB_Text(lr.Range.Cells(1, idColumn).Value2)
        If Len(id) > 0 Then
            If name = "tTQMCFRec" Then
                If Len(PB_Text(lr.Range.Cells(1, 2).Value2)) = 0 Then Err.Raise vbObjectError + 962, , "Receptie fara ID pozitie."
                id = Len(id) & ":" & id & "|" & PB_Text(lr.Range.Cells(1, 2).Value2)
            End If
            If PB_Read.exists(id) Then Err.Raise vbObjectError + 904, , "ID duplicat in " & name & ": " & id
            ReDim a(0 To lo.ListColumns.count - 1)
            For c = 0 To UBound(a): a(c) = lr.Range.Cells(1, c + 1).Value2: Next c
            PB_Read.Add id, a
        End If
    Next lr
End Function
Private Sub PB_Ensure()
    Dim k As Long, c As Long, ws As Worksheet, lo As ListObject, heads As Variant, names As Variant, name As Variant
    For k = 1 To 8
        Set ws = Nothing: On Error Resume Next: Set ws = ThisWorkbook.Worksheets(PB_SName(k)): On Error GoTo 0
        If ws Is Nothing Then Set ws = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count)): ws.name = PB_SName(k)
        ws.Unprotect: Set lo = Nothing: On Error Resume Next: Set lo = ws.ListObjects(PB_TName(k)): On Error GoTo 0
        heads = PB_Heads(k)
        If lo Is Nothing Then
            If Application.CountA(ws.Cells) > 0 Then Err.Raise vbObjectError + 905, , "Foaie existenta cu alta structura: " & ws.name
            For c = 0 To UBound(heads): ws.Cells(12, c + 1).Value2 = heads(c): Next c
            Set lo = ws.ListObjects.Add(xlSrcRange, ws.Cells(12, 1).Resize(2, UBound(heads) + 1), , xlYes): lo.name = PB_TName(k)
        End If
        If lo.ListColumns.count <> UBound(heads) + 1 Then Err.Raise vbObjectError + 906, , "Numar de coloane incorect: " & lo.name
        For c = 0 To UBound(heads)
            If lo.ListColumns(c + 1).name <> heads(c) Then Err.Raise vbObjectError + 907, , "Coloana incompatibila: " & lo.name
        Next c
        If lo.ListRows.count = 0 Then lo.ListRows.Add
        ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
        If k > 1 Then ws.Visible = xlSheetVeryHidden
    Next k
    names = Split("tTQMNMProiecte|tTQMComenzi|tTQMCFPoz|tTQMCFRec|tTQMFacturi|tTQMFPRepartizari|tTQMFPPlati", "|")
    For Each name In names
        Set lo = PB_Source(CStr(name)): heads = PB_SourceHeads(CStr(name))
        If lo.ListColumns.count <> UBound(heads) + 1 Then Err.Raise vbObjectError + 908, , "Structura sursa incompatibila: " & lo.name
        For c = 0 To UBound(heads)
            If lo.ListColumns(c + 1).name <> heads(c) Then Err.Raise vbObjectError + 909, , "Coloana sursa incompatibila: " & lo.name
        Next c
    Next name
End Sub
Private Function PB_Project(ByVal name As Variant, ByVal source As String, ByVal id As String) As String
    Dim key As String, token As String
    key = PB_Norm(name)
    If mNames.exists(key) And Len(key) > 0 Then PB_Project = CStr(mNames(key)): Exit Function
    PB_Project = "NEALOCAT": token = source & "|" & id & "|" & key
    If Not mUnknown.exists(token) Then mUnknown.Add token, Array(PB_Text(name), source, id, "Proiect")
End Function
Private Sub PB_Load()
    Dim key As Variant, a As Variant, b As Variant, n As String, totals As Object, budgets As Object, seen As Object, pid As String
    Set mProjects = PB_Read("tTQMNMProiecte", 1): Set mNames = PB_Dict(): Set mUnknown = PB_Dict()
    For Each key In mProjects.keys
        a = mProjects(key): n = PB_Norm(a(2))
        If n = "" Or mNames.exists(n) Then Err.Raise vbObjectError + 910, , "Denumiri de proiect goale sau duplicate in Nomenclatoare."
        mNames.Add n, CStr(key)
    Next key
    Set mOrders = PB_Read("tTQMComenzi", 1): Set mPositions = PB_Read("tTQMCFPoz", 1)
    Set mInvoices = PB_Read("tTQMFacturi", 16): Set mReps = PB_Read("tTQMFPRepartizari", 1)
    Set mPayments = PB_Read("tTQMFPPlati", 1): Set mLinks = PB_Read(PB_TName(6), 1)
    Set mReceived = PB_Dict(): Set seen = PB_Read("tTQMCFRec", 1)
    For Each key In seen.keys
        a = seen(key)
        If a(6) = "Valida" Then
            If Not mPositions.exists(CStr(a(1))) Then Err.Raise vbObjectError + 911, , "Receptie fara pozitie valida."
            b = mPositions(CStr(a(1)))
            If CStr(a(2)) <> CStr(b(1)) Then Err.Raise vbObjectError + 911, , "Receptie cu alta comanda."
            n = CStr(a(1)): If Not mReceived.exists(n) Then mReceived.Add n, 0#
            mReceived(n) = CDbl(mReceived(n)) + PB_Num(a(5))
        End If
    Next key
    Set totals = PB_Dict()
    For Each key In mReps.keys
        a = mReps(key)
        If a(12) = "Valida" Then
            n = CStr(a(1))
            If Not mInvoices.exists(n) Then Err.Raise vbObjectError + 912, , "Repartizare fara factura."
            b = mInvoices(n)
            If b(18) <> "Valida" Then Err.Raise vbObjectError + 913, , "Repartizare valida pentru factura anulata."
            If Not IsNumeric(a(3)) Or Not IsNumeric(a(4)) Then Err.Raise vbObjectError + 914, , "Factura fara valori net / TVA."
            If Not totals.exists(n) Then totals.Add n, Array(0#, 0#)
            b = totals(n): b(0) = b(0) + PB_Num(a(3)): b(1) = b(1) + PB_Num(a(4)): totals(n) = b
        End If
    Next key
    For Each key In mInvoices.keys
        a = mInvoices(key)
        If a(18) = "Valida" Then
            If Not totals.exists(CStr(key)) Then Err.Raise vbObjectError + 915, , "Factura fara repartizari: " & CStr(a(0))
            b = totals(key)
            If Abs(PB_Num(a(6)) - b(0)) > 0.005 Or Abs(PB_Num(a(7)) - b(1)) > 0.005 Then Err.Raise vbObjectError + 916, , "Net / TVA nereconciliat: " & CStr(a(0))
            If Not IsNumeric(a(5)) Or PB_Num(a(5)) <= 0 Then Err.Raise vbObjectError + 917, , "Scadenta facturii lipseste."
        End If
    Next key
    For Each key In mPayments.keys
        a = mPayments(key)
        If a(13) = "Valida" Then
            If Not mReps.exists(CStr(a(3))) Then Err.Raise vbObjectError + 918, , "Plata fara repartizare."
            b = mReps(CStr(a(3)))
            If b(12) <> "Valida" Or CStr(b(1)) <> CStr(a(2)) Then Err.Raise vbObjectError + 919, , "Plata cu legatura factura invalida."
            If PB_Norm(b(2)) <> PB_Norm(a(4)) Then Err.Raise vbObjectError + 919, , "Proiectul platii difera de repartizare."
            If a(7) <> "Plata" And a(7) <> "Restituire" And a(7) <> "Compensare" Then Err.Raise vbObjectError + 919, , "Tip de plata necunoscut."
            If Not IsNumeric(a(6)) Then Err.Raise vbObjectError + 919, , "Suma platii invalida."
        End If
    Next key
    Set budgets = PB_Read(PB_TName(2), 1): Set seen = PB_Dict()
    For Each key In budgets.keys
        a = budgets(key): pid = CStr(a(1))
        If Not mProjects.exists(pid) Then Err.Raise vbObjectError + 920, , "Bugetul indica un proiect inexistent."
        If Not IsNumeric(a(3)) Or PB_Num(a(3)) < 0 Then Err.Raise vbObjectError + 921, , "Buget invalid."
        If a(4) <> "Ciorna" And a(4) <> "Aprobat" And a(4) <> "Inlocuit" Then Err.Raise vbObjectError + 921, , "Stare buget invalida."
        If a(4) = "Aprobat" Or a(4) = "Ciorna" Then
            n = pid & "|" & CStr(a(4))
            If seen.exists(n) Then Err.Raise vbObjectError + 922, , "Mai multe bugete curente pentru acelasi proiect."
            seen.Add n, True
            If a(4) = "Aprobat" And Len(PB_Text(a(6))) = 0 Then Err.Raise vbObjectError + 922, , "Buget aprobat fara aprobator."
        End If
    Next key
End Sub
Private Sub PB_Group(ByVal orderID As String, ByVal projectID As String, ByVal extras As Double)
    Dim key As String, h As Variant, a As Variant, active As Long, label As String
    key = orderID & "|" & projectID: h = mOrders(orderID)
    If h(8) = "Trimisa" Or h(8) = "Confirmata" Then active = 1
    label = "Proiecte de inregistrat": If mProjects.exists(projectID) Then a = mProjects(projectID): label = CStr(a(2))
    If Not mGroups.exists(key) Then
        mGroups.Add key, Array(key, orderID, projectID, label, h(1), active, extras, "", "", "", "", "", "")
    Else
        a = mGroups(key): a(6) = CDbl(a(6)) + extras: mGroups(key) = a
    End If
End Sub
Private Function PB_Resolve(ByVal a As Variant, ByVal invoice As Variant) As Variant
    Dim orderID As String, posID As String, pid As String, kind As String, b As Variant, link As Variant, linkID As String
    orderID = PB_Text(a(8)): posID = PB_Text(a(9)): linkID = PB_Text(a(0))
    If Not mLinks.exists(linkID) And Len(PB_Text(a(15))) > 0 Then linkID = PB_Text(a(15))
    If mLinks.exists(linkID) Then
        link = mLinks(linkID): kind = CStr(link(1))
        If Len(orderID) > 0 And CStr(link(2)) <> orderID Then Err.Raise vbObjectError + 923, , "Asociere care contrazice comanda facturii."
        If Len(posID) > 0 And CStr(link(3)) <> posID Then Err.Raise vbObjectError + 923, , "Asociere care contrazice pozitia facturii."
        orderID = CStr(link(2)): posID = CStr(link(3)): pid = CStr(link(4))
        If kind <> "Directa" And kind <> "Comanda" Then Err.Raise vbObjectError + 924, , "Clasificare de factura necunoscuta."
        If kind = "Directa" Then
            If Len(orderID & posID & pid) > 0 Then Err.Raise vbObjectError + 925, , "Factura directa are o comanda asociata."
            PB_Resolve = Array("", "", "", "Directa", 0, 0): Exit Function
        End If
        If Len(orderID) = 0 And Len(posID) = 0 Then Err.Raise vbObjectError + 925, , "Asociere Comanda fara comanda."
    End If
    If Len(posID) > 0 Then
        If Not mPositions.exists(posID) Then Err.Raise vbObjectError + 926, , "Factura indica o pozitie inexistenta."
        b = mPositions(posID)
        If Len(orderID) > 0 And orderID <> CStr(b(1)) Then Err.Raise vbObjectError + 927, , "Comanda / pozitie de factura incompatibile."
        orderID = CStr(b(1)): kind = PB_Project(b(15), "tTQMCFPoz", posID)
        If Len(pid) > 0 And pid <> kind Then Err.Raise vbObjectError + 928, , "Proiectul angajamentului trebuie sa fie al pozitiei comenzii."
        pid = kind
    ElseIf Len(orderID) > 0 Then
        If Len(pid) = 0 Then pid = PB_Project(a(2), "tTQMFPRepartizari", CStr(a(0)))
    Else
        PB_Resolve = Array("", "", "", "Clarificare", 1, 0): Exit Function
    End If
    If Not mOrders.exists(orderID) Then Err.Raise vbObjectError + 929, , "Factura indica o comanda inexistenta."
    b = mOrders(orderID)
    If PB_Norm(b(3)) <> PB_Norm(invoice(2)) Then Err.Raise vbObjectError + 930, , "Furnizorul facturii difera de cel al comenzii."
    If Not mGroups.exists(orderID & "|" & pid) Then
        PB_Resolve = Array(orderID, posID, pid, "Clarificare", 1, 0): Exit Function
    End If
    If Len(posID) = 0 Then PB_Resolve = Array(orderID, posID, pid, "Comanda", 0, 1) Else PB_Resolve = Array(orderID, posID, pid, "Comanda", 0, 0)
End Function
Private Sub PB_Build(ByRef rows() As Collection)
    Dim k As Long, key As Variant, a As Variant, h As Variant, b As Variant, pid As String, qty As Double, active As Long, ws As Worksheet, r As Long, id As String
    Dim rfqExtras As Object, projectName As Variant
    For k = 1 To 8: Set rows(k) = New Collection: Next k
    Call PB_Load
    Set mGroups = PB_Dict()
    For Each key In mOrders.keys
        h = mOrders(key)
        Set rfqExtras = RFQ_ProjectExtras(CStr(key))
        If Not rfqExtras Is Nothing Then
            For Each projectName In rfqExtras.keys
                pid = PB_Project(CStr(projectName), "tTQMComenzi", CStr(key))
                PB_Group CStr(key), pid, CDbl(rfqExtras(projectName))
            Next projectName
        ElseIf PB_Norm(h(4)) <> PB_Norm("Mai multe proiecte") Or PB_Num(h(14)) + PB_Num(h(15)) <> 0 Then
            pid = PB_Project(h(4), "tTQMComenzi", CStr(key))
            PB_Group CStr(key), pid, PB_Num(h(14)) + PB_Num(h(15))
        End If
    Next key
    For Each key In mPositions.keys
        a = mPositions(key): id = CStr(a(1))
        If Not mOrders.exists(id) Then Err.Raise vbObjectError + 931, , "Pozitie fara comanda: " & CStr(key)
        h = mOrders(id): pid = PB_Project(a(15), "tTQMCFPoz", CStr(key)): qty = 0: active = 0
        If mReceived.exists(CStr(key)) Then qty = CDbl(mReceived(key))
        If PB_Num(a(6)) < 0 Or PB_Num(a(10)) < 0 Or PB_Num(a(7)) < 0 Or PB_Num(a(8)) < 0 Or PB_Num(a(8)) > 100 Then Err.Raise vbObjectError + 932, , "Cantitate / pret / discount invalid."
        If qty + PB_Num(a(10)) > PB_Num(a(6)) + 0.000001 Or qty < 0 Then Err.Raise vbObjectError + 932, , "Cantitati primite / anulate peste comanda."
        If h(8) = "Trimisa" Or h(8) = "Confirmata" Then active = 1
        PB_Group id, pid, 0
        rows(3).Add Array(key, id, pid, a(15), a(3), a(6), a(10), qty, a(7), a(8), active, "", "", "", "", id & "|" & pid, h(1))
    Next key
    For Each key In mReps.keys
        a = mReps(key)
        If a(12) = "Valida" Then
            h = mInvoices(CStr(a(1))): pid = PB_Project(a(2), "tTQMFPRepartizari", CStr(key)): b = PB_Resolve(a, h)
            id = "": If Len(CStr(b(0))) > 0 And Len(CStr(b(2))) > 0 Then id = CStr(b(0)) & "|" & CStr(b(2))
            rows(5).Add Array(key, a(1), pid, a(2), h(0), h(1), h(5), a(3), a(4), "", "", "", b(0), b(1), b(2), id, b(3), b(4), b(5), a(11), a(15), "", "", "", "")
        End If
    Next key
    For Each key In mGroups.keys: rows(4).Add mGroups(key): Next key
    Set ws = ThisWorkbook.Worksheets("Control_Achizitii")
    For r = 13 To TQM_Control_LastRow(ws)
        If Len(PB_Text(TQM_Control_Cell(ws, r, 6).Value2)) > 0 Then
            id = PB_Text(TQM_Control_Cell(ws, r, 18).Value2): If Len(id) = 0 Then id = CStr(r)
            pid = PB_Project(TQM_Control_Cell(ws, r, 6).Value2, "Control_Achizitii", id)
        End If
    Next r
    For Each key In mUnknown.keys: rows(7).Add mUnknown(key): Next key
    For Each key In mProjects.keys
        a = mProjects(key): rows(1).Add Array(a(1), a(2), "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", a(7), key, a(6), CDbl(Now))
    Next key
    If mUnknown.count > 0 Then rows(1).Add Array("DE COMPLETAT", "Proiecte de inregistrat", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "De verificat", "NEALOCAT", "", CDbl(Now))
End Sub
Private Function PB_Stamp() As String
    Dim names As Variant, name As Variant, lo As ListObject, lr As ListRow, c As Long, s As String, v As String
    names = Split("tTQMNMProiecte|tTQMComenzi|tTQMCFPoz|tTQMCFRec|tTQMFacturi|tTQMFPRepartizari|tTQMFPPlati|tTQMPBBugete|tTQMPBLegaturi", "|")
    For Each name In names
        Set lo = PB_Source(CStr(name)): s = s & "T" & name & ":" & lo.ListRows.count & ";"
        For Each lr In lo.ListRows
            For c = 1 To lo.ListColumns.count
                v = PB_Text(lr.Range.Cells(1, c).Value2): s = s & Len(v) & ":" & v & ";"
            Next c
        Next lr
    Next name
    PB_Stamp = s
End Function
Private Sub PB_Put(ByVal kind As Long, ByVal rows As Collection)
    Dim lo As ListObject, body As Range, data As Variant, a As Variant
    Dim r As Long, c As Long, count As Long

    Set lo = PB_Table(kind)
    If rows Is Nothing Then Err.Raise vbObjectError + 971, "PB_Put", "Colectie de date neinitializata pentru " & lo.name
    lo.Parent.Unprotect Password:=""
    count = CLng(Application.Max(2, rows.count))

    Set body = lo.DataBodyRange
    If Not body Is Nothing Then body.ClearContents
    lo.Resize lo.HeaderRowRange.Resize(count + 1, lo.ListColumns.count)
    Set body = PB_DataArea(lo)

    ReDim data(1 To count, 1 To lo.ListColumns.count)
    For r = 1 To rows.count
        a = rows(r)
        For c = 0 To UBound(a)
            data(r, c + 1) = a(c)
        Next c
    Next r
    body.Cells(1, 1).Resize(count, lo.ListColumns.count).Value2 = data
End Sub
Private Sub PB_Formulas()
    Dim lo As ListObject
    Set lo = PB_Table(1)
    PB_CalcSetR1C1 lo, "Buget_aprobat_net_RON", "=IF(LEN([@ID_proiect])=0,"""",IF(COUNTIFS(tTQMPBBugete[ID_proiect],[@ID_proiect],tTQMPBBugete[Stare],""Aprobat"")=1,SUMIFS(tTQMPBBugete[Buget_net_RON],tTQMPBBugete[ID_proiect],[@ID_proiect],tTQMPBBugete[Stare],""Aprobat""),""n.a.""))"
    PB_CalcSetR1C1 lo, "Facturat_net_RON", "=IF(LEN([@ID_proiect])=0,"""",SUMIFS(tTQMPBFacturi[Net_RON],tTQMPBFacturi[ID_proiect],[@ID_proiect]))"
    PB_CalcSetR1C1 lo, "Plati_efective_cu_TVA_RON", "=IF(LEN([@ID_proiect])=0,"""",SUMIFS(tTQMPBFacturi[Plati_efective_RON],tTQMPBFacturi[ID_proiect],[@ID_proiect]))"
    PB_CalcSetR1C1 lo, "Sold_cu_TVA_RON", "=IF(LEN([@ID_proiect])=0,"""",SUMIFS(tTQMPBFacturi[Sold_RON],tTQMPBFacturi[ID_proiect],[@ID_proiect]))"
    PB_CalcSetR1C1 lo, "Restante_cu_TVA_RON", "=IF(LEN([@ID_proiect])=0,"""",SUMIFS(tTQMPBFacturi[Restante_RON],tTQMPBFacturi[ID_proiect],[@ID_proiect]))"
    PB_CalcSetR1C1 lo, "TVA_facturat_RON", "=IF(LEN([@ID_proiect])=0,"""",SUMIFS(tTQMPBFacturi[TVA_RON],tTQMPBFacturi[ID_proiect],[@ID_proiect]))"
    PB_CalcSetR1C1 lo, "Facturat_cu_TVA_RON", "=IF(LEN([@ID_proiect])=0,"""",SUMIFS(tTQMPBFacturi[Total_RON],tTQMPBFacturi[ID_proiect],[@ID_proiect]))"
    PB_CalcSetR1C1 lo, "Compensari_cu_TVA_RON", "=IF(LEN([@ID_proiect])=0,"""",SUMIFS(tTQMPBFacturi[Compensari_RON],tTQMPBFacturi[ID_proiect],[@ID_proiect]))"
    PB_CalcSetR1C1 lo, "Credit_cu_TVA_RON", "=IF(LEN([@ID_proiect])=0,"""",SUMIFS(tTQMPBFacturi[Credit_RON],tTQMPBFacturi[ID_proiect],[@ID_proiect]))"
    PB_CalcSetR1C1 lo, "Nr_semnale_de_clarificat", "=IF(LEN([@ID_proiect])=0,"""",COUNTIFS(tTQMPBFacturi[ID_proiect],[@ID_proiect],tTQMPBFacturi[Clarificare],1)+SUMIFS(tTQMPBComenzi[Nr_clarificari],tTQMPBComenzi[ID_proiect],[@ID_proiect]))"
    PB_CalcSetR1C1 lo, "Nr_legaturi_doar_comanda", "=IF(LEN([@ID_proiect])=0,"""",COUNTIFS(tTQMPBFacturi[ID_proiect_angajament],[@ID_proiect],tTQMPBFacturi[Doar_comanda],1,tTQMPBFacturi[Clasificare],""Comanda""))"
    PB_CalcSetR1C1 lo, "Comenzi_nefacturate_net_RON", "=IF(LEN([@ID_proiect])=0,"""",IF([@Nr_semnale_de_clarificat]>0,""n.a."",SUMIFS(tTQMPBComenzi[Nefacturat_RON],tTQMPBComenzi[ID_proiect],[@ID_proiect])))"
    PB_CalcSetR1C1 lo, "Expunere_net_RON", "=IF(LEN([@ID_proiect])=0,"""",IF(ISNUMBER([@Comenzi_nefacturate_net_RON]),ROUND([@Facturat_net_RON]+[@Comenzi_nefacturate_net_RON],2),""n.a.""))"
    PB_CalcSetR1C1 lo, "Disponibil_net_RON", "=IF(LEN([@ID_proiect])=0,"""",IF(AND(ISNUMBER([@Buget_aprobat_net_RON]),ISNUMBER([@Expunere_net_RON])),ROUND([@Buget_aprobat_net_RON]-[@Expunere_net_RON],2),""n.a.""))"
    PB_CalcSetR1C1 lo, "Utilizare_pct", "=IF(LEN([@ID_proiect])=0,"""",IF(AND(ISNUMBER([@Buget_aprobat_net_RON]),ISNUMBER([@Expunere_net_RON]),[@Buget_aprobat_net_RON]>0),[@Expunere_net_RON]/[@Buget_aprobat_net_RON],""n.a.""))"
    PB_CalcSetR1C1 lo, "De_primit_net_RON", "=IF(LEN([@ID_proiect])=0,"""",SUMIFS(tTQMPBComenzi[De_primit_RON],tTQMPBComenzi[ID_proiect],[@ID_proiect]))"
    PB_CalcSetR1C1 lo, "Buget_propus_net_RON", "=IF(LEN([@ID_proiect])=0,"""",IF(COUNTIFS(tTQMPBBugete[ID_proiect],[@ID_proiect],tTQMPBBugete[Stare],""Ciorna"")=1,SUMIFS(tTQMPBBugete[Buget_net_RON],tTQMPBBugete[ID_proiect],[@ID_proiect],tTQMPBBugete[Stare],""Ciorna""),""""))"
    PB_CalcSetR1C1 lo, "Actiune", "=IF(LEN([@ID_proiect])=0,"""",IF([@ID_proiect]=""NEALOCAT"",""INREGISTRATI PROIECTELE"",IF([@Nr_semnale_de_clarificat]>0,""CLARIFICATI FACTURILE"",IF(NOT(ISNUMBER([@Buget_aprobat_net_RON])),""STABILITI / APROBATI BUGETUL"",IF([@Disponibil_net_RON]<0,""BUGET DEPASIT"",IF([@Restante_cu_TVA_RON]>0,""PLATI RESTANTE"",IF([@Stare_proiect]<>""Activ"",""PROIECT INACTIV / DE VERIFICAT"",IF([@Nr_legaturi_doar_comanda]>0,""VERIFICATI ALOCAREA PE POZITII"",""IN BUGET""))))))))"
    Set lo = PB_Table(3)
    PB_CalcSetR1C1 lo, "Angajat_net_RON", "=IF(LEN([@ID_pozitie])=0,"""",IF([@Activa]=1,ROUND(MAX(0,[@Cant_comandata]-[@Cant_anulata])*[@Pret_unitar]*(1-[@Discount_pct]/100),2),0))"
    PB_CalcSetR1C1 lo, "Facturat_direct_RON", "=IF(LEN([@ID_pozitie])=0,"""",SUMIFS(tTQMPBFacturi[Net_RON],tTQMPBFacturi[ID_pozitie_legatura],[@ID_pozitie],tTQMPBFacturi[Clasificare],""Comanda""))"
    PB_CalcSetR1C1 lo, "Nefacturat_direct_RON", "=IF(LEN([@ID_pozitie])=0,"""",IF([@Activa]=1,MAX(0,ROUND([@Angajat_net_RON]-[@Facturat_direct_RON],2)),0))"
    PB_CalcSetR1C1 lo, "De_primit_net_RON", "=IF(LEN([@ID_pozitie])=0,"""",IF([@Activa]=1,ROUND(MAX(0,[@Cant_comandata]-[@Cant_anulata]-[@Cant_primita])*[@Pret_unitar]*(1-[@Discount_pct]/100),2),0))"
    Set lo = PB_Table(4)
    PB_CalcSetR1C1 lo, "Materiale_angajate_RON", "=IF(LEN([@Cheie_comanda_proiect])=0,"""",SUMIFS(tTQMPBPozitii[Angajat_net_RON],tTQMPBPozitii[Cheie_comanda_proiect],[@Cheie_comanda_proiect]))"
    PB_CalcSetR1C1 lo, "Materiale_nefacturate_RON", "=IF(LEN([@Cheie_comanda_proiect])=0,"""",SUMIFS(tTQMPBPozitii[Nefacturat_direct_RON],tTQMPBPozitii[Cheie_comanda_proiect],[@Cheie_comanda_proiect]))"
    PB_CalcSetR1C1 lo, "Facturat_fara_pozitie_RON", "=IF(LEN([@Cheie_comanda_proiect])=0,"""",SUMIFS(tTQMPBFacturi[Net_RON],tTQMPBFacturi[Cheie_comanda_proiect],[@Cheie_comanda_proiect],tTQMPBFacturi[Doar_comanda],1,tTQMPBFacturi[Clasificare],""Comanda""))"
    PB_CalcSetR1C1 lo, "Nefacturat_RON", "=IF(LEN([@Cheie_comanda_proiect])=0,"""",IF([@Activa]=1,MAX(0,ROUND([@Materiale_nefacturate_RON]+[@Costuri_suplimentare_RON]-[@Facturat_fara_pozitie_RON],2)),0))"
    PB_CalcSetR1C1 lo, "De_primit_RON", "=IF(LEN([@Cheie_comanda_proiect])=0,"""",SUMIFS(tTQMPBPozitii[De_primit_net_RON],tTQMPBPozitii[Cheie_comanda_proiect],[@Cheie_comanda_proiect]))"
    PB_CalcSetR1C1 lo, "Nr_clarificari", "=IF(LEN([@Cheie_comanda_proiect])=0,"""",COUNTIFS(tTQMPBFacturi[ID_comanda_legatura],[@ID_comanda],tTQMPBFacturi[Clarificare],1))"
    Set lo = PB_Table(5)
    PB_CalcSetR1C1 lo, "Total_RON", "=IF(LEN([@ID_repartizare])=0,"""",ROUND([@Net_RON]+[@TVA_RON],2))"
    PB_CalcSetR1C1 lo, "Achitat_RON", "=IF(LEN([@ID_repartizare])=0,"""",ROUND(SUMIFS(tTQMFPPlati[Suma_RON],tTQMFPPlati[ID_repartizare],[@ID_repartizare],tTQMFPPlati[Stare],""Valida""),2))"
    PB_CalcSetR1C1 lo, "Sold_RON", "=IF(LEN([@ID_repartizare])=0,"""",ROUND([@Total_RON]-[@Achitat_RON],2))"
    PB_CalcSetR1C1 lo, "Plati_efective_RON", "=IF(LEN([@ID_repartizare])=0,"""",ROUND(SUMIFS(tTQMFPPlati[Suma_RON],tTQMFPPlati[ID_repartizare],[@ID_repartizare],tTQMFPPlati[Stare],""Valida"",tTQMFPPlati[Tip],""Plata"")+SUMIFS(tTQMFPPlati[Suma_RON],tTQMFPPlati[ID_repartizare],[@ID_repartizare],tTQMFPPlati[Stare],""Valida"",tTQMFPPlati[Tip],""Restituire""),2))"
    PB_CalcSetR1C1 lo, "Compensari_RON", "=IF(LEN([@ID_repartizare])=0,"""",SUMIFS(tTQMFPPlati[Suma_RON],tTQMFPPlati[ID_repartizare],[@ID_repartizare],tTQMFPPlati[Stare],""Valida"",tTQMFPPlati[Tip],""Compensare""))"
    PB_CalcSetR1C1 lo, "Restante_RON", "=IF(LEN([@ID_repartizare])=0,"""",IF(AND([@Sold_RON]>0,[@Scadenta]<TODAY()),[@Sold_RON],0))"
    PB_CalcSetR1C1 lo, "Credit_RON", "=IF(LEN([@ID_repartizare])=0,"""",MAX(0,-[@Sold_RON]))"
    PB_Table(5).Parent.Calculate: PB_Table(3).Parent.Calculate: PB_Table(4).Parent.Calculate: PB_Table(1).Parent.Calculate
End Sub
Private Sub PB_Restore(ByVal kind As Long, ByVal data As Variant)
    Dim lo As ListObject, body As Range
    Dim rowCount As Long, columnCount As Long, tableRows As Long

    Set lo = PB_Table(kind)
    If Not IsArray(data) Then Err.Raise vbObjectError + 972, "PB_Restore", "Starea anterioara lipseste pentru " & lo.name
    rowCount = UBound(data, 1) - LBound(data, 1) + 1
    columnCount = UBound(data, 2) - LBound(data, 2) + 1
    If columnCount <> lo.ListColumns.count Then Err.Raise vbObjectError + 973, "PB_Restore", "Stare anterioara incompatibila pentru " & lo.name
    tableRows = CLng(Application.Max(2, rowCount))

    lo.Parent.Unprotect Password:=""
    Set body = lo.DataBodyRange
    If Not body Is Nothing Then body.ClearContents
    lo.Resize lo.HeaderRowRange.Resize(tableRows + 1, lo.ListColumns.count)
    Set body = PB_DataArea(lo)
    body.Cells(1, 1).Resize(rowCount, columnCount).formula = data
End Sub
Private Sub PB_Refresh()
    Dim rows(1 To 8) As Collection, backups(1 To 8) As Variant, kinds As Variant, kind As Variant
    Dim stamp As String, written As Boolean, oldE As Boolean, oldS As Boolean, msg As String, eno As Long
    Dim stage As String, errSource As String, body As Range, lo As ListObject
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating
    On Error GoTo Fail
    Application.EnableEvents = False: Application.ScreenUpdating = False
    stage = "Creare si validare tabele - PB_Ensure"
    PB_Ensure
    stage = "Citire semnatura surselor - PB_Stamp"
    stamp = PB_Stamp()
    stage = "Construire date proiecte si bugete - PB_Build"
    PB_Build rows
    stage = "Verificare consistenta surse"
    If stamp <> PB_Stamp() Then Err.Raise vbObjectError + 933, , "Sursele s-au modificat in timpul actualizarii. Reluati."
    kinds = Array(1, 3, 4, 5, 7)
    For Each kind In kinds
        Set lo = PB_Table(CLng(kind))
        stage = "Salvare stare anterioara - " & lo.name
        lo.Parent.Unprotect Password:=""
        Set body = PB_DataArea(lo)
        backups(CLng(kind)) = body.formula
    Next kind
    written = True
    For Each kind In kinds
        stage = "Actualizare date - " & PB_TName(CLng(kind))
        PB_Put CLng(kind), rows(CLng(kind))
    Next kind
    stage = "Scriere formule - PB_Formulas"
    PB_Formulas
    stage = "Refacere interfata - PB_Layout"
    PB_Layout
    PB_Table(1).Parent.Unprotect
    PB_Table(1).Parent.Range("A4").Value2 = "ACTUALIZAT " & Format$(Now, "dd.mm.yyyy hh:mm:ss") & " | Buget net RON, intreaga durata a proiectului."
    stage = "Protejare foi proiecte si bugete"
    Call PB_Protect
    mGood = True
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
    Exit Sub
Fail:
    eno = Err.number: msg = Err.description: errSource = Err.source
    msg = "Etapa: " & stage & vbCrLf & "Eroare: " & CStr(eno) & vbCrLf & _
          "Sursa: " & errSource & vbCrLf & "Mesaj: " & msg
    On Error Resume Next
    If written Then
        For Each kind In kinds: PB_Restore CLng(kind), backups(CLng(kind)): Next kind
    End If
    mGood = False: PB_Table(1).Parent.Unprotect
    PB_Table(1).Parent.Range("A4").Value2 = "NEACTUALIZAT - " & msg & " | Reluati Actualizeaza dupa corectarea sursei."
    Call PB_Protect
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
    On Error GoTo 0
    If Len(errSource) = 0 Then errSource = "PB_Refresh"
    Err.Raise eno, errSource, msg
End Sub
Private Sub PB_Protect()
    Dim k As Long
    For k = 1 To 8: PB_Table(k).Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True: Next k
End Sub
Private Sub PB_Button(ByVal ws As Worksheet, ByVal area As String, ByVal caption As String, ByVal action As String)
    Dim sh As Shape, rg As Range, name As String
    name = "PB_" & action: On Error Resume Next: ws.Shapes(name).Delete: On Error GoTo 0
    Set rg = ws.Range(area): Set sh = ws.Shapes.AddShape(msoShapeRoundedRectangle, rg.Left + 2, rg.Top + 1, rg.width - 4, rg.Height - 2)
    sh.name = name: sh.TextFrame.Characters.text = caption: sh.Fill.ForeColor.RGB = RGB(37, 99, 235): sh.line.Visible = msoFalse
    sh.TextFrame.Characters.Font.Color = vbWhite: sh.TextFrame.Characters.Font.size = 10
    sh.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & action
End Sub
Private Sub PB_LayoutRange(ByVal ws As Worksheet, ByVal areaAddress As String)
    Dim target As Range, cell As Range, mergedArea As Range
    Set target = ws.Range(areaAddress)
    If ws.name <> PB_SHEET Or target.Areas.count <> 1 Or target.rows.count <> 1 Or _
       target.row < 2 Or target.row > 11 Then
        Err.Raise vbObjectError + 973, "PB_LayoutRange", "Zona de interfata nepermisa: " & areaAddress
    End If

    ' Verificam toate imbinarile inainte de a modifica aceasta zona.
    ' Nu desfacem nicio imbinare care ajunge la antetul sau datele tabelului.
    For Each cell In target.Cells
        If cell.MergeCells Then
            Set mergedArea = cell.MergeArea
            If mergedArea.row < 2 Or mergedArea.row + mergedArea.rows.count - 1 > 11 Then
                Err.Raise vbObjectError + 974, "PB_LayoutRange", _
                    "Imbinare in afara interfetei: " & mergedArea.address(False, False) & _
                    ". Verificati zona inainte de actualizare."
            End If
        End If
    Next cell

    ' UnMerge pastreaza continutul existent. Nu golim celulele si nu le reimbinam.
    For Each cell In target.Cells
        If cell.MergeCells Then cell.MergeArea.UnMerge
    Next cell
    target.HorizontalAlignment = xlHAlignCenterAcrossSelection
End Sub

Private Sub PB_Layout()
    Dim ws As Worksheet, k As Long, lo As ListObject, col As ListColumn
    Dim layoutLine As Long, layoutError As Long, layoutMessage As String
    Dim layoutSheet As String
    On Error GoTo LayoutFail
    layoutLine = 100
    For k = 1 To 8
        layoutLine = 110
        Set lo = PB_Table(k)
        layoutLine = 120
        Set ws = lo.Parent
        layoutLine = 130
        ws.Unprotect
        layoutLine = 140
        ws.Cells.Font.name = "Aptos"
        layoutLine = 150
        ws.Cells.Font.size = 10
        layoutLine = 160
        lo.TableStyle = "TableStyleMedium2"
        layoutLine = 170
        lo.HeaderRowRange.Interior.Color = RGB(31, 41, 55)
        layoutLine = 180
        lo.HeaderRowRange.Font.Color = vbWhite
        layoutLine = 190
        lo.HeaderRowRange.Font.Bold = True
        layoutLine = 200
        lo.HeaderRowRange.WrapText = True
        layoutLine = 210
        lo.HeaderRowRange.RowHeight = 44
        layoutLine = 220
        For Each col In lo.ListColumns
            layoutLine = 230
            If InStr(col.name, "RON") > 0 Then col.Range.NumberFormat = "#,##0.00;(#,##0.00);""-"""
        layoutLine = 240
        Next col
    layoutLine = 250
    Next k
    layoutLine = 260
    Set ws = PB_Table(1).Parent
    layoutLine = 265
    Call PB_PrepareHeader(ws)
    layoutLine = 270
    Call PB_LayoutRange(ws, "A2:I2")
    layoutLine = 280
    ws.Range("A2").Value2 = "TQM | PROIECTE SI BUGETE"
    layoutLine = 290
    ws.Range("A2").Font.name = "Aptos Display"
    layoutLine = 300
    ws.Range("A2").Font.size = 18
    layoutLine = 310
    ws.Range("A2").Font.Bold = True
    layoutLine = 320
    Call PB_LayoutRange(ws, "A3:I3")
    layoutLine = 330
    ws.Range("A3").Value2 = "Disponibil = buget aprobat - facturat net - comenzi nefacturate. Platile nu dubleaza cheltuiala."
    layoutLine = 340
    Call PB_LayoutRange(ws, "A4:I4")
    layoutLine = 350
    ws.Range("A4").Font.Color = RGB(71, 85, 105)
    layoutLine = 360
    ws.rows(4).RowHeight = 24
    layoutLine = 370
    ws.rows("5:6").RowHeight = 25
    layoutLine = 380
    PB_Button ws, "A5:B5", "Actualizeaza", "PB_Actualizeaza"
    layoutLine = 390
    PB_Button ws, "C5:D5", "Buget / revizie", "PB_BugetNou"
    layoutLine = 400
    PB_Button ws, "E5:F5", "Aproba ciorna", "PB_Aproba"
    layoutLine = 410
    PB_Button ws, "G5:I5", "Istoric bugete", "PB_Istoric"
    layoutLine = 420
    PB_Button ws, "A6:B6", "Detalii proiect", "PB_Detalii"
    layoutLine = 430
    PB_Button ws, "C6:D6", "Asocieri facturi", "PB_Facturi"
    layoutLine = 440
    PB_Button ws, "E6:F6", "Proiecte folosite", "PB_ProiecteFolosite"
    layoutLine = 450
    PB_Button ws, "G6:I6", "Proiect nou", "PB_ProiectNou"
    layoutLine = 460
    Call PB_LayoutRange(ws, "A8:B8")
    layoutLine = 470
    ws.Range("A8").Value2 = "Bugete aprobate net RON"
    layoutLine = 480
    Call PB_LayoutRange(ws, "C8:D8")
    layoutLine = 490
    ws.Range("C8").Value2 = "Facturat net RON"
    layoutLine = 500
    Call PB_LayoutRange(ws, "E8:F8")
    layoutLine = 510
    ws.Range("E8").Value2 = "Comenzi nefacturate net RON"
    layoutLine = 520
    Call PB_LayoutRange(ws, "G8:I8")
    layoutLine = 530
    ws.Range("G8").Value2 = "Sold facturi cu TVA RON"
    layoutLine = 540
    Call PB_LayoutRange(ws, "A9:B9")
    layoutLine = 550
    Call PB_LayoutRange(ws, "C9:D9")
    layoutLine = 560
    Call PB_LayoutRange(ws, "E9:F9")
    layoutLine = 570
    Call PB_LayoutRange(ws, "G9:I9")
    layoutLine = 580
    ws.Range("A9").formula = "=IF(COUNTIFS(tTQMPBBugete[Stare],""Aprobat"")=0,""n.a."",SUM(tTQMProiecteBugete[Buget_aprobat_net_RON]))"
    layoutLine = 590
    ws.Range("C9").formula = "=SUM(tTQMProiecteBugete[Facturat_net_RON])"
    layoutLine = 600
    ws.Range("E9").formula = "=IF(SUM(tTQMProiecteBugete[Nr_semnale_de_clarificat])>0,""n.a."",SUM(tTQMProiecteBugete[Comenzi_nefacturate_net_RON]))"
    layoutLine = 610
    ws.Range("G9").formula = "=SUM(tTQMProiecteBugete[Sold_cu_TVA_RON])"
    layoutLine = 620
    ws.Range("A8:I9").Interior.Color = RGB(239, 246, 255)
    layoutLine = 630
    ws.Range("A9:I9").Font.size = 15
    layoutLine = 640
    ws.Range("A9:I9").Font.Bold = True
    layoutLine = 650
    ws.Range("A9:I9").HorizontalAlignment = xlHAlignCenterAcrossSelection
    layoutLine = 660
    ws.Range("A9:I9").NumberFormat = "#,##0.00;(#,##0.00);""-"""
    layoutLine = 670
    ws.rows(9).RowHeight = 29
    layoutLine = 680
    Call PB_LayoutRange(ws, "A11:I11")
    layoutLine = 690
    ws.Range("A11").Value2 = "Selectati proiectul. n.a. = buget neaprobat / legaturi neclarificate. De primit este separat de nefacturat."
    layoutLine = 700
    ws.Range("A11").Font.Color = RGB(71, 85, 105)
    layoutLine = 710
    ws.rows(11).RowHeight = 24
    layoutLine = 720
    ws.Columns("A").ColumnWidth = 19
    layoutLine = 730
    ws.Columns("B").ColumnWidth = 28
    layoutLine = 740
    ws.Columns("C:G").ColumnWidth = 20
    layoutLine = 750
    ws.Columns("E").ColumnWidth = 25
    layoutLine = 760
    ws.Columns("H").ColumnWidth = 12
    layoutLine = 770
    ws.Columns("I").ColumnWidth = 36
    layoutLine = 780
    ws.Columns("J:U").ColumnWidth = 19
    layoutLine = 790
    ws.Columns("V").ColumnWidth = 43
    layoutLine = 800
    ws.Columns("W:X").ColumnWidth = 22
    layoutLine = 810
    PB_Table(1).ListColumns("Utilizare_pct").Range.NumberFormat = "0.0%"
    layoutLine = 820
    PB_Table(1).ListColumns("Actualizat_la").Range.NumberFormat = "dd.mm.yyyy hh:mm"
    layoutLine = 830
    PB_Table(1).ListColumns("Actiune").DataBodyRange.WrapText = True
    layoutLine = 840
    PB_Table(1).DataBodyRange.RowHeight = 35
    layoutLine = 850
    Call PB_Protect
    Exit Sub

LayoutFail:
    layoutError = Err.number
    layoutMessage = Err.description
    layoutSheet = ""
    On Error Resume Next
    If Not ws Is Nothing Then layoutSheet = ws.name
    On Error GoTo 0
    Err.Raise layoutError, "PB_Layout", "Instructiunea PB_Layout: " & CStr(layoutLine) & vbCrLf & _
              "Foaie: " & layoutSheet & vbCrLf & "Mesaj original: " & layoutMessage
End Sub
Public Sub PB_Sync()
    Dim ws As Worksheet
    If mUpdating Then Exit Sub
    On Error Resume Next: Set ws = ThisWorkbook.Worksheets(PB_SHEET): On Error GoTo 0
    If ws Is Nothing Then Exit Sub
    mUpdating = True
    On Error GoTo Done
    PB_Refresh
Done:
    mUpdating = False
End Sub
Public Sub PB_Actualizeaza()
    On Error GoTo Fail
    If mUpdating Then Exit Sub
    mUpdating = True: PB_Refresh: mUpdating = False
    Exit Sub
Fail: mUpdating = False: MsgBox Err.description, vbExclamation, "TQM - Proiecte si Bugete"
End Sub
Public Sub PB_Instaleaza()
    On Error GoTo Fail
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 934, , "Registrul este deschis doar pentru citire."
    PB_Actualizeaza
    If Not mGood Then Exit Sub
    ThisWorkbook.Worksheets(PB_SHEET).Activate
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 85
    ActiveWindow.FreezePanes = False: ActiveWindow.SplitRow = 12: ActiveWindow.SplitColumn = 2: ActiveWindow.FreezePanes = True
    MsgBox "Proiecte si Bugete instalat. Inregistrati proiectele, apoi introduceti bugetul aprobat.", vbInformation, "TQM"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Private Function PB_Selected() As String
    Dim hit As Range, lo As ListObject, i As Long
    If Not ActiveWorkbook Is ThisWorkbook Then Err.Raise vbObjectError + 935, , "Selectati un proiect in registrul principal."
    If ActiveSheet.name <> PB_SHEET Then Err.Raise vbObjectError + 936, , "Deschideti Proiecte si Bugete."
    Set lo = PB_Table(1): Set hit = Intersect(ActiveCell, lo.DataBodyRange)
    If hit Is Nothing Then Err.Raise vbObjectError + 937, , "Selectati un rand de proiect."
    i = hit.row - lo.HeaderRowRange.row: PB_Selected = CStr(lo.ListRows(i).Range.Cells(1, 22).Value2)
    If Len(PB_Selected) = 0 Or PB_Selected = "NEALOCAT" Then Err.Raise vbObjectError + 938, , "Inregistrati proiectul in Nomenclatoare mai intai."
End Function
Private Function PB_Start(ByVal mode As String, ByVal id As String) As Worksheet
    If Not mForm Is Nothing Then
        On Error Resume Next: Err.Clear: mForm.Activate
        If Err.number = 0 Then On Error GoTo 0: Err.Raise vbObjectError + 939, , "Inchideti formularul local existent."
        Err.Clear: Set mForm = Nothing: On Error GoTo 0
    End If
    Set mForm = Workbooks.Add(xlWBATWorksheet): mMode = mode: mID = id: mStamp = PB_Stamp()
    Set PB_Start = mForm.Worksheets(1): PB_Start.name = "Formular_Proiecte_Bugete"
    PB_Start.Cells.Font.name = "Aptos": PB_Start.Cells.Font.size = 10: PB_Start.Columns("A").ColumnWidth = 31: PB_Start.Columns("B").ColumnWidth = 52: PB_Start.Columns("C:L").ColumnWidth = 20
    PB_Start.Range("A1:L1").Merge: PB_Start.Range("A1").Value2 = "TQM | " & mode & " (formular local)": PB_Start.Range("A1").Font.size = 17: PB_Start.Range("A1").Font.Bold = True
    PB_Button PB_Start, "A3:B3", "Inchide", "PB_Inchide": PB_Start.rows(3).RowHeight = 27
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 85
End Function
Public Sub PB_Inchide()
    On Error Resume Next
    If Not mForm Is Nothing Then mForm.Close SaveChanges:=False
    Set mForm = Nothing: mMode = "": mID = "": mStamp = ""
    ThisWorkbook.Worksheets(PB_SHEET).Activate
    On Error GoTo 0
End Sub
Private Sub PB_Field(ByVal ws As Worksheet, ByVal row As Long, ByVal label As String, ByVal value As Variant, Optional ByVal editable As Boolean = True)
    ws.Cells(row, 1).Value2 = label: ws.Cells(row, 2).Value2 = value
    If editable Then ws.Cells(row, 2).Interior.Color = RGB(239, 246, 255): ws.Cells(row, 2).Font.Color = RGB(37, 99, 235): ws.Cells(row, 2).Locked = False
    ws.rows(row).RowHeight = 25
End Sub
Private Sub PB_BudgetForm(ByVal approve As Boolean)
    Dim pid As String, ws As Worksheet, a As Variant, budgets As Object, key As Variant, b As Variant, amount As Variant, dateValue As Variant, who As String, reason As String, state As String
    On Error GoTo Fail
    pid = PB_Selected(): PB_Refresh: a = mProjects(pid): amount = "": dateValue = CDbl(Date): state = "Ciorna"
    Set budgets = PB_Read(PB_TName(2), 1)
    For Each key In budgets.keys
        b = budgets(key)
        If CStr(b(1)) = pid And b(4) = "Ciorna" Then amount = b(3): dateValue = b(5): who = CStr(b(6)): reason = CStr(b(7))
    Next key
    If approve Then
        If Len(CStr(amount)) = 0 Then Err.Raise vbObjectError + 940, , "Nu exista o ciorna de aprobat. Folositi Buget / revizie."
        state = "Aprobat"
    End If
    Set ws = PB_Start("BUGET", pid)
    PB_Button ws, "C3:D3", "Salveaza bugetul", "PB_SalveazaBuget"
    PB_Field ws, 5, "Proiect", a(2), False: PB_Field ws, 6, "Buget total net RON (fara TVA)", amount
    PB_Field ws, 7, "Data bugetului", dateValue: ws.Range("B7").NumberFormat = "dd.mm.yyyy"
    PB_Field ws, 8, "Stare", state: PB_Field ws, 9, "Aprobat de", who: PB_Field ws, 10, "Motiv / justificare", reason
    ws.Range("B6").NumberFormat = "#,##0.00": ws.Range("B10").WrapText = True: ws.rows(10).RowHeight = 45
    ws.Range("B8").Validation.Add xlValidateList, Formula1:="Ciorna,Aprobat"
    ws.Range("A12:H12").Merge: ws.Range("A12").Value2 = "Suma este bugetul TOTAL revizuit. Ciorna nu schimba disponibilul. Zero inseamna buget aprobat de zero."
    ws.Protect UserInterfaceOnly:=True
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub PB_BugetNou()
    PB_BudgetForm False
End Sub
Public Sub PB_Aproba()
    PB_BudgetForm True
End Sub
Private Sub PB_CheckForm(ByVal mode As String)
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 941, , "Registrul este doar pentru citire."
    If mForm Is Nothing Then Err.Raise vbObjectError + 942, , "Nu exista formular local."
    If Not ActiveWorkbook Is mForm Or mMode <> mode Then Err.Raise vbObjectError + 943, , "Folositi formularul local potrivit."
    If PB_Stamp() <> mStamp Then Err.Raise vbObjectError + 944, , "Date modificate intre timp. Inchideti si redeschideti formularul."
End Sub
Private Function PB_Add(ByVal kind As Long) As Range
    Dim lo As ListObject, lr As ListRow
    Set lo = PB_Table(kind): lo.Parent.Unprotect
    For Each lr In lo.ListRows
        If Len(PB_Text(lr.Range.Cells(1, 1).Value2)) = 0 Then Set PB_Add = lr.Range: Exit Function
    Next lr
    Set PB_Add = lo.ListRows.Add.Range
End Function
Private Sub PB_Audit(ByVal entity As String, ByVal id As String, ByVal action As String, ByVal revision As Long, ByVal field As String, ByVal oldValue As String, ByVal newValue As String)
    Dim row As Range, a As Variant, i As Long
    Set row = PB_Add(8): a = Array(PB_ID("PBE"), CDbl(Now), Application.UserName, entity, id, action, revision, field, oldValue, newValue)
    For i = 0 To UBound(a): row.Cells(1, i + 1).Value2 = a(i): Next i
End Sub
Public Sub PB_SalveazaBuget()
    Dim ws As Worksheet, amount As Currency, state As String, who As String, reason As String, rev As Long, prev As String
    Dim lr As ListRow, row As Range, a As Variant, i As Long, b As Variant, log As Variant, changed As Boolean, oldE As Boolean, msg As String
    On Error GoTo Fail
    PB_CheckForm "BUGET": Set ws = mForm.Worksheets(1): PB_Load
    If Not mProjects.exists(mID) Then Err.Raise vbObjectError + 945, , "Proiectul nu mai exista."
    a = mProjects(mID)
    If Len(PB_Text(ws.Range("B6").Value2)) = 0 Or Not IsNumeric(ws.Range("B6").Value2) Then Err.Raise vbObjectError + 946, , "Introduceti un buget numeric; campul gol nu inseamna zero."
    amount = CCur(ws.Range("B6").Value2)
    If amount < 0 Or Abs(CDbl(ws.Range("B6").Value2) - Application.Round(CDbl(ws.Range("B6").Value2), 2)) > 0.000001 Then Err.Raise vbObjectError + 947, , "Buget nenegativ, cu maximum doua zecimale."
    If Not IsDate(ws.Range("B7").value) Then Err.Raise vbObjectError + 948, , "Data bugetului invalida."
    state = PB_Text(ws.Range("B8").Value2): who = PB_Text(ws.Range("B9").Value2): reason = PB_Text(ws.Range("B10").Value2)
    If state <> "Ciorna" And state <> "Aprobat" Then Err.Raise vbObjectError + 949, , "Alegeti Ciorna sau Aprobat."
    If Len(reason) = 0 Then Err.Raise vbObjectError + 950, , "Completati motivul bugetului / reviziei."
    If state = "Aprobat" And (Len(who) = 0 Or a(7) <> "Activ") Then Err.Raise vbObjectError + 951, , "Aprobarea necesita un proiect Activ si numele aprobatorului."
    For Each lr In PB_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = mID Then
            rev = Application.Max(rev, PB_Num(lr.Range.Cells(1, 3).Value2))
            If lr.Range.Cells(1, 5).Value2 = "Aprobat" Then prev = CStr(lr.Range.Cells(1, 1).Value2)
        End If
    Next lr
    b = PB_Table(2).DataBodyRange.formula: log = PB_Table(8).DataBodyRange.formula
    oldE = Application.EnableEvents: Application.EnableEvents = False: changed = True: PB_Table(2).Parent.Unprotect
    For Each lr In PB_Table(2).ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = mID Then
            If lr.Range.Cells(1, 5).Value2 = "Ciorna" Or (state = "Aprobat" And lr.Range.Cells(1, 5).Value2 = "Aprobat") Then
                PB_Audit "Buget", CStr(lr.Range.Cells(1, 1).Value2), "Inlocuire", CLng(lr.Range.Cells(1, 3).Value2), "Stare", CStr(lr.Range.Cells(1, 5).Value2), "Inlocuit"
                lr.Range.Cells(1, 5).Value2 = "Inlocuit"
            End If
        End If
    Next lr
    Set row = PB_Add(2): a = Array(PB_ID("PBB"), mID, rev + 1, CDbl(amount), state, CDbl(CDate(ws.Range("B7").value)), who, reason, CDbl(Now), Application.UserName, prev)
    For i = 0 To UBound(a): row.Cells(1, i + 1).Value2 = a(i): Next i
    PB_Audit "Buget", CStr(a(0)), "Creare " & state, rev + 1, "Buget_net_RON", "", CStr(amount)
    Call PB_Refresh
    changed = False: Application.EnableEvents = oldE: PB_Inchide
    Exit Sub
Fail:
    msg = Err.description
    If changed Then
        On Error Resume Next: PB_Restore 2, b: PB_Restore 8, log: PB_Refresh: PB_Protect: Application.EnableEvents = oldE: On Error GoTo 0
    End If
    MsgBox msg, vbExclamation, "TQM"
End Sub
Private Sub PB_ViewTable(ByVal kind As Long, ByVal mode As String, Optional ByVal projectID As String = "")
    Dim ws As Worksheet, lr As ListRow, n As Long, count As Long, include As Boolean, projectColumn As Long
    Set ws = PB_Start(mode, projectID): count = PB_Table(kind).ListColumns.count
    ws.Cells(5, 1).Resize(1, count).Value2 = PB_Table(kind).HeaderRowRange.Value2: n = 6
    Select Case kind
    Case 2: projectColumn = 2
    Case 3, 4, 5: projectColumn = 3
    End Select
    For Each lr In PB_Table(kind).ListRows
        include = Len(PB_Text(lr.Range.Cells(1, 1).Value2)) > 0
        If Len(projectID) > 0 And projectColumn > 0 Then include = include And (CStr(lr.Range.Cells(1, projectColumn).Value2) = projectID)
        If include Then ws.Cells(n, 1).Resize(1, count).Value2 = lr.Range.Value2: n = n + 1
    Next lr
    ws.Cells(5, 1).Resize(1, count).Interior.Color = RGB(31, 41, 55): ws.Cells(5, 1).Resize(1, count).Font.Color = vbWhite
    ws.Cells(5, 1).Resize(1, count).WrapText = True: ws.rows(5).RowHeight = 44
    ws.Cells(5, 1).Resize(Application.Max(2, n - 5), count).AutoFilter
    ws.Columns(1).ColumnWidth = 44: ws.Columns(2).ColumnWidth = 43
    If kind = 2 Then ws.Columns(4).NumberFormat = "#,##0.00": ws.Columns(6).NumberFormat = "dd.mm.yyyy": ws.Columns(9).NumberFormat = "dd.mm.yyyy hh:mm"
    If kind = 5 Then ws.Columns("F:G").NumberFormat = "dd.mm.yyyy": ws.Columns("H:L").NumberFormat = "#,##0.00": ws.Columns("V:Y").NumberFormat = "#,##0.00"
    If kind = 5 Then PB_Button ws, "C3:E3", "Asociaza randul", "PB_LeagaFactura"
    If kind = 7 Then PB_Button ws, "C3:E3", "Inregistreaza proiectul", "PB_InregistreazaProiect"
    ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    ActiveWindow.FreezePanes = False: ActiveWindow.SplitRow = 5: ActiveWindow.SplitColumn = 2: ActiveWindow.FreezePanes = True
End Sub
Public Sub PB_Istoric()
    Dim pid As String
    On Error GoTo Fail
    pid = PB_Selected(): PB_Refresh: PB_ViewTable 2, "ISTORIC", pid
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub PB_Facturi()
    On Error GoTo Fail
    Call PB_Refresh
    PB_ViewTable 5, "FACTURI"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub PB_ProiecteFolosite()
    On Error GoTo Fail
    Call PB_Refresh
    PB_ViewTable 7, "PROIECTE FOLOSITE"
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub PB_ProiectNou()
    On Error GoTo Fail
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_ProiectDinDenumire", ""
    Exit Sub
Fail: MsgBox "Importati versiunea actualizata a modulului Nomenclatoare. " & Err.description, vbExclamation, "TQM"
End Sub
Public Sub PB_InregistreazaProiect()
    Dim name As String
    On Error GoTo Fail
    PB_CheckForm "PROIECTE FOLOSITE"
    If ActiveCell.row < 6 Then Err.Raise vbObjectError + 952, , "Selectati o denumire din lista."
    name = PB_Text(ActiveSheet.Cells(ActiveCell.row, 1).Value2)
    If Len(name) = 0 Then Err.Raise vbObjectError + 953, , "Rand gol."
    PB_Inchide
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_ProiectDinDenumire", name
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub PB_Detalii()
    Dim pid As String, ws As Worksheet, kinds As Variant, kind As Variant, lr As ListRow, n As Long, c As Long, cols As Variant, include As Boolean
    On Error GoTo Fail
    pid = PB_Selected(): PB_Refresh: Set ws = PB_Start("DETALII", pid): n = 5
    kinds = Array(1, 4, 3, 5)
    For Each kind In kinds
        ws.Cells(n, 1).Value2 = Choose(CLng(kind), "Situatie proiect", "", "Pozitii comenzi", "Comenzi pe proiect", "Facturi repartizate")
        ws.Cells(n, 1).Font.Bold = True: n = n + 1
        Select Case CLng(kind)
        Case 1: cols = Array(1, 2, 3, 4, 5, 6, 7, 8, 9, 22)
        Case 4: cols = Array(5, 4, 7, 8, 9, 10, 11, 12, 13, 2)
        Case 3: cols = Array(17, 5, 6, 7, 8, 12, 15, 13, 14, 1)
        Case 5: cols = Array(5, 4, 8, 9, 10, 22, 23, 12, 17, 1)
        End Select
        For c = 0 To UBound(cols): ws.Cells(n, c + 1).Value2 = PB_Table(CLng(kind)).ListColumns(CLng(cols(c))).name: Next c
        ws.Cells(n, 1).Resize(1, 10).Interior.Color = RGB(31, 41, 55): ws.Cells(n, 1).Resize(1, 10).Font.Color = vbWhite
        ws.Cells(n, 1).Resize(1, 10).WrapText = True: ws.rows(n).RowHeight = 40: n = n + 1
        For Each lr In PB_Table(CLng(kind)).ListRows
            If CLng(kind) = 1 Then include = (CStr(lr.Range.Cells(1, 22).Value2) = pid) Else include = (CStr(lr.Range.Cells(1, 3).Value2) = pid)
            If include Then
                For c = 0 To UBound(cols): ws.Cells(n, c + 1).Value2 = lr.Range.Cells(1, CLng(cols(c))).Value2: Next c
                If CLng(kind) = 1 Then ws.Cells(n, 3).Resize(, 5).NumberFormat = "#,##0.00": ws.Cells(n, 8).NumberFormat = "0.0%"
                If CLng(kind) <> 1 Then ws.Cells(n, 3).Resize(, 6).NumberFormat = "#,##0.00"
                n = n + 1
            End If
        Next lr
        n = n + 2
    Next kind
    ws.Columns("A:B").ColumnWidth = 29: ws.Columns("C:H").ColumnWidth = 20: ws.Columns("I").ColumnWidth = 36: ws.Columns("J").ColumnWidth = 44
    ws.Protect UserInterfaceOnly:=True
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Public Sub PB_LeagaFactura()
    Dim id As String, ws As Worksheet, a As Variant, b As Variant, row As Long, nr As String, pname As String, kind As String
    On Error GoTo Fail
    PB_CheckForm "FACTURI": row = ActiveCell.row
    If row < 6 Then Err.Raise vbObjectError + 954, , "Selectati o repartizare de factura."
    id = PB_Text(mForm.Worksheets(1).Cells(row, 1).Value2)
    If Not mReps.exists(id) Then Err.Raise vbObjectError + 955, , "Repartizarea nu mai exista."
    a = mReps(id): b = PB_Resolve(a, mInvoices(CStr(a(1)))): kind = CStr(b(3))
    ' Unclassified rows require an explicit choice, never default Directa.
    If kind = "Clarificare" Then kind = ""
    If mOrders.exists(CStr(b(0))) Then a = mOrders(CStr(b(0))): nr = CStr(a(1))
    If mProjects.exists(CStr(b(2))) Then a = mProjects(CStr(b(2))): pname = CStr(a(2))
    Call PB_Inchide
    Set ws = PB_Start("ASOCIERE", id)
    PB_Button ws, "C3:D3", "Salveaza asocierea", "PB_SalveazaAsociere"
    PB_Field ws, 5, "Repartizare", id, False
    PB_Field ws, 6, "Clasificare", kind: ws.Range("B6").Validation.Add xlValidateList, Formula1:="Comanda,Directa"
    PB_Field ws, 7, "Numar comanda / ID comanda", nr: PB_Field ws, 8, "ID pozitie (optional)", b(1)
    PB_Field ws, 9, "Proiectul comenzii", pname: PB_Field ws, 10, "Observatii / justificare", ""
    ws.Range("A12:H12").Merge: ws.Range("A12").Value2 = "Proiectul facturat ramane cel din Facturi si Plati. Asocierea stabileste ce angajament se reduce."
    ws.Protect UserInterfaceOnly:=True
    Exit Sub
Fail: MsgBox Err.description, vbExclamation, "TQM"
End Sub
Private Function PB_InvoiceSupplier(ByVal id As String) As String
    Dim a As Variant
    a = mInvoices(id): PB_InvoiceSupplier = PB_Norm(a(2))
End Function
Public Sub PB_SalveazaAsociere()
    Dim ws As Worksheet, kind As String, orderID As String, posID As String, pid As String, note As String, referintaComanda As String, a As Variant, h As Variant, key As Variant
    Dim old As Variant, log As Variant, row As Range, lr As ListRow, rev As Long, linkID As String, changed As Boolean, i As Long, rows(1 To 8) As Collection, oldE As Boolean, msg As String
    On Error GoTo Fail
    PB_CheckForm "ASOCIERE": Set ws = mForm.Worksheets(1): PB_Load
    If Not mReps.exists(mID) Then Err.Raise vbObjectError + 956, , "Repartizarea nu mai exista."
    a = mReps(mID)
    If a(12) <> "Valida" Then Err.Raise vbObjectError + 957, , "Factura este anulata."
    kind = PB_Text(ws.Range("B6").Value2): note = PB_Text(ws.Range("B10").Value2)
    If Len(note) = 0 Then Err.Raise vbObjectError + 958, , "Completati justificarea asocierii."
    If kind <> "Directa" And kind <> "Comanda" Then Err.Raise vbObjectError + 959, , "Alegeti clasificarea."
    If kind = "Comanda" Then
        referintaComanda = PB_Text(ws.Range("B7").Value2)
        For Each key In mOrders.keys
            h = mOrders(key)
            If (CStr(key) = referintaComanda Or PB_Norm(h(1)) = PB_Norm(referintaComanda)) And PB_Norm(h(3)) = PB_InvoiceSupplier(CStr(a(1))) Then
                If Len(orderID) > 0 Then Err.Raise vbObjectError + 960, , "Mai multe comenzi cu acest numar. Folositi ID-ul comenzii."
                orderID = CStr(key)
            End If
        Next key
        If Len(orderID) = 0 Then Err.Raise vbObjectError + 961, , "Comanda nu exista pentru furnizorul facturii."
        posID = PB_Text(ws.Range("B8").Value2)
        If Len(posID) > 0 Then
            If Not mPositions.exists(posID) Then Err.Raise vbObjectError + 962, , "Pozitie inexistenta."
            h = mPositions(posID)
            If CStr(h(1)) <> orderID Then Err.Raise vbObjectError + 963, , "Pozitia apartine altei comenzi."
            pid = PB_Project(h(15), "tTQMCFPoz", posID)
        Else
            If Len(PB_Text(ws.Range("B9").Value2)) = 0 Then Err.Raise vbObjectError + 964, , "Selectati proiectul angajamentului."
            pid = PB_Project(ws.Range("B9").Value2, "Asociere", mID)
            If pid = "NEALOCAT" Then Err.Raise vbObjectError + 965, , "Inregistrati proiectul in Nomenclatoare."
        End If
    Else
        If Len(PB_Text(a(8)) & PB_Text(a(9))) > 0 Then Err.Raise vbObjectError + 966, , "Factura are deja o comanda; nu poate fi clasificata Directa."
        If Len(PB_Text(ws.Range("B7").Value2) & PB_Text(ws.Range("B8").Value2) & PB_Text(ws.Range("B9").Value2)) > 0 Then Err.Raise vbObjectError + 966, , "Goliti comanda / pozitia / proiectul comenzii pentru Directa."
    End If
    old = PB_Table(6).DataBodyRange.formula: log = PB_Table(8).DataBodyRange.formula
    oldE = Application.EnableEvents: Application.EnableEvents = False: changed = True: PB_Table(6).Parent.Unprotect
    For Each lr In PB_Table(6).ListRows
        If CStr(lr.Range.Cells(1, 1).Value2) = mID Then Set row = lr.Range: rev = CLng(row.Cells(1, 8).Value2): linkID = CStr(row.Cells(1, 7).Value2)
    Next lr
    If row Is Nothing Then Set row = PB_Add(6): linkID = PB_ID("PBL")
    h = Array(mID, kind, orderID, posID, pid, note, linkID, rev + 1, CDbl(Now), Application.UserName)
    For i = 0 To UBound(h): row.Cells(1, i + 1).Value2 = h(i): Next i
    PB_Build rows
    If kind = "Comanda" And Not mGroups.exists(orderID & "|" & pid) Then Err.Raise vbObjectError + 967, , "Proiectul ales nu apartine comenzii."
    PB_Audit "Asociere", mID, "Revizie asociere", rev + 1, "Clasificare / comanda / pozitie / proiect", PB_OldLink(old, mID), kind & "|" & orderID & "|" & posID & "|" & pid
    Call PB_Refresh
    changed = False: Application.EnableEvents = oldE: PB_Inchide
    Exit Sub
Fail:
    msg = Err.description
    If changed Then
        On Error Resume Next: PB_Restore 6, old: PB_Restore 8, log: PB_Refresh: PB_Protect: Application.EnableEvents = oldE: On Error GoTo 0
    End If
    MsgBox msg, vbExclamation, "TQM"
End Sub
Private Function PB_OldLink(ByVal old As Variant, ByVal id As String) As String
    Dim r As Long
    For r = 1 To UBound(old, 1)
        If CStr(old(r, 1)) = id Then PB_OldLink = CStr(old(r, 2)) & "|" & CStr(old(r, 3)) & "|" & CStr(old(r, 4)) & "|" & CStr(old(r, 5)): Exit Function
    Next r
End Function


Private Function PB_DataArea(ByVal lo As ListObject) As Range
    Dim body As Range, addedRow As ListRow
    If lo Is Nothing Then Err.Raise vbObjectError + 974, "PB_DataArea", "Tabel neinitializat."
    Set body = lo.DataBodyRange
    If body Is Nothing Then
        Set addedRow = lo.ListRows.Add(AlwaysInsert:=False)
        Set body = lo.DataBodyRange
    End If
    If body Is Nothing Then Err.Raise vbObjectError + 975, "PB_DataArea", "Zona de date nu poate fi creata pentru " & lo.name
    Set PB_DataArea = body
End Function

Private Sub PB_CalcSetR1C1(ByVal lo As ListObject, ByVal columnName As String, ByVal template As String)
    Dim target As Range, lc As ListColumn, sourceTable As ListObject
    Dim formulaText As String, token As String, targetAddress As String
    Dim sourceName As Variant, body As Range, errNumber As Long, errMessage As String

    On Error GoTo Fail
    Set body = PB_DataArea(lo)
    Set target = lo.ListColumns(columnName).DataBodyRange
    If target Is Nothing Then Err.Raise vbObjectError + 978, "PB_CalcSetR1C1", "Coloana nu are zona de date: " & columnName
    targetAddress = target.address(False, False)
    formulaText = template

    ' RC plus coloana absoluta pastreaza referinta la randul curent.
    For Each lc In lo.ListColumns
        token = "[@" & lc.name & "]"
        formulaText = Replace(formulaText, token, "RC" & CStr(lc.Range.column), 1, -1, vbBinaryCompare)
    Next lc

    ' Intervalele sursa sunt refacute la fiecare PB_Calc, dupa adaugari de randuri.
    For Each sourceName In Split("tTQMPBBugete|tTQMPBPozitii|tTQMPBComenzi|tTQMPBFacturi|tTQMFPPlati", "|")
        If InStr(1, formulaText, CStr(sourceName) & "[", vbBinaryCompare) > 0 Then
            Set sourceTable = PB_Source(CStr(sourceName))
            For Each lc In sourceTable.ListColumns
                token = sourceTable.name & "[" & lc.name & "]"
                If InStr(1, formulaText, token, vbBinaryCompare) > 0 Then
                    formulaText = Replace(formulaText, token, PB_CalcSourceRefR1C1(lc), 1, -1, vbBinaryCompare)
                End If
            Next lc
        End If
    Next sourceName

    If InStr(1, formulaText, "[@", vbBinaryCompare) > 0 Then
        Err.Raise vbObjectError + 979, "PB_CalcSetR1C1", "Referinta la o coloana inexistenta in formula."
    End If
    target.FormulaR1C1 = formulaText
    Exit Sub

Fail:
    errNumber = Err.number
    errMessage = Err.description
    Debug.Print "PB_Calc: " & lo.name & "." & columnName
    Debug.Print formulaText
    Err.Raise errNumber, "PB_Calc." & lo.name & "." & columnName, _
              errMessage & vbCrLf & "Foaie: " & lo.Parent.name & "; interval: " & targetAddress
End Sub

Private Function PB_CalcSourceRefR1C1(ByVal lc As ListColumn) As String
    Dim sourceRange As Range
    Set sourceRange = lc.DataBodyRange
    If sourceRange Is Nothing Then
        Set sourceRange = lc.Parent.HeaderRowRange.Cells(1, lc.Index).Offset(1, 0)
    End If
    PB_CalcSourceRefR1C1 = "'" & Replace(sourceRange.Parent.name, "'", "''") & "'!" & _
                          sourceRange.address(RowAbsolute:=True, ColumnAbsolute:=True, ReferenceStyle:=xlR1C1, External:=False)
End Function
Private Sub PB_PrepareHeader(ByVal ws As Worksheet)
    Dim sourceCell As Range, mergedArea As Range, copyRange As Range
    Dim backup As Worksheet, candidate As Worksheet, previousSheet As Object
    Dim lastColumn As Long, dirty As Boolean, found As Boolean, suffix As Long
    Dim baseName As String, backupName As String, errorNumber As Long, errorMessage As String
    On Error GoTo Fail
    Set previousSheet = ActiveSheet
    If ws.name <> PB_SHEET Then Err.Raise vbObjectError + 1104, "PB_PrepareHeader", "Foaie de interfata nepermisa."
    lastColumn = 24
    For Each sourceCell In ws.Cells(2, 1).Resize(10, lastColumn).Cells
        If sourceCell.MergeCells Then
            Set mergedArea = sourceCell.MergeArea
            If mergedArea.row < 2 Or mergedArea.row + mergedArea.rows.count - 1 > 11 Then
                Err.Raise vbObjectError + 1105, "PB_PrepareHeader", "Imbinarea " & mergedArea.address(False, False) & " depaseste zona de interfata."
            End If
            If mergedArea.column + mergedArea.Columns.count - 1 > lastColumn Then lastColumn = mergedArea.column + mergedArea.Columns.count - 1
        End If
    Next sourceCell
    Set copyRange = ws.Cells(2, 1).Resize(10, lastColumn)
    For Each sourceCell In copyRange.Cells
        Select Case sourceCell.address(False, False)
        Case "A2", "A3", "A4", "A8", "C8", "E8", "G8", "A9", "C9", "E9", "G9", "A11"
            ' Celule de titlu, status si indicatori rescrise de modul.
        Case Else
            If IsError(sourceCell.Value2) Then
                dirty = True
            ElseIf Len(CStr(sourceCell.formula)) > 0 Then
                dirty = True
            End If
        End Select
    Next sourceCell
    If Not dirty Then Exit Sub

    ' Pastram o copie a intregii zone inainte de curatarea etichetelor vechi.
    baseName = "PB_UI_" & Format$(Now, "yyyymmdd_hhnnss")
    backupName = baseName
    Do
        found = False
        For Each candidate In ThisWorkbook.Worksheets
            If StrComp(candidate.name, backupName, vbTextCompare) = 0 Then found = True: Exit For
        Next candidate
        If Not found Then Exit Do
        suffix = suffix + 1
        backupName = baseName & "_" & CStr(suffix)
    Loop
    Set backup = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
    backup.name = backupName
    copyRange.Copy Destination:=backup.Range("A2")
    backup.Range("A1").Value2 = "Copie antet " & ws.name & " | " & Format$(Now, "dd.mm.yyyy hh:mm:ss")
    ws.Unprotect
    copyRange.UnMerge
    copyRange.ClearContents
    copyRange.Interior.Color = RGB(255, 255, 255)
    copyRange.Font.Color = RGB(31, 41, 55)
    copyRange.HorizontalAlignment = xlLeft
    copyRange.WrapText = False
    If Not previousSheet Is Nothing Then previousSheet.Activate
    Exit Sub
Fail:
    errorNumber = Err.number: errorMessage = Err.description
    On Error Resume Next
    If Not previousSheet Is Nothing Then previousSheet.Activate
    On Error GoTo 0
    Err.Raise errorNumber, "PB_PrepareHeader", errorMessage
End Sub




Public Sub PB_RFQRefresh()
    Dim eno As Long, msg As String
    If mUpdating Then Err.Raise vbObjectError + 2298, "RFQ", "Bugetele sunt deja in curs de actualizare."
    On Error GoTo Failed
    mUpdating = True: PB_Refresh: mUpdating = False
    Exit Sub
Failed:
    eno = Err.Number: msg = Err.description: mUpdating = False
    Err.Raise eno, "PB_RFQRefresh", msg
End Sub
