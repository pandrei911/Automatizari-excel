Attribute VB_Name = "Module3"
Option Explicit
' TQM Nomenclatoare v1. ID-uri stabile; formulare locale; fara stergere fizica.
Private Const NM_Sheet As String = "06_NOMENCLATOARE"
Private Const NM_MARK As String = "TQM_NM_V1"
Private mForm As Workbook, mPick As Workbook
Private mKind As Long, mID As String, mStamp As String
Private mTarget As Worksheet, mTargetAddress As String, mPickKind As Long, mTargetStamp As String
Private Type NM_GUID
    Data1 As Long
    Data2 As Integer
    Data3 As Integer
    Data4(0 To 7) As Byte
End Type
#If VBA7 Then
Private Declare PtrSafe Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As NM_GUID) As Long
#Else
Private Declare Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As NM_GUID) As Long
#End If

Private Function NM_Heads(ByVal kind As Long) As Variant
    Select Case kind
    Case 1: NM_Heads = Split("Cod_material|Denumire|Categorie|Subcategorie|Specificatie|UM|Producator|Model|Stare|Observatii|ID_material|Revizie|Creat_la|Actualizat_la|Actualizat_de|Sursa", "|")
    Case 2: NM_Heads = Split("ID_partener|Cod_partener|Denumire|CIF|Tip|Contact|Email|Telefon|IBAN|Banca|Termen_plata_zile|Adresa|Stare|Observatii|Revizie|Actualizat_la|Actualizat_de", "|")
    Case 3: NM_Heads = Split("ID_proiect|Cod_proiect|Denumire|Client|Adresa|Manager|Responsabil|Stare|Observatii|Revizie|Actualizat_la|Actualizat_de", "|")
    Case 4: NM_Heads = Split("ID_locatie|Cod_locatie|Denumire|Tip|ID_proiect|Adresa|Responsabil|Stare|Observatii|Revizie|Actualizat_la|Actualizat_de", "|")
    Case 5: NM_Heads = Split("ID_atribut|ID_material|Atribut|Valoare|UM|Sursa", "|")
    Case 6: NM_Heads = Split("ID_eveniment|Data|Utilizator|Tip_entitate|ID_entitate|Actiune|Revizie|Camp|Valoare_veche|Valoare_noua", "|")
    End Select
End Function

Private Function NM_GetSheet(ByVal labelName As String) As Worksheet
    On Error Resume Next
    Set NM_GetSheet = ThisWorkbook.Worksheets(labelName)
    On Error GoTo 0
End Function

Private Function NM_Names() As Variant
    NM_Names = Array(NM_Sheet, "_TQM_NM_PART", "_TQM_NM_PROJ", "_TQM_NM_LOC", "_TQM_NM_ATR", "_TQM_NM_LOG")
End Function

Private Function NM_Tables() As Variant
    NM_Tables = Array("tTQMNMMateriale", "tTQMNMParteneri", "tTQMNMProiecte", "tTQMNMLocatii", "tTQMNMAtribute", "tTQMNMJurnal")
End Function

Private Function NM_Table(ByVal kind As Long) As ListObject
    Dim names As Variant, tables As Variant
    names = NM_Names(): tables = NM_Tables()
    Set NM_Table = ThisWorkbook.Worksheets(CStr(names(kind - 1))).ListObjects(CStr(tables(kind - 1)))
End Function

Private Function NM_Source(ByVal labelName As String) As ListObject
    Dim ws As Worksheet, lo As ListObject
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            If lo.name = labelName Then Set NM_Source = lo: Exit Function
        Next lo
    Next ws
End Function

Private Sub NM_Init()
    Dim names As Variant, tables As Variant, hs As Variant, ws As Worksheet, lo As ListObject
    Dim i As Long, c As Long, first As Long
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 701, , "Fisierul este deschis doar pentru citire."
    names = NM_Names(): tables = NM_Tables()
    For i = 0 To 5
        Set ws = NM_GetSheet(CStr(names(i)))
        If ws Is Nothing Then
            Set ws = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
            ws.name = names(i)
            If i = 0 Then ws.Range("R1").Value2 = NM_MARK
        ElseIf i = 0 Then
            If CStr(ws.Range("R1").Value2) <> NM_MARK Then Err.Raise vbObjectError + 702, , "Nomenclatoare are alta structura. Datele nu au fost modificate."
        End If
        ws.Unprotect
        Set lo = Nothing
        On Error Resume Next
        Set lo = ws.ListObjects(CStr(tables(i)))
        On Error GoTo 0
        hs = NM_Heads(i + 1): first = 1: If i = 0 Then first = 12
        If lo Is Nothing Then
            If Application.CountA(ws.Cells(first, 1).Resize(2, UBound(hs) + 1)) > 0 Then Err.Raise vbObjectError + 703, , "Date necunoscute in " & ws.name
            For c = 0 To UBound(hs): ws.Cells(first, c + 1).Value2 = hs(c): Next c
            Set lo = ws.ListObjects.Add(xlSrcRange, ws.Cells(first, 1).Resize(2, UBound(hs) + 1), , xlYes)
            lo.name = tables(i): lo.TableStyle = "TableStyleMedium2"
        End If
        If lo.ListColumns.count <> UBound(hs) + 1 Then Err.Raise vbObjectError + 704, , "Structura invalida: " & lo.name
        For c = 0 To UBound(hs)
            If lo.ListColumns(c + 1).name <> hs(c) Then Err.Raise vbObjectError + 705, , "Coloana schimbata: " & CStr(hs(c))
        Next c
        ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
        If i > 0 Then ws.Visible = xlSheetVeryHidden
    Next i
End Sub

Private Function NM_IDCol(ByVal kind As Long) As Long
    NM_IDCol = 1: If kind = 1 Then NM_IDCol = 11
End Function

Private Function NM_Find(ByVal kind As Long, ByVal id As String) As Range
    Dim lr As ListRow, col As Long
    col = NM_IDCol(kind)
    For Each lr In NM_Table(kind).ListRows
        If Len(id) > 0 And StrComp(CStr(lr.Range.Cells(1, col).Value2), id, vbTextCompare) = 0 Then
            If Not NM_Find Is Nothing Then Err.Raise vbObjectError + 809, , "Identificator duplicat in nomenclator."
            Set NM_Find = lr.Range
        End If
    Next lr
End Function

Private Function NM_Text(ByVal v As Variant) As String
    If IsError(v) Then Err.Raise vbObjectError + 706, , "Celula contine o eroare."
    NM_Text = Trim$(Replace(Replace(CStr(v), vbCr, " "), vbLf, " "))
    If Len(NM_Text) > 3000 Then Err.Raise vbObjectError + 707, , "Campul depaseste 3000 de caractere."
End Function

Private Function NM_Norm(ByVal s As String) As String
    Dim a As Variant, b As Variant, i As Long
    s = UCase$(Trim$(Replace(s, ChrW(160), " ")))
    a = Array(258, 194, 206, 536, 350, 538, 354): b = Array("A", "A", "I", "S", "S", "T", "T")
    For i = 0 To UBound(a): s = Replace(s, ChrW(a(i)), b(i)): Next i
    Do While InStr(s, "  ") > 0: s = Replace(s, "  ", " "): Loop
    NM_Norm = s
End Function

Private Function NM_CIF(ByVal s As String) As String
    s = Replace(Replace(NM_Norm(s), " ", ""), "-", "")
    If Left$(s, 2) = "RO" Then s = VBA.mID$(s, 3)
    NM_CIF = s
End Function

Private Function NM_NewID(ByVal prefix As String) As String
    Dim g As NM_GUID, s As String, i As Long
    If CoCreateGuid(g) <> 0 Then Err.Raise vbObjectError + 708, , "Nu s-a putut genera ID-ul."
    s = Right$("00000000" & Hex$(g.Data1), 8) & "-" & Right$("0000" & Hex$(g.Data2), 4) & "-" & Right$("0000" & Hex$(g.Data3), 4) & "-"
    For i = 0 To 7
        If i = 2 Then s = s & "-"
        s = s & Right$("00" & Hex$(g.Data4(i)), 2)
    Next i
    NM_NewID = prefix & "-" & s
End Function

Private Function NM_Add(ByVal kind As Long) As Range
    Dim lo As ListObject, lr As ListRow
    Set lo = NM_Table(kind): lo.Parent.Unprotect
    For Each lr In lo.ListRows
        If Application.CountA(lr.Range) = 0 Then Set NM_Add = lr.Range: Exit For
    Next lr
    If NM_Add Is Nothing Then Set NM_Add = lo.ListRows.Add.Range
    lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
End Function

Private Sub NM_Write(ByVal r As Range, ByVal v As Variant)
    Dim c As Long
    If UBound(v) = 16 Then
        r.Cells(1, 11).NumberFormat = "@": r.Cells(1, 11).Value2 = v(11)
    End If
    For c = 1 To UBound(v)
        If VarType(v(c)) = vbString Then r.Cells(1, c).NumberFormat = "@"
        r.Cells(1, c).Value2 = v(c)
    Next c
End Sub

Private Function NM_RowValues(ByVal r As Range) As Variant
    Dim v() As Variant, c As Long
    ReDim v(1 To r.Columns.count)
    For c = 1 To r.Columns.count: v(c) = r.Cells(1, c).Value2: Next c
    NM_RowValues = v
End Function

Private Sub NM_Delete(ByVal kind As Long, ByVal col As Long, ByVal value As String)
    Dim lo As ListObject, i As Long
    Set lo = NM_Table(kind): lo.Parent.Unprotect
    For i = lo.ListRows.count To 1 Step -1
        If StrComp(CStr(lo.ListRows(i).Range.Cells(1, col).Value2), value, vbTextCompare) = 0 Then lo.ListRows(i).Delete
    Next i
    lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
End Sub

Private Function NM_Snapshot() As String
    Dim k As Long, lr As ListRow, c As Long, v As String, s As String
    For k = 1 To 5
        For Each lr In NM_Table(k).ListRows
            For c = 1 To lr.Range.Columns.count
                v = CStr(lr.Range.Cells(1, c).Value2): s = s & Len(v) & ":" & v
            Next c
        Next lr
    Next k
    NM_Snapshot = s
End Function

Private Sub NM_Conflict()
    If NM_Snapshot() <> mStamp Then Err.Raise vbObjectError + 709, , "Nomenclatoarele s-au modificat. Inchideti si redeschideti formularul; modificarile nu au fost suprascrise."
End Sub

Public Function NM_Stamp() As String
    Call NM_Init:     NM_Stamp = NM_Snapshot()
End Function

Private Sub NM_Band(ByVal ws As Worksheet, ByVal address As String, ByVal title As String, Optional ByVal size As Long = 10)
    With ws.Range(address)
        .Merge: .Cells(1, 1).Value2 = title: .Font.size = size: .Font.Bold = (size > 10)
        .Font.Color = RGB(31, 41, 55): .VerticalAlignment = xlCenter
    End With
End Sub

Private Sub NM_Button(ByVal ws As Worksheet, ByVal address As String, ByVal title As String, ByVal macro As String)
    Dim r As Range, sh As Shape
    Set r = ws.Range(address): Set sh = ws.Shapes.AddShape(msoShapeRoundedRectangle, r.Left + 2, r.Top + 2, r.width - 4, r.Height - 4)
    sh.name = "NMBTN_" & macro: sh.Fill.ForeColor.RGB = RGB(37, 99, 235): sh.line.Visible = msoFalse
    sh.TextFrame2.TextRange.text = title: sh.TextFrame2.TextRange.Font.size = 10
    sh.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = vbWhite: sh.TextFrame2.TextRange.Font.Bold = msoTrue
    sh.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter: sh.TextFrame2.VerticalAnchor = msoAnchorMiddle
    sh.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & macro
End Sub

Private Sub NM_Input(ByVal ws As Worksheet, ByVal address As String, Optional ByVal v As Variant)
    NM_Band ws, address, ""
    ws.Range(address).Locked = False: ws.Range(address).Interior.Color = RGB(239, 246, 255)
    ws.Range(address).NumberFormat = "@"
    If Not IsMissing(v) Then ws.Range(address).Cells(1, 1).Value2 = v
End Sub

Private Sub NM_List(ByVal rg As Range, ByVal values As String)
    rg.Validation.Delete
    rg.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:=Replace(values, ",", Application.International(xlListSeparator))
    rg.Validation.ShowError = True
End Sub

Private Sub NM_Layout()
    Dim ws As Worksheet, sh As Shape, specs As Variant, v As Variant, widths As Variant, i As Long
    Set ws = ThisWorkbook.Worksheets(NM_Sheet): ws.Unprotect
    ws.Range("A1:P70").Font.name = "Aptos": ws.Range("A1:P70").Font.size = 10: ws.rows("1:70").RowHeight = 24
    NM_Band ws, "A2:J2", "TQM Calarasi - Nomenclatoare", 18: ws.rows(2).RowHeight = 34
    NM_Band ws, "A3:J3", "Materiale, atribute tehnice, parteneri, proiecte si locatii."
    NM_Band ws, "A4:J4", "Materialele importate se verifica si se activeaza din formular. Salvati cu Ctrl+S."
    ws.Range("A3:A4").Font.Color = RGB(100, 116, 139)
    For i = ws.Shapes.count To 1 Step -1
        If Left$(ws.Shapes(i).name, 6) = "NMBTN_" Then ws.Shapes(i).Delete
    Next i
    ws.Range("A5:J6").ClearContents
    specs = Array(Array("A5:B5", "Material nou", "NM_MaterialNou"), Array("C5:D5", "Editeaza material", "NM_EditeazaMaterial"), Array("E5:F5", "Varianta noua", "NM_Varianta"), Array("G5:H5", "Parteneri", "NM_Parteneri"), Array("I5:J5", "Proiecte", "NM_Proiecte"), _
                  Array("A6:B6", "Locatii", "NM_Locatii"), Array("C6:D6", "Preia din Stoc", "NM_ImportStoc"), Array("E6:F6", "Jurnal modificari", "NM_Jurnal"), Array("G6:H6", "Actualizeaza", "NM_Actualizeaza"), Array("I6:J6", "Preia catalog", "NM_ImportCatalog"))
    For Each v In specs: NM_Button ws, CStr(v(0)), CStr(v(1)), CStr(v(2)): Next v
    NM_Band ws, "A8:B8", "Materiale active": NM_Band ws, "A9:B9", "", 18
    NM_Band ws, "C8:E8", "Materiale de verificat": NM_Band ws, "C9:E9", "", 18
    NM_Band ws, "F8:G8", "Parteneri activi": NM_Band ws, "F9:G9", "", 18
    NM_Band ws, "H8:J8", "Locatii active": NM_Band ws, "H9:J9", "", 18
    ws.Range("A8:J9").Interior.Color = RGB(239, 246, 255): ws.rows(9).RowHeight = 34
    ws.Range("C8:E9").Interior.Color = RGB(255, 247, 237)
    NM_Band ws, "A11:J11", "Selectati un material pentru editare. Dezactivarea pastreaza istoricul. Atributele sunt in formular."
    ws.Range("A11").Font.Color = RGB(100, 116, 139)
    widths = Array(19, 34, 28, 24, 52, 9, 24, 20, 18, 32, 43, 10, 22, 22, 24, 65)
    For i = 0 To UBound(widths): ws.Columns(i + 1).ColumnWidth = widths(i): Next i
    With NM_Table(1).HeaderRowRange
        .Interior.Color = RGB(31, 41, 55): .Font.Color = vbWhite: .Font.Bold = True: .WrapText = True: .RowHeight = 40
    End With
    NM_Table(1).ListColumns("Specificatie").DataBodyRange.WrapText = True
    NM_Table(1).ListColumns("Creat_la").DataBodyRange.NumberFormat = "dd.mm.yyyy hh:mm"
    NM_Table(1).ListColumns("Actualizat_la").DataBodyRange.NumberFormat = "dd.mm.yyyy hh:mm"
    ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
End Sub

Private Sub NM_Calc()
    Dim ws As Worksheet
    Set ws = ThisWorkbook.Worksheets(NM_Sheet)
    ws.Range("A9").formula = "=COUNTIFS(tTQMNMMateriale[Stare],""Activ"",tTQMNMMateriale[ID_material],""<>"")"
    ws.Range("C9").formula = "=COUNTIFS(tTQMNMMateriale[Stare],""De verificat"",tTQMNMMateriale[ID_material],""<>"")"
    ws.Range("F9").formula = "=COUNTIFS(tTQMNMParteneri[Stare],""Activ"",tTQMNMParteneri[ID_partener],""<>"")"
    ws.Range("H9").formula = "=COUNTIFS(tTQMNMLocatii[Stare],""Activ"",tTQMNMLocatii[ID_locatie],""<>"")"
    ws.Calculate
    NM_DOCSync
    NM_PBSync
End Sub

Public Sub NM_Instaleaza()
    On Error GoTo Fail
    Call NM_Init:     NM_Check: NM_Layout: NM_Calc
    ThisWorkbook.Worksheets(NM_Sheet).Activate
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 85
    ActiveWindow.FreezePanes = False: ActiveWindow.SplitRow = 12: ActiveWindow.SplitColumn = 2: ActiveWindow.FreezePanes = True
    MsgBox "Nomenclatoare instalat. Daca aveti deja stoc, folositi Preia din Stoc inaintea primei operatiuni noi.", vbInformation, "TQM"
    Exit Sub
Fail: NM_Error Err.description
End Sub

Public Sub NM_Actualizeaza()
    On Error GoTo Fail
    Call NM_Init:     NM_Check: NM_Calc
    Exit Sub
Fail: NM_Error Err.description
End Sub

Private Function NM_IsOpen(ByVal w As Workbook) As Boolean
    Dim x As Workbook
    If w Is Nothing Then Exit Function
    For Each x In Workbooks
        If x Is w Then NM_IsOpen = True: Exit Function
    Next x
End Function

Private Function NM_Start() As Boolean
    Dim ws As Worksheet
    If NM_IsOpen(mForm) Then
        If mKind > 0 Then
            If MsgBox("Inchideti formularul de nomenclatoare si renuntati la modificarile nesalvate?", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Function
        End If
        mForm.Close SaveChanges:=False
    End If
    Set mForm = Workbooks.Add(xlWBATWorksheet): Set ws = mForm.Worksheets(1): ws.name = "Formular_Nomenclatoare"
    ws.Range("A1:I80").Font.name = "Aptos": ws.Range("A1:I80").Font.size = 10
    ws.Range("A1:I80").NumberFormat = "@": ws.rows("1:80").RowHeight = 24
    ws.Columns("A").ColumnWidth = 24: ws.Columns("B").ColumnWidth = 30: ws.Columns("C:I").ColumnWidth = 13
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 85
    mStamp = NM_Snapshot(): NM_Start = True
End Function

Public Sub NM_InchideFormular()
    If NM_IsOpen(mForm) Then
        If mKind > 0 Then
            If MsgBox("Inchideti fara a salva modificarile?", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
        End If
        mForm.Close SaveChanges:=False
    End If
    Set mForm = Nothing: mID = "": mKind = 0
    ThisWorkbook.Worksheets(NM_Sheet).Activate
End Sub

Private Function NM_Selected(ByVal kind As Long) As String
    Dim lo As ListObject, hit As Range, row As Long
    If kind = 1 And ActiveWorkbook Is ThisWorkbook Then
        Set lo = NM_Table(1)
        If ActiveSheet.name <> NM_Sheet Then Err.Raise vbObjectError + 710, , "Selectati materialul in Nomenclatoare."
        Set hit = Intersect(ActiveCell, lo.DataBodyRange)
        If hit Is Nothing Then Err.Raise vbObjectError + 711, , "Selectati un rand din catalog."
        NM_Selected = CStr(lo.ListRows(hit.row - lo.HeaderRowRange.row).Range.Cells(1, 11).Value2)
    ElseIf NM_IsOpen(mForm) Then
        If Not ActiveWorkbook Is mForm Or mKind <> -kind Then Err.Raise vbObjectError + 712, , "Selectati inregistrarea in lista locala."
        row = ActiveCell.row
        If row < 6 Then Err.Raise vbObjectError + 713, , "Selectati o inregistrare din lista."
        NM_Selected = CStr(mForm.Worksheets(1).Cells(row, 1).Value2)
    Else
        Err.Raise vbObjectError + 714, , "Deschideti lista si selectati inregistrarea."
    End If
    If Len(NM_Selected) = 0 Then Err.Raise vbObjectError + 715, , "Randul selectat este gol."
End Function

Public Sub NM_MaterialNou()
    NM_Edit 1, "", False
End Sub
Public Sub NM_EditeazaMaterial()
    On Error GoTo Fail
    Call NM_Init:     NM_Edit 1, NM_Selected(1), False
    Exit Sub
Fail: NM_Error Err.description
End Sub
Public Sub NM_Varianta()
    On Error GoTo Fail
    Call NM_Init:     NM_Edit 1, NM_Selected(1), True
    Exit Sub
Fail: NM_Error Err.description
End Sub
Public Sub NM_Parteneri()
    NM_View 2
End Sub
Public Sub NM_Proiecte()
    NM_View 3
End Sub
Public Sub NM_Locatii()
    NM_View 4
End Sub
Public Sub NM_NouDinLista()
    If mKind >= -4 And mKind <= -2 Then NM_Edit -mKind, "", False
End Sub
Public Sub NM_EditeazaDinLista()
    Dim kind As Long, id As String
    On Error GoTo Fail
    kind = -mKind
    If kind < 2 Or kind > 4 Then Err.Raise vbObjectError + 716, , "Deschideti lista de parteneri, proiecte sau locatii."
    id = NM_Selected(kind): NM_Edit kind, id, False
    Exit Sub
Fail: NM_Error Err.description
End Sub

Private Sub NM_View(ByVal kind As Long)
    Dim ws As Worksheet, lr As ListRow, hs As Variant, c As Long, n As Long
    On Error GoTo Fail
    Call NM_Init:     NM_Check
    If Not NM_Start() Then Exit Sub
    mKind = -kind: mID = "": Set ws = mForm.Worksheets(1)
    NM_Band ws, "A1:I1", Choose(kind, "Materiale", "Parteneri", "Proiecte", "Locatii"), 16
    NM_Button ws, "A3:C3", "Adauga", "NM_NouDinLista": NM_Button ws, "D3:F3", "Editeaza / dezactiveaza", "NM_EditeazaDinLista": NM_Button ws, "G3:I3", "Inchide lista", "NM_InchideFormular"
    hs = NM_Heads(kind)
    For c = 0 To UBound(hs): ws.Cells(5, c + 1).Value2 = hs(c): ws.Columns(c + 1).ColumnWidth = 22: Next c
    ws.Columns(1).ColumnWidth = 43: ws.Columns(3).ColumnWidth = 32: n = 6
    For Each lr In NM_Table(kind).ListRows
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then ws.Cells(n, 1).Resize(1, lr.Range.Columns.count).Value2 = lr.Range.Value2: n = n + 1
    Next lr
    NM_ReportStyle ws, 5, n - 1, UBound(hs) + 1
    ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Exit Sub
Fail: NM_Error Err.description
End Sub

Private Sub NM_ReportStyle(ByVal ws As Worksheet, ByVal header As Long, ByVal last As Long, ByVal count As Long)
    With ws.Cells(header, 1).Resize(1, count)
        .Interior.Color = RGB(31, 41, 55): .Font.Color = vbWhite: .Font.Bold = True: .WrapText = True: .RowHeight = 40
    End With
    ws.Cells(header, 1).Resize(Application.Max(1, last - header + 1), count).AutoFilter
    ActiveWindow.FreezePanes = False: ActiveWindow.SplitRow = header: ActiveWindow.SplitColumn = 1: ActiveWindow.FreezePanes = True
End Sub

Private Sub NM_Edit(ByVal kind As Long, ByVal id As String, ByVal clone As Boolean)
    Dim ws As Worksheet, row As Range, fields As Variant, maps As Variant, i As Long, v As Variant, lr As ListRow, n As Long, proj As Range
    On Error GoTo Fail
    Call NM_Init:     NM_Check
    If Len(id) > 0 Then
        Set row = NM_Find(kind, id)
        If row Is Nothing Then Err.Raise vbObjectError + 717, , "Inregistrarea nu mai exista."
    End If
    If Not NM_Start() Then Exit Sub
    mKind = kind: mID = id: If clone Then mID = ""
    Set ws = mForm.Worksheets(1)
    NM_Band ws, "A1:I1", "TQM - " & Choose(kind, "Material", "Partener", "Proiect", "Locatie") & " (formular local)", 16
    NM_Button ws, "A3:C3", "Salveaza", "NM_Salveaza": NM_Button ws, "D3:F3", "Inchide formularul", "NM_InchideFormular"
    Select Case kind
    Case 1
        fields = Split("Cod material|Denumire|Categorie|Subcategorie|Specificatie|UM|Producator|Model|Stare|Observatii", "|")
        maps = Array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    Case 2
        fields = Split("Cod partener|Denumire|CIF|Tip partener|Persoana contact|Email|Telefon|IBAN|Banca|Termen plata (zile)|Adresa|Stare|Observatii", "|")
        maps = Array(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)
    Case 3
        fields = Split("Cod proiect|Denumire|Client|Adresa|Manager|Responsabil|Stare|Observatii", "|")
        maps = Array(2, 3, 4, 5, 6, 7, 8, 9)
    Case 4
        fields = Split("Cod locatie|Denumire|Tip locatie|Proiect asociat|Adresa|Responsabil|Stare|Observatii", "|")
        maps = Array(2, 3, 4, 5, 6, 7, 8, 9)
    End Select
    For i = 0 To UBound(fields)
        ws.Cells(5 + i, 1).Value2 = fields(i): v = ""
        If Not row Is Nothing Then v = row.Cells(1, CLng(maps(i))).Value2
        If kind = 4 And i = 3 And Len(CStr(v)) > 0 Then
            Set proj = NM_Find(3, CStr(v))
            If proj Is Nothing Then Err.Raise vbObjectError + 718, , "Proiectul asociat lipseste."
            v = proj.Cells(1, 3).Value2
        End If
        NM_Input ws, "B" & 5 + i & ":I" & 5 + i, v
    Next i
    If row Is Nothing Then
        ws.Range(Choose(kind, "B13", "B16", "B11", "B11")).Value2 = "Activ"
        If kind = 2 Then ws.Range("B8").Value2 = "Furnizor"
        If kind = 4 Then ws.Range("B7").Value2 = "Depozit"
    End If
    NM_List ws.Range(Choose(kind, "B13", "B16", "B11", "B11")), "Activ,Inactiv,De verificat"
    NM_SLList ws.Range(Choose(kind, "B13", "B16", "B11", "B11")), "STARE_NOMENCLATOR"
    If kind = 2 Then
        NM_List ws.Range("B8"), "Furnizor,Producator,Prestator,Alt partener,Client,Mixt"
        NM_SLList ws.Range("B8"), "TIP_PARTENER_NM"
        ws.Range("B14").NumberFormat = "0"
    End If
    If kind = 4 Then
        NM_List ws.Range("B7"), "Depozit,Santier,Alta locatie"
        NM_SLList ws.Range("B7"), "TIP_LOCATIE"
    End If
    If kind = 1 Then
        NM_SLList ws.Range("B7"), "CATEGORIE": NM_SLList ws.Range("B10"), "UM"
        ws.Range("B9:I9").WrapText = True: ws.rows(9).RowHeight = 44
        NM_Band ws, "A16:I16", "Atribute tehnice: fiecare atribut o singura data. Maximum 50. Specificatia completa este campul de mai sus."
        ws.Range("A18:E18").Value2 = Array("Atribut", "Valoare", "UM", "Sursa", "ID_atribut")
        ws.Range("A19:D68").Locked = False: ws.Range("A19:D68").Interior.Color = RGB(239, 246, 255)
        ws.Columns("A").ColumnWidth = 26: ws.Columns("B").ColumnWidth = 34: ws.Columns("C").ColumnWidth = 12: ws.Columns("D").ColumnWidth = 40
        ws.Range("E19:E68").Font.Color = vbWhite: ws.Range("E18").ClearContents
        n = 19
        For Each lr In NM_Table(5).ListRows
            If Len(id) > 0 And CStr(lr.Range.Cells(1, 2).Value2) = id Then
                If n > 68 Then Err.Raise vbObjectError + 719, , "Materialul are mai mult de 50 de atribute."
                ws.Cells(n, 1).Resize(1, 4).Value2 = lr.Range.Cells(1, 3).Resize(1, 4).Value2
                If Not clone Then ws.Cells(n, 5).Value2 = lr.Range.Cells(1, 1).Value2
                n = n + 1
            End If
        Next lr
        With ws.Range("A18:D18")
            .Interior.Color = RGB(31, 41, 55): .Font.Color = vbWhite: .Font.Bold = True
        End With
        If clone Then ws.Range("B5").ClearContents: ws.Range("B13").Value2 = "De verificat"
    Else
        NM_Band ws, "A20:I21", "Denumirea si codul raman fixe dupa utilizare. Pentru inchidere alegeti Inactiv. Campurile istorice raman neschimbate."
        ws.Range("A20:I21").WrapText = True
    End If
    ws.Protect UserInterfaceOnly:=True: ws.Range("B5").Select
    Exit Sub
Fail: NM_Error Err.description
End Sub

Private Function NM_ByName(ByVal kind As Long, ByVal labelName As String) As Range
    Dim lr As ListRow, col As Long
    col = 3: If kind = 1 Then col = 2
    If Len(Trim$(labelName)) = 0 Then Exit Function
    For Each lr In NM_Table(kind).ListRows
        If Len(CStr(lr.Range.Cells(1, NM_IDCol(kind)).Value2)) > 0 And NM_Norm(CStr(lr.Range.Cells(1, col).Value2)) = NM_Norm(labelName) Then
            If Not NM_ByName Is Nothing Then Err.Raise vbObjectError + 720, , "Denumire ambigua in nomenclator."
            Set NM_ByName = lr.Range
        End If
    Next lr
End Function

Private Function NM_ByCode(ByVal kind As Long, ByVal code As String) As Range
    Dim lr As ListRow, col As Long
    col = 2: If kind = 1 Then col = 1
    If Len(Trim$(code)) = 0 Then Exit Function
    For Each lr In NM_Table(kind).ListRows
        If Len(CStr(lr.Range.Cells(1, NM_IDCol(kind)).Value2)) > 0 And NM_Norm(CStr(lr.Range.Cells(1, col).Value2)) = NM_Norm(code) Then
            If Not NM_ByCode Is Nothing Then Err.Raise vbObjectError + 721, , "Cod duplicat in nomenclator."
            Set NM_ByCode = lr.Range
        End If
    Next lr
End Function

Private Function NM_StateCol(ByVal kind As Long) As Long
    NM_StateCol = Choose(kind, 9, 13, 8, 8)
End Function
Private Function NM_RevCol(ByVal kind As Long) As Long
    NM_RevCol = Choose(kind, 12, 15, 10, 10)
End Function

Private Sub NM_Validate(ByVal kind As Long, ByVal v As Variant, ByVal id As String)
    Dim code As String, labelName As String, state As String, row As Range, lr As ListRow, proj As Range, priorLocation As Range
    code = CStr(v(IIf(kind = 1, 1, 2))): labelName = CStr(v(IIf(kind = 1, 2, 3))): state = CStr(v(NM_StateCol(kind)))
    If Len(code) = 0 Or Len(labelName) = 0 Then Err.Raise vbObjectError + 722, , "Codul si denumirea sunt obligatorii."
    If Len(code) > 80 Then Err.Raise vbObjectError + 723, , "Codul accepta maximum 80 de caractere."
    If state <> "Activ" And state <> "Inactiv" And state <> "De verificat" Then Err.Raise vbObjectError + 724, , "Stare: Activ, Inactiv sau De verificat."
    Set row = NM_ByCode(kind, code)
    If Not row Is Nothing Then
        If CStr(row.Cells(1, NM_IDCol(kind)).Value2) <> id Then Err.Raise vbObjectError + 725, , "Codul exista deja, inclusiv in inregistrarile inactive."
    End If
    If kind > 1 Then
        Set row = NM_ByName(kind, labelName)
        If Not row Is Nothing Then
            If CStr(row.Cells(1, 1).Value2) <> id Then Err.Raise vbObjectError + 726, , "Denumirea exista deja. Folositi o denumire distincta."
        End If
    End If
    If kind = 1 And Len(CStr(v(6))) = 0 Then Err.Raise vbObjectError + 727, , "UM este obligatorie. Conversiile intre UM nu sunt automate."
    If kind = 1 Then
        NM_SLMaterialLists v, id
    End If
    If kind = 2 Then
        If v(5) <> "Furnizor" And v(5) <> "Producator" And v(5) <> "Prestator" And v(5) <> "Alt partener" And v(5) <> "Client" And v(5) <> "Mixt" Then Err.Raise vbObjectError + 728, , "Tip partener invalid."
        If Len(CStr(v(11))) > 0 Then
            If Not IsNumeric(v(11)) Then Err.Raise vbObjectError + 729, , "Termenul de plata trebuie sa fie un numar intreg de zile."
            If CDbl(v(11)) < 0 Or CDbl(v(11)) > 3650 Or CDbl(v(11)) <> Fix(CDbl(v(11))) Then Err.Raise vbObjectError + 730, , "Termenul de plata: 0-3650 zile intregi."
        End If
        For Each lr In NM_Table(2).ListRows
            If Len(CStr(v(4))) > 0 And CStr(lr.Range.Cells(1, 1).Value2) <> id And Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then
                If NM_CIF(CStr(v(4))) = NM_CIF(CStr(lr.Range.Cells(1, 4).Value2)) Then Err.Raise vbObjectError + 731, , "CIF-ul exista deja la alt partener."
            End If
        Next lr
    End If
    If kind = 4 Then
        If Len(id) > 0 And state <> "Activ" Then
            Set priorLocation = NM_Find(4, id)
            If Not priorLocation Is Nothing Then
                If CStr(priorLocation.Cells(1, 8).Value2) = "Activ" And NM_Norm(CStr(priorLocation.Cells(1, 3).Value2)) = NM_Norm(CStr(NM_SLParam("STOC_LOCATIE_IMPLICITA", "Depozit"))) Then Err.Raise vbObjectError + 810, , "Schimbati locatia implicita din Setari inainte de dezactivare."
            End If
        End If
        If v(4) <> "Depozit" And v(4) <> "Santier" And v(4) <> "Alta locatie" Then Err.Raise vbObjectError + 732, , "Tip locatie invalid."
        If v(4) = "Santier" And Len(CStr(v(5))) = 0 And state = "Activ" Then Err.Raise vbObjectError + 733, , "Asociati santierul unui proiect."
        If Len(CStr(v(5))) > 0 Then
            Set proj = NM_Find(3, CStr(v(5)))
            If proj Is Nothing Then Err.Raise vbObjectError + 734, , "Proiectul asociat nu exista."
            If state = "Activ" And CStr(proj.Cells(1, 8).Value2) <> "Activ" Then Err.Raise vbObjectError + 735, , "Proiectul asociat nu este activ."
        End If
    End If
End Sub

Private Function NM_Contains(ByVal table As String, ByVal col As Long, ByVal value As String) As Boolean
    Dim lo As ListObject, lr As ListRow
    If Len(value) = 0 Then Exit Function
    Set lo = NM_Source(table)
    If lo Is Nothing Then Exit Function
    For Each lr In lo.ListRows
        If NM_Norm(CStr(lr.Range.Cells(1, col).Value2)) = NM_Norm(value) Then NM_Contains = True: Exit Function
    Next lr
End Function

Private Function NM_Used(ByVal kind As Long, ByVal id As String, ByVal old As Variant) As Boolean
    Dim labelName As String, ctl As Worksheet, n As Long
    If NM_DocumentUsed(kind, id) Then NM_Used = True: Exit Function
    If kind = 1 Then
        NM_Used = NM_Contains("tTQMSTMateriale", 1, id) Or NM_Contains("tTQMSTMiscari", 5, id) Or NM_Contains("tTQMCFPoz", 3, CStr(old(1))) Or NM_MaterialReferenced(old)
    ElseIf kind = 4 Then
        NM_Used = NM_Contains("tTQMSTLocatii", 1, id) Or NM_Contains("tTQMSTMiscari", 6, id) Or (NM_Norm(CStr(old(3))) = NM_Norm(CStr(NM_SLParam("STOC_LOCATIE_IMPLICITA", "Depozit"))))
    Else
        labelName = CStr(old(3))
        If kind = 2 Then
            NM_Used = NM_Contains("tTQMComenzi", 4, labelName) Or NM_Contains("tTQMFacturi", 3, labelName) Or NM_Contains("tTQMSTMiscari", 20, labelName) Or NM_Contains("tTQMOferte", 3, labelName) Or NM_Contains("tTQMRFQInvitati", 3, labelName) Or NM_Contains("tTQMRFQOferte", 3, labelName)
        Else
            NM_Used = NM_Contains("tTQMCFPoz", 16, labelName) Or NM_Contains("tTQMFPRepartizari", 3, labelName) Or NM_Contains("tTQMSTMiscari", 19, labelName) Or NM_Contains("tTQMNMLocatii", 5, id) Or NM_Contains("tTQMCereri", 3, labelName) Or NM_Contains("tTQMPBBugete", 2, id) Or NM_Contains("tTQMRFQ", 4, labelName)
        End If
        Set ctl = NM_GetSheet("Control_Achizitii")
        If Not ctl Is Nothing Then
            For n = 13 To TQM_Control_LastRow(ctl)
                If NM_Norm(CStr(TQM_Control_Cell(ctl, n, IIf(kind = 2, 7, 6)).Value2)) = NM_Norm(labelName) Then NM_Used = True
            Next n
        End If
    End If
End Function

Private Function NM_MaterialReferenced(ByVal old As Variant) As Boolean
    Dim names As Variant, cols As Variant, k As Long, lo As ListObject, lr As ListRow
    names = Array("tTQMCFPoz", "tTQMCereri"): cols = Array(Array(4, 5, 6), Array(4, 13, 5))
    For k = 0 To 1
        Set lo = NM_Source(CStr(names(k)))
        If Not lo Is Nothing Then
            For Each lr In lo.ListRows
                If NM_Norm(CStr(lr.Range.Cells(1, CLng(cols(k)(0))).Value2)) = NM_Norm(CStr(old(2))) And NM_Norm(CStr(lr.Range.Cells(1, CLng(cols(k)(1))).Value2)) = NM_Norm(CStr(old(5))) And NM_Norm(CStr(lr.Range.Cells(1, CLng(cols(k)(2))).Value2)) = NM_Norm(CStr(old(6))) Then NM_MaterialReferenced = True: Exit Function
            Next lr
        End If
    Next k
End Function

Private Function NM_Attrs(ByVal id As String) As Collection
    Dim result As New Collection, lr As ListRow
    For Each lr In NM_Table(5).ListRows
        If StrComp(CStr(lr.Range.Cells(1, 2).Value2), id, vbTextCompare) = 0 And Len(id) > 0 Then result.Add NM_RowValues(lr.Range)
    Next lr
    Set NM_Attrs = result
End Function

Private Function NM_AttrKey(ByVal attrs As Collection) As String
    Dim d As Object, v As Variant, keys As Variant, i As Long, j As Long, temp As Variant, s As String
    Set d = CreateObject("Scripting.Dictionary")
    For Each v In attrs: d(NM_Norm(CStr(v(3)))) = NM_Text(v(4)) & ChrW(30) & NM_Text(v(5)): Next v
    If d.count = 0 Then Exit Function
    keys = d.keys
    For i = 0 To UBound(keys)
        For j = i + 1 To UBound(keys)
            If keys(i) > keys(j) Then temp = keys(i): keys(i) = keys(j): keys(j) = temp
        Next j
    Next i
    For i = 0 To UBound(keys): s = s & Len(keys(i)) & ":" & keys(i) & Len(d(keys(i))) & ":" & d(keys(i)): Next i
    NM_AttrKey = s
End Function

Public Sub NM_Salveaza()
    Dim ws As Worksheet, row As Range, old As Variant, v() As Variant, maps As Variant, hs As Variant, c As Long, i As Long
    Dim id As String, kind As Long, rev As Long, n As Long, attrs As New Collection, prior As Collection, av(1 To 6) As Variant, item As Variant
    Dim names As Object, aids As Object, attrRow As Range, project As Range, writing As Boolean, oldE As Boolean, eno As Long, msg As String, eventID As String
    On Error GoTo Fail
    If Not NM_IsOpen(mForm) Then Err.Raise vbObjectError + 736, , "Formularul nu mai este deschis."
    If Not ActiveWorkbook Is mForm Or mKind < 1 Or mKind > 4 Then Err.Raise vbObjectError + 737, , "Salvati din formularul de editare."
    Call NM_Init:     NM_Check: NM_Conflict: Set ws = mForm.Worksheets(1): kind = mKind: id = mID
    hs = NM_Heads(kind): ReDim v(1 To UBound(hs) + 1)
    Select Case kind
    Case 1: maps = Array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
    Case 2: maps = Array(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)
    Case 3, 4: maps = Array(2, 3, 4, 5, 6, 7, 8, 9)
    End Select
    For i = 0 To UBound(maps): v(CLng(maps(i))) = NM_Text(ws.Cells(5 + i, 2).Value2): Next i
    If kind = 4 And Len(CStr(v(5))) > 0 Then
        Set project = NM_ByName(3, CStr(v(5)))
        If project Is Nothing Then Err.Raise vbObjectError + 738, , "Proiectul nu este in nomenclator."
        v(5) = CStr(project.Cells(1, 1).Value2)
    End If
    If kind = 2 And Len(CStr(v(11))) > 0 Then
        If Not IsNumeric(v(11)) Then Err.Raise vbObjectError + 739, , "Termen de plata invalid."
        v(11) = CDbl(v(11))
    End If
    If Len(id) = 0 Then
        id = NM_NewID(Choose(kind, "NM", "NP", "NJ", "NL")): rev = 1
        If kind = 1 Then v(13) = CDbl(Now): v(16) = "Introducere manuala"
    Else
        Set row = NM_Find(kind, id)
        If row Is Nothing Then Err.Raise vbObjectError + 740, , "Inregistrarea nu mai exista."
        old = NM_RowValues(row): rev = CLng(old(NM_RevCol(kind))) + 1
        If kind = 1 Then v(13) = old(13): v(16) = old(16)
    End If
    v(NM_IDCol(kind)) = id: v(NM_RevCol(kind)) = rev
    If kind = 1 Then v(14) = CDbl(Now): v(15) = Application.UserName Else v(UBound(v) - 1) = CDbl(Now): v(UBound(v)) = Application.UserName
    v(NM_StateCol(kind)) = NM_CanonicalChoice("STARE_NOMENCLATOR", CStr(v(NM_StateCol(kind))))
    If kind = 2 Then v(5) = NM_CanonicalChoice("TIP_PARTENER_NM", CStr(v(5)))
    If kind = 4 Then v(4) = NM_CanonicalChoice("TIP_LOCATIE", CStr(v(4)))
    NM_Validate kind, v, id
    Set prior = NM_Attrs(id): Set names = CreateObject("Scripting.Dictionary"): Set aids = CreateObject("Scripting.Dictionary")
    If kind = 1 Then
        For n = 19 To 68
            If Application.CountA(ws.Cells(n, 1).Resize(1, 4)) > 0 Then
                av(1) = NM_Text(ws.Cells(n, 5).Value2): av(2) = id
                For c = 3 To 6: av(c) = NM_Text(ws.Cells(n, c - 2).Value2): Next c
                If Len(av(3)) = 0 Or Len(av(4)) = 0 Then Err.Raise vbObjectError + 741, , "Atributul si valoarea sunt obligatorii la randul " & n
                If names.exists(NM_Norm(CStr(av(3)))) Then Err.Raise vbObjectError + 742, , "Atribut duplicat: " & av(3)
                names.Add NM_Norm(CStr(av(3))), True
                If Len(av(1)) = 0 Then
                    av(1) = NM_NewID("AT")
                Else
                    Set attrRow = NM_Find(5, CStr(av(1)))
                    If attrRow Is Nothing Then Err.Raise vbObjectError + 743, , "ID atribut necunoscut."
                    If CStr(attrRow.Cells(1, 2).Value2) <> id Then Err.Raise vbObjectError + 744, , "Atributul apartine altui material."
                End If
                If aids.exists(CStr(av(1))) Then Err.Raise vbObjectError + 745, , "ID atribut duplicat."
                aids.Add CStr(av(1)), True: attrs.Add av
            End If
        Next n
    End If
    If Not row Is Nothing Then
        If NM_Used(kind, id, old) Then
            If kind = 1 Then
                For c = 1 To 8
                    If NM_Norm(CStr(v(c))) <> NM_Norm(CStr(old(c))) Then Err.Raise vbObjectError + 746, , "Material deja utilizat. Creati Varianta noua pentru schimbari de cod, UM sau date tehnice."
                Next c
                If NM_AttrKey(prior) <> NM_AttrKey(attrs) Then Err.Raise vbObjectError + 747, , "Atributele unui material utilizat raman fixe. Creati o varianta noua."
            Else
                If NM_Norm(CStr(v(2))) <> NM_Norm(CStr(old(2))) Or NM_Norm(CStr(v(3))) <> NM_Norm(CStr(old(3))) Then Err.Raise vbObjectError + 748, , "Codul si denumirea sunt deja utilizate si raman fixe."
                If kind = 2 And NM_CIF(CStr(v(4))) <> NM_CIF(CStr(old(4))) And Len(CStr(old(4))) > 0 Then Err.Raise vbObjectError + 749, , "CIF-ul unui partener utilizat ramane fix."
            End If
        End If
    End If
    Call NM_Conflict:     oldE = Application.EnableEvents: writing = True: Application.EnableEvents = False: eventID = NM_NewID("EV")
    If row Is Nothing Then Set row = NM_Add(kind)
    NM_Write row, v
    If kind = 1 Then
        NM_Delete 5, 2, id
        For Each item In attrs: NM_Write NM_Add(5), item: Next item
    End If
    For c = 1 To UBound(v)
        If IsEmpty(old) Then
            NM_Log eventID, kind, id, "Creare", rev, CStr(hs(c - 1)), "", CStr(v(c))
        ElseIf CStr(old(c)) <> CStr(v(c)) Then
            NM_Log eventID, kind, id, "Modificare", rev, CStr(hs(c - 1)), CStr(old(c)), CStr(v(c))
        End If
    Next c
    If kind = 1 Then NM_LogAttrs eventID, id, rev, prior, attrs
    Call NM_Calc:     Application.EnableEvents = oldE: writing = False
    mForm.Close SaveChanges:=False: Set mForm = Nothing: mKind = 0: mID = ""
    ThisWorkbook.Worksheets(NM_Sheet).Activate
    MsgBox "Inregistrarea a fost salvata. Salvati fisierul cu Ctrl+S.", vbInformation, "TQM"
    Exit Sub
Fail:
    eno = Err.number: msg = Err.description
    If writing Then
        On Error Resume Next
        If IsEmpty(old) Then NM_Delete kind, NM_IDCol(kind), id Else NM_Write row, old
        If kind = 1 Then
            NM_Delete 5, 2, id
            For Each item In prior: NM_Write NM_Add(5), item: Next item
        End If
        NM_Delete 6, 1, eventID: NM_Calc: Application.EnableEvents = oldE
        On Error GoTo 0
    End If
    NM_Error msg
End Sub

Private Sub NM_Log(ByVal eventID As String, ByVal kind As Long, ByVal id As String, ByVal action As String, ByVal rev As Long, ByVal field As String, ByVal before As String, ByVal after As String)
    Dim v(1 To 10) As Variant
    v(1) = eventID: v(2) = CDbl(Now): v(3) = Application.UserName: v(4) = Choose(kind, "Material", "Partener", "Proiect", "Locatie")
    v(5) = id: v(6) = action: v(7) = rev: v(8) = field: v(9) = before: v(10) = after
    NM_Write NM_Add(6), v
End Sub

Private Sub NM_LogAttrs(ByVal eventID As String, ByVal id As String, ByVal rev As Long, ByVal before As Collection, ByVal after As Collection)
    Dim b As Object, a As Object, v As Variant, key As Variant, old As String, newValue As String
    Set b = CreateObject("Scripting.Dictionary"): Set a = CreateObject("Scripting.Dictionary")
    For Each v In before: b(NM_Norm(CStr(v(3)))) = CStr(v(4)) & " " & CStr(v(5)) & " [" & CStr(v(6)) & "]": Next v
    For Each v In after: a(NM_Norm(CStr(v(3)))) = CStr(v(4)) & " " & CStr(v(5)) & " [" & CStr(v(6)) & "]": Next v
    For Each key In b.keys
        newValue = "": If a.exists(key) Then newValue = a(key)
        If b(key) <> newValue Then NM_Log eventID, 1, id, "Atribut", rev, CStr(key), CStr(b(key)), newValue
    Next key
    For Each key In a.keys
        If Not b.exists(key) Then NM_Log eventID, 1, id, "Atribut", rev, CStr(key), "", CStr(a(key))
    Next key
End Sub

Private Sub NM_Check()
    Dim k As Long, lr As ListRow, ids As Object, matIDs As Object, codes As Object, names As Object, id As String, code As String, labelName As String, key As String
    For k = 1 To 4
        Set ids = CreateObject("Scripting.Dictionary"): ids.CompareMode = vbTextCompare: Set codes = CreateObject("Scripting.Dictionary"): Set names = CreateObject("Scripting.Dictionary")
        For Each lr In NM_Table(k).ListRows
            id = CStr(lr.Range.Cells(1, NM_IDCol(k)).Value2)
            If Len(id) > 0 Then
                code = NM_Norm(CStr(lr.Range.Cells(1, IIf(k = 1, 1, 2)).Value2)): labelName = NM_Norm(CStr(lr.Range.Cells(1, IIf(k = 1, 2, 3)).Value2))
                If ids.exists(id) Or codes.exists(code) Then Err.Raise vbObjectError + 750, , "ID sau cod duplicat in " & NM_Table(k).name
                If Len(code) = 0 Or Len(labelName) = 0 Then Err.Raise vbObjectError + 751, , "Cod sau denumire lipsa in " & NM_Table(k).name
                ids.Add id, True: codes.Add code, True
                If k > 1 Then
                    If names.exists(labelName) Then Err.Raise vbObjectError + 752, , "Denumire duplicata: " & labelName
                    names.Add labelName, True
                End If
            ElseIf Application.CountA(lr.Range) > 0 Then
                Err.Raise vbObjectError + 753, , "Inregistrare fara ID in " & NM_Table(k).name
            End If
        Next lr
        If k = 1 Then Set matIDs = ids
    Next k
    Set ids = CreateObject("Scripting.Dictionary"): ids.CompareMode = vbTextCompare: Set names = CreateObject("Scripting.Dictionary")
    For Each lr In NM_Table(5).ListRows
        id = CStr(lr.Range.Cells(1, 1).Value2)
        If Len(id) > 0 Then
            If Not matIDs.exists(CStr(lr.Range.Cells(1, 2).Value2)) Then Err.Raise vbObjectError + 754, , "Atribut fara material."
            key = CStr(lr.Range.Cells(1, 2).Value2) & ChrW(30) & NM_Norm(CStr(lr.Range.Cells(1, 3).Value2))
            If ids.exists(id) Or names.exists(key) Then Err.Raise vbObjectError + 755, , "ID sau denumire de atribut duplicata."
            ids.Add id, True: names.Add key, True
        End If
    Next lr
End Sub

Public Function NM_ResolveMaterial(ByVal code As String, ByVal labelName As String, ByVal spec As String, ByVal unit As String, Optional ByVal historical As Boolean = False) As String
    Dim row As Range, lr As ListRow, matches As Long
    NM_Init
    If Len(code) > 0 Then
        Set row = NM_ByCode(1, code)
    Else
        For Each lr In NM_Table(1).ListRows
            If Len(CStr(lr.Range.Cells(1, 11).Value2)) > 0 And NM_Norm(CStr(lr.Range.Cells(1, 2).Value2)) = NM_Norm(labelName) And NM_Norm(CStr(lr.Range.Cells(1, 5).Value2)) = NM_Norm(spec) And NM_Norm(CStr(lr.Range.Cells(1, 6).Value2)) = NM_Norm(unit) Then
                matches = matches + 1: Set row = lr.Range
            End If
        Next lr
        If matches > 1 Then Err.Raise vbObjectError + 756, , "Material ambiguu. Completati codul materialului."
    End If
    If row Is Nothing Then Err.Raise vbObjectError + 757, , "Materialul nu este in Nomenclatoare. Inregistrati-l sau preluati materialele existente din Stoc."
    If NM_Norm(CStr(row.Cells(1, 2).Value2)) <> NM_Norm(labelName) Or NM_Norm(CStr(row.Cells(1, 5).Value2)) <> NM_Norm(spec) Or NM_Norm(CStr(row.Cells(1, 6).Value2)) <> NM_Norm(unit) Then Err.Raise vbObjectError + 758, , "Codul materialului are alta denumire, specificatie sau UM. Folositi selectarea din catalog."
    If Not historical And CStr(row.Cells(1, 9).Value2) <> "Activ" Then Err.Raise vbObjectError + 759, , "Materialul este inactiv sau de verificat."
    NM_ResolveMaterial = CStr(row.Cells(1, 11).Value2)
End Function

Public Function NM_ResolveLocation(ByVal labelName As String) As String
    Dim row As Range
    Call NM_Init:     Set row = NM_ByName(4, labelName)
    If row Is Nothing Then Err.Raise vbObjectError + 760, , "Locatia nu este in Nomenclatoare."
    If CStr(row.Cells(1, 8).Value2) <> "Activ" Then Err.Raise vbObjectError + 761, , "Locatia nu este activa."
    NM_ResolveLocation = CStr(row.Cells(1, 1).Value2)
End Function

Public Sub NM_ValidatePartner(ByVal labelName As String, ByVal cif As String, Optional ByVal historical As Boolean = False)
    Dim row As Range, lr As ListRow
    Call NM_Init:     Set row = NM_ByName(2, labelName)
    If row Is Nothing Then
        If Len(cif) > 0 Then
            For Each lr In NM_Table(2).ListRows
                If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 And NM_CIF(CStr(lr.Range.Cells(1, 4).Value2)) = NM_CIF(cif) Then Err.Raise vbObjectError + 762, , "CIF-ul este inregistrat cu alta denumire. Alegeti partenerul din catalog."
            Next lr
        End If
        Exit Sub
    End If
    If Not historical And CStr(row.Cells(1, 13).Value2) <> "Activ" Then Err.Raise vbObjectError + 763, , "Partenerul este inactiv sau de verificat."
    If Len(cif) > 0 And Len(CStr(row.Cells(1, 4).Value2)) > 0 Then
        If NM_CIF(cif) <> NM_CIF(CStr(row.Cells(1, 4).Value2)) Then Err.Raise vbObjectError + 764, , "CIF-ul difera de nomenclator."
    End If
End Sub

Public Sub NM_ValidateProject(ByVal labelName As String, Optional ByVal historical As Boolean = False)
    Dim row As Range
    Call NM_Init:     Set row = NM_ByName(3, labelName)
    If row Is Nothing Then Exit Sub
    If Not historical And CStr(row.Cells(1, 8).Value2) <> "Activ" Then Err.Raise vbObjectError + 765, , "Proiectul este inactiv sau de verificat."
End Sub

Public Sub NM_ImportStoc()
    Dim mats As ListObject, locs As ListObject, src As ListObject, lr As ListRow, found As Range, byID As Range, v() As Variant, changes As New Collection, added As New Collection
    Dim row As Range, item As Variant, aid As Range, old As Variant, oldID As String, newID As String, k As Long, c As Long, snapshot As String
    Dim oldE As Boolean, writing As Boolean, msg As String, eventID As String, attrs As New Collection, count As Long
    Dim stockStamp As String, seenIDs As Object, seenKeys As Object, key As String
    On Error GoTo Fail
    Call NM_Init:     NM_Check: snapshot = NM_Snapshot(): Set mats = NM_Source("tTQMSTMateriale"): Set locs = NM_Source("tTQMSTLocatii")
    If mats Is Nothing Or locs Is Nothing Then Err.Raise vbObjectError + 766, , "Instalati mai intai Livrari si stoc."
    stockStamp = NM_StockSnapshot()
    ' Validate the complete migration before writing. Existing stock IDs take priority.
    For k = 1 To 2
        If k = 1 Then Set src = mats Else Set src = locs
        Set seenIDs = CreateObject("Scripting.Dictionary"): Set seenKeys = CreateObject("Scripting.Dictionary")
        For Each lr In src.ListRows
            If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then
                newID = CStr(lr.Range.Cells(1, 1).Value2): Set found = Nothing
                If k = 1 Then
                    key = NM_Norm(CStr(lr.Range.Cells(1, 2).Value2))
                    If Len(key) = 0 Then key = "@" & NM_Norm(CStr(lr.Range.Cells(1, 3).Value2)) & ChrW(30) & NM_Norm(CStr(lr.Range.Cells(1, 4).Value2)) & ChrW(30) & NM_Norm(CStr(lr.Range.Cells(1, 5).Value2))
                Else
                    key = NM_Norm(CStr(lr.Range.Cells(1, 2).Value2))
                End If
                If seenIDs.exists(newID) Or seenKeys.exists(key) Then Err.Raise vbObjectError + 789, , "ID, cod sau locatie duplicata in nomenclatoarele Stocului. Importul a fost oprit."
                seenIDs.Add newID, True: seenKeys.Add key, True
                If k = 1 Then
                    Set found = NM_ByCode(1, CStr(lr.Range.Cells(1, 2).Value2)): Set byID = NM_Find(1, newID)
                    If found Is Nothing And Not byID Is Nothing Then Set found = byID
                    If Not found Is Nothing Then
                        If Not byID Is Nothing Then
                            If CStr(found.Cells(1, 11).Value2) <> CStr(byID.Cells(1, 11).Value2) Then Err.Raise vbObjectError + 790, , "ID-ul si codul materialului indica doua inregistrari diferite."
                        End If
                        If Len(CStr(lr.Range.Cells(1, 2).Value2)) > 0 Then
                            If NM_Norm(CStr(found.Cells(1, 1).Value2)) <> NM_Norm(CStr(lr.Range.Cells(1, 2).Value2)) Then Err.Raise vbObjectError + 791, , "Codul materialului difera pentru acelasi ID."
                        End If
                        If NM_Norm(CStr(found.Cells(1, 2).Value2)) <> NM_Norm(CStr(lr.Range.Cells(1, 3).Value2)) Or NM_Norm(CStr(found.Cells(1, 5).Value2)) <> NM_Norm(CStr(lr.Range.Cells(1, 4).Value2)) Or NM_Norm(CStr(found.Cells(1, 6).Value2)) <> NM_Norm(CStr(lr.Range.Cells(1, 5).Value2)) Then Err.Raise vbObjectError + 767, , "Conflict la materialul " & CStr(lr.Range.Cells(1, 2).Value2) & ". Corectati catalogul neutilizat sau creati un cod distinct."
                        oldID = CStr(found.Cells(1, 11).Value2)
                        If oldID <> newID And NM_Contains("tTQMSTMateriale", 1, oldID) Then Err.Raise vbObjectError + 768, , "Doua ID-uri de stoc folosesc acelasi cod. Nu se combina automat."
                    End If
                Else
                    Set found = NM_ByName(4, CStr(lr.Range.Cells(1, 2).Value2)): Set byID = NM_Find(4, newID)
                    If found Is Nothing And Not byID Is Nothing Then Set found = byID
                    If Not found Is Nothing Then
                        If Not byID Is Nothing Then
                            If CStr(found.Cells(1, 1).Value2) <> CStr(byID.Cells(1, 1).Value2) Then Err.Raise vbObjectError + 792, , "ID-ul si denumirea locatiei indica doua inregistrari diferite."
                        End If
                        If NM_Norm(CStr(found.Cells(1, 3).Value2)) <> NM_Norm(CStr(lr.Range.Cells(1, 2).Value2)) Then Err.Raise vbObjectError + 769, , "Conflict de denumire la locatie."
                        oldID = CStr(found.Cells(1, 1).Value2)
                        If oldID <> newID And NM_Contains("tTQMSTLocatii", 1, oldID) Then Err.Raise vbObjectError + 770, , "Doua ID-uri de stoc folosesc aceeasi locatie."
                    End If
                End If
            End If
        Next lr
    Next k
    If NM_Snapshot() <> snapshot Or NM_StockSnapshot() <> stockStamp Then Err.Raise vbObjectError + 771, , "Nomenclatoarele sau datele Stocului s-au schimbat in timpul importului."
    oldE = Application.EnableEvents: Application.EnableEvents = False: writing = True: eventID = NM_NewID("EV")
    For k = 1 To 2
        If k = 1 Then Set src = mats Else Set src = locs
        For Each lr In src.ListRows
            newID = CStr(lr.Range.Cells(1, 1).Value2)
            If Len(newID) > 0 Then
                Set found = Nothing
                If k = 1 Then Set found = NM_ByCode(1, CStr(lr.Range.Cells(1, 2).Value2)) Else Set found = NM_ByName(4, CStr(lr.Range.Cells(1, 2).Value2))
                If found Is Nothing Then Set found = NM_Find(IIf(k = 1, 1, 4), newID)
                If found Is Nothing Then
                    If k = 1 Then
                        ReDim v(1 To 16): v(1) = lr.Range.Cells(1, 2).Value2
                        If Len(CStr(v(1))) = 0 Then v(1) = "ST-" & newID
                        v(2) = lr.Range.Cells(1, 3).Value2: v(3) = "Din stoc": v(5) = lr.Range.Cells(1, 4).Value2: v(6) = lr.Range.Cells(1, 5).Value2
                        v(9) = "Activ": v(11) = newID: v(12) = 1: v(13) = lr.Range.Cells(1, 6).Value2: v(14) = CDbl(Now): v(15) = Application.UserName: v(16) = "tTQMSTMateriale"
                    Else
                        ReDim v(1 To 12): v(1) = newID: v(2) = "ST-" & newID: v(3) = lr.Range.Cells(1, 2).Value2: v(4) = "Alta locatie"
                        v(8) = "Activ": v(10) = 1: v(11) = CDbl(Now): v(12) = Application.UserName
                    End If
                    Set row = NM_Add(IIf(k = 1, 1, 4)): added.Add Array(IIf(k = 1, 1, 4), newID): NM_Write row, v: count = count + 1
                    NM_Log eventID, IIf(k = 1, 1, 4), newID, "Import stoc", 1, "ID", "", newID
                Else
                    oldID = CStr(found.Cells(1, NM_IDCol(IIf(k = 1, 1, 4))).Value2)
                    If oldID <> newID Then
                        changes.Add Array(IIf(k = 1, 1, 4), oldID, newID, NM_RowValues(found))
                        found.Cells(1, NM_IDCol(IIf(k = 1, 1, 4))).Value2 = newID
                        If k = 1 Then
                            For Each aid In NM_Table(5).DataBodyRange.rows
                                If CStr(aid.Cells(1, 2).Value2) = oldID Then attrs.Add Array(CStr(aid.Cells(1, 1).Value2), oldID): aid.Cells(1, 2).Value2 = newID
                            Next aid
                        End If
                        found.Cells(1, NM_RevCol(IIf(k = 1, 1, 4))).Value2 = CLng(found.Cells(1, NM_RevCol(IIf(k = 1, 1, 4))).Value2) + 1
                        NM_Log eventID, IIf(k = 1, 1, 4), newID, "Import stoc", CLng(found.Cells(1, NM_RevCol(IIf(k = 1, 1, 4))).Value2), "ID", oldID, newID
                        count = count + 1
                    End If
                End If
            End If
        Next lr
    Next k
    Call NM_Check:     NM_Calc: Application.EnableEvents = oldE: writing = False
    MsgBox count & " inregistrari preluate sau aliniate. ID-urile miscarilor de stoc au fost pastrate. Salvati cu Ctrl+S.", vbInformation, "TQM"
    Exit Sub
Fail:
    msg = Err.description
    If writing Then
        On Error Resume Next
        For Each item In added: NM_Delete CLng(item(0)), NM_IDCol(CLng(item(0))), CStr(item(1)): Next item
        For Each item In changes
            Set row = NM_Find(CLng(item(0)), CStr(item(2)))
            If Not row Is Nothing Then NM_Write row, item(3)
        Next item
        For Each item In attrs
            Set aid = NM_Find(5, CStr(item(0)))
            If Not aid Is Nothing Then aid.Cells(1, 2).Value2 = item(1)
        Next item
        NM_Delete 6, 1, eventID: NM_Calc: Application.EnableEvents = oldE
        On Error GoTo 0
    End If
    NM_Error msg
End Sub

Public Sub NM_Jurnal()
    Dim ws As Worksheet, hs As Variant, lr As ListRow, n As Long, c As Long
    On Error GoTo Fail
    NM_Init
    If Not NM_Start() Then Exit Sub
    mKind = -6: Set ws = mForm.Worksheets(1): NM_Band ws, "A1:I1", "TQM - Jurnal modificari nomenclatoare", 16
    NM_Button ws, "A3:C3", "Inchide jurnalul", "NM_InchideFormular"
    hs = NM_Heads(6)
    For c = 0 To UBound(hs): ws.Cells(5, c + 1).Value2 = hs(c): ws.Columns(c + 1).ColumnWidth = 24: Next c
    ws.Columns("I:J").ColumnWidth = 48: ws.Columns("A").ColumnWidth = 43: ws.Columns("E").ColumnWidth = 43: n = 6
    For Each lr In NM_Table(6).ListRows
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then ws.Cells(n, 1).Resize(1, 10).Value2 = lr.Range.Value2: n = n + 1
    Next lr
    ws.Range("B6:B" & Application.Max(6, n - 1)).NumberFormat = "dd.mm.yyyy hh:mm"
    NM_ReportStyle ws, 5, n - 1, 10: ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Exit Sub
Fail: NM_Error Err.description
End Sub

Public Sub NM_CautaMaterial()
    Dim term As String, lr As ListRow, lo As ListObject
    On Error GoTo Fail
    Call NM_Init:     term = InputBox("Cod, denumire sau fragment din specificatie:", "TQM - Cauta material")
    If Len(Trim$(term)) = 0 Then Exit Sub
    Set lo = NM_Table(1)
    For Each lr In lo.ListRows
        If InStr(1, NM_Norm(CStr(lr.Range.Cells(1, 1).Value2) & " " & CStr(lr.Range.Cells(1, 2).Value2) & " " & CStr(lr.Range.Cells(1, 5).Value2)), NM_Norm(term), vbTextCompare) > 0 Then
            ThisWorkbook.Worksheets(NM_Sheet).Activate
            If lo.AutoFilter.FilterMode Then lo.AutoFilter.ShowAllData
            lr.Range.Cells(1, 1).Select: Exit Sub
        End If
    Next lr
    MsgBox "Nu am gasit materialul.", vbInformation, "TQM"
    Exit Sub
Fail: NM_Error Err.description
End Sub

Public Sub NM_AlegeMaterial()
    NM_OpenPicker 1
End Sub
Public Sub NM_AlegePartener()
    NM_OpenPicker 2
End Sub
Public Sub NM_AlegeProiect()
    NM_OpenPicker 3
End Sub
Public Sub NM_AlegeLocatie()
    NM_OpenPicker 4
End Sub

Private Function NM_TargetRange(ByVal kind As Long, ByVal ws As Worksheet) As String
    Dim n As Long
    n = ActiveCell.row
    If ws.Parent Is ThisWorkbook Then Err.Raise vbObjectError + 772, , "Deschideti mai intai formularul local al operatiei."
    Select Case ws.name
    Case "Formular_TQM"
        If CStr(ws.Range("A5").Value2) <> "Nr. comanda" Then Err.Raise vbObjectError + 773, , "Selectarea este disponibila in formularul de comanda."
        If kind = 1 Then
            If n < 15 Or n > 114 Then Err.Raise vbObjectError + 774, , "Selectati mai intai randul materialului."
            If Len(CStr(ws.Cells(n, 11).Value2)) > 0 Or Len(CStr(ws.Cells(n, 12).Value2)) > 0 Then Err.Raise vbObjectError + 775, , "Pozitia provine dintr-o oferta aprobata. Datele tehnice raman cele aprobate."
            NM_TargetRange = "B" & n & ":E" & n
        ElseIf kind = 2 Then
            NM_TargetRange = "B6"
        ElseIf kind = 3 Then
            If n >= 15 And n <= 114 Then NM_TargetRange = "J" & n Else NM_TargetRange = "B7"
        End If
    Case "RFQ_Cerere"
        If kind = 1 Then
            If n < 15 Or n > 114 Then Err.Raise vbObjectError + 774, , "Selectati randul materialului."
            NM_TargetRange = "C" & n & ":F" & n
        ElseIf kind = 3 Then
            If n >= 15 And n <= 114 Then NM_TargetRange = "I" & n Else NM_TargetRange = "B7"
        End If
    Case "RFQ_Oferta"
        If kind = 2 Then NM_TargetRange = "B5"
    Case "Formular_Stoc"
        If kind = 1 Then
            If CStr(ws.Range("A8").Value2) <> "Locatie" Then Err.Raise vbObjectError + 776, , "Materialul este fix pentru aceasta miscare."
            NM_TargetRange = "B5:I7"
        ElseIf kind = 4 Then
            If CStr(ws.Range("A9").Value2) = "Locatie destinatie" Then
                NM_TargetRange = "B9"
            ElseIf CStr(ws.Range("G10").Value2) = "Locatie" And n >= 11 And n <= 110 Then
                NM_TargetRange = "G" & n
            ElseIf CStr(ws.Range("A8").Value2) = "Locatie" Then
                NM_TargetRange = "B8"
            End If
        End If
    Case "Formular_Facturi"
        If CStr(ws.Range("A5").Value2) <> "Numar factura" Then Err.Raise vbObjectError + 777, , "Deschideti formularul facturii."
        If kind = 2 Then NM_TargetRange = "B7:B8"
        If kind = 3 And n >= 21 And n <= 120 Then NM_TargetRange = "B" & n
    End Select
    If Len(NM_TargetRange) = 0 Then Err.Raise vbObjectError + 778, , "Selectati randul sau campul potrivit in formularul local."
    If ws.Range(NM_TargetRange).Cells(1, 1).Locked Then Err.Raise vbObjectError + 779, , "Campul este blocat pentru aceasta operatie."
End Function

Private Function NM_TargetSnapshot(ByVal ws As Worksheet, ByVal address As String) As String
    Dim c As Range, s As String, v As String
    For Each c In ws.Range(address).Cells
        v = CStr(c.Value2): s = s & Len(v) & ":" & v & ":" & CStr(c.Locked)
    Next c
    NM_TargetSnapshot = s
End Function

Private Sub NM_OpenPicker(ByVal kind As Long)
    Dim ws As Worksheet, target As Worksheet, address As String, lr As ListRow, n As Long, a(1 To 1, 1 To 7) As Variant
    On Error GoTo Fail
    Call NM_Init:     NM_Check: Set target = ActiveSheet: address = NM_TargetRange(kind, target)
    If NM_IsOpen(mPick) Then mPick.Close SaveChanges:=False
    Set mTarget = target: mTargetAddress = address: mPickKind = kind: mTargetStamp = NM_TargetSnapshot(target, address)
    Set mPick = Workbooks.Add(xlWBATWorksheet): Set ws = mPick.Worksheets(1): ws.name = "Selectie_Nomenclatoare"
    ws.Range("A1:G5000").NumberFormat = "@": ws.Range("A1:G5000").Font.name = "Aptos": ws.Range("A1:G5000").Font.size = 10
    ws.Columns("A").ColumnWidth = 43: ws.Columns("B").ColumnWidth = 20: ws.Columns("C").ColumnWidth = 34: ws.Columns("D").ColumnWidth = 44
    ws.Columns("E").ColumnWidth = 12: ws.Columns("F:G").ColumnWidth = 24: ws.rows("1:5000").RowHeight = 24
    NM_Band ws, "A1:G1", "Selecteaza " & Choose(kind, "materialul", "partenerul", "proiectul", "locatia"), 16
    NM_Button ws, "A3:C3", "Preia in formular", "NM_PreiaSelectia": NM_Button ws, "D3:F3", "Inchide selectia", "NM_InchideSelectia"
    ws.Range("A5:G5").Value2 = Array("ID", "Cod", "Denumire", "Specificatie / detalii", "UM / Tip", "Categorie / CIF", "Stare")
    n = 6
    For Each lr In NM_Table(kind).ListRows
        If Len(CStr(lr.Range.Cells(1, NM_IDCol(kind)).Value2)) > 0 And NM_PickerAllows(kind, target.name, CStr(lr.Range.Cells(1, NM_StateCol(kind)).Value2)) Then
            a(1, 1) = lr.Range.Cells(1, NM_IDCol(kind)).Value2
            If kind = 1 Then
                a(1, 2) = lr.Range.Cells(1, 1).Value2: a(1, 3) = lr.Range.Cells(1, 2).Value2: a(1, 4) = lr.Range.Cells(1, 5).Value2
                a(1, 5) = lr.Range.Cells(1, 6).Value2: a(1, 6) = lr.Range.Cells(1, 3).Value2
            Else
                a(1, 2) = lr.Range.Cells(1, 2).Value2: a(1, 3) = lr.Range.Cells(1, 3).Value2: a(1, 4) = lr.Range.Cells(1, IIf(kind = 2, 12, IIf(kind = 3, 5, 6))).Value2
                a(1, 5) = lr.Range.Cells(1, 4).Value2: a(1, 6) = ""
                If kind = 2 Then a(1, 5) = lr.Range.Cells(1, 5).Value2: a(1, 6) = lr.Range.Cells(1, 4).Value2
            End If
            a(1, 7) = lr.Range.Cells(1, NM_StateCol(kind)).Value2: ws.Cells(n, 1).Resize(1, 7).Value2 = a
            ws.Cells(n, 8).Value2 = lr.Range.Cells(1, NM_RevCol(kind)).Value2: n = n + 1
        End If
    Next lr
    NM_ReportStyle ws, 5, n - 1, 7
    If kind = 1 And target.name = "RFQ_Cerere" Then
        ws.Range("A2:G2").Merge
        ws.Range("A2").Value2 = "Materialele De verificat pot fi folosite in cerere. Pentru aprobare si comanda, verificati-le si treceti-le Activ in Nomenclatoare."
        ws.Range("A2:G2").WrapText = True: ws.rows(2).RowHeight = 36
    End If
    If n = 6 Then
        ws.Range("B6:G8").Merge
        ws.Range("B6").Value2 = "Nu exista inregistrari disponibile pentru aceasta selectie. Adaugati sau verificati inregistrarile in 06_NOMENCLATOARE."
        ws.Range("B6:G8").WrapText = True
    End If
    ws.Columns("H").Hidden = True
    ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 85
    Exit Sub
Fail: NM_Error Err.description
End Sub

Private Function NM_StockSnapshot() As String
    Dim names As Variant, k As Long, lo As ListObject, lr As ListRow, c As Long, v As String, s As String
    names = Array("tTQMSTMateriale", "tTQMSTLocatii")
    For k = 0 To 1
        Set lo = NM_Source(CStr(names(k)))
        If Not lo Is Nothing Then
            For Each lr In lo.ListRows
                For c = 1 To lr.Range.Columns.count
                    v = CStr(lr.Range.Cells(1, c).Value2): s = s & Len(v) & ":" & v
                Next c
            Next lr
        End If
    Next k
    NM_StockSnapshot = s
End Function

Public Sub NM_PreiaSelectia()
    Dim ws As Worksheet, row As Range, id As String, n As Long, prior As New Collection, addresses As Variant, address As Variant, item As Variant, changed As Boolean, msg As String, oldE As Boolean
    On Error GoTo Fail
    If Not NM_IsOpen(mPick) Then Err.Raise vbObjectError + 780, , "Lista de selectie nu mai este deschisa."
    If Not ActiveWorkbook Is mPick Or ActiveCell.row < 6 Then Err.Raise vbObjectError + 781, , "Selectati o inregistrare din lista."
    If mTarget Is Nothing Then Err.Raise vbObjectError + 784, , "Formularul destinatie nu mai exista."
    If Not NM_IsOpen(mTarget.Parent) Then Err.Raise vbObjectError + 785, , "Formularul destinatie a fost inchis."
    Call NM_Init:     Set ws = mPick.Worksheets(1): id = CStr(ws.Cells(ActiveCell.row, 1).Value2)
    If Len(id) = 0 Then Err.Raise vbObjectError + 782, , "Nu este selectata o inregistrare. Consultati mesajul din lista si 06_NOMENCLATOARE."
    Set row = NM_Find(mPickKind, id)
    If row Is Nothing Then Err.Raise vbObjectError + 782, , "Inregistrarea nu mai exista."
    If CStr(row.Cells(1, NM_RevCol(mPickKind)).Value2) <> CStr(ws.Cells(ActiveCell.row, 8).Value2) Then Err.Raise vbObjectError + 787, , "Inregistrarea s-a modificat. Redeschideti selectia."
    If Not NM_PickerAllows(mPickKind, mTarget.name, CStr(row.Cells(1, NM_StateCol(mPickKind)).Value2)) Then Err.Raise vbObjectError + 783, , "Starea inregistrarii nu mai permite selectia pentru acest formular."
    If NM_TargetSnapshot(mTarget, mTargetAddress) <> mTargetStamp Then Err.Raise vbObjectError + 786, , "Campurile destinatie s-au modificat. Deschideti din nou selectia."
    n = mTarget.Range(mTargetAddress).row
    If mPickKind = 1 Then
        If mTarget.name = "RFQ_Cerere" Then
            addresses = Array("C" & n, "D" & n, "E" & n, "F" & n)
        ElseIf mTarget.name = "Formular_TQM" Then
            addresses = Array("B" & n, "C" & n, "D" & n, "E" & n)
        Else
            addresses = Array("B5", "B6", "B7", "G7")
        End If
    ElseIf mPickKind = 2 And mTarget.name = "Formular_Facturi" Then
        addresses = Array("B7", "B8")
    Else
        addresses = Array(mTarget.Range(mTargetAddress).Cells(1, 1).address)
    End If
    For Each address In addresses
        If mTarget.Range(CStr(address)).Locked Then Err.Raise vbObjectError + 788, , "Un camp destinatie este blocat."
        prior.Add Array(CStr(address), mTarget.Range(CStr(address)).Value2)
    Next address
    oldE = Application.EnableEvents: Application.EnableEvents = False: changed = True
    If mPickKind = 1 Then
        If mTarget.name = "RFQ_Cerere" Then
            mTarget.Cells(n, 3).Value2 = row.Cells(1, 1).Value2: mTarget.Cells(n, 4).Value2 = row.Cells(1, 2).Value2
            mTarget.Cells(n, 5).Value2 = row.Cells(1, 5).Value2: mTarget.Cells(n, 6).Value2 = row.Cells(1, 6).Value2
        ElseIf mTarget.name = "Formular_TQM" Then
            mTarget.Cells(n, 2).Value2 = row.Cells(1, 1).Value2: mTarget.Cells(n, 3).Value2 = row.Cells(1, 2).Value2
            mTarget.Cells(n, 4).Value2 = row.Cells(1, 5).Value2: mTarget.Cells(n, 5).Value2 = row.Cells(1, 6).Value2
        Else
            mTarget.Range("B5").Value2 = row.Cells(1, 2).Value2: mTarget.Range("B6").Value2 = row.Cells(1, 5).Value2
            mTarget.Range("B7").Value2 = row.Cells(1, 6).Value2: mTarget.Range("G7").Value2 = row.Cells(1, 1).Value2
        End If
    ElseIf mPickKind = 2 Then
        mTarget.Range(mTargetAddress).Cells(1, 1).Value2 = row.Cells(1, 3).Value2
        If mTarget.name = "Formular_Facturi" Then mTarget.Range("B8").Value2 = row.Cells(1, 4).Value2
    Else
        mTarget.Range(mTargetAddress).Cells(1, 1).Value2 = row.Cells(1, 3).Value2
    End If
    Application.EnableEvents = oldE: changed = False
    mTarget.Activate: mTarget.Range(mTargetAddress).Cells(1, 1).Select
    NM_InchideSelectia
    Exit Sub
Fail:
    msg = Err.description
    If changed Then
        On Error Resume Next
        For Each item In prior: mTarget.Range(CStr(item(0))).Value2 = item(1): Next item
        Application.EnableEvents = oldE
        On Error GoTo 0
    End If
    NM_Error msg
End Sub

Public Sub NM_InchideSelectia()
    If NM_IsOpen(mPick) Then mPick.Close SaveChanges:=False
    Set mPick = Nothing: Set mTarget = Nothing: mTargetAddress = "": mPickKind = 0
End Sub

Private Sub NM_Error(ByVal message As String)
    MsgBox message, vbExclamation, "TQM - Nomenclatoare"
End Sub

Public Sub NM_ImportCatalog()
    Dim dlg As FileDialog, sourceBook As Workbook, ws As Worksheet, lo As ListObject, atr As ListObject, lr As ListRow
    Dim records As New Collection, attrs As New Collection, added As New Collection, maps As Object, codes As Object, aids As Object
    Dim oldE As Boolean, oldSecurity As Long, writing As Boolean, environmentChanged As Boolean, path As String, snapshot As String, msg As String, existing As Workbook
    Dim hs As Variant, c As Long, oldID As String, id As String, v As Variant, a As Variant, item As Variant, found As Range, skipped As Long, eventID As String
    On Error GoTo Fail
    Call NM_Init:     NM_Check
    Set dlg = Application.FileDialog(msoFileDialogFilePicker)
    dlg.title = "Selectati fisierul TQM care contine catalogul": dlg.AllowMultiSelect = False
    dlg.Filters.Clear: dlg.Filters.Add "Fisiere Excel", "*.xlsm;*.xlsx"
    If dlg.Show <> -1 Then Exit Sub
    path = dlg.SelectedItems(1)
    If StrComp(path, ThisWorkbook.FullName, vbTextCompare) = 0 Then Err.Raise vbObjectError + 793, , "Selectati un alt fisier pentru import."
    For Each existing In Workbooks
        If StrComp(existing.FullName, path, vbTextCompare) = 0 Then Err.Raise vbObjectError + 804, , "Inchideti fisierul sursa inainte de import. Copia cu datele dumneavoastra ramane deschisa."
    Next existing
    oldE = Application.EnableEvents: oldSecurity = Application.AutomationSecurity: Application.EnableEvents = False
    environmentChanged = True
    Application.AutomationSecurity = msoAutomationSecurityForceDisable
    Set sourceBook = Workbooks.Open(fileName:=path, UpdateLinks:=0, readonly:=True)
    Application.AutomationSecurity = oldSecurity
    Set ws = sourceBook.Worksheets(NM_Sheet)
    If CStr(ws.Range("R1").Value2) <> NM_MARK Then Err.Raise vbObjectError + 794, , "Fisierul selectat nu contine catalogul TQM compatibil."
    Set lo = ws.ListObjects("tTQMNMMateriale"): Set atr = sourceBook.Worksheets("_TQM_NM_ATR").ListObjects("tTQMNMAtribute")
    hs = NM_Heads(1)
    If lo.ListColumns.count <> UBound(hs) + 1 Then Err.Raise vbObjectError + 795, , "Structura catalogului sursa este invalida."
    For c = 0 To UBound(hs)
        If lo.ListColumns(c + 1).name <> hs(c) Then Err.Raise vbObjectError + 796, , "Coloana sursa modificata."
    Next c
    hs = NM_Heads(5)
    If atr.ListColumns.count <> UBound(hs) + 1 Then Err.Raise vbObjectError + 797, , "Structura atributelor sursa este invalida."
    For c = 0 To UBound(hs)
        If atr.ListColumns(c + 1).name <> hs(c) Then Err.Raise vbObjectError + 798, , "Coloana sursa de atribut modificata."
    Next c
    Set maps = CreateObject("Scripting.Dictionary"): Set codes = CreateObject("Scripting.Dictionary"): Set aids = CreateObject("Scripting.Dictionary")
    snapshot = NM_Snapshot()
    For Each lr In lo.ListRows
        oldID = CStr(lr.Range.Cells(1, 11).Value2)
        If Len(oldID) > 0 Then
            v = NM_RowValues(lr.Range)
            If maps.exists(oldID) Or codes.exists(NM_Norm(CStr(v(1)))) Then Err.Raise vbObjectError + 799, , "ID sau cod duplicat in catalogul sursa."
            codes.Add NM_Norm(CStr(v(1))), True: Set found = NM_ByCode(1, CStr(v(1)))
            If Not found Is Nothing Then
                skipped = skipped + 1: maps.Add oldID, ""
            Else
                id = oldID: Set found = NM_Find(1, id)
                If Not found Is Nothing Then id = NM_NewID("NM")
                v(11) = id: v(9) = "De verificat": v(12) = 1: v(14) = CDbl(Now): v(15) = Application.UserName
                NM_Validate 1, v, id: maps.Add oldID, id: records.Add v
            End If
        End If
    Next lr
    For Each lr In atr.ListRows
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then
            a = NM_RowValues(lr.Range): oldID = CStr(a(2))
            If Not maps.exists(oldID) Then Err.Raise vbObjectError + 800, , "Atribut sursa fara material."
            If Len(CStr(maps(oldID))) > 0 Then
                a(2) = maps(oldID)
                If Len(NM_Text(a(3))) = 0 Or Len(NM_Text(a(4))) = 0 Then Err.Raise vbObjectError + 801, , "Atribut sursa incomplet."
                id = CStr(a(2)) & ChrW(30) & NM_Norm(CStr(a(3)))
                If aids.exists(id) Then Err.Raise vbObjectError + 802, , "Atribut sursa duplicat."
                aids.Add id, True: a(1) = NM_NewID("AT"): attrs.Add a
            End If
        End If
    Next lr
    sourceBook.Close SaveChanges:=False: Set sourceBook = Nothing
    If NM_Snapshot() <> snapshot Then Err.Raise vbObjectError + 803, , "Catalogul destinatie s-a modificat. Importul a fost oprit."
    eventID = NM_NewID("EV"): writing = True
    For Each item In records
        added.Add CStr(item(11)): NM_Write NM_Add(1), item
        NM_Log eventID, 1, CStr(item(11)), "Import catalog", 1, "Cod_material", "", CStr(item(1))
    Next item
    For Each item In attrs: NM_Write NM_Add(5), item: Next item
    Call NM_Check:     NM_Calc: writing = False: Application.EnableEvents = oldE
    MsgBox records.count & " materiale importate. " & skipped & " coduri deja existente au fost pastrate. Verificati si activati materialele noi.", vbInformation, "TQM"
    Exit Sub
Fail:
    msg = Err.description
    On Error Resume Next
    If Not sourceBook Is Nothing Then sourceBook.Close SaveChanges:=False
    If writing Then
        For Each item In added: NM_Delete 5, 2, CStr(item): NM_Delete 1, 11, CStr(item): Next item
        NM_Delete 6, 1, eventID: NM_Calc
    End If
    If environmentChanged Then Application.EnableEvents = oldE: Application.AutomationSecurity = oldSecurity
    On Error GoTo 0
    NM_Error msg
End Sub

Private Sub NM_SLMaterialLists(ByVal value As Variant, ByVal id As String)
    Dim prior As Range, col As Variant, group As String, historical As Boolean
    If Len(id) > 0 Then Set prior = NM_Find(1, id)
    For Each col In Array(3, 6)
        group = IIf(CLng(col) = 3, "CATEGORIE", "UM"): historical = False
        If Not prior Is Nothing Then historical = (CStr(prior.Cells(1, CLng(col)).Value2) = CStr(value(CLng(col))))
        If Not historical Then NM_SLCheck group, CStr(value(CLng(col)))
    Next col
End Sub

Private Function NM_SLParam(ByVal key As String, ByVal fallback As Variant) As Variant
    Dim ws As Worksheet
    Set ws = NM_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then
        NM_SLParam = fallback
    Else
        NM_SLParam = Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_Param", key, fallback)
    End If
End Function
Private Sub NM_SLList(ByVal target As Range, ByVal group As String)
    Dim ws As Worksheet
    Set ws = NM_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then Exit Sub
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_ApplyList", target, group
End Sub
Private Sub NM_SLCheck(ByVal group As String, ByVal value As String)
    Dim ws As Worksheet
    Set ws = NM_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then Exit Sub
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_CheckValue", group, value
End Sub

Private Sub NM_PBSync()
    On Error Resume Next
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!PB_Sync"
    On Error GoTo 0
End Sub

Public Sub NM_ProiectDinDenumire(ByVal denumire As String)
    NM_Edit 3, "", False
    If Not mForm Is Nothing Then mForm.Worksheets(1).Range("B6").Value2 = denumire
End Sub

Private Sub NM_DOCSync()
    On Error Resume Next
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!DOC_Sync"
    On Error GoTo 0
End Sub

Private Function NM_CanonicalChoice(ByVal group As String, ByVal value As String) As String
    Dim ws As Worksheet, choices As Variant, item As Variant
    Set ws = NM_GetSheet("07_SETARI_LISTE")
    If Not ws Is Nothing Then
        NM_CanonicalChoice = CStr(Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_CanonicalValue", group, value))
        Exit Function
    End If
    Select Case group
    Case "STARE_NOMENCLATOR": choices = Array("Activ", "Inactiv", "De verificat")
    Case "TIP_PARTENER_NM": choices = Array("Furnizor", "Producator", "Prestator", "Alt partener", "Client", "Mixt")
    Case "TIP_LOCATIE": choices = Array("Depozit", "Santier", "Alta locatie")
    Case Else: Err.Raise vbObjectError + 811, , "Lista necunoscuta."
    End Select
    For Each item In choices
        If StrComp(CStr(item), Trim$(value), vbTextCompare) = 0 Then NM_CanonicalChoice = CStr(item): Exit Function
    Next item
    Err.Raise vbObjectError + 812, , "Valoare invalida: " & value
End Function
Private Function NM_DocumentUsed(ByVal kind As Long, ByVal id As String) As Boolean
    Dim lo As ListObject, lr As ListRow, entity As String
    entity = Choose(kind, "Material", "Partener", "Proiect", "Locatie")
    Set lo = NM_Source("tTQMDOCLinkuri")
    If lo Is Nothing Then Exit Function
    For Each lr In lo.ListRows
        If StrComp(CStr(lr.Range.Cells(1, 3).Value2), entity, vbTextCompare) = 0 And StrComp(CStr(lr.Range.Cells(1, 4).Value2), id, vbTextCompare) = 0 And Len(id) > 0 Then NM_DocumentUsed = True: Exit Function
    Next lr
End Function



Public Function NM_PickerAllows(ByVal kind As Long, ByVal targetSheetName As String, ByVal state As String) As Boolean
    If kind < 1 Or kind > 4 Then Exit Function
    state = NM_Norm(state)
    If state = "ACTIV" Then
        NM_PickerAllows = True
    ElseIf kind = 1 And targetSheetName = "RFQ_Cerere" And state = "DE VERIFICAT" Then
        NM_PickerAllows = True
    End If
End Function

Public Function NM_RFQResolveMaterial(ByVal code As String, ByVal labelName As String, ByVal spec As String, ByVal unit As String, Optional ByVal historical As Boolean = False) As String
    Dim id As String, r As Range
    id = NM_ResolveMaterial(code, labelName, spec, unit, True)
    Set r = NM_Find(1, id)
    If r Is Nothing Then Err.Raise vbObjectError + 757, , "Materialul nu este in Nomenclatoare."
    If Not historical Then
        If Not NM_PickerAllows(1, "RFQ_Cerere", CStr(r.Cells(1, 9).Value2)) Then Err.Raise vbObjectError + 759, , "Materialul este Inactiv. Alegeti un material Activ sau De verificat pentru cerere."
    End If
    NM_RFQResolveMaterial = id
End Function

Public Function NM_RFQName(ByVal kind As Long, ByVal labelName As String, Optional ByVal historical As Boolean = False) As String
    Dim r As Range
    If kind = 2 Then
        NM_ValidatePartner labelName, "", historical
    ElseIf kind = 3 Then
        NM_ValidateProject labelName, historical
    Else
        Err.Raise vbObjectError + 2209, "RFQ", "Tip de nomenclator invalid."
    End If
    Set r = NM_ByName(kind, labelName)
    If r Is Nothing Then NM_RFQName = Trim$(labelName) Else NM_RFQName = CStr(r.Cells(1, 3).Value2)
End Function
