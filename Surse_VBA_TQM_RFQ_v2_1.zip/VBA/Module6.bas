Attribute VB_Name = "Module6"
Option Explicit
' TQM - Livrari si stoc v1. Cantitati, fara evaluare contabila.
' Fiecare formular este un registru temporar local. Import standard .bas.
Private Const ST_Sheet As String = "04_LIVRARI_SI_STOC"
Private Const ST_MARK As String = "TQM_ST_V1"
Private mForm As Workbook
Private mMode As String
Private mMat As String
Private mLoc As String
Private mStamp As String
Private Type ST_GUID
    Data1 As Long
    Data2 As Integer
    Data3 As Integer
    Data4(0 To 7) As Byte
End Type
#If VBA7 Then
Private Declare PtrSafe Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As ST_GUID) As Long
#Else
Private Declare Function CoCreateGuid Lib "ole32.dll" (ByRef pGuid As ST_GUID) As Long
#End If

Private Function ST_Heads(ByVal kind As Long) As Variant
    Select Case kind
    Case 1: ST_Heads = Split("Material|Specificatie|UM|Locatie|Intrari|Iesiri|Stoc_curent|Stoc_minim|Alerta|ID_material|ID_locatie|ID_stoc|Actualizat_la", "|")
    Case 2: ST_Heads = Split("ID_material|Cod_material|Denumire|Specificatie|UM|Creat_la", "|")
    Case 3: ST_Heads = Split("ID_locatie|Denumire|Creat_la", "|")
    Case 4: ST_Heads = Split("ID_miscare|ID_operatie|Data|Tip|ID_material|ID_locatie|Cantitate|Document|Responsabil|Observatii|ID_receptie|ID_pozitie|ID_comanda|Stare|Creat_la|Anulat_la|Anulat_de|Motiv_anulare|Proiect|Partener|Link", "|")
    End Select
End Function

Private Function ST_GetSheet(ByVal labelName As String) As Worksheet
    On Error Resume Next
    Set ST_GetSheet = ThisWorkbook.Worksheets(labelName)
    On Error GoTo 0
End Function

Private Function ST_Table(ByVal kind As Long) As ListObject
    Select Case kind
    Case 1: Set ST_Table = ThisWorkbook.Worksheets(ST_Sheet).ListObjects("tTQMStoc")
    Case 2: Set ST_Table = ThisWorkbook.Worksheets("_TQM_ST_MAT").ListObjects("tTQMSTMateriale")
    Case 3: Set ST_Table = ThisWorkbook.Worksheets("_TQM_ST_LOC").ListObjects("tTQMSTLocatii")
    Case 4: Set ST_Table = ThisWorkbook.Worksheets("_TQM_ST_MISC").ListObjects("tTQMSTMiscari")
    End Select
End Function

Private Function ST_Source(ByVal labelName As String) As ListObject
    Dim ws As Worksheet, lo As ListObject
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            If lo.name = labelName Then Set ST_Source = lo: Exit Function
        Next lo
    Next ws
    Err.Raise vbObjectError + 401, , "Lipseste tabelul " & labelName & ". Instalati mai intai Comenzi furnizori."
End Function

Private Sub ST_Init()
    Dim names As Variant, tables As Variant, ws As Worksheet, lo As ListObject, hs As Variant
    Dim i As Long, k As Long, first As Long
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 402, , "Fisierul este deschis doar pentru citire."
    names = Array(ST_Sheet, "_TQM_ST_MAT", "_TQM_ST_LOC", "_TQM_ST_MISC")
    tables = Array("tTQMStoc", "tTQMSTMateriale", "tTQMSTLocatii", "tTQMSTMiscari")
    For i = 0 To 3
        Set ws = ST_GetSheet(CStr(names(i)))
        If ws Is Nothing Then
            Set ws = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.count))
            ws.name = names(i)
            If i = 0 Then ws.Range("O1").Value2 = ST_MARK
        ElseIf i = 0 Then
            If CStr(ws.Range("O1").Value2) <> ST_MARK Then Err.Raise vbObjectError + 403, , "Foaia Livrari si stoc are alta structura. Nu a fost modificata."
        End If
        Set lo = Nothing
        On Error Resume Next
        Set lo = ws.ListObjects(CStr(tables(i)))
        On Error GoTo 0
        hs = ST_Heads(i + 1): first = 1: If i = 0 Then first = 12
        If lo Is Nothing Then
            If Application.CountA(ws.Cells(first, 1).Resize(2, UBound(hs) + 1)) > 0 Then Err.Raise vbObjectError + 404, , "Date necunoscute in " & ws.name
            For k = 0 To UBound(hs): ws.Cells(first, k + 1).Value2 = hs(k): Next k
            Set lo = ws.ListObjects.Add(xlSrcRange, ws.Cells(first, 1).Resize(2, UBound(hs) + 1), , xlYes)
            lo.name = tables(i): lo.TableStyle = "TableStyleMedium2"
        End If
        If lo.ListColumns.count <> UBound(hs) + 1 Then Err.Raise vbObjectError + 405, , "Structura invalida in " & lo.name
        For k = 0 To UBound(hs)
            If lo.ListColumns(k + 1).name <> hs(k) Then Err.Raise vbObjectError + 406, , "Coloana modificata in " & lo.name & ": " & hs(k)
        Next k
        If i = 0 Then ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True Else ws.Visible = xlSheetVeryHidden
    Next i
    Set lo = ST_Source("tTQMCFRec")
    Set lo = ST_Source("tTQMCFPoz")
    Set lo = ST_Source("tTQMComenzi")
End Sub

Public Sub ST_Instaleaza()
    Dim oldE As Boolean, oldS As Boolean
    Dim ws As Worksheet
    Dim etapa As String
    Dim errNumber As Long, errMessage As String, errSource As String
    Dim protectAtExit As Boolean

    oldE = Application.EnableEvents
    oldS = Application.ScreenUpdating
    On Error GoTo Fail

    Application.EnableEvents = False
    Application.ScreenUpdating = False

    etapa = "Initializare registre si verificare surse - ST_Init"
    ST_Init
    Set ws = ThisWorkbook.Worksheets(ST_Sheet)
    protectAtExit = True

    etapa = "Deprotejare foaie Livrari si stoc"
    ws.Unprotect Password:=""

    etapa = "Refacere interfata - ST_Layout"
    ST_Layout ws

    etapa = "Actualizare stoc si formule - ST_Calc"
    ST_Calc

    etapa = "Configurare afisare si panouri fixe"
    ws.Activate
    With ActiveWindow
        .DisplayGridlines = False
        .Zoom = 85
        .FreezePanes = False
        .SplitRow = 12
        .SplitColumn = 1
        .FreezePanes = True
    End With

    etapa = "Reprotejare foaie Livrari si stoc"
    ws.Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=True
    protectAtExit = False

    Application.EnableEvents = oldE
    Application.ScreenUpdating = oldS

    MsgBox "Livrari si stoc este instalat. Datele existente au fost pastrate." & vbCrLf & _
           "Introduceti stocul initial sau preluati receptiile din Comenzi. Salvati cu Ctrl+S.", _
           vbInformation, "TQM"
    Exit Sub

Fail:
    errNumber = Err.number
    errMessage = Err.description
    errSource = Err.source

    On Error Resume Next
    If protectAtExit Then
        If Not ws Is Nothing Then
            ws.Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=True
        End If
    End If
    Application.EnableEvents = oldE
    Application.ScreenUpdating = oldS
    On Error GoTo 0

    ST_Error "Instalarea Livrari si stoc s-a oprit." & vbCrLf & _
             "Etapa: " & etapa & vbCrLf & _
             "Eroare: " & CStr(errNumber) & vbCrLf & _
             "Sursa: " & errSource & vbCrLf & _
             "Mesaj: " & errMessage
End Sub

Private Sub ST_Band(ByVal ws As Worksheet, ByVal address As String, ByVal title As String, Optional ByVal size As Long = 10)
    With ws.Range(address)
        .Merge: .Cells(1, 1).Value2 = title: .Font.size = size: .Font.Color = RGB(31, 41, 55)
        .Font.Bold = (size > 10): .VerticalAlignment = xlCenter
    End With
End Sub

Private Sub ST_Button(ByVal ws As Worksheet, ByVal address As String, ByVal title As String, ByVal macro As String)
    Dim r As Range, sh As Shape
    Set r = ws.Range(address)
    Set sh = ws.Shapes.AddShape(msoShapeRoundedRectangle, r.Left + 2, r.Top + 2, r.width - 4, r.Height - 4)
    sh.name = "STBTN_" & macro: sh.Fill.ForeColor.RGB = RGB(37, 99, 235): sh.line.Visible = msoFalse
    sh.TextFrame2.TextRange.text = title: sh.TextFrame2.TextRange.Font.name = "Aptos"
    sh.TextFrame2.TextRange.Font.size = 10: sh.TextFrame2.TextRange.Font.Fill.ForeColor.RGB = vbWhite
    sh.TextFrame2.VerticalAnchor = msoAnchorMiddle: sh.TextFrame2.TextRange.ParagraphFormat.Alignment = msoAlignCenter
    sh.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & macro: sh.Placement = xlFreeFloating
End Sub

Private Sub ST_Layout(ByVal ws As Worksheet)
    Dim specs As Variant, a As Variant, i As Long, widths As Variant
    ws.Range("A1:M11").UnMerge: ws.Range("A1:M11").Clear
    ws.Range("A1:M11").Font.name = "Aptos": ws.Range("A1:M11").Font.size = 10: ws.rows("1:11").RowHeight = 24
    ws.rows(2).RowHeight = 34: ws.rows(9).RowHeight = 34
    ST_Band ws, "A2:I2", "TQM Calarasi - Livrari si stoc", 18
    ST_Band ws, "A3:I3", "Receptii pe locatii, transferuri, consum si retururi"
    ST_Band ws, "A11:I11", "Selectati materialul si locatia. Transferul muta stocul; consumul il scade. Cantitatile sunt in UM afisata."
    specs = Array(Array("A5:B5", "Preia receptii", "ST_PreiaReceptii"), Array("C5:D5", "Stoc initial", "ST_StocInitial"), _
        Array("E5:F5", "Transfer", "ST_Transfer"), Array("G5:H5", "Consum", "ST_Consum"), _
        Array("A6:B6", "Retur furnizor", "ST_Retur"), Array("C6:D6", "Corectie inventar", "ST_Corectie"), _
        Array("E6:F6", "Prag minim", "ST_PragMinim"), Array("G6:H6", "Istoric miscari", "ST_Istoric"), _
        Array("A7:B7", "Anuleaza operatie", "ST_AnuleazaOperatie"), Array("C7:D7", "Actualizeaza", "ST_Actualizeaza"))
    For i = ws.Shapes.count To 1 Step -1
        If Left$(ws.Shapes(i).name, 6) = "STBTN_" Then ws.Shapes(i).Delete
    Next i
    For Each a In specs: ST_Button ws, CStr(a(0)), CStr(a(1)), CStr(a(2)): Next a
    ST_Card ws, "A8:B8", "A9:B9", "Materiale urmarite", "=COUNTIFS(tTQMSTMateriale[ID_material],""<>"")", RGB(239, 246, 255)
    ST_Card ws, "C8:D8", "C9:D9", "Locatii inregistrate", "=COUNTIFS(tTQMSTLocatii[ID_locatie],""<>"")", RGB(240, 253, 244)
    ST_Card ws, "E8:F8", "E9:F9", "Pozitii sub prag minim", "=COUNTIFS(tTQMStoc[Alerta],""SUB MINIM"")", RGB(255, 247, 237)
    ST_Card ws, "G8:I8", "G9:I9", "Solduri negative", "=COUNTIFS(tTQMStoc[Stoc_curent],""<0"")", RGB(254, 242, 242)
    widths = Array(30, 30, 9, 25, 15, 15, 17, 16, 20, 18, 18, 18, 22)
    For i = 0 To UBound(widths): ws.Columns(i + 1).ColumnWidth = widths(i): Next i
    ws.Columns("J:L").Hidden = True: ws.Columns("O").Hidden = True
    ws.Columns("E:H").NumberFormat = "#,##0.######": ws.Columns("M").NumberFormat = "dd.mm.yyyy hh:mm"
    With ws.Range("A12:M12")
        .Font.name = "Aptos": .Font.size = 10: .Interior.Color = RGB(31, 41, 55)
        .Font.Color = vbWhite: .Font.Bold = True: .WrapText = True: .RowHeight = 38
        .VerticalAlignment = xlCenter: .HorizontalAlignment = xlCenter
    End With
    ws.Tab.Color = RGB(37, 99, 235)
    With ws.Range("I13:I5012")
        .FormatConditions.Delete
        .FormatConditions.Add Type:=xlExpression, Formula1:="=$I13=""SUB MINIM""": .FormatConditions(1).Interior.Color = RGB(255, 247, 237)
        .FormatConditions.Add Type:=xlExpression, Formula1:="=$I13=""STOC NEGATIV""": .FormatConditions(2).Interior.Color = RGB(254, 242, 242)
        .FormatConditions.Add Type:=xlExpression, Formula1:="=$I13=""STOC ZERO""": .FormatConditions(3).Interior.Color = RGB(241, 245, 249)
    End With
End Sub

Private Sub ST_Card(ByVal ws As Worksheet, ByVal label As String, ByVal value As String, ByVal title As String, ByVal formula As String, ByVal colour As Long)
    ST_Band ws, label, title: ST_Band ws, value, "", 18
    ws.Range(label).Interior.Color = colour: ws.Range(value).Interior.Color = colour
    ws.Range(value).Cells(1, 1).formula = formula
End Sub

Private Function ST_ID(ByVal prefix As String) As String
    Dim g As ST_GUID, t As String, i As Long
    If CoCreateGuid(g) <> 0 Then Err.Raise vbObjectError + 407, , "Nu s-a putut genera un ID unic."
    t = Right$("00000000" & Hex$(g.Data1), 8) & Right$("0000" & Hex$(g.Data2), 4) & Right$("0000" & Hex$(g.Data3), 4)
    For i = 0 To 7: t = t & Right$("00" & Hex$(g.Data4(i)), 2): Next i
    ST_ID = prefix & "-" & t
End Function

Private Function ST_Text(ByVal value As Variant) As String
    If IsError(value) Then Err.Raise vbObjectError + 408, , "Un camp contine o eroare Excel."
    ST_Text = Trim$(CStr(value))
End Function

Private Function ST_Norm(ByVal value As String) As String
    value = LCase$(Trim$(Replace(value, ChrW(160), " ")))
    value = Replace(value, ChrW(259), "a"): value = Replace(value, ChrW(226), "a")
    value = Replace(value, ChrW(238), "i"): value = Replace(value, ChrW(537), "s"): value = Replace(value, ChrW(351), "s")
    value = Replace(value, ChrW(539), "t"): value = Replace(value, ChrW(355), "t")
    Do While InStr(value, "  ") > 0: value = Replace(value, "  ", " "): Loop
    ST_Norm = value
End Function

Private Function ST_Num(ByVal value As Variant, ByVal label As String, Optional ByVal signed As Boolean = False) As Double
    If IsError(value) Or IsEmpty(value) Then Err.Raise vbObjectError + 409, , label & ": valoare numerica obligatorie."
    If Not IsNumeric(value) Then Err.Raise vbObjectError + 410, , label & ": valoare numerica invalida."
    ST_Num = CDbl(value)
    If Not signed And ST_Num < 0 Then Err.Raise vbObjectError + 411, , label & ": nu accepta valori negative."
    If Abs(ST_Num - Round(ST_Num, 6)) > 0.00000001 Then Err.Raise vbObjectError + 412, , label & ": maximum 6 zecimale."
End Function

Private Function ST_Date(ByVal value As Variant) As Double
    Dim d As Date
    If IsError(value) Or IsEmpty(value) Then Err.Raise vbObjectError + 413, , "Introduceti data miscarii."
    If IsNumeric(value) Then
        If CDbl(value) < 36526 Then Err.Raise vbObjectError + 414, , "Data miscarii este invalida."
        d = CDate(value)
    ElseIf IsDate(value) Then
        d = CDate(value)
    Else
        Err.Raise vbObjectError + 415, , "Folositi o data Excel, de exemplu 09.10.2026."
    End If
    If d > Date Or Year(d) < 2000 Then Err.Raise vbObjectError + 416, , "Data nu poate fi viitoare sau anterioara anului 2000."
    ST_Date = Int(CDbl(d))
End Function

Private Function ST_Find(ByVal lo As ListObject, ByVal id As String, Optional ByVal column As Long = 1) As Range
    Dim lr As ListRow, found As Range
    For Each lr In lo.ListRows
        If StrComp(CStr(lr.Range.Cells(1, column).Value2), id, vbTextCompare) = 0 And Len(id) > 0 Then
            If Not found Is Nothing Then Err.Raise vbObjectError + 417, , "ID duplicat in " & lo.name
            Set found = lr.Range
        End If
    Next lr
    Set ST_Find = found
End Function

Private Function ST_Add(ByVal lo As ListObject, Optional ByVal idColumn As Long = 1) As Range
    Dim lr As ListRow, wasProtected As Boolean, eno As Long, msg As String
    On Error GoTo Fail
    For Each lr In lo.ListRows
        If Len(CStr(lr.Range.Cells(1, idColumn).Value2)) = 0 Then Set ST_Add = lr.Range: Exit Function
    Next lr
    wasProtected = lo.Parent.ProtectContents
    If wasProtected Then lo.Parent.Unprotect
    Set ST_Add = lo.ListRows.Add.Range
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Exit Function
Fail:
    eno = Err.number: msg = Err.description
    On Error Resume Next
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    On Error GoTo 0
    Err.Raise eno, "ST_Add", msg
End Function

Private Sub ST_Write(ByVal row As Range, ByVal value As Variant)
    Dim i As Long
    For i = 1 To UBound(value)
        If VarType(value(i)) = vbString Then row.Cells(1, i).NumberFormat = "@"
        row.Cells(1, i).Value2 = value(i)
    Next i
End Sub

Private Sub ST_Error(ByVal message As String)
    MsgBox message, vbExclamation, "TQM - Livrari si stoc"
End Sub

Private Function ST_FormOpen() As Boolean
    Dim w As Workbook
    If mForm Is Nothing Then Exit Function
    For Each w In Application.Workbooks
        If w Is mForm Then ST_FormOpen = True: Exit Function
    Next w
    Set mForm = Nothing
End Function

Private Function ST_Start(ByVal mode As String) As Boolean
    Dim ws As Worksheet
    If ST_FormOpen Then
        If MsgBox("Inchideti formularul local si renuntati la modificarile nesalvate?", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Function
        mForm.Close SaveChanges:=False
    End If
    Set mForm = Workbooks.Add(xlWBATWorksheet): Set ws = mForm.Worksheets(1): ws.name = "Formular_Stoc"
    ws.Range("A1:I115").Font.name = "Aptos": ws.Range("A1:I115").Font.size = 10: ws.Range("A1:I115").RowHeight = 25
    ws.Columns("A").ColumnWidth = 22: ws.Columns("B").ColumnWidth = 28: ws.Columns("C:I").ColumnWidth = 15
    mMode = mode: mStamp = ST_Stamp()
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 90
    ST_Start = True
End Function

Private Sub ST_Input(ByVal ws As Worksheet, ByVal address As String, Optional ByVal value As Variant)
    With ws.Range(address)
        .Merge: .Interior.Color = RGB(239, 246, 255): .Locked = False
        If Not IsMissing(value) Then .Cells(1, 1).Value2 = value
    End With
End Sub

Public Sub ST_InchideFormular()
    If Not ST_FormOpen Then Exit Sub
    If mMode <> "ISTORIC" Then
        If MsgBox("Inchideti formularul si renuntati la modificarile nesalvate?", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
    End If
    ST_Close
End Sub

Private Sub ST_Close()
    If ST_FormOpen Then mForm.Close SaveChanges:=False
    Set mForm = Nothing: mMode = "": mStamp = ""
    ThisWorkbook.Worksheets(ST_Sheet).Activate
End Sub

Private Function ST_Stamp() As String
    Dim kind As Long, lr As ListRow, c As Long, v As String, result As String, lo As ListObject
    For kind = 1 To 4
        For Each lr In ST_Table(kind).ListRows
            For c = 1 To lr.Range.Columns.count
                If kind <> 1 Or (c <> 5 And c <> 6 And c <> 7 And c <> 9 And c <> 13) Then
                    v = CStr(lr.Range.Cells(1, c).Value2): result = result & Len(v) & ":" & v
                End If
            Next c
        Next lr
    Next kind
    Set lo = ST_Source("tTQMCFRec")
    For Each lr In lo.ListRows
        For c = 1 To 11
            v = CStr(lr.Range.Cells(1, c).Value2): result = result & Len(v) & ":" & v
        Next c
    Next lr
    Set lo = ST_Source("tTQMCFPoz")
    For Each lr In lo.ListRows
        For c = 1 To 19
            If c <> 10 And c <> 12 And c <> 13 And c <> 14 Then
                v = CStr(lr.Range.Cells(1, c).Value2): result = result & Len(v) & ":" & v
            End If
        Next c
    Next lr
    ST_Stamp = result & ST_NMStamp()
End Function

Private Sub ST_Conflict()
    If ST_Stamp() <> mStamp Then Err.Raise vbObjectError + 418, , "Stocul sau receptiile s-au modificat dupa deschiderea formularului. Datele nu au fost suprascrise. Inchideti si redeschideti formularul."
End Sub

Private Function ST_Material(ByVal code As String, ByVal labelName As String, ByVal spec As String, ByVal unit As String, ByVal added As Collection, Optional ByVal historical As Boolean = False) As String
    Dim lr As ListRow, v As Variant, candidate As String, canonical As String, i As Long, candidates As New Collection, nv(1 To 6) As Variant
    If Len(labelName) = 0 Or Len(unit) = 0 Then Err.Raise vbObjectError + 419, , "Material si UM sunt obligatorii."
    For Each lr In ST_Table(2).ListRows
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then
            For i = 1 To 6: nv(i) = lr.Range.Cells(1, i).Value2: Next i
            candidates.Add nv
        End If
    Next lr
    For Each v In added: candidates.Add v: Next v
    canonical = ST_NMMaterial(code, labelName, spec, unit, historical)
    For Each v In candidates
        If Len(code) > 0 And ST_Norm(CStr(v(2))) = ST_Norm(code) Then
            If ST_Norm(CStr(v(3))) <> ST_Norm(labelName) Or ST_Norm(CStr(v(4))) <> ST_Norm(spec) Or ST_Norm(CStr(v(5))) <> ST_Norm(unit) Then _
                Err.Raise vbObjectError + 420, , "Codul materialului exista cu alta denumire, specificatie sau UM. Nu se cumuleaza materiale diferite."
            If Len(canonical) > 0 And canonical <> CStr(v(1)) Then Err.Raise vbObjectError + 481, , "ID material nealiniat. Folositi Preia din Stoc in Nomenclatoare."
            ST_Material = CStr(v(1)): Exit Function
        End If
        If ST_Norm(CStr(v(3))) = ST_Norm(labelName) And ST_Norm(CStr(v(4))) = ST_Norm(spec) And ST_Norm(CStr(v(5))) = ST_Norm(unit) Then
            If Len(code) = 0 Or Len(CStr(v(2))) = 0 Then
                If Len(candidate) > 0 And candidate <> CStr(v(1)) Then Err.Raise vbObjectError + 421, , "Material ambiguu. Completati codul materialului."
                candidate = CStr(v(1))
            End If
        End If
    Next v
    If Len(candidate) > 0 Then
        If Len(canonical) > 0 And canonical <> candidate Then Err.Raise vbObjectError + 482, , "ID material nealiniat. Folositi Preia din Stoc in Nomenclatoare."
        ST_Material = candidate: Exit Function
    End If
    nv(1) = ST_ID("SM"): nv(2) = code: nv(3) = labelName: nv(4) = spec: nv(5) = unit: nv(6) = CDbl(Now)
    If Len(canonical) > 0 Then nv(1) = canonical
    added.Add nv: ST_Material = nv(1)
End Function

Private Function ST_Location(ByVal labelName As String, ByVal added As Collection) As String
    Dim lr As ListRow, v As Variant, nv(1 To 3) As Variant, result As String, canonical As String
    If Len(Trim$(labelName)) = 0 Then Err.Raise vbObjectError + 422, , "Introduceti locatia fizica."
    canonical = ST_NMLocation(labelName)
    For Each lr In ST_Table(3).ListRows
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 And ST_Norm(CStr(lr.Range.Cells(1, 2).Value2)) = ST_Norm(labelName) Then
            If Len(result) > 0 Then Err.Raise vbObjectError + 423, , "Locatie duplicata in nomenclator."
            result = CStr(lr.Range.Cells(1, 1).Value2)
        End If
    Next lr
    If Len(result) > 0 Then
        If Len(canonical) > 0 And canonical <> result Then Err.Raise vbObjectError + 483, , "ID locatie nealiniat. Folositi Preia din Stoc in Nomenclatoare."
        ST_Location = result: Exit Function
    End If
    For Each v In added
        If ST_Norm(CStr(v(2))) = ST_Norm(labelName) Then ST_Location = CStr(v(1)): Exit Function
    Next v
    nv(1) = ST_ID("SL"): If Len(canonical) > 0 Then nv(1) = canonical
    nv(2) = labelName: nv(3) = CDbl(Now): added.Add nv: ST_Location = nv(1)
End Function

Private Function ST_Record(ByVal op As String, ByVal dat As Double, ByVal tip As String, ByVal mat As String, ByVal loc As String, ByVal qty As Double, ByVal doc As String, ByVal person As String, ByVal note As String) As Variant
    Dim v(1 To 21) As Variant, i As Long
    For i = 1 To 21: v(i) = "": Next i
    v(1) = ST_ID("MV"): v(2) = op: v(3) = dat: v(4) = tip: v(5) = mat: v(6) = loc: v(7) = qty
    v(8) = doc: v(9) = person: v(10) = note: v(14) = "Valida": v(15) = CDbl(Now): v(16) = Empty
    ST_Record = v
End Function

Private Function ST_Array(ByVal row As Range) As Variant
    Dim v(1 To 21) As Variant, i As Long
    For i = 1 To 21: v(i) = row.Cells(1, i).Value2: Next i
    ST_Array = v
End Function

Private Sub ST_Check(ByVal records As Collection)
    Dim affected As Object, days As Object, lr As ListRow, v As Variant, key As String, k As Variant
    Dim dateKey As String, dates As Variant, i As Long, n As Long, tmp As Variant, bal As Double
    Set affected = CreateObject("Scripting.Dictionary")
    For Each v In records
        key = CStr(v(5)) & "|" & CStr(v(6))
        If Not affected.exists(key) Then Set days = CreateObject("Scripting.Dictionary"): affected.Add key, days
    Next v
    For Each lr In ST_Table(4).ListRows
        If CStr(lr.Range.Cells(1, 14).Value2) = "Valida" Then
            key = CStr(lr.Range.Cells(1, 5).Value2) & "|" & CStr(lr.Range.Cells(1, 6).Value2)
            If affected.exists(key) Then
                Set days = affected(key): dateKey = CStr(CLng(lr.Range.Cells(1, 3).Value2))
                If Not days.exists(dateKey) Then days.Add dateKey, 0#
                days(dateKey) = CDbl(days(dateKey)) + CDbl(lr.Range.Cells(1, 7).Value2)
            End If
        End If
    Next lr
    For Each v In records
        key = CStr(v(5)) & "|" & CStr(v(6)): Set days = affected(key): dateKey = CStr(CLng(v(3)))
        If Not days.exists(dateKey) Then days.Add dateKey, 0#
        days(dateKey) = CDbl(days(dateKey)) + CDbl(v(7))
    Next v
    For Each k In affected.keys
        Set days = affected(k): dates = days.keys
        For i = LBound(dates) To UBound(dates) - 1
            For n = i + 1 To UBound(dates)
                If CLng(dates(i)) > CLng(dates(n)) Then tmp = dates(i): dates(i) = dates(n): dates(n) = tmp
            Next n
        Next i
        bal = 0
        For i = LBound(dates) To UBound(dates)
            bal = bal + CDbl(days(CStr(dates(i))))
            If bal < -0.00000001 Then Err.Raise vbObjectError + 424, , "Operatia ar produce stoc negativ la data " & Format$(CDate(CLng(dates(i))), "dd.mm.yyyy") & ". Verificati cantitatea, locatia si ordinea miscarilor."
        Next i
    Next k
End Sub

Private Function ST_Receipt(ByVal receipt As String, ByVal position As String) As Range
    Dim lr As ListRow, result As Range
    For Each lr In ST_Source("tTQMCFRec").ListRows
        If CStr(lr.Range.Cells(1, 1).Value2) = receipt And CStr(lr.Range.Cells(1, 2).Value2) = position And CStr(lr.Range.Cells(1, 7).Value2) = "Valida" Then
            If Not result Is Nothing Then Err.Raise vbObjectError + 425, , "Pozitie de receptie duplicata in Comenzi furnizori."
            Set result = lr.Range
        End If
    Next lr
    Set ST_Receipt = result
End Function

Private Function ST_Allocated(ByVal receipt As String, ByVal position As String) As Double
    Dim lr As ListRow
    For Each lr In ST_Table(4).ListRows
        If CStr(lr.Range.Cells(1, 4).Value2) = "Receptie comanda" And CStr(lr.Range.Cells(1, 14).Value2) = "Valida" And _
           CStr(lr.Range.Cells(1, 11).Value2) = receipt And CStr(lr.Range.Cells(1, 12).Value2) = position Then
            ST_Allocated = ST_Allocated + CDbl(lr.Range.Cells(1, 7).Value2)
        End If
    Next lr
End Function

Private Sub ST_VerificaSurse()
    Dim lr As ListRow, source As Range, checked As Object, key As String
    Set checked = CreateObject("Scripting.Dictionary")
    For Each lr In ST_Table(4).ListRows
        If CStr(lr.Range.Cells(1, 4).Value2) = "Receptie comanda" And CStr(lr.Range.Cells(1, 14).Value2) = "Valida" Then
            key = CStr(lr.Range.Cells(1, 11).Value2) & "|" & CStr(lr.Range.Cells(1, 12).Value2)
            If Not checked.exists(key) Then
                checked.Add key, True
                Set source = ST_Receipt(CStr(lr.Range.Cells(1, 11).Value2), CStr(lr.Range.Cells(1, 12).Value2))
                If source Is Nothing Then Err.Raise vbObjectError + 426, , "Exista stoc provenit dintr-o receptie anulata in Comenzi. Corectati repartizarea inainte de alte miscari."
                If ST_Allocated(CStr(source.Cells(1, 1).Value2), CStr(source.Cells(1, 2).Value2)) - CDbl(source.Cells(1, 6).Value2) > 0.00000001 Then _
                    Err.Raise vbObjectError + 427, , "O receptie din Comenzi are mai putina cantitate decat stocul repartizat. Corectati repartizarea."
            End If
        End If
    Next lr
End Sub

Private Function ST_Stock(ByVal mat As String, ByVal loc As String) As Range
    Dim lr As ListRow, result As Range
    For Each lr In ST_Table(1).ListRows
        If CStr(lr.Range.Cells(1, 10).Value2) = mat And CStr(lr.Range.Cells(1, 11).Value2) = loc Then
            If Not result Is Nothing Then Err.Raise vbObjectError + 428, , "Sold duplicat pentru acelasi material si aceeasi locatie."
            Set result = lr.Range
        End If
    Next lr
    Set ST_Stock = result
End Function

Private Function ST_EnsureStock(ByVal mat As String, ByVal loc As String, ByRef created As Boolean) As Range
    Dim row As Range, mr As Range, lr As Range
    Set row = ST_Stock(mat, loc): created = False
    If row Is Nothing Then
        Set mr = ST_Find(ST_Table(2), mat): Set lr = ST_Find(ST_Table(3), loc)
        If mr Is Nothing Or lr Is Nothing Then Err.Raise vbObjectError + 429, , "Lipseste materialul sau locatia asociata miscarii."
        Set row = ST_Add(ST_Table(1), 12)
        row.Cells(1, 1).Resize(1, 4).NumberFormat = "@"
        row.Cells(1, 1).Value2 = mr.Cells(1, 3).Value2: row.Cells(1, 2).Value2 = mr.Cells(1, 4).Value2
        row.Cells(1, 3).Value2 = mr.Cells(1, 5).Value2: row.Cells(1, 4).Value2 = lr.Cells(1, 2).Value2
        row.Cells(1, 8).Value2 = 0: row.Cells(1, 10).Value2 = mat: row.Cells(1, 11).Value2 = loc
        row.Cells(1, 12).Value2 = ST_ID("SS"): created = True
    End If
    Set ST_EnsureStock = row
End Function

Private Sub ST_Calc()
    Dim lo As ListObject, lr As ListRow, row As Range, created As Boolean, oldE As Boolean, eno As Long, msg As String
    Dim calcSheets(1 To 4) As Worksheet
    Dim restoreProtection(1 To 4) As Boolean
    Dim savedFiltering(1 To 4) As Boolean
    Dim i As Long, stage As String, errSource As String
    oldE = Application.EnableEvents
    On Error GoTo Fail
    Application.EnableEvents = False
    stage = "Pregatire foi pentru calculul stocului"
    For i = 1 To 4
        Set calcSheets(i) = ST_Table(i).Parent
        If calcSheets(i).ProtectContents Or calcSheets(i).ProtectDrawingObjects Or calcSheets(i).ProtectScenarios Then
            savedFiltering(i) = calcSheets(i).Protection.AllowFiltering
            calcSheets(i).Unprotect Password:=""
            restoreProtection(i) = True
        End If
    Next i
    stage = "Asociere materiale si locatii - ST_EnsureStock"
    For Each lr In ST_Table(4).ListRows
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then Set row = ST_EnsureStock(CStr(lr.Range.Cells(1, 5).Value2), CStr(lr.Range.Cells(1, 6).Value2), created)
    Next lr
    stage = "Scriere formule intrari, iesiri, sold si alerta"
    Set lo = ST_Table(1)
    If Not lo.DataBodyRange Is Nothing Then
        ST_CalcSetR1C1 lo, "Intrari", "=IF([@ID_material]="""","""",SUMIFS(tTQMSTMiscari[Cantitate],tTQMSTMiscari[ID_material],[@ID_material],tTQMSTMiscari[ID_locatie],[@ID_locatie],tTQMSTMiscari[Stare],""Valida"",tTQMSTMiscari[Cantitate],"">0""))"
        ST_CalcSetR1C1 lo, "Iesiri", "=IF([@ID_material]="""","""",-SUMIFS(tTQMSTMiscari[Cantitate],tTQMSTMiscari[ID_material],[@ID_material],tTQMSTMiscari[ID_locatie],[@ID_locatie],tTQMSTMiscari[Stare],""Valida"",tTQMSTMiscari[Cantitate],""<0""))"
        ST_CalcSetR1C1 lo, "Stoc_curent", "=IF([@ID_material]="""","""",ROUND([@Intrari]-[@Iesiri],6))"
        ST_CalcSetR1C1 lo, "Alerta", "=IF([@ID_material]="""","""",IF([@Stoc_curent]<0,""STOC NEGATIV"",IF([@Stoc_curent]<[@Stoc_minim],""SUB MINIM"",IF([@Stoc_curent]=0,""STOC ZERO"",""OK""))))"
        stage = "Formatare tabel stoc"
        lo.Range.Font.name = "Aptos": lo.Range.Font.size = 10
        lo.ListColumns("Actualizat_la").DataBodyRange.NumberFormat = "dd.mm.yyyy hh:mm"
        stage = "Actualizare data calculului"
        For Each lr In lo.ListRows
            If Len(CStr(lr.Range.Cells(1, 12).Value2)) > 0 Then lr.Range.Cells(1, 13).Value2 = CDbl(Now)
        Next lr
        stage = "Recalculare foaie stoc"
        lo.Parent.Calculate
    End If
    stage = "Format data miscarilor"
    ST_Table(4).ListColumns("Data").Range.NumberFormat = "dd.mm.yyyy"
    stage = "Sincronizare documente"
    ST_DOCSync
    stage = "Restabilire protectie foi"
    For i = 1 To 4
        If restoreProtection(i) Then
            calcSheets(i).Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=savedFiltering(i)
            restoreProtection(i) = False
        End If
    Next i
    Application.EnableEvents = oldE
    Exit Sub
Fail:
    eno = Err.number: msg = Err.description: errSource = Err.source
    On Error Resume Next
    For i = 1 To 4
        If restoreProtection(i) Then
            calcSheets(i).Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=savedFiltering(i)
        End If
    Next i
    Application.EnableEvents = oldE
    On Error GoTo 0
    If Len(errSource) = 0 Then errSource = "ST_Calc"
    Err.Raise eno, errSource, "Etapa ST_Calc: " & stage & vbCrLf & _
              "Eroare: " & CStr(eno) & vbCrLf & "Sursa: " & errSource & vbCrLf & msg
End Sub

Private Sub ST_CalcSetR1C1(ByVal lo As ListObject, ByVal columnName As String, ByVal template As String)
    Dim target As Range, lc As ListColumn, sourceTable As ListObject
    Dim formulaText As String, token As String, targetAddress As String
    Dim i As Long, errNumber As Long, errMessage As String

    On Error GoTo Fail
    Set target = lo.ListColumns(columnName).DataBodyRange
    If target Is Nothing Then Exit Sub
    targetAddress = target.address(False, False)
    formulaText = template

    ' RC plus coloana absoluta pastreaza referinta la randul curent.
    For Each lc In lo.ListColumns
        token = "[@" & lc.name & "]"
        formulaText = Replace(formulaText, token, "RC" & CStr(lc.Range.column), 1, -1, vbBinaryCompare)
    Next lc

    ' Intervalele sursa sunt refacute la fiecare ST_Calc, dupa adaugari de randuri.
    For i = 1 To 4
        Set sourceTable = ST_Table(i)
        For Each lc In sourceTable.ListColumns
            token = sourceTable.name & "[" & lc.name & "]"
            If InStr(1, formulaText, token, vbBinaryCompare) > 0 Then
                formulaText = Replace(formulaText, token, ST_CalcSourceRefR1C1(lc), 1, -1, vbBinaryCompare)
            End If
        Next lc
    Next i

    If InStr(1, formulaText, "[@", vbBinaryCompare) > 0 Then
        Err.Raise vbObjectError + 499, "ST_CalcSetR1C1", "Referinta la o coloana inexistenta in formula."
    End If
    target.FormulaR1C1 = formulaText
    Exit Sub

Fail:
    errNumber = Err.number
    errMessage = Err.description
    Debug.Print "ST_Calc: " & lo.name & "." & columnName
    Debug.Print formulaText
    Err.Raise errNumber, "ST_Calc." & lo.name & "." & columnName, _
              errMessage & vbCrLf & "Foaie: " & lo.Parent.name & "; interval: " & targetAddress
End Sub

Private Function ST_CalcSourceRefR1C1(ByVal lc As ListColumn) As String
    Dim sourceRange As Range
    Set sourceRange = lc.DataBodyRange
    If sourceRange Is Nothing Then
        Set sourceRange = lc.Parent.HeaderRowRange.Cells(1, lc.Index).Offset(1, 0)
    End If
    ST_CalcSourceRefR1C1 = "'" & Replace(sourceRange.Parent.name, "'", "''") & "'!" & _
                          sourceRange.address(RowAbsolute:=True, ColumnAbsolute:=True, ReferenceStyle:=xlR1C1, External:=False)
End Function


Private Sub ST_Delete(ByVal lo As ListObject, ByVal column As Long, ByVal id As String)
    Dim i As Long, wasProtected As Boolean, eno As Long, msg As String
    On Error GoTo Fail
    wasProtected = lo.Parent.ProtectContents
    If wasProtected Then lo.Parent.Unprotect
    For i = lo.ListRows.count To 1 Step -1
        If CStr(lo.ListRows(i).Range.Cells(1, column).Value2) = id Then lo.ListRows(i).Delete
    Next i
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    Exit Sub
Fail:
    eno = Err.number: msg = Err.description
    On Error Resume Next
    If wasProtected Then lo.Parent.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    On Error GoTo 0
    Err.Raise eno, "ST_Delete", msg
End Sub

Private Sub ST_Commit(ByVal records As Collection, ByVal materials As Collection, ByVal locations As Collection)
    Dim v As Variant, row As Range, source As Range, groups As Object, key As String, newStocks As New Collection
    Dim oldE As Boolean, oldS As Boolean, writing As Boolean, created As Boolean, op As String, eno As Long, msg As String
    On Error GoTo Fail
    If records.count = 0 Then Err.Raise vbObjectError + 430, , "Nu exista cantitati de salvat."
    Call ST_Conflict:     ST_VerificaSurse: ST_Check records
    Set groups = CreateObject("Scripting.Dictionary")
    For Each v In records
        If v(4) = "Receptie comanda" Then
            key = CStr(v(11)) & "|" & CStr(v(12))
            If Not groups.exists(key) Then groups.Add key, ST_Allocated(CStr(v(11)), CStr(v(12)))
            groups(key) = CDbl(groups(key)) + CDbl(v(7)): Set source = ST_Receipt(CStr(v(11)), CStr(v(12)))
            If source Is Nothing Then Err.Raise vbObjectError + 431, , "Receptia sursa nu mai este valida."
            If CDbl(groups(key)) - CDbl(source.Cells(1, 6).Value2) > 0.00000001 Then Err.Raise vbObjectError + 432, , "Cantitatea depaseste receptia nepreluata in stoc."
        End If
    Next v
    v = records(1): op = CStr(v(2))
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: writing = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    For Each v In materials: Set row = ST_Add(ST_Table(2)): ST_Write row, v: Next v
    For Each v In locations: Set row = ST_Add(ST_Table(3)): ST_Write row, v: Next v
    For Each v In records
        Set row = ST_Add(ST_Table(4)): ST_Write row, v
        Set row = ST_EnsureStock(CStr(v(5)), CStr(v(6)), created)
        If created Then newStocks.Add CStr(row.Cells(1, 12).Value2)
    Next v
    ST_Calc
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
    Exit Sub
Fail:
    eno = Err.number: msg = Err.description
    If writing Then
        On Error Resume Next
        ST_Delete ST_Table(4), 2, op
        For Each v In newStocks: ST_Delete ST_Table(1), 12, CStr(v): Next v
        For Each v In materials: ST_Delete ST_Table(2), 1, CStr(v(1)): Next v
        For Each v In locations: ST_Delete ST_Table(3), 1, CStr(v(1)): Next v
    Call ST_Calc:         Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
        On Error GoTo 0
    End If
    Err.Raise eno, "ST_Commit", msg
End Sub

Private Sub ST_SelectStock()
    Dim lo As ListObject, hit As Range, i As Long
    If Not ActiveWorkbook Is ThisWorkbook Then Err.Raise vbObjectError + 433, , "Selectati materialul in fisierul principal."
    If ActiveSheet.name <> ST_Sheet Then Err.Raise vbObjectError + 434, , "Deschideti Livrari si stoc."
    Set lo = ST_Table(1)
    If lo.DataBodyRange Is Nothing Then Err.Raise vbObjectError + 435, , "Nu exista pozitii de stoc."
    Set hit = Intersect(ActiveCell, lo.DataBodyRange)
    If hit Is Nothing Then Err.Raise vbObjectError + 436, , "Selectati un rand din tabelul de stoc."
    i = ActiveCell.row - lo.HeaderRowRange.row
    mMat = CStr(lo.ListRows(i).Range.Cells(1, 10).Value2): mLoc = CStr(lo.ListRows(i).Range.Cells(1, 11).Value2)
    If Len(mMat) = 0 Or Len(mLoc) = 0 Then Err.Raise vbObjectError + 437, , "Randul selectat este gol."
End Sub

Public Sub ST_StocInitial()
    ST_OpenMove "Stoc initial"
End Sub
Public Sub ST_Transfer()
    ST_OpenMove "Transfer"
End Sub
Public Sub ST_Consum()
    ST_OpenMove "Consum"
End Sub
Public Sub ST_Retur()
    ST_OpenMove "Retur furnizor"
End Sub
Public Sub ST_Corectie()
    ST_OpenMove "Corectie"
End Sub

Private Sub ST_OpenMove(ByVal mode As String)
    Dim ws As Worksheet, mat As Range, loc As Range, title As String
    Dim previousMat As String, previousLoc As String, opened As Boolean
    previousMat = mMat: previousLoc = mLoc
    On Error GoTo Fail
    Call ST_Init:     ST_Calc: ST_VerificaSurse
    If mode = "Stoc initial" Then mMat = "": mLoc = "" Else ST_SelectStock
    If Not ST_Start(mode) Then
        mMat = previousMat: mLoc = previousLoc
        Exit Sub
    End If
    opened = True
    Set ws = mForm.Worksheets(1)
    ST_Band ws, "A1:I1", "TQM - " & mode & " (formular local)", 16
    ST_Button ws, "A3:C3", "Salveaza miscarea", "ST_SalveazaMiscare"
    ST_Button ws, "D3:F3", "Inchide formularul", "ST_InchideFormular"
    If mode = "Stoc initial" Then ST_Button ws, "G3:I3", "Alege material", "NM_AlegeMaterial"
    If mode = "Stoc initial" Or mode = "Transfer" Then ST_Button ws, "A19:C19", "Alege locatie", "NM_AlegeLocatie"
    ws.Range("A5").Value2 = "Material": ws.Range("A6").Value2 = "Specificatie"
    ws.Range("A7").Value2 = "UM": ws.Range("F7").Value2 = "Cod material"
    ws.Range("A8").Value2 = "Locatie sursa"
    ws.Range("A10").Value2 = "Cantitate": ws.Range("E10").Value2 = "Data"
    ws.Range("A11").Value2 = "Document": ws.Range("A12").Value2 = "Responsabil"
    ws.Range("A13").Value2 = "Motiv / observatii": ws.Range("A14").Value2 = "Link document"
    If mode = "Stoc initial" Then
        ws.Range("A8").Value2 = "Locatie"
        ST_Input ws, "B5:I5": ST_Input ws, "B6:I6": ST_Input ws, "B7:C7": ST_Input ws, "G7:I7"
        ST_Input ws, "B8:I8", ST_SLParam("STOC_LOCATIE_IMPLICITA", "Depozit")
    Else
        Set mat = ST_Find(ST_Table(2), mMat): Set loc = ST_Find(ST_Table(3), mLoc)
        If mat Is Nothing Or loc Is Nothing Then Err.Raise vbObjectError + 438, , "Material sau locatie lipsa."
        ST_Band ws, "B5:I5", CStr(mat.Cells(1, 3).Value2)
        ST_Band ws, "B6:I6", CStr(mat.Cells(1, 4).Value2)
        ST_Band ws, "B7:C7", CStr(mat.Cells(1, 5).Value2): ST_Band ws, "G7:I7", CStr(mat.Cells(1, 2).Value2)
        ST_Band ws, "B8:I8", CStr(loc.Cells(1, 2).Value2)
        Select Case mode
        Case "Transfer": ws.Range("A9").Value2 = "Locatie destinatie": ST_Input ws, "B9:I9"
        Case "Consum": ws.Range("A9").Value2 = "Lucrare / obiectiv": ST_Input ws, "B9:I9", CStr(loc.Cells(1, 2).Value2)
        Case "Retur furnizor": ws.Range("A9").Value2 = "Furnizor": ST_Input ws, "B9:I9"
        Case "Corectie": ws.Range("A9").Value2 = "Lucrare / obiectiv": ST_Input ws, "B9:I9", CStr(loc.Cells(1, 2).Value2)
        End Select
    End If
    ST_Input ws, "B10:C10": ST_Input ws, "F10:I10", CDbl(Date)
    ST_Input ws, "B11:I11": ST_Input ws, "B12:I12", Application.UserName
    ST_Input ws, "B13:I13": ST_Input ws, "B14:I14"
    ws.Range("G7").NumberFormat = "@": ws.Range("B11").NumberFormat = "@"
    ws.Range("B10").NumberFormat = "#,##0.######": ws.Range("F10").NumberFormat = "dd.mm.yyyy"
    title = "Cantitatile sunt in UM materialului. Miscarea trebuie justificata prin document."
    If mode = "Corectie" Then title = "Corectie inventar: cantitate pozitiva creste stocul; cantitate negativa il scade. Motivul este obligatoriu."
    If mode = "Stoc initial" Then title = "Stocul initial reprezinta soldul de deschidere si se introduce inaintea primei miscari pentru material si locatie."
    ST_Band ws, "A16:I17", title: ws.Range("A16:I17").WrapText = True
    ws.Protect UserInterfaceOnly:=True
    If mode = "Stoc initial" Then ws.Range("B5").Select Else ws.Range("B10").Select
    Exit Sub
Fail:
    If Not opened Then mMat = previousMat: mLoc = previousLoc
    ST_Error Err.description
End Sub

Public Sub ST_SalveazaMiscare()
    Dim ws As Worksheet, records As New Collection, mats As New Collection, locs As New Collection
    Dim mat As String, loc As String, dest As String, dat As Double, qty As Double, doc As String, person As String, note As String
    Dim link As String, extra As String, op As String, v As Variant, lr As ListRow, mode As String
    On Error GoTo Fail
    If Not ST_FormOpen Then Err.Raise vbObjectError + 439, , "Formularul local nu mai este deschis."
    If Not ActiveWorkbook Is mForm Then Err.Raise vbObjectError + 440, , "Salvati din fereastra formularului local."
    mode = mMode
    If mode <> "Stoc initial" And mode <> "Transfer" And mode <> "Consum" And mode <> "Retur furnizor" And mode <> "Corectie" Then Err.Raise vbObjectError + 441, , "Formular invalid pentru aceasta actiune."
    Call ST_Init:     Set ws = mForm.Worksheets(1)
    qty = ST_Num(ws.Range("B10").Value2, "Cantitate", mode = "Corectie")
    If qty = 0 Then Err.Raise vbObjectError + 442, , "Cantitatea trebuie sa fie diferita de zero."
    dat = ST_Date(ws.Range("F10").Value2): doc = ST_Text(ws.Range("B11").Value2)
    person = ST_Text(ws.Range("B12").Value2): note = ST_Text(ws.Range("B13").Value2): link = ST_Text(ws.Range("B14").Value2)
    If Len(doc) = 0 Or Len(person) = 0 Then Err.Raise vbObjectError + 443, , "Document si Responsabil sunt obligatorii."
    If (mode = "Corectie" Or mode = "Retur furnizor") And Len(note) = 0 Then Err.Raise vbObjectError + 444, , "Completati motivul miscarii."
    If Not ST_LinkOK(link) Then Err.Raise vbObjectError + 445, , "Link document invalid."
    If mode = "Stoc initial" Then
        mat = ST_Material(ST_Text(ws.Range("G7").Value2), ST_Text(ws.Range("B5").Value2), ST_Text(ws.Range("B6").Value2), ST_Text(ws.Range("B7").Value2), mats)
        loc = ST_Location(ST_Text(ws.Range("B8").Value2), locs)
        For Each lr In ST_Table(4).ListRows
            If CStr(lr.Range.Cells(1, 5).Value2) = mat And CStr(lr.Range.Cells(1, 6).Value2) = loc And CStr(lr.Range.Cells(1, 14).Value2) = "Valida" Then _
                Err.Raise vbObjectError + 446, , "Exista deja miscari pentru acest material si locatie. Pentru ajustari folositi Corectie inventar."
        Next lr
    Else
        mat = mMat: loc = mLoc: extra = ST_Text(ws.Range("B9").Value2)
        If mode <> "Corectie" And Len(extra) = 0 Then Err.Raise vbObjectError + 447, , "Completati destinatia, obiectivul sau furnizorul."
    End If
    op = ST_ID("OP")
    If mode = "Transfer" Then
        dest = ST_Location(extra, locs)
        If dest = loc Then Err.Raise vbObjectError + 448, , "Destinatia trebuie sa fie diferita de sursa."
        v = ST_Record(op, dat, mode, mat, loc, -qty, doc, person, note): v(21) = link: records.Add v
        v = ST_Record(op, dat, mode, mat, dest, qty, doc, person, note): v(21) = link: records.Add v
    Else
        If mode = "Consum" Or mode = "Retur furnizor" Then qty = -qty
        v = ST_Record(op, dat, mode, mat, loc, qty, doc, person, note): v(21) = link
        If mode = "Consum" Or mode = "Corectie" Then v(19) = extra
        If mode = "Retur furnizor" Then v(20) = extra
        records.Add v
    End If
    ST_Commit records, mats, locs
    ST_Close
    MsgBox "Miscarea a fost salvata: " & mode & vbCrLf & "ID operatie: " & op & vbCrLf & "Ctrl+S salveaza fisierul principal.", vbInformation, "TQM"
    Exit Sub
Fail: ST_Error Err.description
End Sub

Private Function ST_LinkOK(ByVal value As String) As Boolean
    ST_LinkOK = (Len(value) = 0 Or LCase$(Left$(value, 8)) = "https://" Or LCase$(Left$(value, 7)) = "http://" Or _
                 Left$(value, 2) = "\\" Or (Len(value) > 2 And mID$(value, 2, 2) = ":\"))
End Function

Public Sub ST_PreiaReceptii()
    Dim ws As Worksheet, lr As ListRow, source As Range, pos As Range, order As Range, n As Long, i As Long, qty As Double, heads As Variant
    On Error GoTo Fail
    Call ST_Init:     ST_Calc: ST_VerificaSurse
    If Not ST_Start("RECEPTII") Then Exit Sub
    Set ws = mForm.Worksheets(1)
    ST_Band ws, "A1:I1", "TQM - Repartizare receptii pe locatii", 16
    ST_Button ws, "A3:C3", "Salveaza in stoc", "ST_SalveazaReceptii"
    ST_Button ws, "D3:F3", "Inchide formularul", "ST_InchideFormular"
    ST_Button ws, "G3:I3", "Alege locatie", "NM_AlegeLocatie"
    ws.Range("A5").Value2 = "Responsabil": ST_Input ws, "B5:D5", Application.UserName
    ws.Range("A6").Value2 = "Locatie implicita": ST_Input ws, "B6:D6", ST_SLParam("STOC_LOCATIE_IMPLICITA", "Depozit")
    ws.Range("A7").Value2 = "Observatii": ST_Input ws, "B7:I7"
    ST_Band ws, "A8:I8", "Preluati numai ce a intrat fizic in locatia aleasa. Randurile fara cantitate raman nepreluate."
    heads = Split("Data|Material|Specificatie|UM|Nepreluat|Preiau acum|Locatie|Comanda|Document|ID_receptie|ID_pozitie", "|")
    For i = 0 To UBound(heads): ws.Cells(10, i + 1).Value2 = heads(i): Next i
    n = 11
    For Each lr In ST_Source("tTQMCFRec").ListRows
        If CStr(lr.Range.Cells(1, 7).Value2) = "Valida" Then
            Set source = ST_Receipt(CStr(lr.Range.Cells(1, 1).Value2), CStr(lr.Range.Cells(1, 2).Value2))
            qty = CDbl(source.Cells(1, 6).Value2) - ST_Allocated(CStr(source.Cells(1, 1).Value2), CStr(source.Cells(1, 2).Value2))
            If qty > 0.00000001 Then
                If n > 110 Then Exit For
                Set pos = ST_Find(ST_Source("tTQMCFPoz"), CStr(source.Cells(1, 2).Value2))
                If pos Is Nothing Then Err.Raise vbObjectError + 449, , "Receptie fara pozitie de comanda."
                ws.Cells(n, 1).Value2 = source.Cells(1, 4).Value2: ws.Cells(n, 2).Value2 = pos.Cells(1, 4).Value2
                ws.Cells(n, 3).Value2 = pos.Cells(1, 5).Value2: ws.Cells(n, 4).Value2 = pos.Cells(1, 6).Value2
                ws.Cells(n, 5).Value2 = Round(qty, 6): ws.Cells(n, 6).Value2 = 0
                Set order = ST_Find(ST_Source("tTQMComenzi"), CStr(source.Cells(1, 3).Value2))
                If order Is Nothing Then Err.Raise vbObjectError + 461, , "Receptie fara comanda asociata."
                ws.Cells(n, 8).Value2 = order.Cells(1, 2).Value2: ws.Cells(n, 9).Value2 = source.Cells(1, 5).Value2
                ws.Cells(n, 10).Value2 = source.Cells(1, 1).Value2: ws.Cells(n, 11).Value2 = source.Cells(1, 2).Value2
                ws.Cells(n, 6).Locked = False: ws.Cells(n, 7).Locked = False
                ws.Range(ws.Cells(n, 6), ws.Cells(n, 7)).Interior.Color = RGB(239, 246, 255)
                n = n + 1
            End If
        End If
    Next lr
    If n = 11 Then
    Call ST_Close:         MsgBox "Nu exista receptii valide nepreluate in stoc.", vbInformation, "TQM": Exit Sub
    End If
    ws.Columns("A").ColumnWidth = 22: ws.Columns("B:C").ColumnWidth = 28: ws.Columns("D").ColumnWidth = 9
    ws.Columns("E:F").ColumnWidth = 15: ws.Columns("G").ColumnWidth = 24: ws.Columns("H:I").ColumnWidth = 20
    ws.Columns("J:K").Hidden = True
    ws.Range("A10:I10").Interior.Color = RGB(31, 41, 55): ws.Range("A10:I10").Font.Color = vbWhite
    ws.Range("A10:I10").WrapText = True: ws.rows(10).RowHeight = 32
    ws.Range("A11:A110").NumberFormat = "dd.mm.yyyy": ws.Range("E11:F110").NumberFormat = "#,##0.######"
    ws.Range("G11:G110").NumberFormat = "@": ws.Protect UserInterfaceOnly:=True
    ActiveWindow.SplitRow = 10: ActiveWindow.SplitColumn = 1: ActiveWindow.FreezePanes = True
    ws.Range("F11").Select
    If n = 111 Then MsgBox "Sunt afisate primele 100 de pozitii nepreluate. Salvati, apoi redeschideti pentru celelalte.", vbInformation, "TQM"
    Exit Sub
Fail: ST_Error Err.description
End Sub

Public Sub ST_SalveazaReceptii()
    Dim ws As Worksheet, source As Range, pos As Range, order As Range, records As New Collection, mats As New Collection, locs As New Collection
    Dim n As Long, qty As Double, mat As String, loc As String, labelName As String, op As String, v As Variant, person As String, note As String
    On Error GoTo Fail
    If Not ST_FormOpen Then Err.Raise vbObjectError + 450, , "Formularul nu mai este deschis."
    If Not ActiveWorkbook Is mForm Or mMode <> "RECEPTII" Then Err.Raise vbObjectError + 451, , "Salvati din formularul de receptii."
    Call ST_Init:     Set ws = mForm.Worksheets(1): person = ST_Text(ws.Range("B5").Value2): note = ST_Text(ws.Range("B7").Value2)
    If Len(person) = 0 Then Err.Raise vbObjectError + 452, , "Responsabilul este obligatoriu."
    op = ST_ID("OP")
    For n = 11 To 110
        If Len(CStr(ws.Cells(n, 10).Value2)) > 0 Then
            qty = ST_Num(ws.Cells(n, 6).Value2, "Preiau acum la randul " & n)
            If qty > 0 Then
                Set source = ST_Receipt(CStr(ws.Cells(n, 10).Value2), CStr(ws.Cells(n, 11).Value2))
                If source Is Nothing Then Err.Raise vbObjectError + 453, , "Receptia nu mai este valida."
                Set pos = ST_Find(ST_Source("tTQMCFPoz"), CStr(source.Cells(1, 2).Value2))
                If pos Is Nothing Then Err.Raise vbObjectError + 454, , "Pozitia de comanda nu mai exista."
                mat = ST_Material(ST_Text(pos.Cells(1, 3).Value2), ST_Text(pos.Cells(1, 4).Value2), ST_Text(pos.Cells(1, 5).Value2), ST_Text(pos.Cells(1, 6).Value2), mats, True)
                labelName = ST_Text(ws.Cells(n, 7).Value2): If Len(labelName) = 0 Then labelName = ST_Text(ws.Range("B6").Value2)
                loc = ST_Location(labelName, locs)
                v = ST_Record(op, ST_Date(source.Cells(1, 4).Value2), "Receptie comanda", mat, loc, qty, CStr(source.Cells(1, 5).Value2), person, note)
                v(11) = source.Cells(1, 1).Value2: v(12) = source.Cells(1, 2).Value2: v(13) = source.Cells(1, 3).Value2
                v(19) = pos.Cells(1, 16).Value2: v(21) = source.Cells(1, 8).Value2
                Set order = ST_Find(ST_Source("tTQMComenzi"), CStr(source.Cells(1, 3).Value2))
                If order Is Nothing Then Err.Raise vbObjectError + 462, , "Comanda sursa nu exista."
                v(20) = order.Cells(1, 4).Value2
                records.Add v
            End If
        End If
    Next n
    ST_Commit records, mats, locs: ST_Close
    MsgBox "Receptiile au fost preluate in stoc: " & records.count & " pozitii." & vbCrLf & "Ctrl+S salveaza fisierul principal.", vbInformation, "TQM"
    Exit Sub
Fail: ST_Error Err.description
End Sub

Public Sub ST_Actualizeaza()
    On Error GoTo Fail
    Call ST_Init:     ST_Calc: ST_VerificaSurse
    Exit Sub
Fail: ST_Error Err.description
End Sub

Public Sub ST_PragMinim()
    Dim answer As Variant, row As Range, stamp As String, threshold As Double, oldE As Boolean, writing As Boolean
    Dim oldThreshold As Variant, message As String
    On Error GoTo Fail
    Call ST_Init:     ST_Calc: ST_SelectStock: Set row = ST_Stock(mMat, mLoc): stamp = ST_Stamp()
    answer = Application.InputBox("Introduceti stocul minim pentru acest material si aceasta locatie, in UM afisata. Zero dezactiveaza pragul.", "TQM - Prag minim", Default:=row.Cells(1, 8).Value2, Type:=1)
    If VarType(answer) = vbBoolean Then Exit Sub
    threshold = ST_Num(answer, "Prag minim")
    If ST_Stamp() <> stamp Then Err.Raise vbObjectError + 455, , "Datele s-au modificat. Reluati setarea pragului."
    Set row = ST_Stock(mMat, mLoc): oldThreshold = row.Cells(1, 8).Value2: oldE = Application.EnableEvents: writing = True: Application.EnableEvents = False
    row.Cells(1, 8).Value2 = threshold: ST_Calc
    Application.EnableEvents = oldE: writing = False
    Exit Sub
Fail:
    message = Err.description
    If writing Then
        On Error Resume Next
        row.Cells(1, 8).Value2 = oldThreshold
        ST_Calc
        Application.EnableEvents = oldE
        On Error GoTo 0
    End If
    ST_Error message
End Sub

Public Sub ST_Istoric()
    Dim ws As Worksheet, lr As ListRow, mat As Range, loc As Range, n As Long, heads As Variant, i As Long
    On Error GoTo Fail
    Call ST_Init:     ST_Calc: ST_SelectStock: Set mat = ST_Find(ST_Table(2), mMat)
    If mat Is Nothing Then Err.Raise vbObjectError + 456, , "Materialul nu exista."
    If Not ST_Start("ISTORIC") Then Exit Sub
    Set ws = mForm.Worksheets(1)
    ST_Band ws, "A1:L1", "TQM - Istoric: " & CStr(mat.Cells(1, 3).Value2), 16
    ST_Button ws, "A3:C3", "Inchide istoricul", "ST_InchideFormular"
    heads = Split("ID_operatie|Data|Tip|Locatie|Cantitate semnata|UM|Document|Responsabil|Stare|Proiect / Furnizor|Observatii / Anulare|Link", "|")
    For i = 0 To UBound(heads): ws.Cells(5, i + 1).Value2 = heads(i): Next i
    n = 6
    For Each lr In ST_Table(4).ListRows
        If CStr(lr.Range.Cells(1, 5).Value2) = mMat Then
            Set loc = ST_Find(ST_Table(3), CStr(lr.Range.Cells(1, 6).Value2))
            If loc Is Nothing Then Err.Raise vbObjectError + 457, , "Miscare fara locatie."
            ws.Cells(n, 1).Value2 = lr.Range.Cells(1, 2).Value2: ws.Cells(n, 2).Value2 = lr.Range.Cells(1, 3).Value2
            ws.Cells(n, 3).Value2 = lr.Range.Cells(1, 4).Value2: ws.Cells(n, 4).Value2 = loc.Cells(1, 2).Value2
            ws.Cells(n, 5).Value2 = lr.Range.Cells(1, 7).Value2: ws.Cells(n, 6).Value2 = mat.Cells(1, 5).Value2
            ws.Cells(n, 7).Value2 = lr.Range.Cells(1, 8).Value2: ws.Cells(n, 8).Value2 = lr.Range.Cells(1, 9).Value2
            ws.Cells(n, 9).Value2 = lr.Range.Cells(1, 14).Value2
            ws.Cells(n, 10).Value2 = CStr(lr.Range.Cells(1, 19).Value2) & " " & CStr(lr.Range.Cells(1, 20).Value2)
            ws.Cells(n, 11).Value2 = CStr(lr.Range.Cells(1, 10).Value2) & " " & CStr(lr.Range.Cells(1, 18).Value2)
            ws.Cells(n, 12).Value2 = lr.Range.Cells(1, 21).Value2: n = n + 1
        End If
    Next lr
    ws.Range("A5:L5").Interior.Color = RGB(31, 41, 55): ws.Range("A5:L5").Font.Color = vbWhite
    ws.Range("A5:L5").WrapText = True: ws.rows(5).RowHeight = 34
    ws.Columns("A").ColumnWidth = 42: ws.Columns("B").ColumnWidth = 14: ws.Columns("C:D").ColumnWidth = 24
    ws.Columns("E:F").ColumnWidth = 13: ws.Columns("G:J").ColumnWidth = 22: ws.Columns("K:L").ColumnWidth = 36
    ws.Range("B6:B" & n).NumberFormat = "dd.mm.yyyy": ws.Range("E6:E" & n).NumberFormat = "#,##0.######"
    If n = 6 Then ws.Range("A6").Value2 = "Nu exista miscari."
    ws.Range("A5:L" & n).AutoFilter: ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True
    ActiveWindow.SplitRow = 5: ActiveWindow.FreezePanes = True
    Exit Sub
Fail: ST_Error Err.description
End Sub

Private Function ST_VoidPlan(ByVal receipt As String, ByVal operation As String) As Collection
    Dim result As New Collection, lr As ListRow, v As Variant, match As Boolean
    For Each lr In ST_Table(4).ListRows
        match = False
        If CStr(lr.Range.Cells(1, 14).Value2) = "Valida" Then
            If Len(receipt) > 0 Then match = (CStr(lr.Range.Cells(1, 11).Value2) = receipt And CStr(lr.Range.Cells(1, 4).Value2) = "Receptie comanda")
            If Len(operation) > 0 Then match = (CStr(lr.Range.Cells(1, 2).Value2) = operation)
            If match Then
                v = ST_Array(lr.Range): v(7) = -CDbl(v(7)): result.Add v
            End If
        End If
    Next lr
    Set ST_VoidPlan = result
End Function

' Public functions below are called by the updated Comenzi furnizori module.
Public Function ST_ValidateReceiptVoid(ByVal receipt As String) As Boolean
    Dim plan As Collection
    Call ST_Init:     Set plan = ST_VoidPlan(receipt, "")
    If plan.count > 0 Then ST_Check plan
    ST_ValidateReceiptVoid = True
End Function

Public Function ST_ApplyReceiptVoid(ByVal receipt As String, ByVal reason As String) As Boolean
    Call ST_Init:     ST_Void receipt, "", "Receptie anulata in Comenzi: " & reason
    ST_ApplyReceiptVoid = True
End Function

Private Sub ST_Void(ByVal receipt As String, ByVal operation As String, ByVal reason As String)
    Dim plan As Collection, backups As Object, v As Variant, row As Range, key As Variant
    Dim oldE As Boolean, oldS As Boolean, writing As Boolean, eno As Long, msg As String
    On Error GoTo Fail
    Set plan = ST_VoidPlan(receipt, operation)
    If plan.count = 0 Then Exit Sub
    ST_Check plan: Set backups = CreateObject("Scripting.Dictionary")
    For Each v In plan
        Set row = ST_Find(ST_Table(4), CStr(v(1))): backups.Add CStr(v(1)), row.formula
    Next v
    oldE = Application.EnableEvents: oldS = Application.ScreenUpdating: writing = True
    Application.EnableEvents = False: Application.ScreenUpdating = False
    For Each v In plan
        Set row = ST_Find(ST_Table(4), CStr(v(1)))
        row.Cells(1, 14).Value2 = "Anulata": row.Cells(1, 16).Value2 = CDbl(Now)
        row.Cells(1, 17).Value2 = Application.UserName: row.Cells(1, 18).Value2 = reason
    Next v
    ST_Calc
    Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
    Exit Sub
Fail:
    eno = Err.number: msg = Err.description
    If writing Then
        On Error Resume Next
        For Each key In backups.keys
            Set row = ST_Find(ST_Table(4), CStr(key)): row.formula = backups(key)
        Next key
    Call ST_Calc:         Application.EnableEvents = oldE: Application.ScreenUpdating = oldS
        On Error GoTo 0
    End If
    Err.Raise eno, "ST_Void", msg
End Sub

Public Sub ST_AnuleazaOperatie()
    Dim answer As Variant, reason As Variant, plan As Collection, stamp As String
    On Error GoTo Fail
    Call ST_Init:     ST_Calc: stamp = ST_Stamp()
    answer = Application.InputBox("Introduceti ID_operatie din Istoric miscari. Se anuleaza toate miscarile valide ale operatiei, inclusiv ambele sensuri ale unui transfer.", "TQM - Anulare operatie", Type:=2)
    If VarType(answer) = vbBoolean Then Exit Sub
    Set plan = ST_VoidPlan("", Trim$(CStr(answer)))
    If plan.count = 0 Then Err.Raise vbObjectError + 458, , "Operatia nu exista sau este deja anulata."
    reason = Application.InputBox("Motivul anularii:", "TQM", Type:=2)
    If VarType(reason) = vbBoolean Then Exit Sub
    If Len(Trim$(CStr(reason))) = 0 Then Err.Raise vbObjectError + 459, , "Introduceti motivul anularii."
    If MsgBox("Anulati " & plan.count & " miscari ale acestei operatii? O preluare de receptii poate cuprinde mai multe materiale. Istoricul se pastreaza.", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
    If ST_Stamp() <> stamp Then Err.Raise vbObjectError + 460, , "Datele s-au modificat in timpul confirmarii. Reluati anularea."
    ST_Void "", Trim$(CStr(answer)), CStr(reason)
    MsgBox "Operatia a fost anulata. Istoricul este pastrat. Ctrl+S salveaza fisierul.", vbInformation, "TQM"
    Exit Sub
Fail: ST_Error Err.description
End Sub

Private Function ST_NMMaterial(ByVal code As String, ByVal labelName As String, ByVal spec As String, ByVal unit As String, ByVal historical As Boolean) As String
    Dim ws As Worksheet
    Set ws = ST_GetSheet("06_NOMENCLATOARE")
    If ws Is Nothing Then Exit Function
    ST_NMMaterial = CStr(Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_ResolveMaterial", code, labelName, spec, unit, historical))
End Function
Private Function ST_NMLocation(ByVal labelName As String) As String
    Dim ws As Worksheet
    Set ws = ST_GetSheet("06_NOMENCLATOARE")
    If ws Is Nothing Then Exit Function
    ST_NMLocation = CStr(Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_ResolveLocation", labelName))
End Function
Private Function ST_NMStamp() As String
    Dim ws As Worksheet
    Set ws = ST_GetSheet("06_NOMENCLATOARE")
    If ws Is Nothing Then Exit Function
    ST_NMStamp = CStr(Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!NM_Stamp"))
End Function

Private Function ST_SLParam(ByVal key As String, ByVal fallback As Variant) As Variant
    Dim ws As Worksheet
    Set ws = ST_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then
        ST_SLParam = fallback
    Else
        ST_SLParam = Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_Param", key, fallback)
    End If
End Function
Private Sub ST_SLList(ByVal target As Range, ByVal group As String)
    Dim ws As Worksheet
    Set ws = ST_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then Exit Sub
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_ApplyList", target, group
End Sub
Private Sub ST_SLCheck(ByVal group As String, ByVal value As String)
    Dim ws As Worksheet
    Set ws = ST_GetSheet("07_SETARI_LISTE")
    If ws Is Nothing Then Exit Sub
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_CheckValue", group, value
End Sub

Private Sub ST_DOCSync()
    On Error Resume Next
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!DOC_Sync"
    On Error GoTo 0
End Sub



Public Sub ST_RFQRefresh()
    ST_Init
    ST_Calc
End Sub
