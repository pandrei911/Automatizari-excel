Attribute VB_Name = "Module4"
Option Explicit

' RFQ v2: parent requests and commercial documents supplement the original IDs.
Private mRXForm As Workbook
Private mRXKind As String
Private mRXID As String
Private mRXParent As String
Private mRXStamp As String
Private mRXBackup As Collection
Private mRXInserted As Collection
Private mRXProtection As Collection
Private mRXEvents As Boolean
Private mRXScreen As Boolean
Private mRXWriting As Boolean
Private mRXBusy As Boolean
Private mRXTables As Object
Private mRXIndexes As Object


Private Const CO_SHEET As String = "02_CERERI_SI_OFERTE"
Private Const CO_REQ As String = "tTQMCereri"
Private Const CO_OFF As String = "tTQMOferte"
Private Const CO_MARK As String = "TQM_CERERI_OFERTE_V1"

' Local dialog inputs are collected before any shared record is written.
' Record IDs stay stable after sorting. Changed records are checked again before writing.
' Install with TQM_CO_Instaleaza. Do not remove any existing TQM module.

Public Sub TQM_CO_Instaleaza()
    Dim ws As Worksheet, req As ListObject, offers As ListObject
    Dim oldEvents As Boolean, oldScreen As Boolean, message As String
    oldEvents = Application.EnableEvents
    oldScreen = Application.ScreenUpdating
    On Error GoTo Failed
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Set ws = CO_GetSheet()
    If ws Is Nothing Then
        If ThisWorkbook.ProtectStructure Then Err.Raise vbObjectError + 1201, , "Structura fisierului este protejata."
        Set ws = ThisWorkbook.Worksheets.Add(after:=ThisWorkbook.Worksheets("Control_Achizitii"))
        ws.name = CO_SHEET
        CO_Layout ws
        CO_CreateTables ws
        ws.Range("AF1").Value2 = CO_MARK
  Else
    If CStr(ws.Range("AF1").Value2) <> CO_MARK Then
        If Len(CStr(ws.Range("AF1").Value2)) > 0 Then
            Err.Raise vbObjectError + 1202, , _
                "Marcaj diferit in AF1: " & CStr(ws.Range("AF1").Value2)
        End If
    End If

    If ws.ProtectContents Then
        Err.Raise vbObjectError + 1203, , _
            "Foaia este protejata."
    End If

    If ws.ListObjects.count = 0 Then

        If Application.WorksheetFunction.CountA( _
            ws.Range("A23:AC" & ws.rows.count)) > 0 Then

            Err.Raise vbObjectError + 1208, , _
                "Exista valori in zona registrelor. Initializarea a fost oprita pentru a pastra datele."
        End If

        If ThisWorkbook.ProtectStructure Then
            Err.Raise vbObjectError + 1201, , _
                "Structura fisierului este protejata."
        End If

        ' Pastreaza o copie completa inainte de reconstruire.
        ws.Copy after:=ThisWorkbook.Worksheets( _
            ThisWorkbook.Worksheets.count)

        ActiveSheet.name = "CO_backup_" & _
            Format$(Now, "yyyymmdd_hhnnss")

        ' Pregateste zona pentru interfata si tabele.
        ws.Range("A1:AC48").UnMerge
        ws.Range("A1:AC48").ClearContents

        Call CO_Layout(ws)
        Call CO_CreateTables(ws)

        ws.Range("C9").Value2 = ""
    End If

    Set req = CO_Table(CO_REQ)
    Set offers = CO_Table(CO_OFF)
    Call CO_CheckSchema(req, offers)

    ws.Range("AF1").Value2 = CO_MARK
End If
    If ws.ProtectContents Then Err.Raise vbObjectError + 1203, , "Foaia este protejata."
    Application.EnableEvents = False
    Application.ScreenUpdating = False
    Set req = CO_Table(CO_REQ)
    Set offers = CO_Table(CO_OFF)
    CO_CheckSchema req, offers
    CO_RefreshCore
    CO_Buttons ws
    CO_ConnectDashboard
    ThisWorkbook.Activate
    ws.Activate
    ActiveWindow.DisplayGridlines = False
    ActiveWindow.FreezePanes = False
    ActiveWindow.SplitColumn = 0
    ActiveWindow.SplitRow = 0
    ws.Range("C4").Select
    ActiveWindow.FreezePanes = True
    ActiveWindow.Zoom = 85
    ws.Columns("U:AG").Hidden = True
    ws.Range("C9").Select
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    MsgBox "Cereri si oferte este pregatit. Adaugati cererea, apoi ofertele ei.", vbInformation, "TQM Calarasi"
    Exit Sub
Failed:
    message = Err.description
    Application.EnableEvents = oldEvents
    Application.ScreenUpdating = oldScreen
    MsgBox message, vbExclamation, "TQM Calarasi"
End Sub

Private Function CO_GetSheet() As Worksheet
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If ws.name = CO_SHEET Then Set CO_GetSheet = ws: Exit Function
    Next ws
End Function

Private Function CO_Table(ByVal tableName As String) As ListObject
    Dim ws As Worksheet, tbl As ListObject
    Set ws = CO_GetSheet()
    If ws Is Nothing Then Err.Raise vbObjectError + 1204, , "Rulati TQM_CO_Instaleaza mai intai."
    For Each tbl In ws.ListObjects
        If tbl.name = tableName Then Set CO_Table = tbl: Exit Function
    Next tbl
    Err.Raise vbObjectError + 1205, , "Lipseste tabelul " & tableName & "."
End Function

Private Sub CO_Layout(ByVal ws As Worksheet)
    ws.Range("A2:L2").Merge
    ws.Range("A3:B3").Merge
    ws.Range("C3:D3").Merge
    ws.Range("E3:F3").Merge
    ws.Range("G3:H3").Merge
    ws.Range("I3:J3").Merge
    ws.Range("K3:L3").Merge
    ws.Range("A5:C5").Merge
    ws.Range("A6:C7").Merge
    ws.Range("D5:F5").Merge
    ws.Range("D6:F7").Merge
    ws.Range("G5:I5").Merge
    ws.Range("G6:I7").Merge
    ws.Range("J5:L5").Merge
    ws.Range("J6:L7").Merge
    ws.Range("A9:B9").Merge
    ws.Range("C9:F9").Merge
    ws.Range("G9:L9").Merge
    ws.Range("A10:L10").Merge
    ws.Range("A12:B12").Merge
    ws.Range("C12:D12").Merge
    ws.Range("E12:F12").Merge
    ws.Range("G12:H12").Merge
    ws.Range("I12:J12").Merge
    ws.Range("K12:L12").Merge
    ws.Range("A13:B13").Merge
    ws.Range("C13:D13").Merge
    ws.Range("E13:F13").Merge
    ws.Range("G13:H13").Merge
    ws.Range("I13:J13").Merge
    ws.Range("K13:L13").Merge
    ws.Range("A14:B14").Merge
    ws.Range("C14:D14").Merge
    ws.Range("E14:F14").Merge
    ws.Range("G14:H14").Merge
    ws.Range("I14:J14").Merge
    ws.Range("K14:L14").Merge
    ws.Range("A15:B15").Merge
    ws.Range("C15:D15").Merge
    ws.Range("E15:F15").Merge
    ws.Range("G15:H15").Merge
    ws.Range("I15:J15").Merge
    ws.Range("K15:L15").Merge
    ws.Range("A16:B16").Merge
    ws.Range("C16:D16").Merge
    ws.Range("E16:F16").Merge
    ws.Range("G16:H16").Merge
    ws.Range("I16:J16").Merge
    ws.Range("K16:L16").Merge
    ws.Range("A17:B17").Merge
    ws.Range("C17:D17").Merge
    ws.Range("E17:F17").Merge
    ws.Range("G17:H17").Merge
    ws.Range("I17:J17").Merge
    ws.Range("K17:L17").Merge
    ws.Range("A18:B18").Merge
    ws.Range("C18:D18").Merge
    ws.Range("E18:F18").Merge
    ws.Range("G18:H18").Merge
    ws.Range("I18:J18").Merge
    ws.Range("K18:L18").Merge
    ws.Range("A20:L20").Merge
    ws.Range("A22:L22").Merge
    ws.Range("A34:L34").Merge
    ws.Range("A2").Value2 = "TQM Calarasi - Cereri si oferte"
    ws.Range("A3").Value2 = "Cerere noua"
    ws.Range("C3").Value2 = "Oferta noua"
    ws.Range("E3").Value2 = "Aproba oferta"
    ws.Range("G3").Value2 = "Compara"
    ws.Range("I3").Value2 = "Actualizeaza"
    ws.Range("K3").Value2 = "Dashboard"
    ws.Range("A5").Value2 = "Cereri"
    ws.Range("A6").Value2 = ""
    ws.Range("D5").Value2 = "De ofertat"
    ws.Range("D6").Value2 = ""
    ws.Range("G5").Value2 = "De aprobat"
    ws.Range("G6").Value2 = ""
    ws.Range("J5").Value2 = "Aprobate"
    ws.Range("J6").Value2 = ""
    ws.Range("A9").Value2 = "ID cerere"
    ws.Range("C9").Value2 = ""
    ws.Range("G9").Value2 = ""
    ws.Range("A10").Value2 = "Cost total fara TVA, in RON. Primele 6 oferte dupa cost; ofertele necomparabile au motivul afisat."
    ws.Range("A12").Value2 = "ID oferta"
    ws.Range("C12").Value2 = "Furnizor"
    ws.Range("E12").Value2 = "Total RON"
    ws.Range("G12").Value2 = "Livrare"
    ws.Range("I12").Value2 = "Comparabila?"
    ws.Range("K12").Value2 = "Motiv / recomandare"
    ws.Range("A13").Value2 = ""
    ws.Range("C13").Value2 = ""
    ws.Range("E13").Value2 = ""
    ws.Range("G13").Value2 = ""
    ws.Range("I13").Value2 = ""
    ws.Range("K13").Value2 = ""
    ws.Range("A14").Value2 = ""
    ws.Range("C14").Value2 = ""
    ws.Range("E14").Value2 = ""
    ws.Range("G14").Value2 = ""
    ws.Range("I14").Value2 = ""
    ws.Range("K14").Value2 = ""
    ws.Range("A15").Value2 = ""
    ws.Range("C15").Value2 = ""
    ws.Range("E15").Value2 = ""
    ws.Range("G15").Value2 = ""
    ws.Range("I15").Value2 = ""
    ws.Range("K15").Value2 = ""
    ws.Range("A16").Value2 = ""
    ws.Range("C16").Value2 = ""
    ws.Range("E16").Value2 = ""
    ws.Range("G16").Value2 = ""
    ws.Range("I16").Value2 = ""
    ws.Range("K16").Value2 = ""
    ws.Range("A17").Value2 = ""
    ws.Range("C17").Value2 = ""
    ws.Range("E17").Value2 = ""
    ws.Range("G17").Value2 = ""
    ws.Range("I17").Value2 = ""
    ws.Range("K17").Value2 = ""
    ws.Range("A18").Value2 = ""
    ws.Range("C18").Value2 = ""
    ws.Range("E18").Value2 = ""
    ws.Range("G18").Value2 = ""
    ws.Range("I18").Value2 = ""
    ws.Range("K18").Value2 = ""
    ws.Range("A20").Value2 = "Recomandarea propune costul minim eligibil. Aprobarea se inregistreaza separat."
    ws.Range("A22").Value2 = "Registru cereri - o pozitie pentru fiecare material"
    ws.Range("A34").Value2 = "Registru oferte - legatura prin ID_cerere"
    ws.Range("AF1").Value2 = "TQM_CERERI_OFERTE_V1"
    ws.Range("C9").Value2 = "CER-TEST-1"
    With ws.Range("A1:AC48")
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .Interior.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
        .RowHeight = 23
    End With
    With ws.Range("A1:A48")
        .ColumnWidth = 22
    End With
    With ws.Range("B1:B48")
        .ColumnWidth = 14
    End With
    With ws.Range("C1:C48")
        .ColumnWidth = 23
    End With
    With ws.Range("D1:D48")
        .ColumnWidth = 15
    End With
    With ws.Range("E1:E48")
        .ColumnWidth = 10
    End With
    With ws.Range("F1:F48")
        .ColumnWidth = 14
    End With
    With ws.Range("G1:G48")
        .ColumnWidth = 14
    End With
    With ws.Range("H1:H48")
        .ColumnWidth = 15
    End With
    With ws.Range("I1:I48")
        .ColumnWidth = 14
    End With
    With ws.Range("J1:J48")
        .ColumnWidth = 13
    End With
    With ws.Range("K1:K48")
        .ColumnWidth = 24
    End With
    With ws.Range("L1:L48")
        .ColumnWidth = 28
    End With
    With ws.Range("M1:T48")
        .ColumnWidth = 24
    End With
    With ws.Range("U1:AC48")
        .ColumnWidth = 12
    End With
    With ws.Range("A2:L2")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 20
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A2:L2")
        .Font.name = "Aptos Display"
        .Font.size = 20
        .Font.Bold = True
        .Font.Color = RGB(31, 41, 55)
        .RowHeight = 34
    End With
    With ws.Range("A3:B3")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("C3:D3")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("E3:F3")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G3:H3")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("I3:J3")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("K3:L3")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A5:C5")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A6:C7")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 22
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A6:C7")
        .Font.name = "Aptos Display"
        .Font.size = 22
        .Font.Bold = True
        .Font.Color = RGB(29, 78, 216)
        .Interior.Color = RGB(239, 246, 255)
        .NumberFormat = "0"
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("D5:F5")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("D6:F7")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 22
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("D6:F7")
        .Font.name = "Aptos Display"
        .Font.size = 22
        .Font.Bold = True
        .Font.Color = RGB(29, 78, 216)
        .Interior.Color = RGB(239, 246, 255)
        .NumberFormat = "0"
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("G5:I5")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G6:I7")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 22
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G6:I7")
        .Font.name = "Aptos Display"
        .Font.size = 22
        .Font.Bold = True
        .Font.Color = RGB(29, 78, 216)
        .Interior.Color = RGB(239, 246, 255)
        .NumberFormat = "0"
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("J5:L5")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("J6:L7")
        .Interior.Color = RGB(239, 246, 255)
        .Font.name = "Aptos"
        .Font.size = 22
        .Font.Color = RGB(29, 78, 216)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("J6:L7")
        .Font.name = "Aptos Display"
        .Font.size = 22
        .Font.Bold = True
        .Font.Color = RGB(29, 78, 216)
        .Interior.Color = RGB(239, 246, 255)
        .NumberFormat = "0"
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("A9:B9")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("C9:F9")
        .Interior.Color = RGB(254, 243, 199)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G9:L9")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A10:L10")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(107, 114, 128)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A12:B12")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A12:B12")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("C12:D12")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("C12:D12")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("E12:F12")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("E12:F12")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("G12:H12")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G12:H12")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("I12:J12")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("I12:J12")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("K12:L12")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(255, 255, 255)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("K12:L12")
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("A13:B13")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("C13:D13")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("E13:F13")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G13:H13")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("I13:J13")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("K13:L13")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A13:L13")
        .RowHeight = 38
        .WrapText = True
    End With
    With ws.Range("E13:F13")
        .NumberFormat = "#,##0.00"
    End With
    With ws.Range("G13:H13")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("A14:B14")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("C14:D14")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("E14:F14")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G14:H14")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("I14:J14")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("K14:L14")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A14:L14")
        .RowHeight = 38
        .WrapText = True
    End With
    With ws.Range("E14:F14")
        .NumberFormat = "#,##0.00"
    End With
    With ws.Range("G14:H14")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("A15:B15")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("C15:D15")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("E15:F15")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G15:H15")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("I15:J15")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("K15:L15")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A15:L15")
        .RowHeight = 38
        .WrapText = True
    End With
    With ws.Range("E15:F15")
        .NumberFormat = "#,##0.00"
    End With
    With ws.Range("G15:H15")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("A16:B16")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("C16:D16")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("E16:F16")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G16:H16")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("I16:J16")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("K16:L16")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A16:L16")
        .RowHeight = 38
        .WrapText = True
    End With
    With ws.Range("E16:F16")
        .NumberFormat = "#,##0.00"
    End With
    With ws.Range("G16:H16")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("A17:B17")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("C17:D17")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("E17:F17")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G17:H17")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("I17:J17")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("K17:L17")
        .Interior.Color = RGB(248, 250, 252)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A17:L17")
        .RowHeight = 38
        .WrapText = True
    End With
    With ws.Range("E17:F17")
        .NumberFormat = "#,##0.00"
    End With
    With ws.Range("G17:H17")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("A18:B18")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("C18:D18")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("E18:F18")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("G18:H18")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("I18:J18")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("K18:L18")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 11
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A18:L18")
        .RowHeight = 38
        .WrapText = True
    End With
    With ws.Range("E18:F18")
        .NumberFormat = "#,##0.00"
    End With
    With ws.Range("G18:H18")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("A20:L20")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Color = RGB(107, 114, 128)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A22:L22")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 12
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("A34:L34")
        .Interior.Color = RGB(255, 255, 255)
        .Font.name = "Aptos"
        .Font.size = 12
        .Font.Color = RGB(31, 41, 55)
        .VerticalAlignment = xlCenter
        .WrapText = True
    End With
    With ws.Range("B24:B28")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("G24:G28")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("R24:R28")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("W24:W28")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("H37:I46")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("N37:N46")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("X37:X46")
        .NumberFormat = "dd.mm.yyyy"
    End With
    With ws.Range("J24:J28")
        .NumberFormat = "#,##0.00"
    End With
    With ws.Range("O24:O28")
        .NumberFormat = "#,##0.00"
    End With
    With ws.Range("F37:G46")
        .NumberFormat = "#,##0.00"
    End With
    With ws.Range("P37:Q46")
        .NumberFormat = "#,##0.00"
    End With
    With ws.Range("O37:O46")
        .NumberFormat = "0.0%"
    End With
    With ws.Range("A23:X23")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .RowHeight = 35
        .WrapText = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("A36:AC36")
        .Interior.Color = RGB(31, 41, 55)
        .Font.name = "Aptos"
        .Font.size = 10
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .RowHeight = 35
        .WrapText = True
        .HorizontalAlignment = xlCenter
    End With
    With ws.Range("A24:X28")
        .RowHeight = 44
        .WrapText = True
    End With
    With ws.Range("A37:AC46")
        .RowHeight = 44
        .WrapText = True
    End With
    With ws.Range("A24:H28")
        .Interior.Color = RGB(255, 251, 235)
    End With
    With ws.Range("M24:T28")
        .Interior.Color = RGB(255, 251, 235)
    End With
    With ws.Range("A37:F46")
        .Interior.Color = RGB(255, 251, 235)
    End With
    With ws.Range("H37:J46")
        .Interior.Color = RGB(255, 251, 235)
    End With
    With ws.Range("M37:U46")
        .Interior.Color = RGB(255, 251, 235)
    End With
End Sub

Private Sub CO_CreateTables(ByVal ws As Worksheet)
    Dim tbl As ListObject, headers As Variant, i As Long
    headers = Array( _
        "ID_cerere", "Data_cerere", "Proiect", "Material", "UM", _
        "Cantitate", "Data_necesara", "Prioritate", "Oferte_valide", "Cost_min", _
        "Furnizor_recom", "Status", "Specificatie", "Solicitant", "Buget_RON", _
        "ID_oferta_aprobata", "Aprobat_de", "Data_aprobarii", "Motiv_decizie", "Observatii", _
        "Amprenta_aprobarii", "Creat_de", "Actualizat_la", "Amprenta_cerere")
    For i = LBound(headers) To UBound(headers)
        ws.Cells(23, i + 1).Value2 = headers(i)
    Next i
    Set tbl = ws.ListObjects.Add(xlSrcRange, ws.Range("A23:X28"), , xlYes)
    tbl.name = CO_REQ
    tbl.TableStyle = "TableStyleMedium2"
    headers = Array( _
        "ID_oferta", "ID_cerere", "Furnizor", "Cantitate", "UM", _
        "Pret_unitar", "Total_RON", "Data_livrare", "Valabila_pana", "Conform_tehnic", _
        "Eligibila", "Motiv", "Nr_oferta", "Data_oferta", "Discount_pct", _
        "Transport_RON", "Alte_costuri_RON", "Conditii_plata", "Garantie", "Link_oferta", _
        "Observatii", "Amprenta_oferta", "Creat_de", "Actualizat_la", "Rang_cost", _
        "Cheie_cost", "Rang_eligibil", "Cheie_min", "Cost_sortare")
    For i = LBound(headers) To UBound(headers)
        ws.Cells(36, i + 1).Value2 = headers(i)
    Next i
    Set tbl = ws.ListObjects.Add(xlSrcRange, ws.Range("A36:AC46"), , xlYes)
    tbl.name = CO_OFF
    tbl.TableStyle = "TableStyleMedium2"
End Sub

Private Sub CO_CheckSchema(ByVal req As ListObject, ByVal offers As ListObject)
    If req.ListColumns.count <> 24 Then Err.Raise vbObjectError + 1206, , "Numarul coloanelor difera in " & req.name
    If req.ListColumns(1).name <> "ID_cerere" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "ID_cerere"
    If req.ListColumns(2).name <> "Data_cerere" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Data_cerere"
    If req.ListColumns(3).name <> "Proiect" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Proiect"
    If req.ListColumns(4).name <> "Material" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Material"
    If req.ListColumns(5).name <> "UM" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "UM"
    If req.ListColumns(6).name <> "Cantitate" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Cantitate"
    If req.ListColumns(7).name <> "Data_necesara" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Data_necesara"
    If req.ListColumns(8).name <> "Prioritate" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Prioritate"
    If req.ListColumns(9).name <> "Oferte_valide" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Oferte_valide"
    If req.ListColumns(10).name <> "Cost_min" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Cost_min"
    If req.ListColumns(11).name <> "Furnizor_recom" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Furnizor_recom"
    If req.ListColumns(12).name <> "Status" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Status"
    If req.ListColumns(13).name <> "Specificatie" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Specificatie"
    If req.ListColumns(14).name <> "Solicitant" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Solicitant"
    If req.ListColumns(15).name <> "Buget_RON" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Buget_RON"
    If req.ListColumns(16).name <> "ID_oferta_aprobata" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "ID_oferta_aprobata"
    If req.ListColumns(17).name <> "Aprobat_de" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Aprobat_de"
    If req.ListColumns(18).name <> "Data_aprobarii" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Data_aprobarii"
    If req.ListColumns(19).name <> "Motiv_decizie" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Motiv_decizie"
    If req.ListColumns(20).name <> "Observatii" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Observatii"
    If req.ListColumns(21).name <> "Amprenta_aprobarii" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Amprenta_aprobarii"
    If req.ListColumns(22).name <> "Creat_de" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Creat_de"
    If req.ListColumns(23).name <> "Actualizat_la" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Actualizat_la"
    If req.ListColumns(24).name <> "Amprenta_cerere" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Amprenta_cerere"
    If offers.ListColumns.count <> 29 Then Err.Raise vbObjectError + 1206, , "Numarul coloanelor difera in " & offers.name
    If offers.ListColumns(1).name <> "ID_oferta" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "ID_oferta"
    If offers.ListColumns(2).name <> "ID_cerere" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "ID_cerere"
    If offers.ListColumns(3).name <> "Furnizor" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Furnizor"
    If offers.ListColumns(4).name <> "Cantitate" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Cantitate"
    If offers.ListColumns(5).name <> "UM" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "UM"
    If offers.ListColumns(6).name <> "Pret_unitar" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Pret_unitar"
    If offers.ListColumns(7).name <> "Total_RON" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Total_RON"
    If offers.ListColumns(8).name <> "Data_livrare" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Data_livrare"
    If offers.ListColumns(9).name <> "Valabila_pana" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Valabila_pana"
    If offers.ListColumns(10).name <> "Conform_tehnic" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Conform_tehnic"
    If offers.ListColumns(11).name <> "Eligibila" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Eligibila"
    If offers.ListColumns(12).name <> "Motiv" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Motiv"
    If offers.ListColumns(13).name <> "Nr_oferta" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Nr_oferta"
    If offers.ListColumns(14).name <> "Data_oferta" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Data_oferta"
    If offers.ListColumns(15).name <> "Discount_pct" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Discount_pct"
    If offers.ListColumns(16).name <> "Transport_RON" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Transport_RON"
    If offers.ListColumns(17).name <> "Alte_costuri_RON" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Alte_costuri_RON"
    If offers.ListColumns(18).name <> "Conditii_plata" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Conditii_plata"
    If offers.ListColumns(19).name <> "Garantie" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Garantie"
    If offers.ListColumns(20).name <> "Link_oferta" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Link_oferta"
    If offers.ListColumns(21).name <> "Observatii" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Observatii"
    If offers.ListColumns(22).name <> "Amprenta_oferta" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Amprenta_oferta"
    If offers.ListColumns(23).name <> "Creat_de" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Creat_de"
    If offers.ListColumns(24).name <> "Actualizat_la" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Actualizat_la"
    If offers.ListColumns(25).name <> "Rang_cost" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Rang_cost"
    If offers.ListColumns(26).name <> "Cheie_cost" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Cheie_cost"
    If offers.ListColumns(27).name <> "Rang_eligibil" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Rang_eligibil"
    If offers.ListColumns(28).name <> "Cheie_min" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Cheie_min"
    If offers.ListColumns(29).name <> "Cost_sortare" Then Err.Raise vbObjectError + 1207, , "Antet modificat: " & "Cost_sortare"
End Sub

Public Sub TQM_CO_Actualizeaza()
    On Error GoTo Failed
    CO_RefreshCore
    Exit Sub
Failed:
    MsgBox Err.description, vbExclamation, "TQM Calarasi"
End Sub

Private Sub CO_RefreshCore()
    Dim ws As Worksheet, req As ListObject, offers As ListObject, firstOffer As Long
    Set ws = CO_GetSheet()
    Set req = CO_Table(CO_REQ)
    Set offers = CO_Table(CO_OFF)
    CO_CheckSchema req, offers
    firstOffer = offers.DataBodyRange.row
    CO_FormulaColumn offers, "Total_RON", "=IF(IF(ISBLANK([@ID_oferta]),"""",[@ID_oferta])="""","""",IF(AND(ISNUMBER([@Cantitate]),N([@Cantitate])>0,ISNUMBER([@Pret_unitar]),N([@Pret_unitar])>=0,ISNUMBER([@Discount_pct]),N([@Discount_pct])>=0,N([@Discount_pct])<=1,ISNUMBER([@Transport_RON]),N([@Transport_RON])>=0,ISNUMBER([@Alte_costuri_RON]),N([@Alte_costuri_RON])>=0),ROUND([@Cantitate]*[@Pret_unitar]*(1-[@Discount_pct])+[@Transport_RON]+[@Alte_costuri_RON],2),""DATE INVALIDE""))", firstOffer
    CO_FormulaColumn offers, "Motiv", _
        "=IF(IF(ISBLANK([@ID_oferta]),"""",[@ID_oferta])="""","""",IF(COUNTIFS(tTQMOferte[ID_oferta],IF(ISBLANK([@ID_oferta]),"""",[@ID_oferta]))<>1,""ID oferta duplicat"",IF(COUNTIFS(tTQMCereri[ID_cerere],IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]))<>1,""Cerere inexistenta / duplicata"",IF(NOT(AND(ISNUMBER([@Total_RON]),LEN(IF(ISBLANK([@Furnizor]),"""",[@Furnizor])&"""")>0,ISNUMBER([@Data_oferta]),ISNUMBER([@Valabila_pana]),ISNUMBER([@Data_livrare]),N([@Data_oferta])<=TODAY(),N([@Valabila_pana])>=N([@Data_oferta]),N([@Data_livrare])>=N([@Data_oferta]))),""Date / costuri invalide"",IF(OR(NOT(ISNUMBER(INDEX(tTQMCereri[Cant" & _
        "itate],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))),NOT(ISNUMBER(INDEX(tTQMCereri[Data_necesara],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))))),""Cerere incompleta"",IF(OR([@Cantitate]<>INDEX(tTQMCereri[Cantitate],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)),[@UM]<>INDEX(tTQMCereri[UM],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),""Cantitate / UM diferite"",IF(IF(ISBLANK([@Conform_tehnic]),"""",[@Conform_tehnic])<>""Da"",IF(IF(ISBLANK([@Conform_tehnic]),"""",[@Conform_tehnic])=""Nu"",""Neconform tehnic"",""Conformitate de verificat""),IF([@Valabila_pana]<TODAY(),""Oferta expirata"",IF([@Data_livrare]<TODAY(" & _
        "),""Livrarea a trecut"",IF([@Data_livrare]>INDEX(tTQMCereri[Data_necesara],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)),""Livrare intarziata"",""OK""))))))))))", firstOffer
    CO_FormulaColumn offers, "Eligibila", "=IF(IF(ISBLANK([@ID_oferta]),"""",[@ID_oferta])="""","""",IF([@Motiv]=""OK"",1,0))", firstOffer
    CO_FormulaColumn offers, "Cost_sortare", "=IF(ISNUMBER([@Total_RON]),[@Total_RON],1E+99)", firstOffer
    CO_FormulaColumn offers, "Rang_cost", "=IF(IF(ISBLANK([@ID_oferta]),"""",[@ID_oferta])="""",0,COUNTIFS(tTQMOferte[ID_cerere],IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]),tTQMOferte[Cost_sortare],""<""&[@Cost_sortare])+COUNTIFS($B$37:B37,IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]),$AC$37:AC37,[@Cost_sortare]))", firstOffer
    CO_FormulaColumn offers, "Cheie_cost", "=IF(IF(ISBLANK([@ID_oferta]),"""",[@ID_oferta])="""","""",[@ID_cerere]&""#""&[@Rang_cost])", firstOffer
    CO_FormulaColumn offers, "Rang_eligibil", "=IF([@Eligibila]<>1,0,COUNTIFS(tTQMOferte[ID_cerere],IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]),tTQMOferte[Eligibila],1,tTQMOferte[Total_RON],""<""&[@Total_RON])+COUNTIFS($B$37:B37,IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]),$K$37:K37,1,$G$37:G37,[@Total_RON]))", firstOffer
    CO_FormulaColumn offers, "Cheie_min", "=IF([@Rang_eligibil]=1,[@ID_cerere],"""")", firstOffer
    CO_FormulaColumn offers, "Amprenta_oferta", _
        "=IF(OR(IF(ISBLANK([@ID_oferta]),"""",[@ID_oferta])="""",COUNTIFS(tTQMCereri[ID_cerere],IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]))<>1),"""",LEN(IF(ISBLANK([@ID_oferta]),"""",[@ID_oferta])&"""")&"":""&IF(ISBLANK([@ID_oferta]),"""",[@ID_oferta])&""|""&LEN(IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere])&"""")&"":""&IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere])&""|""&LEN(IF(ISBLANK([@Furnizor]),"""",[@Furnizor])&"""")&"":""&IF(ISBLANK([@Furnizor]),"""",[@Furnizor])&""|""&LEN(IF(ISBLANK([@Cantitate]),"""",[@Cantitate])&"""")&"":""&IF(ISBLANK([@Cantitate]),"""",[@Cantitate])&""|""&LEN(IF(ISBLANK([@UM]),"""",[@UM])&"""")&"":""&IF(ISBLANK([@UM]),"""",[@UM])&""|""" & _
        "&LEN(IF(ISBLANK([@Pret_unitar]),"""",[@Pret_unitar])&"""")&"":""&IF(ISBLANK([@Pret_unitar]),"""",[@Pret_unitar])&""|""&LEN(IF(ISBLANK([@Data_livrare]),"""",[@Data_livrare])&"""")&"":""&IF(ISBLANK([@Data_livrare]),"""",[@Data_livrare])&""|""&LEN(IF(ISBLANK([@Valabila_pana]),"""",[@Valabila_pana])&"""")&"":""&IF(ISBLANK([@Valabila_pana]),"""",[@Valabila_pana])&""|""&LEN(IF(ISBLANK([@Conform_tehnic]),"""",[@Conform_tehnic])&"""")&"":""&IF(ISBLANK([@Conform_tehnic]),"""",[@Conform_tehnic])&""|""&LEN(IF(ISBLANK([@Nr_oferta]),"""",[@Nr_oferta])&"""")&"":""&IF(ISBLANK([@Nr_oferta]),"""",[@Nr_oferta])&""|""&LEN(IF(ISBLANK([@Data_oferta]),"""",[@Data_of" & _
        "erta])&"""")&"":""&IF(ISBLANK([@Data_oferta]),"""",[@Data_oferta])&""|""&LEN(IF(ISBLANK([@Discount_pct]),"""",[@Discount_pct])&"""")&"":""&IF(ISBLANK([@Discount_pct]),"""",[@Discount_pct])&""|""&LEN(IF(ISBLANK([@Transport_RON]),"""",[@Transport_RON])&"""")&"":""&IF(ISBLANK([@Transport_RON]),"""",[@Transport_RON])&""|""&LEN(IF(ISBLANK([@Alte_costuri_RON]),"""",[@Alte_costuri_RON])&"""")&"":""&IF(ISBLANK([@Alte_costuri_RON]),"""",[@Alte_costuri_RON])&""|""&LEN(IF(ISBLANK([@Conditii_plata]),"""",[@Conditii_plata])&"""")&"":""&IF(ISBLANK([@Conditii_plata]),"""",[@Conditii_plata])&""|""&LEN(IF(ISBLANK([@Garantie]),"""",[@Garantie])&"""")&"":""&IF(ISBL" & _
        "ANK([@Garantie]),"""",[@Garantie])&""|""&LEN(IF(ISBLANK([@Link_oferta]),"""",[@Link_oferta])&"""")&"":""&IF(ISBLANK([@Link_oferta]),"""",[@Link_oferta])&""|""&LEN(IF(ISBLANK(INDEX(tTQMCereri[Proiect],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Proiect],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&"""")&"":""&IF(ISBLANK(INDEX(tTQMCereri[Proiect],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Proiect],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&""|""&LEN(IF(ISBLANK(INDEX(tTQMCereri[Material],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Material],MATCH" & _
        "([@ID_cerere],tTQMCereri[ID_cerere],0)))&"""")&"":""&IF(ISBLANK(INDEX(tTQMCereri[Material],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Material],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&""|""&LEN(IF(ISBLANK(INDEX(tTQMCereri[UM],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[UM],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&"""")&"":""&IF(ISBLANK(INDEX(tTQMCereri[UM],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[UM],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&""|""&LEN(IF(ISBLANK(INDEX(tTQMCereri[Cantitate],MATCH([@ID_cerere],tTQMCereri[ID" & _
        "_cerere],0))),"""",INDEX(tTQMCereri[Cantitate],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&"""")&"":""&IF(ISBLANK(INDEX(tTQMCereri[Cantitate],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Cantitate],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&""|""&LEN(IF(ISBLANK(INDEX(tTQMCereri[Data_necesara],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Data_necesara],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&"""")&"":""&IF(ISBLANK(INDEX(tTQMCereri[Data_necesara],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Data_necesara],MATCH([@ID_cerere],tTQMCereri" & _
        "[ID_cerere],0)))&""|""&LEN(IF(ISBLANK(INDEX(tTQMCereri[Specificatie],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Specificatie],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&"""")&"":""&IF(ISBLANK(INDEX(tTQMCereri[Specificatie],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Specificatie],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&""|""&LEN(IF(ISBLANK(INDEX(tTQMCereri[Buget_RON],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Buget_RON],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0)))&"""")&"":""&IF(ISBLANK(INDEX(tTQMCereri[Buget_RON],MATCH([@ID_cer" & _
        "ere],tTQMCereri[ID_cerere],0))),"""",INDEX(tTQMCereri[Buget_RON],MATCH([@ID_cerere],tTQMCereri[ID_cerere],0))))", firstOffer
    CO_FormulaColumn req, "Oferte_valide", "=IF(IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere])="""","""",COUNTIFS(tTQMOferte[ID_cerere],IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]),tTQMOferte[Eligibila],1))", firstOffer
    CO_FormulaColumn req, "Cost_min", "=IF(OR(IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere])="""",[@Oferte_valide]=0),"""",INDEX(tTQMOferte[Total_RON],MATCH(IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]),tTQMOferte[Cheie_min],0)))", firstOffer
    CO_FormulaColumn req, "Furnizor_recom", "=IF(OR(IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere])="""",[@Oferte_valide]=0),"""",INDEX(tTQMOferte[Furnizor],MATCH(IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]),tTQMOferte[Cheie_min],0)))", firstOffer
    CO_FormulaColumn req, "Status", _
        "=IF(IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere])="""","""",IF(COUNTIFS(tTQMCereri[ID_cerere],IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]))<>1,""ID CERERE DUPLICAT"",IF(IF(ISBLANK([@ID_oferta_aprobata]),"""",[@ID_oferta_aprobata])="""",IF([@Oferte_valide]=0,""DE OFERTAT"",""DE APROBAT""),IF(COUNTIFS(tTQMOferte[ID_oferta],IF(ISBLANK([@ID_oferta_aprobata]),"""",[@ID_oferta_aprobata]),tTQMOferte[ID_cerere],IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere]))<>1,""RECONFIRMA APROBAREA"",IF(AND([@Aprobat_de]<>"""",ISNUMBER([@Data_aprobarii]),[@Amprenta_aprobarii]<>"""",[@Amprenta_aprobarii]=INDEX(tTQMOferte[Amprenta_oferta],IF(COUNTIFS(" & _
        "tTQMOferte[ID_oferta],IF(ISBLANK([@ID_oferta_aprobata]),"""",[@ID_oferta_aprobata]))=1,MATCH(IF(ISBLANK([@ID_oferta_aprobata]),"""",[@ID_oferta_aprobata]),tTQMOferte[ID_oferta],0),1)),INDEX(tTQMOferte[Eligibila],IF(COUNTIFS(tTQMOferte[ID_oferta],IF(ISBLANK([@ID_oferta_aprobata]),"""",[@ID_oferta_aprobata]))=1,MATCH(IF(ISBLANK([@ID_oferta_aprobata]),"""",[@ID_oferta_aprobata]),tTQMOferte[ID_oferta],0),1))=1),""APROBATA"",""RECONFIRMA APROBAREA"")))))", firstOffer
    CO_FormulaColumn req, "Amprenta_cerere", _
        "=IF(IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere])="""","""",LEN(IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere])&"""")&"":""&IF(ISBLANK([@ID_cerere]),"""",[@ID_cerere])&""|""&LEN(IF(ISBLANK([@Data_cerere]),"""",[@Data_cerere])&"""")&"":""&IF(ISBLANK([@Data_cerere]),"""",[@Data_cerere])&""|""&LEN(IF(ISBLANK([@Proiect]),"""",[@Proiect])&"""")&"":""&IF(ISBLANK([@Proiect]),"""",[@Proiect])&""|""&LEN(IF(ISBLANK([@Material]),"""",[@Material])&"""")&"":""&IF(ISBLANK([@Material]),"""",[@Material])&""|""&LEN(IF(ISBLANK([@UM]),"""",[@UM])&"""")&"":""&IF(ISBLANK([@UM]),"""",[@UM])&""|""&LEN(IF(ISBLANK([@Cantitate]),"""",[@Cantitate])&"""")&"":""&IF(ISBLANK([@Cantitate]),""" & _
        """,[@Cantitate])&""|""&LEN(IF(ISBLANK([@Data_necesara]),"""",[@Data_necesara])&"""")&"":""&IF(ISBLANK([@Data_necesara]),"""",[@Data_necesara])&""|""&LEN(IF(ISBLANK([@Prioritate]),"""",[@Prioritate])&"""")&"":""&IF(ISBLANK([@Prioritate]),"""",[@Prioritate])&""|""&LEN(IF(ISBLANK([@Specificatie]),"""",[@Specificatie])&"""")&"":""&IF(ISBLANK([@Specificatie]),"""",[@Specificatie])&""|""&LEN(IF(ISBLANK([@Solicitant]),"""",[@Solicitant])&"""")&"":""&IF(ISBLANK([@Solicitant]),"""",[@Solicitant])&""|""&LEN(IF(ISBLANK([@Buget_RON]),"""",[@Buget_RON])&"""")&"":""&IF(ISBLANK([@Buget_RON]),"""",[@Buget_RON])&""|""&LEN(IF(ISBLANK([@Observatii]),"""",[@Observati" & _
        "i])&"""")&"":""&IF(ISBLANK([@Observatii]),"""",[@Observatii]))", firstOffer
    ws.Range("A6").formula = "=COUNTIF(tTQMCereri[ID_cerere],""?*"")"
    ws.Range("D6").formula = "=COUNTIFS(tTQMCereri[Status],""DE OFERTAT"")"
    ws.Range("G6").formula = "=COUNTIFS(tTQMCereri[Status],""DE APROBAT"")+COUNTIFS(tTQMCereri[Status],""RECONFIRMA APROBAREA"")+COUNTIFS(tTQMCereri[Status],""APROBATA PARTIAL"")"
    ws.Range("J6").formula = "=COUNTIFS(tTQMCereri[Status],""APROBATA"")"
    ws.Range("G9").formula = "=IF($C$9="""",""Alegeti cererea pentru comparatie"",IF(COUNTIFS(tTQMCereri[ID_cerere],$C$9)<>1,""ID cerere invalid / duplicat"",INDEX(tTQMCereri[Proiect],MATCH($C$9,tTQMCereri[ID_cerere],0))&"" / ""&INDEX(tTQMCereri[Material],MATCH($C$9,tTQMCereri[ID_cerere],0))))"
    ws.Range("A13").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#1"")<>1),"""",INDEX(tTQMOferte[ID_oferta],MATCH($C$9&""#1"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("C13").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#1"")<>1),"""",INDEX(tTQMOferte[Furnizor],MATCH($C$9&""#1"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("E13").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#1"")<>1),"""",INDEX(tTQMOferte[Total_RON],MATCH($C$9&""#1"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("G13").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#1"")<>1),"""",INDEX(tTQMOferte[Data_livrare],MATCH($C$9&""#1"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("I13").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#1"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#1"",tTQMOferte[Cheie_cost],0))=1,""DA"",""NU""))"
    ws.Range("K13").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#1"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#1"",tTQMOferte[Cheie_cost],0))=0,INDEX(tTQMOferte[Motiv],MATCH($C$9&""#1"",tTQMOferte[Cheie_cost],0)),IF(INDEX(tTQMOferte[Rang_eligibil],MATCH($C$9&""#1"",tTQMOferte[Cheie_cost],0))=1,""Cost minim eligibil"",""Comparabila"")))"
    ws.Range("A14").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#2"")<>1),"""",INDEX(tTQMOferte[ID_oferta],MATCH($C$9&""#2"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("C14").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#2"")<>1),"""",INDEX(tTQMOferte[Furnizor],MATCH($C$9&""#2"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("E14").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#2"")<>1),"""",INDEX(tTQMOferte[Total_RON],MATCH($C$9&""#2"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("G14").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#2"")<>1),"""",INDEX(tTQMOferte[Data_livrare],MATCH($C$9&""#2"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("I14").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#2"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#2"",tTQMOferte[Cheie_cost],0))=1,""DA"",""NU""))"
    ws.Range("K14").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#2"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#2"",tTQMOferte[Cheie_cost],0))=0,INDEX(tTQMOferte[Motiv],MATCH($C$9&""#2"",tTQMOferte[Cheie_cost],0)),IF(INDEX(tTQMOferte[Rang_eligibil],MATCH($C$9&""#2"",tTQMOferte[Cheie_cost],0))=1,""Cost minim eligibil"",""Comparabila"")))"
    ws.Range("A15").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#3"")<>1),"""",INDEX(tTQMOferte[ID_oferta],MATCH($C$9&""#3"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("C15").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#3"")<>1),"""",INDEX(tTQMOferte[Furnizor],MATCH($C$9&""#3"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("E15").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#3"")<>1),"""",INDEX(tTQMOferte[Total_RON],MATCH($C$9&""#3"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("G15").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#3"")<>1),"""",INDEX(tTQMOferte[Data_livrare],MATCH($C$9&""#3"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("I15").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#3"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#3"",tTQMOferte[Cheie_cost],0))=1,""DA"",""NU""))"
    ws.Range("K15").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#3"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#3"",tTQMOferte[Cheie_cost],0))=0,INDEX(tTQMOferte[Motiv],MATCH($C$9&""#3"",tTQMOferte[Cheie_cost],0)),IF(INDEX(tTQMOferte[Rang_eligibil],MATCH($C$9&""#3"",tTQMOferte[Cheie_cost],0))=1,""Cost minim eligibil"",""Comparabila"")))"
    ws.Range("A16").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#4"")<>1),"""",INDEX(tTQMOferte[ID_oferta],MATCH($C$9&""#4"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("C16").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#4"")<>1),"""",INDEX(tTQMOferte[Furnizor],MATCH($C$9&""#4"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("E16").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#4"")<>1),"""",INDEX(tTQMOferte[Total_RON],MATCH($C$9&""#4"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("G16").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#4"")<>1),"""",INDEX(tTQMOferte[Data_livrare],MATCH($C$9&""#4"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("I16").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#4"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#4"",tTQMOferte[Cheie_cost],0))=1,""DA"",""NU""))"
    ws.Range("K16").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#4"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#4"",tTQMOferte[Cheie_cost],0))=0,INDEX(tTQMOferte[Motiv],MATCH($C$9&""#4"",tTQMOferte[Cheie_cost],0)),IF(INDEX(tTQMOferte[Rang_eligibil],MATCH($C$9&""#4"",tTQMOferte[Cheie_cost],0))=1,""Cost minim eligibil"",""Comparabila"")))"
    ws.Range("A17").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#5"")<>1),"""",INDEX(tTQMOferte[ID_oferta],MATCH($C$9&""#5"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("C17").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#5"")<>1),"""",INDEX(tTQMOferte[Furnizor],MATCH($C$9&""#5"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("E17").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#5"")<>1),"""",INDEX(tTQMOferte[Total_RON],MATCH($C$9&""#5"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("G17").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#5"")<>1),"""",INDEX(tTQMOferte[Data_livrare],MATCH($C$9&""#5"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("I17").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#5"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#5"",tTQMOferte[Cheie_cost],0))=1,""DA"",""NU""))"
    ws.Range("K17").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#5"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#5"",tTQMOferte[Cheie_cost],0))=0,INDEX(tTQMOferte[Motiv],MATCH($C$9&""#5"",tTQMOferte[Cheie_cost],0)),IF(INDEX(tTQMOferte[Rang_eligibil],MATCH($C$9&""#5"",tTQMOferte[Cheie_cost],0))=1,""Cost minim eligibil"",""Comparabila"")))"
    ws.Range("A18").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#6"")<>1),"""",INDEX(tTQMOferte[ID_oferta],MATCH($C$9&""#6"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("C18").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#6"")<>1),"""",INDEX(tTQMOferte[Furnizor],MATCH($C$9&""#6"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("E18").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#6"")<>1),"""",INDEX(tTQMOferte[Total_RON],MATCH($C$9&""#6"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("G18").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#6"")<>1),"""",INDEX(tTQMOferte[Data_livrare],MATCH($C$9&""#6"",tTQMOferte[Cheie_cost],0)))"
    ws.Range("I18").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#6"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#6"",tTQMOferte[Cheie_cost],0))=1,""DA"",""NU""))"
    ws.Range("K18").formula = "=IF(OR($C$9="""",COUNTIFS(tTQMOferte[Cheie_cost],$C$9&""#6"")<>1),"""",IF(INDEX(tTQMOferte[Eligibila],MATCH($C$9&""#6"",tTQMOferte[Cheie_cost],0))=0,INDEX(tTQMOferte[Motiv],MATCH($C$9&""#6"",tTQMOferte[Cheie_cost],0)),IF(INDEX(tTQMOferte[Rang_eligibil],MATCH($C$9&""#6"",tTQMOferte[Cheie_cost],0))=1,""Cost minim eligibil"",""Comparabila"")))"
    CO_Validations ws, req, offers
    ws.Calculate
    ws.Calculate
    RFQ_Sync
    CO_DOCSync
End Sub

Private Sub CO_FormulaColumn(ByVal tbl As ListObject, _
    ByVal columnName As String, _
    ByVal template As String, _
    ByVal firstOffer As Long)

    Dim col As Variant
    Dim target As Range
    Dim field As ListColumn
    Dim shortRef As String
    Dim fullRef As String

    For Each col In Array("B", "AC", "K", "G")
        template = Replace(template, _
            "$" & col & "$37:" & col & "37", _
            "$" & col & "$" & firstOffer & _
            ":" & col & firstOffer)
    Next col

    For Each field In tbl.ListColumns
        shortRef = "[@" & field.name & "]"
        fullRef = tbl.name & _
            "[[#This Row],[" & field.name & "]]"

        template = Replace(template, shortRef, fullRef)
    Next field

    Set target = tbl.ListColumns(columnName).DataBodyRange

    target.Cells(1, 1).formula = template

    If target.rows.count > 1 Then
        target.FillDown
    End If
End Sub

Private Sub CO_Validations(ByVal ws As Worksheet, ByVal req As ListObject, ByVal offers As ListObject)
    Dim separator As String
    separator = Application.International(xlListSeparator)
    CO_ListValidation ws.Range("C9:F9"), "=INDIRECT(""tTQMCereri[ID_cerere]"")"
    CO_ListValidation req.ListColumns("Prioritate").DataBodyRange, "Normala" & separator & "Ridicata" & separator & "Urgenta"
    CO_ListValidation offers.ListColumns("Conform_tehnic").DataBodyRange, "Da" & separator & "Nu" & separator & "De verificat"
    CO_SLList req.ListColumns("Prioritate").DataBodyRange, "PRIORITATE"
    CO_SLList offers.ListColumns("Conform_tehnic").DataBodyRange, "CONFORM_TEHNIC"
    req.DataBodyRange.RowHeight = 44
    offers.DataBodyRange.RowHeight = 44
    req.DataBodyRange.WrapText = True
    offers.DataBodyRange.WrapText = True
    req.ListColumns("Data_cerere").DataBodyRange.NumberFormat = "dd.mm.yyyy"
    req.ListColumns("Data_necesara").DataBodyRange.NumberFormat = "dd.mm.yyyy"
    req.ListColumns("Data_aprobarii").DataBodyRange.NumberFormat = "dd.mm.yyyy hh:mm"
    req.ListColumns("Actualizat_la").DataBodyRange.NumberFormat = "dd.mm.yyyy hh:mm"
    req.ListColumns("Cost_min").DataBodyRange.NumberFormat = "#,##0.00"
    req.ListColumns("Buget_RON").DataBodyRange.NumberFormat = "#,##0.00"
    offers.ListColumns("Data_oferta").DataBodyRange.NumberFormat = "dd.mm.yyyy"
    offers.ListColumns("Data_livrare").DataBodyRange.NumberFormat = "dd.mm.yyyy"
    offers.ListColumns("Valabila_pana").DataBodyRange.NumberFormat = "dd.mm.yyyy"
    offers.ListColumns("Actualizat_la").DataBodyRange.NumberFormat = "dd.mm.yyyy hh:mm"
    offers.ListColumns("Pret_unitar").DataBodyRange.NumberFormat = "#,##0.00"
    offers.ListColumns("Total_RON").DataBodyRange.NumberFormat = "#,##0.00"
    offers.ListColumns("Transport_RON").DataBodyRange.NumberFormat = "#,##0.00"
    offers.ListColumns("Alte_costuri_RON").DataBodyRange.NumberFormat = "#,##0.00"
    offers.ListColumns("Discount_pct").DataBodyRange.NumberFormat = "0.0%"
End Sub

Private Sub CO_ListValidation(ByVal target As Range, ByVal source As String)
    With target.Validation
        .Delete
        .Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Operator:=xlBetween, Formula1:=source
        .InCellDropdown = True
        .ShowError = True
    End With
End Sub

Private Function CO_Find(ByVal tbl As ListObject, ByVal recordID As String) As Long
    Dim i As Long, countFound As Long
    For i = 1 To tbl.ListRows.count
        If StrComp(CStr(tbl.DataBodyRange.Cells(i, 1).Value2), recordID, vbTextCompare) = 0 Then
            CO_Find = i
            countFound = countFound + 1
        End If
    Next i
    If countFound > 1 Then Err.Raise vbObjectError + 1210, , "ID duplicat: " & recordID
End Function

Private Sub CO_CheckOrderUse(ByVal requestID As String, Optional ByVal offerID As String = "")
    Dim ws As Worksheet, lo As ListObject, row As ListRow, committed As Double
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            If lo.name = "tTQMCFPoz" Then
                For Each row In lo.ListRows
                    If StrComp(CStr(row.Range.Cells(1, 17).Value2), requestID, vbTextCompare) = 0 Then
                        If Len(offerID) = 0 Or StrComp(CStr(row.Range.Cells(1, 18).Value2), offerID, vbTextCompare) = 0 Then
                            If Not IsNumeric(row.Range.Cells(1, 7).Value2) Or Not IsNumeric(row.Range.Cells(1, 11).Value2) Then _
                                Err.Raise vbObjectError + 1260, , "Cantitati invalide in comanda asociata. Corectati registrul inainte de modificarea sursei."
                            committed = CDbl(row.Range.Cells(1, 7).Value2) - CDbl(row.Range.Cells(1, 11).Value2)
                            If committed > 0.00000001 Then Err.Raise vbObjectError + 1261, , _
                                "Cererea/oferta este utilizata in comanda " & CStr(row.Range.Cells(1, 2).Value2) & ". Sursa si aprobarea se pastreaza. Anulati mai intai restul neexecutat; cantitatile primite raman protejate."
                        End If
                    End If
                Next row
            End If
        Next lo
    Next ws
End Sub

Private Function CO_RecordStamp(ByVal tbl As ListObject, ByVal rowIndex As Long) As String
    Dim i As Long, cellValue As Variant, token As String
    For i = 1 To tbl.ListColumns.count
        cellValue = tbl.DataBodyRange.Cells(rowIndex, i).Value2
        If IsError(cellValue) Then
            token = "ERROARE"
        Else
            token = CStr(cellValue)
        End If
        CO_RecordStamp = CO_RecordStamp & Len(token) & ":" & token & "|"
    Next i
End Function

Private Function CO_FreeRow(ByVal tbl As ListObject) As Long
    Dim i As Long, nextSheetRow As Long, previousRowCount As Long, ws As Worksheet
    For i = 1 To tbl.ListRows.count
        If Len(CStr(tbl.DataBodyRange.Cells(i, 1).Value2)) = 0 Then CO_FreeRow = i: Exit Function
    Next i
    Set ws = tbl.Parent
    previousRowCount = tbl.Range.rows.count
    nextSheetRow = tbl.Range.row + previousRowCount
    ws.rows(nextSheetRow).Insert Shift:=xlDown
    tbl.Resize tbl.Range.Resize(previousRowCount + 1, tbl.Range.Columns.count)
    CO_FreeRow = tbl.ListRows.count
End Function

Private Function CO_NewID(ByVal prefix As String) As String
    Static seeded As Boolean
    Dim idText As String, userCode As String, i As Long, charText As String
    If Not seeded Then Randomize Timer: seeded = True
    For i = 1 To Len(Application.UserName)
        charText = UCase$(mID$(Application.UserName, i, 1))
        If charText Like "[A-Z0-9]" Then userCode = userCode & charText
        If Len(userCode) = 3 Then Exit For
    Next i
    If Len(userCode) = 0 Then userCode = "USR"
    Do
        idText = prefix & "-" & Format$(Now, "yymmdd-hhnnss") & "-" & userCode & "-" & Right$("00000000" & Hex$(CLng(Rnd() * 1000000000#)), 8)
    Loop While CO_Find(CO_Table(CO_REQ), idText) > 0 Or CO_Find(CO_Table(CO_OFF), idText) > 0
    CO_NewID = idText
End Function

Private Function CO_Text(ByVal prompt As String, ByVal initial As String, _
    ByVal required As Boolean, ByRef answer As String) As Boolean
    Dim response As Variant
    Do
        response = Application.InputBox(prompt, "TQM - Cereri si oferte", initial, Type:=2)
        If VarType(response) = vbBoolean Then Exit Function
        answer = Trim$(CStr(response))
        If Len(answer) > 2000 Then
            MsgBox "Textul este prea lung. Folositi cel mult 2000 de caractere.", vbExclamation
        ElseIf required And Len(answer) = 0 Then
            MsgBox "Campul este obligatoriu.", vbExclamation
        Else
            CO_Text = True
            Exit Function
        End If
    Loop
End Function

Private Function CO_Number(ByVal prompt As String, ByVal initial As Double, _
    ByVal minimum As Double, ByVal strict As Boolean, ByRef answer As Double, _
    Optional ByVal maximum As Double = 1E+50) As Boolean
    Dim response As Variant
    Do
        response = Application.InputBox(prompt, "TQM - Cereri si oferte", initial, Type:=1)
        If VarType(response) = vbBoolean Then Exit Function
        answer = CDbl(response)
        If answer > maximum Or answer < minimum Or (strict And answer = minimum) Then
            MsgBox "Valoarea nu este in intervalul permis.", vbExclamation
        Else
            CO_Number = True
            Exit Function
        End If
    Loop
End Function

Private Function CO_Date(ByVal prompt As String, ByVal initial As Date, ByRef answer As Date) As Boolean
    Dim textValue As String, parts As Variant, candidate As Date
    Dim dayPart As Long, monthPart As Long, yearPart As Long
    Do
        If Not CO_Text(prompt & " (zz.ll.aaaa)", Format$(initial, "dd.mm.yyyy"), True, textValue) Then Exit Function
        textValue = Replace(Replace(textValue, "/", "."), "-", ".")
        parts = Split(textValue, ".")
        If UBound(parts) = 2 Then
            If IsNumeric(parts(0)) And IsNumeric(parts(1)) And IsNumeric(parts(2)) Then
                dayPart = CLng(parts(0)): monthPart = CLng(parts(1)): yearPart = CLng(parts(2))
                If yearPart >= 2000 And yearPart <= 9999 And monthPart >= 1 And monthPart <= 12 And dayPart >= 1 And dayPart <= 31 Then
                    candidate = DateSerial(yearPart, monthPart, dayPart)
                    If Day(candidate) = dayPart And Month(candidate) = monthPart And Year(candidate) = yearPart Then
                        answer = candidate
                        CO_Date = True
                        Exit Function
                    End If
                End If
            End If
        End If
        MsgBox "Data nu este valida. Exemplu: 08.10.2026.", vbExclamation
    Loop
End Function

Private Function CO_Choice(ByVal prompt As String, ByVal initial As String, _
    ByVal choices As Variant, ByRef answer As String) As Boolean
    Dim response As String, item As Variant
    Do
        If Not CO_Text(prompt, initial, True, response) Then Exit Function
        For Each item In choices
            If StrComp(response, CStr(item), vbTextCompare) = 0 Then
                answer = CStr(item): CO_Choice = True: Exit Function
            End If
        Next item
        MsgBox "Alegeti una dintre valorile indicate.", vbExclamation
    Loop
End Function

Private Function CO_Default(ByVal tbl As ListObject, ByVal rowIndex As Long, _
    ByVal fieldName As String, ByVal fallback As Variant) As Variant
    If rowIndex = 0 Then
        CO_Default = fallback
    Else
        CO_Default = tbl.ListColumns(fieldName).DataBodyRange.Cells(rowIndex, 1).Value2
        If Len(CStr(CO_Default)) = 0 Then CO_Default = fallback
    End If
End Function

Public Sub TQM_CO_CerereNoua()
    RFQ_OpenRequest
End Sub

Public Sub TQM_CO_ModificaCerere()
    Dim requestID As String
    requestID = CO_CurrentRequest()
    If Len(requestID) > 0 Then
        If Len(RFQ_Parent(requestID)) > 0 Then RFQ_OpenRequest RFQ_Parent(requestID) Else CO_EditRequest requestID
    End If
End Sub

Private Sub CO_EditRequest(ByVal requestID As String)
    Dim tbl As ListObject, ws As Worksheet, rowIndex As Long, initialStamp As String
    Dim projectName As String, material As String, unitText As String, specification As String
    Dim requester As String, priority As String, notes As String, budgetText As String
    Dim quantity As Double, needed As Date, budget As Variant, record As Variant
    Dim oldEvents As Boolean, message As String
    oldEvents = Application.EnableEvents
    On Error GoTo Failed
    CO_RefreshCore
    Set tbl = CO_Table(CO_REQ): Set ws = tbl.Parent
    If Len(requestID) > 0 Then
        rowIndex = CO_Find(tbl, requestID)
        If rowIndex = 0 Then Err.Raise vbObjectError + 1220, , "Cererea nu a fost gasita."
        CO_CheckOrderUse requestID
        initialStamp = CO_RecordStamp(tbl, rowIndex)
    End If
    If Not CO_Text("Proiect / santier", CStr(CO_Default(tbl, rowIndex, "Proiect", "")), True, projectName) Then Exit Sub
    If Not CO_Text("Material", CStr(CO_Default(tbl, rowIndex, "Material", "")), True, material) Then Exit Sub
    If Not CO_Text("Specificatia tehnica", CStr(CO_Default(tbl, rowIndex, "Specificatie", "")), False, specification) Then Exit Sub
    If Not CO_Text("Unitatea de masura", CStr(CO_Default(tbl, rowIndex, "UM", "m")), True, unitText) Then Exit Sub
    If Not CO_Number("Cantitatea necesara (> 0)", CDbl(CO_Default(tbl, rowIndex, "Cantitate", 1)), 0, True, quantity) Then Exit Sub
    If Not CO_Date("Data necesara pe santier", CDate(CO_Default(tbl, rowIndex, "Data_necesara", Date + CLng(CO_SLParam("CERERE_TERMEN_ZILE", 7)))), needed) Then Exit Sub
    If needed < Date Then Err.Raise vbObjectError + 1221, , "Data necesara a trecut. Reluati cu un termen actual."
    If Not CO_Text("Solicitant", CStr(CO_Default(tbl, rowIndex, "Solicitant", Application.UserName)), True, requester) Then Exit Sub
    If Not CO_Choice("Prioritate: Normala / Ridicata / Urgenta", CStr(CO_Default(tbl, rowIndex, "Prioritate", "Normala")), Array("Normala", "Ridicata", "Urgenta"), priority) Then Exit Sub
    If Not CO_Text("Bugetul total fara TVA (RON). Lasati gol daca nu este stabilit.", CStr(CO_Default(tbl, rowIndex, "Buget_RON", "")), False, budgetText) Then Exit Sub
    If Len(budgetText) > 0 Then
        If Not IsNumeric(budgetText) Then Err.Raise vbObjectError + 1222, , "Bugetul trebuie sa fie numeric."
        budget = CDbl(budgetText)
        If budget < 0 Then Err.Raise vbObjectError + 1223, , "Bugetul nu poate fi negativ."
    Else
        budget = Empty
    End If
    If Not CO_Text("Observatii", CStr(CO_Default(tbl, rowIndex, "Observatii", "")), False, notes) Then Exit Sub
    CO_RefreshCore
    If Len(requestID) > 0 Then
        rowIndex = CO_Find(tbl, requestID)
        If rowIndex = 0 Then Err.Raise vbObjectError + 1224, , "Cererea a fost eliminata in timpul completarii."
        If CO_RecordStamp(tbl, rowIndex) <> initialStamp Then Err.Raise vbObjectError + 1225, , "Cererea s-a schimbat in timpul completarii. Reluati pentru a folosi datele actuale."
        CO_CheckOrderUse requestID
        record = tbl.ListRows(rowIndex).Range.Value2
    Else
        requestID = CO_NewID("CER")
        ReDim record(1 To 1, 1 To 24)
        record(1, 2) = CDbl(Date): record(1, 22) = Application.UserName
    End If
    record(1, 1) = requestID: record(1, 3) = projectName: record(1, 4) = material
    record(1, 5) = unitText: record(1, 6) = quantity: record(1, 7) = CDbl(needed)
    record(1, 8) = priority: record(1, 13) = specification: record(1, 14) = requester
    record(1, 15) = budget: record(1, 20) = notes: record(1, 23) = CDbl(Now)
    Application.EnableEvents = False
    If rowIndex = 0 Then rowIndex = CO_FreeRow(tbl)
    If Len(CStr(tbl.DataBodyRange.Cells(rowIndex, 1).Value2)) > 0 And CStr(tbl.DataBodyRange.Cells(rowIndex, 1).Value2) <> requestID Then Err.Raise vbObjectError + 1226, , "Randul a fost ocupat. Reluati salvarea."
    tbl.ListRows(rowIndex).Range.Value2 = record
    CO_RefreshCore
    Application.EnableEvents = oldEvents
    ws.Range("C9").Value2 = requestID
    Application.Goto tbl.DataBodyRange.Cells(rowIndex, 1), True
    MsgBox "Cerere salvata: " & requestID, vbInformation, "TQM Calarasi"
    Exit Sub
Failed:
    message = Err.description
    Application.EnableEvents = oldEvents
    MsgBox message, vbExclamation, "TQM Calarasi"
End Sub

Private Function CO_CurrentRequest() As String
    Dim ws As Worksheet, tbl As ListObject, hit As Range, response As String
    On Error GoTo Failed
    CO_CurrentRequest = RFQ_CurrentPosition()
    If Len(CO_CurrentRequest) > 0 Then Exit Function
    Set ws = CO_GetSheet()
    If ws Is Nothing Then Err.Raise vbObjectError + 1230, , "Instalati modulul mai intai."
    If ActiveSheet.name = ws.name Then
        Set tbl = CO_Table(CO_REQ): Set hit = Intersect(ActiveCell, tbl.DataBodyRange)
        If Not hit Is Nothing Then CO_CurrentRequest = CStr(ws.Cells(ActiveCell.row, 1).Value2)
        If Len(CO_CurrentRequest) = 0 Then
            Set tbl = CO_Table(CO_OFF): Set hit = Intersect(ActiveCell, tbl.DataBodyRange)
            If Not hit Is Nothing Then CO_CurrentRequest = CStr(ws.Cells(ActiveCell.row, 2).Value2)
        End If
    End If
    If Len(CO_CurrentRequest) = 0 Then CO_CurrentRequest = CStr(ws.Range("C9").Value2)
    If Len(CO_CurrentRequest) = 0 Then
        If CO_Text("ID-ul cererii", "", True, response) Then CO_CurrentRequest = response
    End If
    If Len(RFQ_Resolve(CO_CurrentRequest)) > 0 Then CO_CurrentRequest = RFQ_FirstPosition(RFQ_Resolve(CO_CurrentRequest))
    Exit Function
Failed:
    MsgBox Err.description, vbExclamation, "TQM Calarasi"
End Function

Public Sub TQM_CO_OfertaNoua()
    Dim requestID As String
    requestID = CO_CurrentRequest()
    If Len(requestID) > 0 Then
        If Len(RFQ_Parent(requestID)) > 0 Then RFQ_OpenQuote RFQ_Parent(requestID) Else CO_EditOffer requestID, ""
    End If
End Sub

Public Sub TQM_CO_ModificaOferta()
    Dim tbl As ListObject, offerID As String, rowIndex As Long
    On Error GoTo Failed
    Set tbl = CO_Table(CO_OFF)
    If ActiveSheet.name = CO_SHEET Then
        If Not Intersect(ActiveCell, tbl.DataBodyRange) Is Nothing Then offerID = CStr(ActiveSheet.Cells(ActiveCell.row, 1).Value2)
    End If
    If Len(offerID) = 0 Then If Not CO_Text("ID-ul ofertei", "", True, offerID) Then Exit Sub
    rowIndex = CO_Find(tbl, offerID)
    If rowIndex = 0 Then Err.Raise vbObjectError + 1240, , "Oferta nu exista."
    If Len(RFQ_Document(offerID)) > 0 Then
        RFQ_OpenQuote RFQ_Parent(CStr(tbl.DataBodyRange.Cells(rowIndex, 2).Value2)), RFQ_Document(offerID)
    Else
        CO_EditOffer CStr(tbl.DataBodyRange.Cells(rowIndex, 2).Value2), offerID
    End If
    Exit Sub
Failed:
    MsgBox Err.description, vbExclamation, "TQM Calarasi"
End Sub

Private Sub CO_EditOffer(ByVal requestID As String, ByVal offerID As String)
    Dim req As ListObject, offers As ListObject, ri As Long, oi As Long
    Dim requestStamp As String, offerStamp As String, supplier As String, number As String
    Dim terms As String, warranty As String, link As String, notes As String, technical As String
    Dim quantity As Double, price As Double, discount As Double, freight As Double, extraCost As Double
    Dim offerDate As Date, validUntil As Date, delivery As Date, record As Variant
    Dim oldEvents As Boolean, message As String
    oldEvents = Application.EnableEvents
    On Error GoTo Failed
Call CO_RefreshCore:     Set req = CO_Table(CO_REQ): Set offers = CO_Table(CO_OFF)
    ri = CO_Find(req, requestID)
    If ri = 0 Then Err.Raise vbObjectError + 1241, , "Cererea nu exista."
    requestStamp = CO_RecordStamp(req, ri)
    If Len(offerID) > 0 Then
        oi = CO_Find(offers, offerID)
        If oi = 0 Then Err.Raise vbObjectError + 1242, , "Oferta nu exista."
        CO_CheckOrderUse requestID, offerID
        offerStamp = CO_RecordStamp(offers, oi)
    End If
    MsgBox "Cerere: " & requestID & vbCrLf & "Material: " & req.DataBodyRange.Cells(ri, 4).Value2 & vbCrLf & _
        "Cantitate necesara: " & req.DataBodyRange.Cells(ri, 6).Value2 & " " & req.DataBodyRange.Cells(ri, 5).Value2, vbInformation, "TQM Calarasi"
    If Not CO_Text("Furnizor", CStr(CO_Default(offers, oi, "Furnizor", "")), True, supplier) Then Exit Sub
    If Not CO_Text("Numarul / referinta ofertei", CStr(CO_Default(offers, oi, "Nr_oferta", "")), False, number) Then Exit Sub
    If Not CO_Date("Data ofertei", CDate(CO_Default(offers, oi, "Data_oferta", Date)), offerDate) Then Exit Sub
    If Not CO_Date("Valabila pana la", CDate(CO_Default(offers, oi, "Valabila_pana", Date + CLng(CO_SLParam("OFERTA_VALABILA_ZILE", 30)))), validUntil) Then Exit Sub
    If Not CO_Number("Cantitatea ofertata; folositi intreaga cantitate ceruta pentru comparatie.", CDbl(CO_Default(offers, oi, "Cantitate", req.DataBodyRange.Cells(ri, 6).Value2)), 0, True, quantity) Then Exit Sub
    If Not CO_Number("Pret unitar RON fara TVA", CDbl(CO_Default(offers, oi, "Pret_unitar", 0)), 0, False, price) Then Exit Sub
    If Not CO_Number("Discount in procente (10 inseamna 10%)", CDbl(CO_Default(offers, oi, "Discount_pct", 0)) * 100, 0, False, discount, 100) Then Exit Sub
    If Not CO_Number("Transportul alocat acestei pozitii (RON fara TVA)", CDbl(CO_Default(offers, oi, "Transport_RON", 0)), 0, False, freight) Then Exit Sub
    If Not CO_Number("Alte costuri pentru pozitie (RON fara TVA)", CDbl(CO_Default(offers, oi, "Alte_costuri_RON", 0)), 0, False, extraCost) Then Exit Sub
    If Not CO_Date("Data estimata a livrarii", CDate(CO_Default(offers, oi, "Data_livrare", Date + CLng(CO_SLParam("OFERTA_LIVRARE_ZILE", 2)))), delivery) Then Exit Sub
    If Not CO_Choice("Conform tehnic: Da / Nu / De verificat", CStr(CO_Default(offers, oi, "Conform_tehnic", "De verificat")), Array("Da", "Nu", "De verificat"), technical) Then Exit Sub
    If Not CO_Text("Conditii de plata", CStr(CO_Default(offers, oi, "Conditii_plata", "")), False, terms) Then Exit Sub
    If Not CO_Text("Garantie", CStr(CO_Default(offers, oi, "Garantie", "")), False, warranty) Then Exit Sub
    If Not CO_Text("Link / cale catre oferta", CStr(CO_Default(offers, oi, "Link_oferta", "")), False, link) Then Exit Sub
    If Not CO_Text("Observatii", CStr(CO_Default(offers, oi, "Observatii", "")), False, notes) Then Exit Sub
    If offerDate > Date Or validUntil < offerDate Or delivery < offerDate Then _
        Err.Raise vbObjectError + 1262, , "Data ofertei nu poate fi in viitor; valabilitatea si livrarea nu pot preceda data ofertei."
    CO_RefreshCore
    ri = CO_Find(req, requestID)
    If ri = 0 Then Err.Raise vbObjectError + 1243, , "Cererea a fost eliminata in timpul completarii."
    If CO_RecordStamp(req, ri) <> requestStamp Then Err.Raise vbObjectError + 1244, , "Cererea s-a schimbat. Reluati cu datele actuale."
    If Len(offerID) > 0 Then
        oi = CO_Find(offers, offerID)
        If oi = 0 Then Err.Raise vbObjectError + 1245, , "Oferta a fost eliminata."
        If CO_RecordStamp(offers, oi) <> offerStamp Then Err.Raise vbObjectError + 1246, , "Oferta s-a schimbat. Reluati editarea."
        CO_CheckOrderUse requestID, offerID
        record = offers.ListRows(oi).Range.Value2
    Else
        offerID = CO_NewID("OFR"): ReDim record(1 To 1, 1 To 29)
        record(1, 23) = Application.UserName
    End If
    record(1, 1) = offerID: record(1, 2) = requestID: record(1, 3) = supplier
    record(1, 4) = quantity: record(1, 5) = req.DataBodyRange.Cells(ri, 5).Value2: record(1, 6) = price
    record(1, 8) = CDbl(delivery): record(1, 9) = CDbl(validUntil): record(1, 10) = technical
    record(1, 13) = number: record(1, 14) = CDbl(offerDate): record(1, 15) = discount / 100
    record(1, 16) = freight: record(1, 17) = extraCost: record(1, 18) = terms
    record(1, 19) = warranty: record(1, 20) = link: record(1, 21) = notes: record(1, 24) = CDbl(Now)
    Application.EnableEvents = False
    If oi = 0 Then oi = CO_FreeRow(offers)
    If Len(CStr(offers.DataBodyRange.Cells(oi, 1).Value2)) > 0 And CStr(offers.DataBodyRange.Cells(oi, 1).Value2) <> offerID Then Err.Raise vbObjectError + 1247, , "Randul a fost ocupat. Reluati salvarea."
    offers.ListRows(oi).Range.Value2 = record
    CO_RefreshCore
    Application.EnableEvents = oldEvents
    offers.Parent.Range("C9").Value2 = requestID
    Application.Goto offers.DataBodyRange.Cells(oi, 1), True
    MsgBox "Oferta salvata: " & offerID & vbCrLf & CStr(offers.DataBodyRange.Cells(oi, 12).Value2), vbInformation, "TQM Calarasi"
    Exit Sub
Failed:
    message = Err.description: Application.EnableEvents = oldEvents
    MsgBox message, vbExclamation, "TQM Calarasi"
End Sub

Public Sub TQM_CO_Compara()
    Dim requestID As String, tbl As ListObject
    On Error GoTo Failed
    requestID = CO_CurrentRequest()
    If Len(requestID) = 0 Then Exit Sub
    Set tbl = CO_Table(CO_REQ)
    If Len(RFQ_Parent(requestID)) > 0 Then RFQ_Compare RFQ_Parent(requestID): Exit Sub
    If CO_Find(tbl, requestID) = 0 Then Err.Raise vbObjectError + 1250, , "Cererea nu exista."
    CO_GetSheet().Range("C9").Value2 = requestID
    CO_RefreshCore
    Application.Goto CO_GetSheet().Range("A9"), True
    Exit Sub
Failed:
    MsgBox Err.description, vbExclamation, "TQM Calarasi"
End Sub

Public Sub TQM_CO_AprobaOferta()
    Dim req As ListObject, offers As ListObject, requestID As String, offerID As String
    Dim ri As Long, oi As Long, defaultID As String, i As Long
    Dim approver As String, reason As String, neededReason As Boolean
    Dim requestStamp As String, quoteStamp As String, message As String, oldEvents As Boolean
    oldEvents = Application.EnableEvents
    On Error GoTo Failed
    requestID = CO_CurrentRequest()
    If Len(requestID) = 0 Then Exit Sub
    If Len(RFQ_Parent(requestID)) > 0 Then RFQ_ApproveFromMain requestID: Exit Sub
Call CO_RefreshCore:     Set req = CO_Table(CO_REQ): Set offers = CO_Table(CO_OFF)
    ri = CO_Find(req, requestID)
    If ri = 0 Then Err.Raise vbObjectError + 1251, , "Cererea nu exista."
    For i = 1 To offers.ListRows.count
        If CStr(offers.DataBodyRange.Cells(i, 28).Value2) = requestID Then defaultID = CStr(offers.DataBodyRange.Cells(i, 1).Value2): Exit For
    Next i
    If Not CO_Text("ID-ul ofertei de aprobat", defaultID, True, offerID) Then Exit Sub
    oi = CO_Find(offers, offerID)
    If oi = 0 Then Err.Raise vbObjectError + 1252, , "Oferta nu exista."
    If CStr(offers.DataBodyRange.Cells(oi, 2).Value2) <> requestID Then Err.Raise vbObjectError + 1253, , "Oferta apartine altei cereri."
    If CLng(offers.DataBodyRange.Cells(oi, 11).Value2) <> 1 Then Err.Raise vbObjectError + 1254, , "Oferta nu poate fi aprobata: " & offers.DataBodyRange.Cells(oi, 12).Value2
    CO_CheckOrderUse requestID
    requestStamp = CO_RecordStamp(req, ri): quoteStamp = CO_RecordStamp(offers, oi)
    neededReason = CDbl(offers.DataBodyRange.Cells(oi, 7).Value2) > CDbl(req.DataBodyRange.Cells(ri, 10).Value2) + 0.005
    If IsNumeric(req.DataBodyRange.Cells(ri, 15).Value2) And Len(CStr(req.DataBodyRange.Cells(ri, 15).Value2)) > 0 Then
        If CDbl(offers.DataBodyRange.Cells(oi, 7).Value2) > CDbl(req.DataBodyRange.Cells(ri, 15).Value2) + 0.005 Then neededReason = True
    End If
    If Not CO_Text("Numele persoanei care aproba", Application.UserName, True, approver) Then Exit Sub
    If Not CO_Text("Motivul alegerii (obligatoriu peste costul minim sau peste buget)", "", neededReason, reason) Then Exit Sub
    If Len(reason) = 0 Then reason = "Cost minim eligibil"
    If MsgBox("Aprobati " & offerID & " de la " & offers.DataBodyRange.Cells(oi, 3).Value2 & vbCrLf & _
        "Total: " & Format$(offers.DataBodyRange.Cells(oi, 7).Value2, "#,##0.00") & " RON fara TVA?", vbYesNo + vbQuestion, "TQM Calarasi") <> vbYes Then Exit Sub
Call CO_RefreshCore:     ri = CO_Find(req, requestID): oi = CO_Find(offers, offerID)
    If ri = 0 Or oi = 0 Then Err.Raise vbObjectError + 1255, , "Inregistrarea nu mai exista."
    If CO_RecordStamp(req, ri) <> requestStamp Or CO_RecordStamp(offers, oi) <> quoteStamp Then Err.Raise vbObjectError + 1256, , "Datele s-au schimbat in timpul aprobarii. Reluati decizia."
    CO_CheckOrderUse requestID
    Application.EnableEvents = False
    req.DataBodyRange.Cells(ri, 16).Value2 = offerID
    req.DataBodyRange.Cells(ri, 17).Value2 = approver
    req.DataBodyRange.Cells(ri, 18).Value2 = CDbl(Now)
    req.DataBodyRange.Cells(ri, 19).Value2 = reason
    req.DataBodyRange.Cells(ri, 21).Value2 = offers.DataBodyRange.Cells(oi, 22).Value2
    req.DataBodyRange.Cells(ri, 23).Value2 = CDbl(Now)
Call CO_RefreshCore:     Application.EnableEvents = oldEvents
    MsgBox "Aprobare inregistrata. ID oferta: " & offerID, vbInformation, "TQM Calarasi"
    Exit Sub
Failed:
    message = Err.description: Application.EnableEvents = oldEvents
    MsgBox message, vbExclamation, "TQM Calarasi"
End Sub

Public Sub TQM_CO_RetrageAprobarea()
    Dim requestID As String, tbl As ListObject, ri As Long, initialStamp As String
    Dim oldEvents As Boolean, message As String
    oldEvents = Application.EnableEvents
    On Error GoTo Failed
    requestID = CO_CurrentRequest(): If Len(requestID) = 0 Then Exit Sub
    If Len(RFQ_Parent(requestID)) > 0 Then RFQ_WithdrawFromMain requestID: Exit Sub
    CO_RefreshCore
    Set tbl = CO_Table(CO_REQ): ri = CO_Find(tbl, requestID)
    If ri = 0 Then Exit Sub
    CO_CheckOrderUse requestID
    initialStamp = CO_RecordStamp(tbl, ri)
    If MsgBox("Retrageti aprobarea curenta pentru " & requestID & "?", vbYesNo + vbQuestion, "TQM Calarasi") <> vbYes Then Exit Sub
Call CO_RefreshCore:     ri = CO_Find(tbl, requestID)
    If ri = 0 Then Err.Raise vbObjectError + 1257, , "Cererea nu mai exista."
    If CO_RecordStamp(tbl, ri) <> initialStamp Then Err.Raise vbObjectError + 1258, , "Cererea s-a schimbat. Reluati retragerea."
    CO_CheckOrderUse requestID
    Application.EnableEvents = False
    tbl.DataBodyRange.Cells(ri, 16).Resize(1, 4).ClearContents
    tbl.DataBodyRange.Cells(ri, 21).ClearContents
    tbl.DataBodyRange.Cells(ri, 23).Value2 = CDbl(Now)
    CO_RefreshCore
    Application.EnableEvents = oldEvents
    Exit Sub
Failed:
    message = Err.description: Application.EnableEvents = oldEvents
    MsgBox message, vbExclamation, "TQM Calarasi"
End Sub

Private Sub CO_Buttons(ByVal ws As Worksheet)
    Dim i As Long, button As Shape
    For i = ws.Shapes.count To 1 Step -1
        If Left$(ws.Shapes(i).name, 7) = "TQM_CO_" Then ws.Shapes(i).Delete
    Next i
    ws.Range("A3:L3").ClearContents
    CO_Button ws, "A3:B3", "Cerere noua", "TQM_CO_CerereNoua"
    CO_Button ws, "C3:D3", "Oferta noua", "TQM_CO_OfertaNoua"
    CO_Button ws, "E3:F3", "Aproba oferta", "TQM_CO_AprobaOferta"
    CO_Button ws, "G3:H3", "Compara", "TQM_CO_Compara"
    CO_Button ws, "I3:J3", "Actualizeaza", "TQM_CO_Actualizeaza"
    CO_Button ws, "K3:L3", "Dashboard", "TQM_CO_Dashboard"
    CO_Button ws, "A21:C21", "Modifica cererea", "TQM_CO_ModificaCerere"
    CO_Button ws, "D21:F21", "Retrage aprobarea", "TQM_CO_RetrageAprobarea"
    CO_Button ws, "G21:I21", "Modifica oferta", "TQM_CO_ModificaOferta"
    CO_Button ws, "J21:L21", "Vezi ofertele", "TQM_CO_VeziOferte"
End Sub

Private Sub CO_Button(ByVal ws As Worksheet, ByVal addr As String, ByVal caption As String, ByVal action As String)
    Dim target As Range, button As Shape
    Set target = ws.Range(addr)
    Set button = ws.Shapes.AddShape(msoShapeRoundedRectangle, target.Left + 2, target.Top + 2, target.width - 4, target.Height - 4)
    button.name = "TQM_CO_" & action
    button.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & action
    button.Placement = xlMoveAndSize
    button.Fill.ForeColor.RGB = RGB(37, 99, 235)
    button.line.Visible = msoFalse
    With button.TextFrame2
        .TextRange.text = caption
        .TextRange.Font.name = "Aptos"
        .TextRange.Font.size = 10
        .TextRange.Font.Bold = msoTrue
        .TextRange.Font.Fill.ForeColor.RGB = RGB(255, 255, 255)
        .TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .VerticalAnchor = msoAnchorMiddle
        .MarginLeft = 2: .MarginRight = 2: .MarginTop = 1: .MarginBottom = 1
    End With
End Sub

Private Sub CO_ConnectDashboard()
    Dim ws As Worksheet
    For Each ws In ThisWorkbook.Worksheets
        If ws.name = "00_DASHBOARD" Then
            ws.Range("B47").formula = "=HYPERLINK(""#'02_CERERI_SI_OFERTE'!A2"",""Cereri si oferte - modul activ"")"
            ws.Range("B47:G48").Font.Color = RGB(37, 99, 235)
            Exit Sub
        End If
    Next ws
End Sub

Public Sub TQM_CO_Dashboard()
    On Error GoTo Failed
    ThisWorkbook.Activate
    Application.Goto ThisWorkbook.Worksheets("00_DASHBOARD").Range("A1"), True
    Exit Sub
Failed:
    MsgBox Err.description, vbExclamation, "TQM Calarasi"
End Sub

Public Sub TQM_CO_VeziOferte()
    On Error GoTo Failed
    Application.Goto CO_Table(CO_OFF).HeaderRowRange.Cells(1, 1), True
    Exit Sub
Failed:
    MsgBox Err.description, vbExclamation, "TQM Calarasi"
End Sub

Private Function CO_SLSheet(ByVal labelName As String) As Worksheet
    On Error Resume Next
    Set CO_SLSheet = ThisWorkbook.Worksheets(labelName)
    On Error GoTo 0
End Function

Private Function CO_SLParam(ByVal key As String, ByVal fallback As Variant) As Variant
    Dim ws As Worksheet
    Set ws = CO_SLSheet("07_SETARI_LISTE")
    If ws Is Nothing Then
        CO_SLParam = fallback
    Else
        CO_SLParam = Application.Run("'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_Param", key, fallback)
    End If
End Function
Private Sub CO_SLList(ByVal target As Range, ByVal group As String)
    Dim ws As Worksheet
    Set ws = CO_SLSheet("07_SETARI_LISTE")
    If ws Is Nothing Then Exit Sub
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_ApplyList", target, group
End Sub
Private Sub CO_SLCheck(ByVal group As String, ByVal value As String)
    Dim ws As Worksheet
    Set ws = CO_SLSheet("07_SETARI_LISTE")
    If ws Is Nothing Then Exit Sub
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!SL_CheckValue", group, value
End Sub

Private Sub CO_DOCSync()
    On Error Resume Next
    Application.Run "'" & Replace(ThisWorkbook.name, "'", "''") & "'!DOC_Sync"
    On Error GoTo 0
End Sub



' RFQ APIs raise errors. GUI entry points handle them once, after restoring state.
Public Function RFQ_Table(ByVal name As String) As ListObject
    Dim ws As Worksheet, lo As ListObject
    If mRXTables Is Nothing Then Set mRXTables = CreateObject("Scripting.Dictionary"): mRXTables.CompareMode = vbTextCompare
    If mRXTables.exists(name) Then Set RFQ_Table = mRXTables(name): Exit Function
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            If StrComp(lo.name, name, vbTextCompare) = 0 Then
                mRXTables.Add name, lo: Set RFQ_Table = lo: Exit Function
            End If
        Next lo
    Next ws
    Err.Raise vbObjectError + 2201, "RFQ", "Lipseste tabelul " & name
End Function

Public Sub RFQ_ResetCache()
    Set mRXTables = Nothing: Set mRXIndexes = Nothing
End Sub

Private Function RX_Find(ByVal tableName As String, ByVal id As String, Optional ByVal col As Long = 1) As Range
    Dim lr As ListRow, found As Range, index As Object, key As String, current As String
    If Len(id) = 0 Then Exit Function
    If mRXIndexes Is Nothing Then Set mRXIndexes = CreateObject("Scripting.Dictionary")
    key = tableName & "|" & col
    If Not mRXIndexes.exists(key) Then
        Set index = CreateObject("Scripting.Dictionary"): index.CompareMode = vbTextCompare
        For Each lr In RFQ_Table(tableName).ListRows
            current = CStr(lr.Range.Cells(1, col).Value2)
            If Len(current) > 0 Then
                If index.exists(current) Then Err.Raise vbObjectError + 2202, "RFQ", "ID duplicat in " & tableName & ": " & current
                index.Add current, lr.Range
            End If
        Next lr
        mRXIndexes.Add key, index
    End If
    Set index = mRXIndexes(key)
    If index.exists(id) Then
        Set found = index(id)
        If StrComp(CStr(found.Cells(1, col).Value2), id, vbTextCompare) <> 0 Then
            mRXIndexes.Remove key: Set RX_Find = RX_Find(tableName, id, col): Exit Function
        End If
        Set RX_Find = found
    End If
End Function

Private Function RX_Required(ByVal tableName As String, ByVal id As String) As Range
    Set RX_Required = RX_Find(tableName, id)
    If RX_Required Is Nothing Then Err.Raise vbObjectError + 2203, "RFQ", "Inregistrarea nu exista: " & id
End Function

Private Function RX_Num(ByVal value As Variant, ByVal label As String, Optional ByVal positive As Boolean = False) As Double
    If IsError(value) Then Err.Raise vbObjectError + 2204, "RFQ", label & ": valoare Excel invalida."
    If Len(Trim$(CStr(value))) = 0 And Not positive Then RX_Num = 0: Exit Function
    If Not IsNumeric(value) Then Err.Raise vbObjectError + 2204, "RFQ", label & ": completati un numar."
    RX_Num = CDbl(value)
    If RX_Num < 0 Or (positive And RX_Num <= 0) Then Err.Raise vbObjectError + 2205, "RFQ", label & ": valoare negativa sau cantitate nula."
End Function

Private Function RX_Date(ByVal value As Variant, ByVal label As String) As Double
    If IsNumeric(value) Then
        RX_Date = Int(CDbl(value))
    ElseIf IsDate(value) Then
        RX_Date = CDbl(DateValue(CDate(value)))
    Else
        Err.Raise vbObjectError + 2206, "RFQ", label & ": data invalida."
    End If
    If RX_Date < 1 Or RX_Date > 2958465# Then Err.Raise vbObjectError + 2206, "RFQ", label & ": data invalida."
End Function

Private Function RX_Text(ByVal value As Variant, ByVal label As String, Optional ByVal required As Boolean = False) As String
    If IsError(value) Then Err.Raise vbObjectError + 2207, "RFQ", label & ": valoare invalida."
    RX_Text = Trim$(CStr(value))
    If (required And Len(RX_Text) = 0) Or Len(RX_Text) > 2000 Then Err.Raise vbObjectError + 2207, "RFQ", label & ": camp gol sau prea lung (max. 2000)."
End Function

Private Function RX_LinkOK(ByVal value As String) As Boolean
    RX_LinkOK = (Len(value) = 0 Or LCase$(Left$(value, 8)) = "https://" Or LCase$(Left$(value, 7)) = "http://" Or _
        Left$(value, 2) = "\\" Or (Len(value) > 3 And Mid$(value, 2, 2) = ":\"))
End Function

Private Function RX_ID(ByVal prefix As String) As String
    Dim lo As ListObject, ws As Worksheet, duplicate As Boolean, lr As ListRow
    Do
        RX_ID = CO_NewID(prefix): duplicate = False
        For Each ws In ThisWorkbook.Worksheets
            If Left$(ws.name, 8) = "_TQM_RFQ" Then
                For Each lo In ws.ListObjects
                    For Each lr In lo.ListRows
                        If CStr(lr.Range.Cells(1, 1).Value2) = RX_ID Then duplicate = True
                    Next lr
                Next lo
            End If
        Next ws
    Loop While duplicate
End Function

Private Function RX_Friendly(ByVal prefix As String, ByVal tableName As String) As String
    Dim i As Long, lr As ListRow, exists As Boolean
    i = 1
    Do
        RX_Friendly = prefix & "-" & Year(Date) & "-" & Format$(i, "0000")
        exists = False
        For Each lr In RFQ_Table(tableName).ListRows
            If StrComp(CStr(lr.Range.Cells(1, 2).Value2), RX_Friendly, vbTextCompare) = 0 Then exists = True
        Next lr
        i = i + 1
    Loop While exists
End Function

Public Function RFQ_Parent(ByVal requestID As String) As String
    Dim r As Range
    Set r = RX_Find("tTQMRFQPozitii", requestID)
    If Not r Is Nothing Then RFQ_Parent = CStr(r.Cells(1, 2).Value2)
End Function

Public Function RFQ_Document(ByVal offerID As String) As String
    Dim r As Range
    Set r = RX_Find("tTQMRFQLiniiOferte", offerID)
    If Not r Is Nothing Then RFQ_Document = CStr(r.Cells(1, 2).Value2)
End Function

Public Function RFQ_Resolve(ByVal value As String) As String
    Dim r As Range
    Set r = RX_Find("tTQMRFQ", value)
    If r Is Nothing Then Set r = RX_Find("tTQMRFQ", value, 2)
    If Not r Is Nothing Then RFQ_Resolve = CStr(r.Cells(1, 1).Value2): Exit Function
    RFQ_Resolve = RFQ_Parent(value)
End Function

Public Function RFQ_CurrentPosition() As String
    Dim lo As ListObject, hit As Range, root As String, lr As ListRow
    If ActiveWorkbook Is ThisWorkbook Then
        If ActiveSheet.name = CO_SHEET Then
            Set lo = CO_Table(CO_REQ): Set hit = Intersect(ActiveCell, lo.DataBodyRange)
            If Not hit Is Nothing Then RFQ_CurrentPosition = CStr(ActiveSheet.Cells(ActiveCell.row, 1).Value2)
            If Len(RFQ_CurrentPosition) = 0 Then
                Set lo = CO_Table(CO_OFF): Set hit = Intersect(ActiveCell, lo.DataBodyRange)
                If Not hit Is Nothing Then RFQ_CurrentPosition = CStr(ActiveSheet.Cells(ActiveCell.row, 2).Value2)
            End If
        End If
    End If
    If Len(RFQ_CurrentPosition) > 0 Then Exit Function
    root = RFQ_Resolve(CStr(CO_GetSheet().Range("C9").Value2))
    If Len(root) > 0 Then
        For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
            If CStr(lr.Range.Cells(1, 2).Value2) = root And CStr(lr.Range.Cells(1, 5).Value2) = "Activa" Then
                RFQ_CurrentPosition = CStr(lr.Range.Cells(1, 1).Value2): Exit Function
            End If
        Next lr
    End If
End Function

' All participating tables are restored if a write or any downstream refresh fails.
Private Sub RX_Begin()
    Dim ws As Worksheet, lo As ListObject, a As Variant
    If mRXWriting Then Err.Raise vbObjectError + 2208, "RFQ", "O salvare RFQ este deja in curs."
    If ThisWorkbook.readonly Then Err.Raise vbObjectError + 2208, "RFQ", "Fisierul este deschis numai pentru citire."
    RFQ_ResetCache
    mRXEvents = Application.EnableEvents: mRXScreen = Application.ScreenUpdating
    Set mRXBackup = New Collection: Set mRXInserted = New Collection: Set mRXProtection = New Collection
    For Each ws In ThisWorkbook.Worksheets
        For Each lo In ws.ListObjects
            a = lo.DataBodyRange.Formula
            mRXBackup.Add Array(lo.name, lo.Range.address, a)
        Next lo
    Next ws
    mRXWriting = True: Application.EnableEvents = False: Application.ScreenUpdating = False
    For Each ws In ThisWorkbook.Worksheets
        If ws.ListObjects.count > 0 And ws.ProtectContents Then
            mRXProtection.Add Array(ws.name, ws.Protection.AllowFiltering)
            ws.Unprotect Password:=""
        End If
    Next ws
End Sub

Private Sub RX_End(ByVal rollback As Boolean)
    Dim item As Variant, lo As ListObject, ws As Worksheet, i As Long
    If Not mRXWriting Then Exit Sub
    If rollback Then
        For Each ws In ThisWorkbook.Worksheets
            If ws.ListObjects.count > 0 And ws.ProtectContents Then ws.Unprotect Password:=""
        Next ws
        For i = mRXInserted.count To 1 Step -1
            item = mRXInserted(i): ThisWorkbook.Worksheets(CStr(item(0))).rows(CLng(item(1))).Delete
        Next i
        For Each item In mRXBackup
            Set lo = RFQ_Table(CStr(item(0)))
            lo.DataBodyRange.ClearContents
            lo.Resize lo.Parent.Range(CStr(item(1)))
            lo.DataBodyRange.Formula = item(2)
        Next item
    End If
    For Each item In mRXProtection
        Set ws = ThisWorkbook.Worksheets(CStr(item(0)))
        ws.Protect Password:="", UserInterfaceOnly:=True, AllowFiltering:=CBool(item(1))
    Next item
    Application.EnableEvents = mRXEvents: Application.ScreenUpdating = mRXScreen
    mRXWriting = False
    RFQ_ResetCache
End Sub

Private Sub RX_Fail(ByVal eno As Long, ByVal msg As String)
    Dim rollbackMessage As String
    On Error Resume Next
    Err.Clear: RX_End True
    If Err.Number <> 0 Then rollbackMessage = vbCrLf & "Restaurare incompleta: " & Err.description & ". Inchideti fara salvare si redeschideti copia."
    Application.EnableEvents = mRXEvents: Application.ScreenUpdating = mRXScreen: mRXWriting = False
    On Error GoTo 0
    Err.Raise eno, "RFQ", msg & rollbackMessage
End Sub

Private Function RX_Add(ByVal tableName As String) As Range
    Dim lo As ListObject, lr As ListRow, n As Long, insertRow As Long
    Set lo = RFQ_Table(tableName)
    For Each lr In lo.ListRows
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) = 0 Then Set RX_Add = lr.Range: Exit Function
    Next lr
    If tableName = CO_REQ Or tableName = CO_OFF Then
        insertRow = lo.Range.row + lo.Range.rows.count
        n = CO_FreeRow(lo)
        If mRXWriting Then mRXInserted.Add Array(lo.Parent.name, insertRow)
        Set RX_Add = lo.ListRows(n).Range
    Else
        lo.Resize lo.Range.Resize(lo.Range.rows.count + 1, lo.Range.Columns.count)
        Set RX_Add = lo.ListRows(lo.ListRows.count).Range
    End If
End Function

Private Sub RX_Write(ByVal row As Range, ByVal data As Variant)
    Dim i As Long
    For i = 1 To UBound(data)
        If VarType(data(i)) = vbString Then row.Cells(1, i).NumberFormat = "@"
        row.Cells(1, i).Value2 = data(i)
    Next i
End Sub

Private Function RX_Serialize(ByVal row As Range, ByVal columns As Variant) As String
    Dim c As Variant, v As String
    For Each c In columns
        v = CStr(row.Cells(1, CLng(c)).Value2): RX_Serialize = RX_Serialize & Len(v) & ":" & v & ";"
    Next c
End Function

Private Function RX_Stamp(ByVal root As String) As String
    Dim name As Variant, lr As ListRow, v As String, include As Boolean, row As Range
    Set row = RX_Find("tTQMRFQ", root)
    If Not row Is Nothing Then RX_Stamp = RX_Serialize(row, Array(1, 2, 3, 4, 5, 6, 7, 9, 10))
    For Each name In Array("tTQMRFQPozitii", "tTQMRFQOferte", "tTQMRFQAtribuiri", "tTQMRFQInvitati")
        For Each lr In RFQ_Table(CStr(name)).ListRows
            include = (CStr(lr.Range.Cells(1, 2).Value2) = root)
            If include Then
                For Each row In lr.Range.Cells
                    v = CStr(row.Value2): RX_Stamp = RX_Stamp & Len(v) & ":" & v & ";"
                Next row
            End If
        Next lr
    Next name
    For Each lr In CO_Table(CO_REQ).ListRows
        If RFQ_Parent(CStr(lr.Range.Cells(1, 1).Value2)) = root Then RX_Stamp = RX_Stamp & RX_Serialize(lr.Range, Array(1, 2, 3, 4, 5, 6, 7, 8, 13, 14, 15, 20))
    Next lr
    For Each lr In CO_Table(CO_OFF).ListRows
        If RFQ_Parent(CStr(lr.Range.Cells(1, 2).Value2)) = root Then RX_Stamp = RX_Stamp & RX_Serialize(lr.Range, Array(1, 2, 3, 4, 5, 6, 8, 9, 10, 13, 14, 15, 16, 17, 18, 19, 20, 21))
    Next lr
End Function

Private Function RX_Fingerprint(ByVal offerID As String) As String
    Dim q As Range, r As Range, h As Range, m As Range
    Set q = RX_Required(CO_OFF, offerID): Set r = RX_Required(CO_REQ, CStr(q.Cells(1, 2).Value2))
    Set h = RX_Required("tTQMRFQOferte", RFQ_Document(offerID)): Set m = RX_Required("tTQMRFQLiniiOferte", offerID)
    RX_Fingerprint = RX_Serialize(r, Array(1, 3, 4, 5, 6, 7, 13)) & RX_Serialize(q, Array(1, 2, 3, 4, 5, 6, 8, 9, 10, 15, 16, 17, 18)) & _
        RX_Serialize(h, Array(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 16)) & RX_Serialize(m, Array(1, 2, 3, 4))
End Function

Private Function RX_POStamp(ByVal r As Range) As String
    RX_POStamp = RX_Serialize(r, Array(1, 2, 3, 4, 5, 6, 7, 8, 9, 15, 16, 17, 18))
End Function

Private Function RX_AwardQty(ByVal award As Range) As Double
    Dim p As Range
    If Len(CStr(award.Cells(1, 11).Value2)) > 0 Then
        Set p = RX_Required("tTQMCFPoz", CStr(award.Cells(1, 11).Value2))
        RX_AwardQty = Application.Max(RX_Num(p.Cells(1, 10).Value2, "Primit"), RX_Num(p.Cells(1, 7).Value2, "Comandat") - RX_Num(p.Cells(1, 11).Value2, "Anulat"))
    ElseIf CStr(award.Cells(1, 6).Value2) = "Aprobata" Then
        If CStr(award.Cells(1, 10).Value2) = RX_Fingerprint(CStr(award.Cells(1, 4).Value2)) Then RX_AwardQty = RX_Num(award.Cells(1, 5).Value2, "Cantitate aprobata", True)
    End If
End Function

Private Function RX_Allocated(ByVal id As String, ByVal byOffer As Boolean) As Double
    Dim lr As ListRow, c As Long
    If byOffer Then c = 4 Else c = 3
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If CStr(lr.Range.Cells(1, c).Value2) = id Then RX_Allocated = RX_Allocated + RX_AwardQty(lr.Range)
    Next lr
End Function

Private Function RX_HasOrders(ByVal id As String, ByVal byOffer As Boolean) As Boolean
    Dim lr As ListRow, c As Long
    If byOffer Then c = 4 Else c = 3
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If CStr(lr.Range.Cells(1, c).Value2) = id And Len(CStr(lr.Range.Cells(1, 11).Value2)) > 0 Then RX_HasOrders = True: Exit Function
    Next lr
End Function

Private Function RX_Eligibility(ByVal offerID As String) As String
    Dim o As Range, p As Range, h As Range, m As Range, q As Double
    On Error GoTo InvalidData
    Set o = RX_Required(CO_OFF, offerID): Set p = RX_Required(CO_REQ, CStr(o.Cells(1, 2).Value2))
    Set h = RX_Required("tTQMRFQOferte", RFQ_Document(offerID))
    Set m = RX_Required("tTQMRFQPozitii", CStr(o.Cells(1, 2).Value2))
    Call RX_NMEligibility(p, m, CStr(h.Cells(1, 3).Value2))
    If CStr(m.Cells(1, 5).Value2) <> "Activa" Then RX_Eligibility = "Pozitie anulata": Exit Function
    If CStr(h.Cells(1, 16).Value2) <> "Activa" Then RX_Eligibility = "Document retras": Exit Function
    If CStr(o.Cells(1, 3).Value2) <> CStr(h.Cells(1, 3).Value2) Or CStr(o.Cells(1, 5).Value2) <> CStr(p.Cells(1, 5).Value2) Then RX_Eligibility = "Furnizor / UM diferite": Exit Function
    q = RX_Num(o.Cells(1, 4).Value2, "Cantitate oferita", True)
    If RX_Num(o.Cells(1, 15).Value2, "Discount") > 1 Then RX_Eligibility = "Discount invalid": Exit Function
    If RX_Num(o.Cells(1, 16).Value2, "Transport pe linie") <> 0 Or RX_Num(o.Cells(1, 17).Value2, "Costuri pe linie") <> 0 Then RX_Eligibility = "Costurile comune se introduc in antetul ofertei": Exit Function
    If CStr(o.Cells(1, 10).Value2) <> "Da" Then RX_Eligibility = "Conformitate tehnica de verificat / Nu": Exit Function
    If RX_Date(o.Cells(1, 14).Value2, "Data oferta") > CDbl(Date) Or RX_Date(h.Cells(1, 6).Value2, "Valabilitate") < CDbl(Date) Then RX_Eligibility = "Oferta expirata sau cu data viitoare": Exit Function
    If RX_Date(o.Cells(1, 8).Value2, "Livrare") < CDbl(Date) Then RX_Eligibility = "Termen de livrare trecut": Exit Function
    If RX_Date(o.Cells(1, 8).Value2, "Livrare") > RX_Date(p.Cells(1, 7).Value2, "Necesar") Then RX_Eligibility = "Livrare dupa data necesara": Exit Function
    Set m = RX_Required("tTQMRFQLiniiOferte", offerID)
    If CStr(m.Cells(1, 4).Value2) <> "Activa" Then RX_Eligibility = "Linie retrasa": Exit Function
    If RX_Num(m.Cells(1, 3).Value2, "Cantitate minima") > q Then RX_Eligibility = "Minim mai mare decat cantitatea oferita": Exit Function
    Call RX_Num(o.Cells(1, 6).Value2, "Pret")
    Exit Function
InvalidData:
    RX_Eligibility = Err.description
End Function

Private Sub RX_NMEligibility(ByVal request As Range, ByVal meta As Range, ByVal supplier As String)
    Dim r As Range
    Set r = RX_Required("tTQMNMMateriale", CStr(meta.Cells(1, 4).Value2))
    If CStr(r.Cells(1, 9).Value2) <> "Activ" Or StrComp(CStr(r.Cells(1, 2).Value2), CStr(request.Cells(1, 4).Value2), vbTextCompare) <> 0 Or _
        StrComp(CStr(r.Cells(1, 5).Value2), CStr(request.Cells(1, 13).Value2), vbTextCompare) <> 0 Or StrComp(CStr(r.Cells(1, 6).Value2), CStr(request.Cells(1, 5).Value2), vbTextCompare) <> 0 Then _
        Err.Raise vbObjectError + 2209, "RFQ", "Material inactiv sau specificatie nealiniata cu Nomenclatoare."
    Set r = RX_Find("tTQMNMParteneri", supplier, 3)
    If Not r Is Nothing Then
        If CStr(r.Cells(1, 13).Value2) <> "Activ" Then Err.Raise vbObjectError + 2209, "RFQ", "Furnizor inactiv."
    End If
    Set r = RX_Find("tTQMNMProiecte", CStr(request.Cells(1, 3).Value2), 3)
    If Not r Is Nothing Then
        If CStr(r.Cells(1, 8).Value2) <> "Activ" Then Err.Raise vbObjectError + 2209, "RFQ", "Proiect inactiv."
    End If
End Sub

Public Sub RFQ_Sync()
    Dim lr As ListRow, p As Range, q As Range, root As ListRow, valid As Long, n As Long, full As Long, partial As Long
    Dim amount As Double, need As Double, msg As String, id As String, parentID As String, stats As Object, parents As Object, a As Variant, b As Variant
    If mRXBusy Then Exit Sub
    RFQ_ResetCache
    mRXBusy = True
    On Error GoTo Failed
    Set stats = CreateObject("Scripting.Dictionary"): Set parents = CreateObject("Scripting.Dictionary")
    For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
        id = CStr(lr.Range.Cells(1, 1).Value2)
        If Len(id) > 0 Then stats.Add id, Array(0#, 0&, 0&, "")
    Next lr
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If Len(CStr(lr.Range.Cells(1, 11).Value2)) > 0 Then
            Set p = RX_Required("tTQMCFPoz", CStr(lr.Range.Cells(1, 11).Value2))
            If RX_POStamp(p) <> CStr(lr.Range.Cells(1, 12).Value2) Then Err.Raise vbObjectError + 2283, "RFQ_Sync", "Pozitia " & p.Cells(1, 1).Value2 & " difera de atribuirea comandata."
            If RX_Fingerprint(CStr(lr.Range.Cells(1, 4).Value2)) <> CStr(lr.Range.Cells(1, 10).Value2) Then Err.Raise vbObjectError + 2284, "RFQ_Sync", "Sursa comerciala a unei comenzi RFQ a fost modificata direct. Restabiliti cererea / oferta originala; folositi o revizie noua pentru conditii noi."
        End If
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 And Len(CStr(lr.Range.Cells(1, 11).Value2)) = 0 And CStr(lr.Range.Cells(1, 6).Value2) = "Aprobata" Then
            If CStr(lr.Range.Cells(1, 10).Value2) <> RX_Fingerprint(CStr(lr.Range.Cells(1, 4).Value2)) Or Len(RX_Eligibility(CStr(lr.Range.Cells(1, 4).Value2))) > 0 Then lr.Range.Cells(1, 6).Value2 = "De reconfirmat"
        End If
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then
            id = CStr(lr.Range.Cells(1, 3).Value2): amount = RX_AwardQty(lr.Range)
            If Not stats.exists(id) Then Err.Raise vbObjectError + 2203, "RFQ_Sync", "Atribuire fara pozitie RFQ."
            a = stats(id)
            If amount > 0 Then a(0) = a(0) + amount: a(2) = a(2) + 1: a(3) = CStr(lr.Range.Cells(1, 4).Value2)
            stats(id) = a
        End If
    Next lr
    For Each lr In RFQ_Table("tTQMRFQLiniiOferte").ListRows
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then
            Set q = RX_Required(CO_OFF, CStr(lr.Range.Cells(1, 1).Value2))
            msg = RX_Eligibility(CStr(q.Cells(1, 1).Value2))
            q.Cells(1, 11).Value2 = IIf(Len(msg) = 0, 1, 0)
            q.Cells(1, 12).Value2 = IIf(Len(msg) = 0, "Comparati cantitatile si costurile documentului RFQ", msg)
            q.Cells(1, 29).Value2 = RX_Num(q.Cells(1, 6).Value2, "Pret") * (1 - RX_Num(q.Cells(1, 15).Value2, "Discount"))
            id = CStr(q.Cells(1, 2).Value2)
            If Not stats.exists(id) Then Err.Raise vbObjectError + 2203, "RFQ_Sync", "Oferta fara pozitie RFQ."
            a = stats(id): If Len(msg) = 0 Then a(1) = a(1) + 1
            stats(id) = a
        End If
    Next lr
    For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
        If Len(CStr(lr.Range.Cells(1, 1).Value2)) > 0 Then
            Set p = RX_Required(CO_REQ, CStr(lr.Range.Cells(1, 1).Value2))
            a = stats(CStr(p.Cells(1, 1).Value2)): amount = CDbl(a(0)): valid = CLng(a(1)): need = RX_Num(p.Cells(1, 6).Value2, "Necesar", True)
            p.Cells(1, 9).Value2 = valid: p.Cells(1, 10).ClearContents: p.Cells(1, 11).Value2 = "Vezi Compara RFQ"
            If CLng(a(2)) = 1 Then p.Cells(1, 16).Value2 = CStr(a(3)) Else p.Cells(1, 16).ClearContents
            p.Cells(1, 21).ClearContents
            If CStr(lr.Range.Cells(1, 5).Value2) = "Anulata" Then
                p.Cells(1, 12).Value2 = "ANULATA"
            ElseIf amount >= need - 0.00000001 Then
                p.Cells(1, 12).Value2 = "APROBATA"
            ElseIf amount > 0 Then
                p.Cells(1, 12).Value2 = "APROBATA PARTIAL"
            ElseIf valid > 0 Then
                p.Cells(1, 12).Value2 = "DE APROBAT"
            Else
                p.Cells(1, 12).Value2 = "DE OFERTAT"
            End If
            parentID = CStr(lr.Range.Cells(1, 2).Value2)
            If Not parents.exists(parentID) Then parents.Add parentID, Array(0&, 0&, 0&)
            b = parents(parentID)
            If CStr(lr.Range.Cells(1, 5).Value2) = "Activa" Then
                b(0) = b(0) + 1
                If CStr(p.Cells(1, 12).Value2) = "APROBATA" Then b(1) = b(1) + 1
                If amount > 0 Then b(2) = b(2) + 1
            End If
            parents(parentID) = b
        End If
    Next lr
    For Each root In RFQ_Table("tTQMRFQ").ListRows
        If Len(CStr(root.Range.Cells(1, 1).Value2)) > 0 Then
            b = Array(0&, 0&, 0&)
            If parents.exists(CStr(root.Range.Cells(1, 1).Value2)) Then b = parents(CStr(root.Range.Cells(1, 1).Value2))
            n = CLng(b(0)): full = CLng(b(1)): partial = CLng(b(2))
            root.Range.Cells(1, 8).Value2 = IIf(n = 0, "Anulata", IIf(full = n, "Aprobata", IIf(partial > 0, "Aprobata partial", "In evaluare")))
        End If
    Next root
    mRXBusy = False
    Exit Sub
Failed:
    mRXBusy = False: Err.Raise Err.Number, "RFQ_Sync", Err.description
End Sub

' Request header: Nr, Data, default Project, Requester, deadline, notes.
' Lines: stable ID, position no, code, material, specification, UM, qty,
'        need date, project, priority, notes, state, optional line budget.
Public Function RFQ_SaveRequest(ByVal root As String, ByVal header As Variant, ByVal lines As Collection, Optional ByVal stamp As String = "") As String
    Dim item As Variant, seen As Object, refs As Object, r As Range, h As Range, m As Range, lr As ListRow
    Dim a(1 To 24) As Variant, b(1 To 5) As Variant, v(1 To 11) As Variant, i As Long, id As String, q As Double, eno As Long, msg As String, newRoot As Boolean
    Dim prepared As New Collection, materialID As String
    On Error GoTo Failed
    newRoot = (Len(root) = 0)
    If newRoot Then root = RX_ID("RFQ") Else Set h = RX_Required("tTQMRFQ", root)
    If Len(stamp) > 0 And RX_Stamp(root) <> stamp Then Err.Raise vbObjectError + 2210, "RFQ", "Cererea s-a modificat. Redeschideti formularul."
    header(1) = RX_Text(header(1), "Nr. cerere", True): header(2) = RX_Date(header(2), "Data cerere")
    header(3) = RX_Text(header(3), "Proiect implicit", True): header(4) = RX_Text(header(4), "Solicitant", True)
    header(3) = NM_RFQName(3, CStr(header(3)), Not newRoot)
    header(5) = RX_Date(header(5), "Termen raspuns"): header(6) = RX_Text(header(6), "Observatii")
    If header(2) > CDbl(Date) Or header(5) < header(2) Then Err.Raise vbObjectError + 2211, "RFQ", "Datele cererii sunt incorecte."
    For Each lr In RFQ_Table("tTQMRFQ").ListRows
        If CStr(lr.Range.Cells(1, 1).Value2) <> root And StrComp(CStr(lr.Range.Cells(1, 2).Value2), CStr(header(1)), vbTextCompare) = 0 Then Err.Raise vbObjectError + 2212, "RFQ", "Numar RFQ deja folosit."
    Next lr
    If lines.count = 0 Or lines.count > 100 Then Err.Raise vbObjectError + 2213, "RFQ", "Introduceti intre 1 si 100 pozitii."
    Set seen = CreateObject("Scripting.Dictionary"): Set refs = CreateObject("Scripting.Dictionary")
    For Each item In lines
        id = CStr(item(1))
        If Len(id) > 0 Then
            If RFQ_Parent(id) <> root Or refs.exists(id) Then Err.Raise vbObjectError + 2214, "RFQ", "Pozitie duplicata sau din alta cerere."
            refs.Add id, True
        End If
        If seen.exists(CStr(item(2))) Or RX_Num(item(2), "Nr. pozitie", True) <> Int(CDbl(item(2))) Then Err.Raise vbObjectError + 2215, "RFQ", "Numerele pozitiilor trebuie sa fie intregi si unice."
        seen.Add CStr(item(2)), True
        Call RX_Text(item(4), "Material", True): Call RX_Text(item(6), "UM", True)
        materialID = NM_ResolveMaterial(CStr(item(3)), CStr(item(4)), CStr(item(5)), CStr(item(6)), RX_HasOrders(id, False))
        Set r = RX_Find("tTQMNMMateriale", materialID, 11)
        If r Is Nothing Then Err.Raise vbObjectError + 2216, "RFQ", "Materialul trebuie selectat din Nomenclatoare."
        item(3) = r.Cells(1, 1).Value2: item(4) = r.Cells(1, 2).Value2: item(5) = r.Cells(1, 5).Value2: item(6) = r.Cells(1, 6).Value2
        q = RX_Num(item(7), "Cantitate", True)
        If Abs(q - Round(q, 6)) > 0.00000001 Then Err.Raise vbObjectError + 2217, "RFQ", "Cantitatea accepta maximum 6 zecimale."
        If RX_Date(item(8), "Data necesara") < header(2) Then Err.Raise vbObjectError + 2218, "RFQ", "Data necesara este anterioara cererii."
        item(9) = NM_RFQName(3, RX_Text(item(9), "Proiect pozitie", True), RX_HasOrders(id, False))
        item(11) = RX_Text(item(11), "Observatii pozitie")
        If item(10) <> "Normala" And item(10) <> "Ridicata" And item(10) <> "Urgenta" Then Err.Raise vbObjectError + 2219, "RFQ", "Prioritate: Normala / Ridicata / Urgenta."
        If item(12) <> "Activa" And item(12) <> "Anulata" Then Err.Raise vbObjectError + 2219, "RFQ", "Stare pozitie: Activa / Anulata."
        If Len(CStr(item(13))) > 0 Then Call RX_Num(item(13), "Buget")
        If RX_HasOrders(id, False) Then
            Set r = RX_Required(CO_REQ, id): Set m = RX_Required("tTQMRFQPozitii", id)
            If CStr(item(3)) <> CStr(m.Cells(1, 4).Value2) Or CStr(item(4)) <> CStr(r.Cells(1, 4).Value2) Or CStr(item(5)) <> CStr(r.Cells(1, 13).Value2) Or _
                CStr(item(6)) <> CStr(r.Cells(1, 5).Value2) Or Abs(q - CDbl(r.Cells(1, 6).Value2)) > 0.00000001 Or CStr(item(9)) <> CStr(r.Cells(1, 3).Value2) Or _
                CDbl(item(8)) <> CDbl(r.Cells(1, 7).Value2) Or CStr(item(12)) <> CStr(m.Cells(1, 5).Value2) Then Err.Raise vbObjectError + 2220, "RFQ", "Pozitia are comenzi. Datele ei comerciale raman cele comandate."
        End If
        prepared.Add item
    Next item
    For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root Then
            If Not refs.exists(CStr(lr.Range.Cells(1, 1).Value2)) Then Err.Raise vbObjectError + 2221, "RFQ", "Nu stergeti pozitii existente. Folositi starea Anulata."
        End If
    Next lr
    RX_Begin
    If newRoot Then Set h = RX_Add("tTQMRFQ")
    v(1) = root: v(2) = header(1): v(3) = header(2): v(4) = header(3): v(5) = header(4): v(6) = header(5): v(7) = header(6)
    v(8) = "In evaluare": v(9) = 1: v(10) = "": v(11) = CDbl(Now)
    If Not newRoot Then v(9) = Val(CStr(h.Cells(1, 9).Value2)) + 1: v(10) = h.Cells(1, 10).Value2
    RX_Write h, v
    For Each item In prepared
        id = CStr(item(1)): Set r = Nothing: Set m = Nothing
        For i = 1 To 24: a(i) = Empty: Next i
        If Len(id) = 0 Then
            id = RX_ID("CER"): Set r = RX_Add(CO_REQ): Set m = RX_Add("tTQMRFQPozitii"): a(22) = Application.UserName
        Else
            Set r = RX_Required(CO_REQ, id): Set m = RX_Required("tTQMRFQPozitii", id)
            a(22) = r.Cells(1, 22).Value2
        End If
        a(1) = id: a(2) = header(2): a(3) = item(9): a(4) = item(4): a(5) = item(6): a(6) = CDbl(item(7)): a(7) = RX_Date(item(8), "Necesar")
        a(8) = item(10): a(13) = item(5): a(14) = header(4): a(15) = item(13): a(20) = item(11): a(23) = CDbl(Now)
        RX_Write r, a
        b(1) = id: b(2) = root: b(3) = CLng(item(2)): b(4) = item(3): b(5) = item(12): RX_Write m, b
    Next item
    CO_RefreshCore: RX_End False
    RFQ_SaveRequest = root
    Exit Function
Failed:
    eno = Err.Number: msg = Err.description
    If mRXWriting Then RX_Fail eno, msg Else Err.Raise eno, "RFQ_SaveRequest", msg
End Function

' Quote header: supplier, number, date, expiry, freight, other, order minimum,
' package (Independent/Integral), package discount RON, terms, link, notes.
' Lines: request ID, offered qty, unit price, discount PERCENT, delivery, technical,
' minimum qty, notes. Zero/blank qty means NO BID and creates no offer line.
Public Function RFQ_SaveQuote(ByVal root As String, ByVal docID As String, ByVal header As Variant, ByVal lines As Collection, Optional ByVal stamp As String = "") As String
    Dim h As Range, p As Range, o As Range, m As Range, lr As ListRow, item As Variant, seen As Object, oldIDs As Collection, id As Variant
    Dim v(1 To 17) As Variant, a(1 To 29) As Variant, b(1 To 3) As Variant, q As Double, i As Long, count As Long, newDoc As Boolean, total As Double, eno As Long, msg As String
    On Error GoTo Failed
    Call RX_Required("tTQMRFQ", root)
    newDoc = (Len(docID) = 0)
    If newDoc Then docID = RX_ID("OFD") Else Set h = RX_Required("tTQMRFQOferte", docID)
    If Not newDoc Then
        If CStr(h.Cells(1, 2).Value2) <> root Then Err.Raise vbObjectError + 2230, "RFQ", "Oferta apartine altei cereri."
        For Each lr In RFQ_Table("tTQMRFQLiniiOferte").ListRows
            If CStr(lr.Range.Cells(1, 2).Value2) = docID And RX_HasOrders(CStr(lr.Range.Cells(1, 1).Value2), True) Then Err.Raise vbObjectError + 2231, "RFQ", "Documentul are comenzi. Inregistrati o oferta noua pentru conditii noi."
        Next lr
    End If
    If Len(stamp) > 0 And RX_Stamp(root) <> stamp Then Err.Raise vbObjectError + 2232, "RFQ", "Sursele s-au modificat. Redeschideti oferta."
    header(1) = NM_RFQName(2, RX_Text(header(1), "Furnizor", True), False)
    header(2) = RX_Text(header(2), "Nr. oferta", True): header(3) = RX_Date(header(3), "Data oferta"): header(4) = RX_Date(header(4), "Valabilitate")
    If header(3) > CDbl(Date) Or header(4) < header(3) Then Err.Raise vbObjectError + 2233, "RFQ", "Datele ofertei sunt incorecte."
    For i = 5 To 7: header(i) = Application.WorksheetFunction.Round(RX_Num(header(i), "Cost / prag oferta"), 2): Next i
    header(9) = Application.WorksheetFunction.Round(RX_Num(header(9), "Discount pachet"), 2)
    For i = 10 To 12: header(i) = RX_Text(header(i), "Conditii / link / observatii oferta"): Next i
    If header(8) <> "Independent" And header(8) <> "Integral" Then Err.Raise vbObjectError + 2234, "RFQ", "Conditie: Independent / Integral."
    If header(9) > 0 And header(8) <> "Integral" Then Err.Raise vbObjectError + 2235, "RFQ", "Discountul de pachet necesita conditia Integral."
    If Not RX_LinkOK(CStr(header(11))) Then Err.Raise vbObjectError + 2236, "RFQ", "Link oferta invalid."
    For Each lr In RFQ_Table("tTQMRFQOferte").ListRows
        If CStr(lr.Range.Cells(1, 1).Value2) <> docID And StrComp(CStr(lr.Range.Cells(1, 3).Value2), CStr(header(1)), vbTextCompare) = 0 And _
            StrComp(CStr(lr.Range.Cells(1, 4).Value2), CStr(header(2)), vbTextCompare) = 0 Then Err.Raise vbObjectError + 2237, "RFQ", "Nr. oferta deja folosit pentru acest furnizor. Folositi numarul reviziei."
    Next lr
    Set seen = CreateObject("Scripting.Dictionary"): Set oldIDs = New Collection
    If lines.count > 100 Then Err.Raise vbObjectError + 2238, "RFQ", "Maximum 100 pozitii per oferta."
    For Each item In lines
        q = RX_Num(item(2), "Cantitate oferita")
        If q > 0 Then
            If RFQ_Parent(CStr(item(1))) <> root Or seen.exists(CStr(item(1))) Then Err.Raise vbObjectError + 2238, "RFQ", "Pozitie duplicata sau din alta cerere."
            seen.Add CStr(item(1)), True: count = count + 1
            Set p = RX_Required(CO_REQ, CStr(item(1))): Set m = RX_Required("tTQMRFQPozitii", CStr(item(1)))
            If CStr(m.Cells(1, 5).Value2) <> "Activa" Then Err.Raise vbObjectError + 2239, "RFQ", "Nu ofertati pozitii anulate."
            If Abs(q - Round(q, 6)) > 0.00000001 Then Err.Raise vbObjectError + 2240, "RFQ", "Cantitatea accepta maximum 6 zecimale."
            Call RX_Text(item(3), "Pret (0 numai daca este explicit)", True)
            Call RX_Num(item(3), "Pret", False)
            If RX_Num(item(4), "Discount %") > 100 Then Err.Raise vbObjectError + 2241, "RFQ", "Discountul procentual trebuie sa fie 0..100."
            If RX_Date(item(5), "Livrare") < header(3) Then Err.Raise vbObjectError + 2242, "RFQ", "Livrarea este anterioara ofertei."
            If item(6) <> "Da" And item(6) <> "Nu" And item(6) <> "De verificat" Then Err.Raise vbObjectError + 2243, "RFQ", "Conformitate: Da / Nu / De verificat."
            If RX_Num(item(7), "Minim cantitate") > q Then Err.Raise vbObjectError + 2244, "RFQ", "Minimul depaseste cantitatea disponibila."
            Call RX_Text(item(8), "Observatii linie oferta")
            total = total + Application.WorksheetFunction.Round(q * CDbl(item(3)) * (1 - RX_Num(item(4), "Discount") / 100), 2)
        End If
    Next item
    If count = 0 Or header(9) > Application.WorksheetFunction.Round(total, 2) Then Err.Raise vbObjectError + 2245, "RFQ", "Oferta fara pozitii sau discount de pachet mai mare decat marfa."
    For Each lr In CO_Table(CO_OFF).ListRows
        If RFQ_Document(CStr(lr.Range.Cells(1, 1).Value2)) = docID Then oldIDs.Add CStr(lr.Range.Cells(1, 1).Value2)
    Next lr
    RX_Begin
    If newDoc Then Set h = RX_Add("tTQMRFQOferte")
    v(1) = docID: v(2) = root: v(3) = header(1): v(4) = header(2): v(5) = header(3): v(6) = header(4): v(7) = header(5): v(8) = header(6)
    v(9) = header(7): v(10) = header(8): v(11) = header(9): v(12) = header(10): v(13) = header(11): v(14) = header(12): v(15) = 1: v(16) = "Activa": v(17) = CDbl(Now)
    If Not newDoc Then v(15) = Val(CStr(h.Cells(1, 15).Value2)) + 1
    RX_Write h, v
    For Each id In oldIDs
        Set o = RX_Required(CO_OFF, CStr(id))
        If Not seen.exists(CStr(o.Cells(1, 2).Value2)) Then
            ' Keep IDs and document references, but mark a withdrawn line unavailable.
            o.Cells(1, 10).Value2 = "Nu": o.Cells(1, 21).Value2 = "Linie retrasa din documentul furnizorului."
            Set m = RX_Required("tTQMRFQLiniiOferte", CStr(id)): m.Cells(1, 4).Value2 = "Retrasa"
        End If
    Next id
    For Each item In lines
        q = RX_Num(item(2), "Cantitate")
        If q > 0 Then
            Set p = RX_Required(CO_REQ, CStr(item(1))): Set o = Nothing
            For Each id In oldIDs
                Set m = RX_Required(CO_OFF, CStr(id))
                If CStr(m.Cells(1, 2).Value2) = CStr(item(1)) Then Set o = m
            Next id
            For i = 1 To 29: a(i) = Empty: Next i
            If o Is Nothing Then
                a(1) = RX_ID("OFE"): a(23) = Application.UserName: Set o = RX_Add(CO_OFF): Set m = RX_Add("tTQMRFQLiniiOferte")
            Else
                a(1) = o.Cells(1, 1).Value2: a(23) = o.Cells(1, 23).Value2: Set m = RX_Required("tTQMRFQLiniiOferte", CStr(a(1)))
            End If
            a(2) = item(1): a(3) = header(1): a(4) = q: a(5) = p.Cells(1, 5).Value2: a(6) = CDbl(item(3)): a(8) = RX_Date(item(5), "Livrare")
            a(9) = header(4): a(10) = item(6): a(13) = header(2): a(14) = header(3): a(15) = RX_Num(item(4), "Discount") / 100
            a(16) = 0: a(17) = 0: a(18) = header(10): a(20) = header(11): a(21) = item(8): a(24) = CDbl(Now)
            RX_Write o, a
            m.Cells(1, 1).Value2 = a(1): m.Cells(1, 2).Value2 = docID: m.Cells(1, 3).Value2 = RX_Num(item(7), "Cantitate minima"): m.Cells(1, 4).Value2 = "Activa"
        End If
    Next item
    RFQ_InviteCore root, CStr(header(1)), "Raspuns primit", ""
    CO_RefreshCore: RX_End False
    RFQ_SaveQuote = docID
    Exit Function
Failed:
    eno = Err.Number: msg = Err.description
    If mRXWriting Then RX_Fail eno, msg Else Err.Raise eno, "RFQ_SaveQuote", msg
End Function

Private Sub RFQ_InviteCore(ByVal root As String, ByVal supplier As String, ByVal state As String, ByVal notes As String)
    Dim lr As ListRow, r As Range, a(1 To 7) As Variant
    For Each lr In RFQ_Table("tTQMRFQInvitati").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root And StrComp(CStr(lr.Range.Cells(1, 3).Value2), supplier, vbTextCompare) = 0 Then Set r = lr.Range
    Next lr
    If r Is Nothing Then
        Set r = RX_Add("tTQMRFQInvitati"): a(1) = RX_ID("INV")
    Else
        a(1) = r.Cells(1, 1).Value2: a(5) = r.Cells(1, 5).Value2
    End If
    a(2) = root: a(3) = supplier: a(4) = state
    If state = "Trimisa" Then a(5) = CDbl(Date)
    a(6) = CDbl(Now): a(7) = notes: RX_Write r, a
End Sub

Public Sub RFQ_RecordInvitation(ByVal root As String, ByVal supplier As String, ByVal state As String, Optional ByVal notes As String = "")
    Dim eno As Long, msg As String
    On Error GoTo Failed
    Call RX_Required("tTQMRFQ", root): NM_ValidatePartner RX_Text(supplier, "Furnizor", True), "", False
    If InStr("|De trimis|Trimisa|Raspuns primit|Refuzat|Fara raspuns|", "|" & state & "|") = 0 Then Err.Raise vbObjectError + 2250, "RFQ", "Stare invitatie necunoscuta."
    RX_Begin: RFQ_InviteCore root, supplier, state, notes: RX_End False
    Exit Sub
Failed:
    eno = Err.Number: msg = Err.description
    If mRXWriting Then RX_Fail eno, msg Else Err.Raise eno, "RFQ_RecordInvitation", msg
End Sub

Public Sub RFQ_Approve(ByVal offerID As String, ByVal qty As Double, ByVal approver As String, ByVal reason As String)
    Dim o As Range, p As Range, h As Range, m As Range, item As Variant, group As Collection, lr As ListRow, a(1 To 15) As Variant
    Dim msg As String, id As String, amount As Double, available As Double, eno As Long
    On Error GoTo Failed
    Set o = RX_Required(CO_OFF, offerID): Set h = RX_Required("tTQMRFQOferte", RFQ_Document(offerID)): Set group = New Collection
    If CStr(h.Cells(1, 10).Value2) = "Integral" Then
        For Each lr In RFQ_Table("tTQMRFQLiniiOferte").ListRows
            If CStr(lr.Range.Cells(1, 2).Value2) = CStr(h.Cells(1, 1).Value2) And CStr(lr.Range.Cells(1, 4).Value2) = "Activa" Then
                Set o = RX_Required(CO_OFF, CStr(lr.Range.Cells(1, 1).Value2))
                If RX_Allocated(CStr(o.Cells(1, 1).Value2), True) > 0 Then Err.Raise vbObjectError + 2260, "RFQ", "Pachetul are deja atribuiri. Retrageti intregul pachet necomandat inainte de o noua decizie."
                group.Add Array(CStr(o.Cells(1, 1).Value2), CDbl(o.Cells(1, 4).Value2))
            End If
        Next lr
    Else
        group.Add Array(offerID, qty)
    End If
    approver = RX_Text(approver, "Aprobat de", True): reason = RX_Text(reason, "Motivul deciziei", True)
    For Each item In group
        id = CStr(item(0)): amount = RX_Num(item(1), "Cantitate aprobata", True): Set o = RX_Required(CO_OFF, id)
        Set p = RX_Required(CO_REQ, CStr(o.Cells(1, 2).Value2)): Set m = RX_Required("tTQMRFQLiniiOferte", id)
        msg = RX_Eligibility(id)
        If Len(msg) > 0 Then Err.Raise vbObjectError + 2261, "RFQ", msg
        If amount < RX_Num(m.Cells(1, 3).Value2, "Cantitate minima") Or Abs(amount - Round(amount, 6)) > 0.00000001 Then Err.Raise vbObjectError + 2262, "RFQ", "Cantitate sub minimul furnizorului sau peste 6 zecimale."
        available = CDbl(p.Cells(1, 6).Value2) - RX_Allocated(CStr(p.Cells(1, 1).Value2), False)
        If amount > available + 0.00000001 Or amount + RX_Allocated(id, True) > CDbl(o.Cells(1, 4).Value2) + 0.00000001 Then Err.Raise vbObjectError + 2263, "RFQ", "Cantitatea depaseste necesarul ramas sau disponibilul ofertei."
        For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
            If CStr(lr.Range.Cells(1, 4).Value2) = id And CStr(lr.Range.Cells(1, 6).Value2) = "Aprobata" And Len(CStr(lr.Range.Cells(1, 11).Value2)) = 0 Then Err.Raise vbObjectError + 2264, "RFQ", "Aceasta oferta are deja o atribuire necomandata. Retrageti-o pentru a schimba cantitatea."
        Next lr
    Next item
    RX_Begin
    For Each item In group
        Set o = RX_Required(CO_OFF, CStr(item(0)))
        a(1) = RX_ID("ATR"): a(2) = RFQ_Parent(CStr(o.Cells(1, 2).Value2)): a(3) = o.Cells(1, 2).Value2: a(4) = item(0): a(5) = CDbl(item(1))
        a(6) = "Aprobata": a(7) = approver: a(8) = CDbl(Now): a(9) = reason: a(10) = RX_Fingerprint(CStr(item(0)))
        a(11) = "": a(12) = "": a(13) = "": a(14) = 0: a(15) = 0
        Set m = RX_Add("tTQMRFQAtribuiri"): RX_Write m, a
    Next item
    CO_RefreshCore: RX_End False
    Exit Sub
Failed:
    eno = Err.Number: msg = Err.description
    If mRXWriting Then RX_Fail eno, msg Else Err.Raise eno, "RFQ_Approve", msg
End Sub

Public Sub RFQ_Withdraw(ByVal awardID As String)
    Dim r As Range, h As Range, lr As ListRow, group As Collection, item As Variant, docID As String, eno As Long, msg As String
    On Error GoTo Failed
    Set r = RX_Required("tTQMRFQAtribuiri", awardID): docID = RFQ_Document(CStr(r.Cells(1, 4).Value2))
    Set h = RX_Required("tTQMRFQOferte", docID): Set group = New Collection
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If CStr(lr.Range.Cells(1, 1).Value2) = awardID Or (CStr(h.Cells(1, 10).Value2) = "Integral" And RFQ_Document(CStr(lr.Range.Cells(1, 4).Value2)) = docID And CStr(lr.Range.Cells(1, 6).Value2) <> "Retrasa") Then
            If Len(CStr(lr.Range.Cells(1, 11).Value2)) > 0 Then Err.Raise vbObjectError + 2270, "RFQ", "Atribuirea are comanda. Anulati cantitatea ramasa din Comenzi furnizori."
            group.Add CStr(lr.Range.Cells(1, 1).Value2)
        End If
    Next lr
    RX_Begin
    For Each item In group
        Set r = RX_Required("tTQMRFQAtribuiri", CStr(item)): r.Cells(1, 6).Value2 = "Retrasa"
    Next item
    CO_RefreshCore: RX_End False
    Exit Sub
Failed:
    eno = Err.Number: msg = Err.description
    If mRXWriting Then RX_Fail eno, msg Else Err.Raise eno, "RFQ_Withdraw", msg
End Sub

' Award and native position IDs stay stable after editing the order header.
Public Sub RFQ_CheckOrderLine(ByVal line As Variant, ByVal supplier As String, ByVal orderID As String)
    Dim lr As ListRow, award As Range, p As Range, h As Range, fake(1 To 1, 1 To 19) As Variant, i As Variant
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If CStr(lr.Range.Cells(1, 11).Value2) = CStr(line(1)) And CStr(lr.Range.Cells(1, 13).Value2) = orderID Then Set award = lr.Range
    Next lr
    If award Is Nothing Then Err.Raise vbObjectError + 2280, "RFQ", "Pozitia RFQ trebuie generata din atribuirile aprobate."
    Set p = RX_Required("tTQMCFPoz", CStr(line(1))): Set h = RX_Required("tTQMComenzi", orderID)
    If StrComp(CStr(h.Cells(1, 4).Value2), supplier, vbTextCompare) <> 0 Then Err.Raise vbObjectError + 2281, "RFQ", "Furnizorul atribuirii nu poate fi schimbat."
    For i = 1 To 19: fake(1, i) = line(i): Next i
    For Each i In Array(1, 2, 3, 4, 5, 6, 7, 8, 9, 15, 16, 17, 18)
        If IsNumeric(fake(1, i)) And IsNumeric(p.Cells(1, i).Value2) Then
            If Abs(CDbl(fake(1, i)) - CDbl(p.Cells(1, i).Value2)) > 0.00000001 Then Err.Raise vbObjectError + 2282, "RFQ", "Cantitatea, pretul si sursele RFQ raman cele atribuite."
        ElseIf CStr(fake(1, i)) <> CStr(p.Cells(1, i).Value2) Then
            Err.Raise vbObjectError + 2282, "RFQ", "Datele tehnice si sursele RFQ raman cele atribuite."
        End If
    Next i
    If CStr(award.Cells(1, 12).Value2) <> RX_POStamp(p) Then Err.Raise vbObjectError + 2283, "RFQ", "Pozitia comenzii a fost modificata in afara circuitului aprobat."
    If CStr(h.Cells(1, 9).Value2) = "Ciorna" Then
        If CStr(award.Cells(1, 10).Value2) <> RX_Fingerprint(CStr(award.Cells(1, 4).Value2)) Then Err.Raise vbObjectError + 2284, "RFQ", "Sursa comerciala s-a modificat dupa generarea ciornei."
        If Len(RX_Eligibility(CStr(award.Cells(1, 4).Value2))) > 0 Then Err.Raise vbObjectError + 2285, "RFQ", "Oferta ciornei nu mai este valabila pentru trimitere."
    End If
End Sub

Public Sub RFQ_CheckOrderPlan(ByVal header As Variant, ByVal lines As Collection, ByVal orderID As String)
    Dim lr As ListRow, expected As Object, item As Variant, amount As Double, other As Double, managed As Boolean
    Set expected = CreateObject("Scripting.Dictionary")
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If CStr(lr.Range.Cells(1, 13).Value2) = orderID And Len(orderID) > 0 Then
            managed = True: expected.Add CStr(lr.Range.Cells(1, 11).Value2), True
            amount = amount + CDbl(lr.Range.Cells(1, 14).Value2): other = other + CDbl(lr.Range.Cells(1, 15).Value2)
        End If
    Next lr
    If Not managed Then Exit Sub
    If expected.count <> lines.count Then Err.Raise vbObjectError + 2286, "RFQ", "Pozitiile ciornei RFQ nu pot fi adaugate sau eliminate."
    For Each item In lines
        If Not expected.exists(CStr(item(1))) Then Err.Raise vbObjectError + 2287, "RFQ", "Pozitie diferita de atribuirea RFQ."
    Next item
    If Abs(CDbl(header(15)) - amount) > 0.005 Or Abs(CDbl(header(16)) - other) > 0.005 Then Err.Raise vbObjectError + 2288, "RFQ", "Costurile comune raman cele aprobate din documentele ofertelor."
End Sub

Public Function RFQ_OrderCancelled(ByVal orderID As String) As Boolean
    Dim lr As ListRow, p As Range
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If CStr(lr.Range.Cells(1, 13).Value2) = orderID And Len(orderID) > 0 Then
            Set p = RX_Required("tTQMCFPoz", CStr(lr.Range.Cells(1, 11).Value2))
            If RX_Num(p.Cells(1, 11).Value2, "Cantitate anulata") > 0 Then RFQ_OrderCancelled = True: Exit Function
        End If
    Next lr
End Function

' Common costs follow the projects on the awarded lines, including mixed-project POs.
Public Function RFQ_ProjectExtras(ByVal orderID As String) As Object
    Dim lr As ListRow, ar As Range, p As Range, docs As Object, charges As Object, weights As Object, shares As Object
    Dim doc As Variant, key As Variant, project As String, amount As Double, managed As Boolean
    Set docs = CreateObject("Scripting.Dictionary"): Set charges = CreateObject("Scripting.Dictionary")
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        Set ar = lr.Range
        If CStr(ar.Cells(1, 13).Value2) = orderID And Len(orderID) > 0 Then
            managed = True: doc = RFQ_Document(CStr(ar.Cells(1, 4).Value2))
            If Not docs.exists(doc) Then
                Set weights = CreateObject("Scripting.Dictionary"): weights.CompareMode = vbTextCompare
                docs.Add doc, weights: charges.Add doc, 0#
            End If
            Set p = RX_Required("tTQMCFPoz", CStr(ar.Cells(1, 11).Value2)): project = CStr(p.Cells(1, 16).Value2): Set weights = docs(doc)
            If Not weights.exists(project) Then weights.Add project, 0#
            amount = CDbl(p.Cells(1, 7).Value2) * CDbl(p.Cells(1, 8).Value2) * (1 - CDbl(p.Cells(1, 9).Value2) / 100)
            weights(project) = weights(project) + amount
            charges(doc) = charges(doc) + CDbl(ar.Cells(1, 14).Value2) + CDbl(ar.Cells(1, 15).Value2)
        End If
    Next lr
    If Not managed Then Exit Function
    Set RFQ_ProjectExtras = CreateObject("Scripting.Dictionary"): RFQ_ProjectExtras.CompareMode = vbTextCompare
    For Each doc In docs.keys
        Set weights = docs(doc): Set shares = RX_ShareMoney(weights, CDbl(charges(doc)))
        For Each key In shares.keys
            If Not RFQ_ProjectExtras.exists(key) Then RFQ_ProjectExtras.Add key, 0#
            RFQ_ProjectExtras(key) = RFQ_ProjectExtras(key) + shares(key)
        Next key
    Next doc
End Function

Private Function RX_ShareMoney(ByVal weights As Object, ByVal total As Double) As Object
    Dim key As Variant, fractions As Object, sum As Double, amount As Double, base As Double, used As Double, remaining As Long, best As String, fraction As Double
    Set RX_ShareMoney = CreateObject("Scripting.Dictionary"): RX_ShareMoney.CompareMode = vbTextCompare
    Set fractions = CreateObject("Scripting.Dictionary")
    For Each key In weights.keys: sum = sum + CDbl(weights(key)): Next key
    For Each key In weights.keys
        If sum > 0 Then amount = total * CDbl(weights(key)) / sum Else amount = total / weights.count
        base = Int(amount * 100 + 0.00000001) / 100
        RX_ShareMoney.Add key, base: fractions.Add key, amount - base: used = used + base
    Next key
    remaining = CLng(Application.WorksheetFunction.Round(total * 100, 0) - Application.WorksheetFunction.Round(used * 100, 0))
    Do While remaining > 0
        best = "": fraction = -1
        For Each key In fractions.keys
            If fractions(key) > fraction Then best = CStr(key): fraction = fractions(key)
        Next key
        RX_ShareMoney(best) = RX_ShareMoney(best) + 0.01: fractions(best) = -1: remaining = remaining - 1
    Loop
End Function

' Largest remainders distribute a package discount in cents without negative lines.
Private Function RX_PackageAmounts(ByVal group As Collection, ByVal sumGoods As Double, ByVal discount As Double) As Object
    Dim item As Variant, ar As Range, o As Range, amount As Double, base As Double, used As Double, remaining As Long, best As String, bestFraction As Double
    Dim fractions As Object, key As Variant
    Set RX_PackageAmounts = CreateObject("Scripting.Dictionary"): Set fractions = CreateObject("Scripting.Dictionary")
    For Each item In group
        Set ar = RX_Required("tTQMRFQAtribuiri", CStr(item)): Set o = RX_Required(CO_OFF, CStr(ar.Cells(1, 4).Value2))
        amount = Application.WorksheetFunction.Round(CDbl(ar.Cells(1, 5).Value2) * CDbl(o.Cells(1, 6).Value2) * (1 - CDbl(o.Cells(1, 15).Value2)), 2)
        If sumGoods > 0 Then amount = amount * (sumGoods - discount) / sumGoods
        base = Int(amount * 100 + 0.00000001) / 100
        RX_PackageAmounts.Add CStr(item), base: fractions.Add CStr(item), amount - base: used = used + base
    Next item
    remaining = CLng(Application.WorksheetFunction.Round((sumGoods - discount) * 100, 0) - Application.WorksheetFunction.Round(used * 100, 0))
    Do While remaining > 0
        best = "": bestFraction = -1
        For Each key In fractions.keys
            If fractions(key) > bestFraction Then best = CStr(key): bestFraction = fractions(key)
        Next key
        RX_PackageAmounts(best) = RX_PackageAmounts(best) + 0.01: fractions(best) = -1: remaining = remaining - 1
    Loop
End Function

' Returns the number of draft POs. Repeated calls consume no award twice.
Public Function RFQ_GenerateOrders(ByVal root As String) As Long
    Dim suppliers As Object, docs As Object, awards As Collection, lr As ListRow, ar As Range, o As Range, p As Range, meta As Range, h As Range, row As Range
    Dim key As Variant, doc As Variant, item As Variant, id As String, po As String, sumGoods As Double, dsc As Double, target As Double, used As Double, amount As Double
    Dim a(1 To 22) As Variant, v(1 To 19) As Variant, net As Double, project As String, n As Long, deadline As Double, eno As Long, msg As String
    Dim iRX As Long, groupRX As Collection, packageAmounts As Object
    On Error GoTo Failed
    Call RX_Required("tTQMRFQ", root): CO_RefreshCore
    Set suppliers = CreateObject("Scripting.Dictionary"): suppliers.CompareMode = vbTextCompare
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        Set ar = lr.Range
        If CStr(ar.Cells(1, 2).Value2) = root And Len(CStr(ar.Cells(1, 11).Value2)) = 0 And CStr(ar.Cells(1, 6).Value2) = "Aprobata" Then
            id = CStr(ar.Cells(1, 4).Value2): Set o = RX_Required(CO_OFF, id): msg = RX_Eligibility(id)
            If Len(msg) > 0 Or CStr(ar.Cells(1, 10).Value2) <> RX_Fingerprint(id) Then Err.Raise vbObjectError + 2290, "RFQ", "Atribuire nevalabila: " & id & " " & msg
            Set p = RX_Required(CO_REQ, CStr(ar.Cells(1, 3).Value2))
            If RX_Allocated(CStr(p.Cells(1, 1).Value2), False) > CDbl(p.Cells(1, 6).Value2) + 0.00000001 Or RX_Allocated(id, True) > CDbl(o.Cells(1, 4).Value2) + 0.00000001 Then Err.Raise vbObjectError + 2291, "RFQ", "Cantitati atribuite peste necesar / oferta."
            key = CStr(o.Cells(1, 3).Value2)
            If Not suppliers.exists(key) Then Set awards = New Collection: suppliers.Add key, awards
            Set awards = suppliers(key): awards.Add CStr(ar.Cells(1, 1).Value2)
        End If
    Next lr
    If suppliers.count = 0 Then Exit Function
    ' Validate every supplier document before writing any supplier order.
    For Each key In suppliers.keys
        Set awards = suppliers(key): Set docs = CreateObject("Scripting.Dictionary")
        If awards.count > 100 Then Err.Raise vbObjectError + 2292, "RFQ", "Maximum 100 atribuiri intr-o comanda de furnizor."
        For Each item In awards
            Set ar = RX_Required("tTQMRFQAtribuiri", CStr(item)): id = RFQ_Document(CStr(ar.Cells(1, 4).Value2))
            If Not docs.exists(id) Then docs.Add id, 0#
            Set o = RX_Required(CO_OFF, CStr(ar.Cells(1, 4).Value2))
            docs(id) = docs(id) + Application.WorksheetFunction.Round(CDbl(ar.Cells(1, 5).Value2) * CDbl(o.Cells(1, 6).Value2) * (1 - CDbl(o.Cells(1, 15).Value2)), 2)
        Next item
        For Each doc In docs.keys
            Set h = RX_Required("tTQMRFQOferte", CStr(doc))
            If docs(doc) - CDbl(h.Cells(1, 11).Value2) < CDbl(h.Cells(1, 9).Value2) - 0.005 Then Err.Raise vbObjectError + 2293, "RFQ", "Prag minim de marfa neindeplinit pentru oferta " & h.Cells(1, 4).Value2
            If CStr(h.Cells(1, 10).Value2) = "Integral" Then
                For Each lr In RFQ_Table("tTQMRFQLiniiOferte").ListRows
                    If CStr(lr.Range.Cells(1, 2).Value2) = CStr(doc) And CStr(lr.Range.Cells(1, 4).Value2) = "Activa" Then
                        Set o = RX_Required(CO_OFF, CStr(lr.Range.Cells(1, 1).Value2))
                        amount = 0
                        For Each item In awards
                            Set ar = RX_Required("tTQMRFQAtribuiri", CStr(item))
                            If CStr(ar.Cells(1, 4).Value2) = CStr(o.Cells(1, 1).Value2) Then amount = amount + CDbl(ar.Cells(1, 5).Value2)
                        Next item
                        If Abs(amount - CDbl(o.Cells(1, 4).Value2)) > 0.00000001 Then Err.Raise vbObjectError + 2294, "RFQ", "Pachetul integral trebuie comandat complet intr-o singura comanda."
                    End If
                Next lr
            End If
        Next doc
    Next key
    RX_Begin
    For Each key In suppliers.keys
        Set awards = suppliers(key): Set docs = CreateObject("Scripting.Dictionary")
        For iRX = 1 To 22: a(iRX) = Empty: Next iRX
        po = RX_ID("CF"): a(1) = po: a(2) = RX_Friendly("CF", "tTQMComenzi"): a(3) = CDbl(Date): a(4) = CStr(key)
        a(6) = "Ferma": a(7) = Application.UserName: a(9) = "Ciorna": a(15) = 0: a(16) = 0: a(17) = RX_Required("tTQMRFQ", root).Cells(1, 2).Value2
        a(19) = "Generata din atribuiri RFQ. Verificati si trimiteti din Deschide comanda.": a(20) = 1: a(21) = Application.UserName: a(22) = CDbl(Now)
        project = "": deadline = CDbl(Date): Set row = RX_Add("tTQMComenzi"): RX_Write row, a
        For Each item In awards
            Set ar = RX_Required("tTQMRFQAtribuiri", CStr(item)): id = RFQ_Document(CStr(ar.Cells(1, 4).Value2))
            If Not docs.exists(id) Then Set groupRX = New Collection: docs.Add id, groupRX
            Set groupRX = docs(id): groupRX.Add CStr(item)
        Next item
        For Each doc In docs.keys
            Set h = RX_Required("tTQMRFQOferte", CStr(doc)): Set groupRX = docs(doc): sumGoods = 0
            For Each item In groupRX
                Set ar = RX_Required("tTQMRFQAtribuiri", CStr(item)): Set o = RX_Required(CO_OFF, CStr(ar.Cells(1, 4).Value2))
                sumGoods = sumGoods + Application.WorksheetFunction.Round(CDbl(ar.Cells(1, 5).Value2) * CDbl(o.Cells(1, 6).Value2) * (1 - CDbl(o.Cells(1, 15).Value2)), 2)
            Next item
            dsc = CDbl(h.Cells(1, 11).Value2): target = Application.WorksheetFunction.Round(sumGoods - dsc, 2): used = 0: n = 0
            If dsc > 0 Then Set packageAmounts = RX_PackageAmounts(groupRX, sumGoods, dsc)
            a(15) = a(15) + CDbl(h.Cells(1, 7).Value2): a(16) = a(16) + CDbl(h.Cells(1, 8).Value2)
            For Each item In groupRX
                n = n + 1: Set ar = RX_Required("tTQMRFQAtribuiri", CStr(item)): Set o = RX_Required(CO_OFF, CStr(ar.Cells(1, 4).Value2))
                Set p = RX_Required(CO_REQ, CStr(ar.Cells(1, 3).Value2)): Set meta = RX_Required("tTQMRFQPozitii", CStr(ar.Cells(1, 3).Value2))
                For iRX = 1 To 19: v(iRX) = Empty: Next iRX
                v(1) = RX_ID("CP"): v(2) = po: v(3) = meta.Cells(1, 4).Value2: v(4) = p.Cells(1, 4).Value2: v(5) = p.Cells(1, 13).Value2: v(6) = p.Cells(1, 5).Value2
                v(7) = CDbl(ar.Cells(1, 5).Value2): v(8) = CDbl(o.Cells(1, 6).Value2): v(9) = 100 * CDbl(o.Cells(1, 15).Value2)
                net = v(7) * v(8) * (1 - v(9) / 100)
                If dsc > 0 Then
                    amount = packageAmounts(CStr(item))
                    v(8) = amount / v(7): v(9) = 0
                    used = used + amount
                End If
                v(10) = 0: v(11) = 0: v(12) = v(7): v(15) = o.Cells(1, 8).Value2: v(16) = p.Cells(1, 3).Value2: v(17) = p.Cells(1, 1).Value2: v(18) = o.Cells(1, 1).Value2
                v(19) = "RFQ " & CStr(a(17)) & "; oferta " & CStr(h.Cells(1, 4).Value2)
                If dsc > 0 Then v(19) = v(19) & "; pret net include discount pachet proportional."
                If Len(project) = 0 Then project = CStr(v(16)) Else If project <> CStr(v(16)) Then project = "Mai multe proiecte"
                deadline = Application.Max(deadline, CDbl(v(15)))
                Set p = RX_Add("tTQMCFPoz"): RX_Write p, v
                ar.Cells(1, 11).Value2 = v(1): ar.Cells(1, 12).Value2 = RX_POStamp(p): ar.Cells(1, 13).Value2 = po
                If n = 1 Then ar.Cells(1, 14).Value2 = h.Cells(1, 7).Value2: ar.Cells(1, 15).Value2 = h.Cells(1, 8).Value2
            Next item
        Next doc
        a(5) = project: a(8) = deadline: RX_Write row, a
        RFQ_GenerateOrders = RFQ_GenerateOrders + 1
    Next key
    CF_RFQRefresh: CO_RefreshCore: PB_RFQRefresh: DOC_RFQRefresh: RX_End False
    Exit Function
Failed:
    eno = Err.Number: msg = Err.description
    If mRXWriting Then RX_Fail eno, msg Else Err.Raise eno, "RFQ_GenerateOrders", msg
End Function


Private Function RX_FormOpen() As Boolean
    Dim wb As Workbook
    If mRXForm Is Nothing Then Exit Function
    For Each wb In Application.Workbooks
        If wb Is mRXForm Then RX_FormOpen = True: Exit Function
    Next wb
End Function

Private Function RX_StartForm(ByVal kind As String, ByVal id As String, ByVal root As String, ByVal sheetName As String) As Worksheet
    If RX_FormOpen() Then Err.Raise vbObjectError + 2300, "RFQ", "Un formular RFQ este deja deschis. Salvati-l sau folositi Inchide formular."
    mRXKind = kind: mRXID = id: mRXParent = root: mRXStamp = ""
    If Len(root) > 0 Then mRXStamp = RX_Stamp(root)
    Set mRXForm = Workbooks.Add(xlWBATWorksheet): Set RX_StartForm = mRXForm.Worksheets(1)
    RX_StartForm.name = sheetName
    With RX_StartForm
        .Cells.Font.name = "Aptos": .Cells.Font.size = 10: .Cells.Locked = True
        .Columns("A").ColumnWidth = 44: .Columns("B").ColumnWidth = 10
        .Columns("C").ColumnWidth = 20: .Columns("D:F").ColumnWidth = 24
        .Columns("G:H").ColumnWidth = 15: .Columns("I:O").ColumnWidth = 23
        .rows("1:3000").RowHeight = 24
        .Range("A1:O1").Merge: .Range("A1").Value2 = "TQM - " & kind
        .Range("A1:O1").Interior.Color = RGB(15, 23, 42): .Range("A1").Font.Color = vbWhite: .Range("A1").Font.size = 17
        .Range("A2:O2").Merge: .Range("A2").Value2 = "Formular local; salvarea scrie in fisierul principal. Ctrl+S salveaza fisierul principal."
        .Range("A2").Font.Color = RGB(100, 116, 139)
    End With
    ActiveWindow.DisplayGridlines = False: ActiveWindow.Zoom = 80
    ActiveWindow.FreezePanes = False: ActiveWindow.SplitRow = 3: ActiveWindow.FreezePanes = True
End Function

Private Sub RX_Button(ByVal ws As Worksheet, ByVal address As String, ByVal caption As String, ByVal action As String)
    Dim rg As Range, s As Shape
    Set rg = ws.Range(address)
    Set s = ws.Shapes.AddShape(msoShapeRoundedRectangle, rg.Left + 2, rg.Top + 2, rg.width - 4, rg.Height - 4)
    s.name = "RFQBTN_" & action: s.OnAction = "'" & Replace(ThisWorkbook.name, "'", "''") & "'!" & action
    s.Fill.ForeColor.RGB = RGB(37, 99, 235): s.line.Visible = msoFalse
    With s.TextFrame2
        .TextRange.text = caption: .TextRange.Font.name = "Aptos": .TextRange.Font.size = 10
        .TextRange.Font.Fill.ForeColor.RGB = vbWhite: .TextRange.ParagraphFormat.Alignment = msoAlignCenter
        .VerticalAnchor = msoAnchorMiddle
    End With
End Sub

Private Sub RX_Field(ByVal ws As Worksheet, ByVal labelCell As String, ByVal valueCell As String, ByVal caption As String, ByVal value As Variant, Optional ByVal editable As Boolean = True)
    ws.Range(labelCell).Value2 = caption
    With ws.Range(valueCell)
        If .Cells.count > 1 Then .Merge
        If VarType(value) = vbString Then .NumberFormat = "@"
        .Value2 = value: .Locked = Not editable
        .Interior.Color = IIf(editable, RGB(239, 246, 255), RGB(241, 245, 249))
    End With
End Sub

Private Sub RX_Grid(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal captions As Variant, ByVal lastRow As Long)
    Dim i As Long, lo As ListObject
    For i = 0 To UBound(captions): ws.Cells(rowNo, i + 1).Value2 = captions(i): Next i
    With ws.Range(ws.Cells(rowNo, 1), ws.Cells(rowNo, UBound(captions) + 1))
        .Interior.Color = RGB(37, 99, 235): .Font.Color = vbWhite: .Font.Bold = True: .WrapText = True
    End With
    ws.rows(rowNo).RowHeight = 38
    ws.Range(ws.Cells(rowNo + 1, 1), ws.Cells(lastRow, UBound(captions) + 1)).Interior.Color = RGB(239, 246, 255)
    If ws.name = "RFQ_Cerere" Or ws.name = "RFQ_Oferta" Then
        Set lo = ws.ListObjects.Add(xlSrcRange, ws.Range(ws.Cells(rowNo, 1), ws.Cells(lastRow, UBound(captions) + 1)), , xlYes)
        lo.TableStyle = "TableStyleMedium2"
    End If
End Sub

Private Sub RX_List(ByVal rg As Range, ByVal values As String)
    rg.Validation.Delete
    rg.Validation.Add Type:=xlValidateList, AlertStyle:=xlValidAlertStop, Formula1:=Replace(values, ",", Application.International(xlListSeparator))
    rg.Validation.ShowError = True
End Sub

Public Sub RFQ_CloseForm()
    If RX_FormOpen() Then
        If mRXKind = "CERERE" Or mRXKind = "OFERTA" Then
            If MsgBox("Inchideti formularul? Modificarile nesalvate din acest formular se pierd.", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
        End If
        mRXForm.Close SaveChanges:=False
    End If
    Set mRXForm = Nothing: mRXKind = "": mRXID = "": mRXParent = "": mRXStamp = ""
End Sub

Private Sub RX_CloseSaved()
    If RX_FormOpen() Then mRXForm.Close SaveChanges:=False
    Set mRXForm = Nothing: mRXKind = "": mRXID = "": mRXParent = "": mRXStamp = ""
End Sub

Private Sub RX_RequireForm(ByVal kind As String)
    If Not RX_FormOpen() Then Err.Raise vbObjectError + 2301, "RFQ", "Formularul nu mai este deschis."
    If mRXKind <> kind Then Err.Raise vbObjectError + 2302, "RFQ", "Deschideti formularul potrivit."
End Sub

Public Sub RFQ_OpenRequest(Optional ByVal root As String = "")
    Dim ws As Worksheet, h As Range, p As Range, lr As ListRow, n As Long, a(1 To 1, 1 To 13) As Variant, i As Variant
    On Error GoTo Failed
    CO_RefreshCore
    If Len(root) > 0 Then Set h = RX_Required("tTQMRFQ", root)
    Set ws = RX_StartForm("CERERE", root, root, "RFQ_Cerere")
    RX_Button ws, "B3:D3", "Salveaza cererea", "RFQ_SaveForm"
    RX_Button ws, "E3:G3", "Selecteaza material", "NM_AlegeMaterial"
    RX_Button ws, "H3:J3", "Selecteaza proiect", "NM_AlegeProiect"
    RX_Button ws, "K3:M3", "Inchide formular", "RFQ_CloseForm"
    RX_Field ws, "A5", "B5:F5", "Nr. cerere comuna", RX_Friendly("RFQ", "tTQMRFQ")
    RX_Field ws, "A6", "B6:F6", "Data cerere", CDbl(Date)
    RX_Field ws, "A7", "B7:F7", "Proiect implicit", ""
    RX_Field ws, "A8", "B8:F8", "Solicitant", Application.UserName
    RX_Field ws, "A9", "B9:F9", "Termen raspuns furnizori", CDbl(Date + 3)
    RX_Field ws, "A10", "B10:M10", "Observatii cerere", ""
    ws.Range("B6").NumberFormat = "dd.mm.yyyy": ws.Range("B9").NumberFormat = "dd.mm.yyyy"
    If Not h Is Nothing Then
        For i = 2 To 7: ws.Cells(i + 3, 2).Value2 = h.Cells(1, i).Value2: Next i
    End If
    ws.Range("B12:M12").Merge: ws.Range("B12").Value2 = "Un singur numar RFQ pentru toate pozitiile. ID-urile ascunse pastreaza legaturile. Marcati Anulata in loc sa stergeti pozitii existente."
    RX_Grid ws, 14, Array("ID intern", "Poz.", "Cod material", "Material", "Specificatie", "UM", "Necesar", "Data necesara", "Proiect", "Prioritate", "Observatii", "Stare", "Buget net RON"), 114
    ws.Range("B15:M114").Locked = False: ws.Range("C15:F114").NumberFormat = "@"
    ws.Range("I15:L114").NumberFormat = "@": ws.Range("H15:H114").NumberFormat = "dd.mm.yyyy"
    RX_List ws.Range("J15:J114"), "Normala,Ridicata,Urgenta": RX_List ws.Range("L15:L114"), "Activa,Anulata"
    n = 15
    For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
        If Len(root) > 0 And CStr(lr.Range.Cells(1, 2).Value2) = root Then
            Set p = RX_Required(CO_REQ, CStr(lr.Range.Cells(1, 1).Value2))
            a(1, 1) = p.Cells(1, 1).Value2: a(1, 2) = lr.Range.Cells(1, 3).Value2: a(1, 3) = lr.Range.Cells(1, 4).Value2
            a(1, 4) = p.Cells(1, 4).Value2: a(1, 5) = p.Cells(1, 13).Value2: a(1, 6) = p.Cells(1, 5).Value2
            a(1, 7) = p.Cells(1, 6).Value2: a(1, 8) = p.Cells(1, 7).Value2: a(1, 9) = p.Cells(1, 3).Value2
            a(1, 10) = p.Cells(1, 8).Value2: a(1, 11) = p.Cells(1, 20).Value2: a(1, 12) = lr.Range.Cells(1, 5).Value2: a(1, 13) = p.Cells(1, 15).Value2
            ws.Cells(n, 1).Resize(1, 13).Value2 = a
            If RX_HasOrders(CStr(a(1, 1)), False) Then ws.Range("C" & n & ":I" & n).Locked = True: ws.Cells(n, 12).Locked = True
            n = n + 1
        End If
    Next lr
    ws.Range("A15:A114").NumberFormat = ";;;": ws.Columns("B").ColumnWidth = 8
    ws.Protect UserInterfaceOnly:=True: ws.Range("D15").Select
    Exit Sub
Failed: MsgBox Err.description, vbExclamation, "TQM - RFQ"
End Sub

Public Sub RFQ_OpenQuote(ByVal root As String, Optional ByVal docID As String = "")
    Dim ws As Worksheet, h As Range, p As Range, o As Range, lr As ListRow, ml As ListRow, n As Long, a(1 To 1, 1 To 15) As Variant, i As Long
    On Error GoTo Failed
    CO_RefreshCore: Call RX_Required("tTQMRFQ", root)
    If Len(docID) > 0 Then Set h = RX_Required("tTQMRFQOferte", docID)
    Set ws = RX_StartForm("OFERTA", docID, root, "RFQ_Oferta")
    RX_Button ws, "B3:D3", "Salveaza oferta", "RFQ_SaveForm"
    RX_Button ws, "E3:G3", "Selecteaza furnizor", "NM_AlegePartener"
    RX_Button ws, "K3:M3", "Inchide formular", "RFQ_CloseForm"
    RX_Field ws, "A5", "B5:D5", "Furnizor", "": RX_Field ws, "F5", "G5:I5", "Nr. oferta / revizie", ""
    RX_Field ws, "A6", "B6:D6", "Data oferta", CDbl(Date): RX_Field ws, "F6", "G6:I6", "Valabila pana", CDbl(Date + 14)
    RX_Field ws, "A7", "B7:D7", "Transport comun net RON", 0: RX_Field ws, "F7", "G7:I7", "Alte costuri net RON", 0
    RX_Field ws, "A8", "B8:D8", "Prag minim marfa net RON", 0: RX_Field ws, "F8", "G8:I8", "Conditie pachet", "Independent"
    RX_Field ws, "A9", "B9:D9", "Discount pachet net RON", 0: RX_Field ws, "F9", "G9:M9", "Conditii plata", ""
    RX_Field ws, "A10", "B10:M10", "Link document oferta", ""
    RX_Field ws, "A11", "B11:M11", "Observatii document", ""
    ws.Range("B6").NumberFormat = "dd.mm.yyyy": ws.Range("G6").NumberFormat = "dd.mm.yyyy": RX_List ws.Range("G8"), "Independent,Integral"
    If Not h Is Nothing Then
        ws.Range("B5").Value2 = h.Cells(1, 3).Value2: ws.Range("G5").Value2 = h.Cells(1, 4).Value2
        ws.Range("B6").Value2 = h.Cells(1, 5).Value2: ws.Range("G6").Value2 = h.Cells(1, 6).Value2
        ws.Range("B7").Value2 = h.Cells(1, 7).Value2: ws.Range("G7").Value2 = h.Cells(1, 8).Value2
        ws.Range("B8").Value2 = h.Cells(1, 9).Value2: ws.Range("G8").Value2 = h.Cells(1, 10).Value2
        ws.Range("B9").Value2 = h.Cells(1, 11).Value2: ws.Range("G9").Value2 = h.Cells(1, 12).Value2
        ws.Range("B10").Value2 = h.Cells(1, 13).Value2: ws.Range("B11").Value2 = h.Cells(1, 14).Value2
    End If
    ws.Range("B12:O12").Merge: ws.Range("B12").Value2 = "Cantitate oferita goala/0 = fara raspuns pe pozitie. Pret 0 este admis numai explicit. Transportul se scrie o singura data, in antet."
    RX_Grid ws, 14, Array("ID intern", "Poz.", "Material", "Specificatie", "UM", "Necesar", "Disponibil oferit", "Pret unitar net", "Discount %", "Livrare", "Conform", "Minim cantitate", "Observatii", "Proiect", "ID oferta intern"), 114
    ws.Range("G15:M114").Locked = False: ws.Range("K15:K114").NumberFormat = "@": ws.Range("M15:M114").NumberFormat = "@"
    ws.Range("C15:E114").NumberFormat = "@"
    ws.Range("I15:I114").NumberFormat = "0.00%": ws.Range("H15:H114").NumberFormat = "#,##0.000000"
    ws.Range("J15:J114").NumberFormat = "dd.mm.yyyy": RX_List ws.Range("K15:K114"), "Da,Nu,De verificat"
    n = 15
    For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root And CStr(lr.Range.Cells(1, 5).Value2) = "Activa" Then
            For i = 1 To 15: a(1, i) = Empty: Next i
            Set p = RX_Required(CO_REQ, CStr(lr.Range.Cells(1, 1).Value2))
            a(1, 1) = p.Cells(1, 1).Value2: a(1, 2) = lr.Range.Cells(1, 3).Value2: a(1, 3) = p.Cells(1, 4).Value2: a(1, 4) = p.Cells(1, 13).Value2
            a(1, 5) = p.Cells(1, 5).Value2: a(1, 6) = p.Cells(1, 6).Value2: a(1, 9) = 0: a(1, 10) = p.Cells(1, 7).Value2: a(1, 11) = "De verificat": a(1, 12) = 0: a(1, 14) = p.Cells(1, 3).Value2
            If Len(docID) > 0 Then
                For Each ml In RFQ_Table("tTQMRFQLiniiOferte").ListRows
                    If CStr(ml.Range.Cells(1, 2).Value2) = docID And CStr(ml.Range.Cells(1, 4).Value2) = "Activa" Then
                        Set o = RX_Required(CO_OFF, CStr(ml.Range.Cells(1, 1).Value2))
                        If CStr(o.Cells(1, 2).Value2) = CStr(a(1, 1)) Then
                            a(1, 7) = o.Cells(1, 4).Value2: a(1, 8) = o.Cells(1, 6).Value2: a(1, 9) = CDbl(o.Cells(1, 15).Value2)
                            a(1, 10) = o.Cells(1, 8).Value2: a(1, 11) = o.Cells(1, 10).Value2: a(1, 12) = ml.Range.Cells(1, 3).Value2: a(1, 13) = o.Cells(1, 21).Value2: a(1, 15) = o.Cells(1, 1).Value2
                        End If
                    End If
                Next ml
            End If
            ws.Cells(n, 1).Resize(1, 15).Value2 = a: n = n + 1
        End If
    Next lr
    ws.Range("A15:A114").NumberFormat = ";;;": ws.Columns("O").Hidden = True: ws.Columns("B").ColumnWidth = 8
    ws.Protect UserInterfaceOnly:=True: ws.Range("B5").Select
    Exit Sub
Failed: MsgBox Err.description, vbExclamation, "TQM - RFQ"
End Sub

Public Sub RFQ_SaveForm()
    Dim ws As Worksheet, header(1 To 12) As Variant, lines As New Collection, a(1 To 13) As Variant, b(1 To 8) As Variant
    Dim n As Long, i As Long, id As String, root As String, kind As String
    On Error GoTo Failed
    If Not RX_FormOpen() Then Err.Raise vbObjectError + 2310, "RFQ", "Formularul nu mai exista."
    Set ws = mRXForm.Worksheets(1): kind = mRXKind
    If kind = "CERERE" Then
        For i = 1 To 6: header(i) = ws.Cells(i + 4, 2).Value2: Next i
        For n = 15 To 114
            If Application.CountA(ws.Range("C" & n & ":G" & n)) > 0 Or Len(CStr(ws.Cells(n, 1).Value2)) > 0 Then
                For i = 1 To 13: a(i) = ws.Cells(n, i).Value2: Next i
                If Len(CStr(a(2))) = 0 Then a(2) = n - 14
                If Len(CStr(a(8))) = 0 Then a(8) = CDbl(Date + 7)
                If Len(CStr(a(9))) = 0 Then a(9) = header(3)
                If Len(CStr(a(10))) = 0 Then a(10) = "Normala"
                If Len(CStr(a(12))) = 0 Then a(12) = "Activa"
                lines.Add a
            End If
        Next n
        root = RFQ_SaveRequest(mRXID, header, lines, mRXStamp)
        id = RX_Required("tTQMRFQ", root).Cells(1, 2).Value2
    ElseIf kind = "OFERTA" Then
        header(1) = ws.Range("B5").Value2: header(2) = ws.Range("G5").Value2: header(3) = ws.Range("B6").Value2: header(4) = ws.Range("G6").Value2
        header(5) = ws.Range("B7").Value2: header(6) = ws.Range("G7").Value2: header(7) = ws.Range("B8").Value2: header(8) = ws.Range("G8").Value2
        header(9) = ws.Range("B9").Value2: header(10) = ws.Range("G9").Value2: header(11) = ws.Range("B10").Value2: header(12) = ws.Range("B11").Value2
        For n = 15 To 114
            If Len(CStr(ws.Cells(n, 1).Value2)) > 0 Then
                b(1) = ws.Cells(n, 1).Value2: b(2) = ws.Cells(n, 7).Value2: b(3) = ws.Cells(n, 8).Value2: b(4) = 100 * RX_Num(ws.Cells(n, 9).Value2, "Discount %")
                b(5) = ws.Cells(n, 10).Value2: b(6) = ws.Cells(n, 11).Value2: b(7) = ws.Cells(n, 12).Value2: b(8) = ws.Cells(n, 13).Value2: lines.Add b
            End If
        Next n
        id = RFQ_SaveQuote(mRXParent, mRXID, header, lines, mRXStamp): root = mRXParent
    Else
        Err.Raise vbObjectError + 2311, "RFQ", "Acest raport nu este formular de editare."
    End If
    RX_CloseSaved
    ThisWorkbook.Activate: CO_GetSheet().Activate
    CO_GetSheet().Range("C9").Value2 = RFQ_FirstPosition(root)
    MsgBox "Salvat: " & id & vbCrLf & "Ctrl+S salveaza fisierul principal.", vbInformation, "TQM - RFQ"
    Exit Sub
Failed: MsgBox Err.description, vbExclamation, "TQM - RFQ"
End Sub

Private Function RFQ_FirstPosition(ByVal root As String) As String
    Dim lr As ListRow
    For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root And CStr(lr.Range.Cells(1, 5).Value2) = "Activa" Then RFQ_FirstPosition = CStr(lr.Range.Cells(1, 1).Value2): Exit Function
    Next lr
End Function

Private Function RX_ChooseRoot() As String
    Dim answer As Variant
    If RX_FormOpen() Then RX_ChooseRoot = mRXParent
    If Len(RX_ChooseRoot) = 0 Then RX_ChooseRoot = RFQ_Parent(RFQ_CurrentPosition())
    If Len(RX_ChooseRoot) > 0 Then Exit Function
    answer = Application.InputBox("Numarul comun RFQ (ex. RFQ-2026-0001) sau ID-ul unei pozitii:", "TQM - Cerere comuna", Type:=2)
    If VarType(answer) = vbBoolean Then Exit Function
    RX_ChooseRoot = RFQ_Resolve(Trim$(CStr(answer)))
    If Len(RX_ChooseRoot) = 0 Then Err.Raise vbObjectError + 2312, "RFQ", "Cererea comuna nu exista."
End Function

Public Sub RFQ_Compare(ByVal root As String)
    Dim ws As Worksheet, lr As ListRow, ol As ListRow, p As Range, o As Range, h As Range, n As Long, a(1 To 1, 1 To 16) As Variant
    Dim unitCost As Double, alloc As Double, found As Boolean, docs As Object, key As Variant, sumGoods As Double, pending As Double, item As ListRow
    On Error GoTo Failed
    CO_RefreshCore: CF_RFQRefresh: RFQ_Sync
    Set h = RX_Required("tTQMRFQ", root)
    Set ws = RX_StartForm("COMPARATIE", root, root, "RFQ_Comparatie")
    ws.Range("A1").Value2 = "TQM - " & h.Cells(1, 2).Value2 & " - comparatie si atribuiri"
    RX_Button ws, "B3:D3", "Aproba linia selectata", "RFQ_ApproveSelected"
    RX_Button ws, "E3:G3", "Genereaza comenzi", "RFQ_GenerateButton"
    RX_Button ws, "H3:J3", "Export cerere PDF", "RFQ_ExportRequest"
    RX_Button ws, "K3:M3", "Invitatii furnizori", "RFQ_InvitationsButton"
    RX_Button ws, "N3:P3", "Inchide raport", "RFQ_CloseForm"
    ws.Range("B5:P5").Merge: ws.Range("B5").Value2 = "Comparatie determinista, fara statistici istorice. Costurile de document de mai jos se adauga o singura data la selectia comandata."
    ws.Range("B6:P6").Merge: ws.Range("B6").Value2 = "Pentru Integral, aprobarea unei linii atribuie toate liniile ofertate. Pentru retragere, folositi Retrage aprobare din foaia principala."
    RX_Grid ws, 8, Array("ID oferta", "Poz.", "Material", "UM", "Necesar", "Atribuit total", "Rest necesar", "Furnizor", "Disponibil oferta", "Pret net / UM", "Minim cant.", "Livrare", "Eligibila / motiv", "Nr. oferta", "Atribuit oferta", "ID pozitie"), 9
    n = 9
    For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root And CStr(lr.Range.Cells(1, 5).Value2) = "Activa" Then
            Set p = RX_Required(CO_REQ, CStr(lr.Range.Cells(1, 1).Value2)): alloc = RX_Allocated(CStr(p.Cells(1, 1).Value2), False): found = False
            For Each ol In RFQ_Table("tTQMRFQLiniiOferte").ListRows
                If Len(CStr(ol.Range.Cells(1, 1).Value2)) > 0 And CStr(ol.Range.Cells(1, 4).Value2) = "Activa" Then
                    Set o = RX_Required(CO_OFF, CStr(ol.Range.Cells(1, 1).Value2))
                    If CStr(o.Cells(1, 2).Value2) = CStr(p.Cells(1, 1).Value2) Then
                        a(1, 1) = o.Cells(1, 1).Value2: a(1, 2) = lr.Range.Cells(1, 3).Value2: a(1, 3) = p.Cells(1, 4).Value2: a(1, 4) = p.Cells(1, 5).Value2
                        a(1, 5) = p.Cells(1, 6).Value2: a(1, 6) = alloc: a(1, 7) = Application.Max(0, CDbl(a(1, 5)) - alloc)
                        a(1, 8) = o.Cells(1, 3).Value2: a(1, 9) = o.Cells(1, 4).Value2: a(1, 10) = CDbl(o.Cells(1, 6).Value2) * (1 - CDbl(o.Cells(1, 15).Value2))
                        a(1, 11) = ol.Range.Cells(1, 3).Value2: a(1, 12) = o.Cells(1, 8).Value2: a(1, 13) = IIf(Len(RX_Eligibility(CStr(a(1, 1)))) = 0, "DA", RX_Eligibility(CStr(a(1, 1))))
                        a(1, 14) = o.Cells(1, 13).Value2: a(1, 15) = RX_Allocated(CStr(a(1, 1)), True): a(1, 16) = p.Cells(1, 1).Value2
                        ws.Cells(n, 1).Resize(1, 16).Value2 = a: n = n + 1: found = True
                    End If
                End If
            Next ol
            If Not found Then
                ws.Cells(n, 2).Value2 = lr.Range.Cells(1, 3).Value2: ws.Cells(n, 3).Value2 = p.Cells(1, 4).Value2: ws.Cells(n, 4).Value2 = p.Cells(1, 5).Value2
                ws.Cells(n, 5).Value2 = p.Cells(1, 6).Value2: ws.Cells(n, 6).Value2 = alloc: ws.Cells(n, 7).Value2 = CDbl(p.Cells(1, 6).Value2) - alloc
                ws.Cells(n, 13).Value2 = "FARA OFERTA": ws.Cells(n, 16).Value2 = p.Cells(1, 1).Value2: n = n + 1
            End If
        End If
    Next lr
    ws.Range("B8:P" & Application.Max(n - 1, 9)).AutoFilter
    n = n + 2: RX_Grid ws, n, Array("ID document", "Furnizor", "Nr. oferta", "Conditie", "Transport", "Alte costuri", "Prag minim marfa", "Discount pachet", "Marfa selectata", "Cost selectie net", "Prag indeplinit", "Valabilitate", "Plata"), n + 1
    For Each lr In RFQ_Table("tTQMRFQOferte").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root Then
            n = n + 1: Set h = lr.Range: sumGoods = 0: pending = 0
            For Each item In RFQ_Table("tTQMRFQAtribuiri").ListRows
                If RFQ_Document(CStr(item.Range.Cells(1, 4).Value2)) = CStr(h.Cells(1, 1).Value2) Then
                    Set o = RX_Required(CO_OFF, CStr(item.Range.Cells(1, 4).Value2))
                    If Len(CStr(item.Range.Cells(1, 11).Value2)) = 0 And RX_AwardQty(item.Range) > 0 Then
                        pending = pending + RX_AwardQty(item.Range)
                        sumGoods = sumGoods + Application.WorksheetFunction.Round(RX_AwardQty(item.Range) * CDbl(o.Cells(1, 6).Value2) * (1 - CDbl(o.Cells(1, 15).Value2)), 2)
                    End If
                End If
            Next item
            ws.Cells(n, 1).Value2 = h.Cells(1, 1).Value2: ws.Cells(n, 2).Value2 = h.Cells(1, 3).Value2: ws.Cells(n, 3).Value2 = h.Cells(1, 4).Value2
            ws.Cells(n, 4).Value2 = h.Cells(1, 10).Value2: ws.Cells(n, 5).Value2 = h.Cells(1, 7).Value2: ws.Cells(n, 6).Value2 = h.Cells(1, 8).Value2
            ws.Cells(n, 7).Value2 = h.Cells(1, 9).Value2: ws.Cells(n, 8).Value2 = h.Cells(1, 11).Value2: ws.Cells(n, 9).Value2 = Application.WorksheetFunction.Round(sumGoods, 2)
            If pending > 0 Then ws.Cells(n, 10).Value2 = Application.WorksheetFunction.Round(sumGoods - CDbl(h.Cells(1, 11).Value2) + CDbl(h.Cells(1, 7).Value2) + CDbl(h.Cells(1, 8).Value2), 2)
            ws.Cells(n, 11).Value2 = IIf(pending > 0 And sumGoods - CDbl(h.Cells(1, 11).Value2) >= CDbl(h.Cells(1, 9).Value2) - 0.005, "DA", "NU / fara selectie")
            ws.Cells(n, 12).Value2 = h.Cells(1, 6).Value2: ws.Cells(n, 13).Value2 = h.Cells(1, 12).Value2
        End If
    Next lr
    ws.Columns("A").Hidden = True: ws.Columns("P").Hidden = True: ws.Columns("B").ColumnWidth = 8
    ws.Columns("C").ColumnWidth = 36: ws.Columns("M").ColumnWidth = 46: ws.Columns("L").NumberFormat = "dd.mm.yyyy"
    ws.Range("J9:J" & n).NumberFormat = "0.000000": ws.Protect UserInterfaceOnly:=True, AllowFiltering:=True: ws.Range("C9").Select
    Exit Sub
Failed: MsgBox Err.description, vbExclamation, "TQM - RFQ"
End Sub

Public Sub RFQ_ApproveSelected()
    Dim ws As Worksheet, id As String, o As Range, p As Range, h As Range, amount As Variant, who As Variant, reason As Variant, root As String, qty As Double, stamp As String
    On Error GoTo Failed
    RX_RequireForm "COMPARATIE": Set ws = mRXForm.Worksheets(1)
    If Not ActiveWorkbook Is mRXForm Or ActiveCell.row < 9 Then Err.Raise vbObjectError + 2320, "RFQ", "Selectati linia unei oferte in comparatie."
    id = CStr(ws.Cells(ActiveCell.row, 1).Value2)
    If Len(RFQ_Document(id)) = 0 Then Err.Raise vbObjectError + 2321, "RFQ", "Selectati o oferta, nu antetul sau o pozitie fara oferta."
    Set o = RX_Required(CO_OFF, id): Set p = RX_Required(CO_REQ, CStr(o.Cells(1, 2).Value2)): Set h = RX_Required("tTQMRFQOferte", RFQ_Document(id))
    root = mRXParent: stamp = RX_Stamp(root)
    qty = Application.Min(CDbl(p.Cells(1, 6).Value2) - RX_Allocated(CStr(p.Cells(1, 1).Value2), False), CDbl(o.Cells(1, 4).Value2) - RX_Allocated(id, True))
    If CStr(h.Cells(1, 10).Value2) = "Integral" Then
        If MsgBox("Oferta este conditionata de intregul pachet. Se vor atribui toate cantitatile ofertate din documentul " & h.Cells(1, 4).Value2 & ". Continuati?", vbYesNo + vbQuestion, "TQM") <> vbYes Then Exit Sub
    Else
        amount = Application.InputBox("Cantitatea atribuita acestui furnizor; restul poate fi atribuit altuia:", "TQM - Atribuire", qty, Type:=1)
        If VarType(amount) = vbBoolean Then Exit Sub
        qty = CDbl(amount)
    End If
    who = Application.InputBox("Persoana care aproba:", "TQM - Atribuire", Application.UserName, Type:=2): If VarType(who) = vbBoolean Then Exit Sub
    reason = Application.InputBox("Motivul alegerii (pret, livrare, calitate, buget; verificati costul comun):", "TQM - Atribuire", Type:=2): If VarType(reason) = vbBoolean Then Exit Sub
    If RX_Stamp(root) <> stamp Then Err.Raise vbObjectError + 2322, "RFQ", "Datele s-au modificat in timpul deciziei. Redeschideti comparatia."
    RFQ_Approve id, qty, CStr(who), CStr(reason)
    RX_CloseSaved: RFQ_Compare root
    Exit Sub
Failed: MsgBox Err.description, vbExclamation, "TQM - RFQ"
End Sub

Public Sub RFQ_ApproveFromMain(ByVal requestID As String)
    RFQ_Compare RFQ_Parent(requestID)
End Sub

Public Sub RFQ_WithdrawFromMain(ByVal requestID As String)
    Dim wb As Workbook, ws As Worksheet, lr As ListRow, n As Long, answer As Variant, root As String
    On Error GoTo Failed
    root = RFQ_Parent(requestID): CO_RefreshCore
    Set wb = Workbooks.Add(xlWBATWorksheet): Set ws = wb.Worksheets(1): ws.name = "Atribuiri_RFQ"
    ws.Range("A1:G1").Value2 = Array("ID atribuire", "ID pozitie", "Furnizor", "Cantitate", "Stare", "Comanda", "Motiv")
    n = 2
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root And CStr(lr.Range.Cells(1, 6).Value2) <> "Retrasa" Then
            ws.Cells(n, 1).Value2 = lr.Range.Cells(1, 1).Value2: ws.Cells(n, 2).Value2 = lr.Range.Cells(1, 3).Value2
            ws.Cells(n, 3).Value2 = RX_Required(CO_OFF, CStr(lr.Range.Cells(1, 4).Value2)).Cells(1, 3).Value2
            ws.Cells(n, 4).Value2 = lr.Range.Cells(1, 5).Value2: ws.Cells(n, 5).Value2 = lr.Range.Cells(1, 6).Value2
            ws.Cells(n, 6).Value2 = lr.Range.Cells(1, 13).Value2: ws.Cells(n, 7).Value2 = lr.Range.Cells(1, 9).Value2: n = n + 1
        End If
    Next lr
    ws.Columns("A:G").AutoFit: ws.Protect
    answer = Application.InputBox("Copiati ID atribuire de retras din lista. Pentru Integral se retrage tot pachetul necomandat:", "TQM - Retragere", Type:=2)
    If VarType(answer) <> vbBoolean Then RFQ_Withdraw Trim$(CStr(answer))
    wb.Close SaveChanges:=False
    Exit Sub
Failed:
    MsgBox Err.description, vbExclamation, "TQM - RFQ"
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
End Sub

Public Sub RFQ_GenerateButton()
    Dim root As String, n As Long
    On Error GoTo Failed
    root = RX_ChooseRoot(): If Len(root) = 0 Then Exit Sub
    n = RFQ_GenerateOrders(root)
    If RX_FormOpen() And mRXKind = "COMPARATIE" Then RX_CloseSaved
    ThisWorkbook.Activate: ThisWorkbook.Worksheets("03_COMENZI_FURNIZORI").Activate
    MsgBox n & " comenzi Ciorna generate, grupate pe furnizor. Atribuirile deja comandate nu se genereaza din nou." & vbCrLf & "Deschideti fiecare comanda pentru verificare si schimbarea starii. Ctrl+S salveaza fisierul principal.", vbInformation, "TQM - RFQ"
    Exit Sub
Failed: MsgBox Err.description, vbExclamation, "TQM - RFQ"
End Sub

Public Sub RFQ_InvitationsButton()
    Dim root As String, supplier As Variant, state As Variant, notes As Variant, wb As Workbook, ws As Worksheet, lr As ListRow, n As Long
    On Error GoTo Failed
    root = RX_ChooseRoot(): If Len(root) = 0 Then Exit Sub
    Set wb = Workbooks.Add(xlWBATWorksheet): Set ws = wb.Worksheets(1): ws.name = "Invitatii_RFQ"
    ws.Range("A1:E1").Value2 = Array("Furnizor", "Stare", "Data trimitere", "Actualizat", "Observatii")
    n = 2
    For Each lr In RFQ_Table("tTQMRFQInvitati").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root Then
            ws.Cells(n, 1).Resize(1, 5).Value2 = lr.Range.Cells(1, 3).Resize(1, 5).Value2: n = n + 1
        End If
    Next lr
    ws.Columns("C:D").NumberFormat = "dd.mm.yyyy": ws.Columns("A:E").AutoFit: ws.Protect
    supplier = Application.InputBox("Furnizor de adaugat / actualizat in lista invitatiilor. Nu se trimit mesaje automat:", "TQM - Invitatii", Type:=2)
    If VarType(supplier) <> vbBoolean Then
        state = Application.InputBox("Stare: De trimis / Trimisa / Raspuns primit / Refuzat / Fara raspuns", "TQM - Invitatii", "De trimis", Type:=2)
        If VarType(state) <> vbBoolean Then
            notes = Application.InputBox("Observatii (optional):", "TQM - Invitatii", Type:=2)
            If VarType(notes) <> vbBoolean Then RFQ_RecordInvitation root, Trim$(CStr(supplier)), Trim$(CStr(state)), CStr(notes)
        End If
    End If
    wb.Close SaveChanges:=False
    Exit Sub
Failed:
    MsgBox Err.description, vbExclamation, "TQM - RFQ"
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
End Sub

Public Sub RFQ_ExportRequest()
    Dim root As String, h As Range, p As Range, lr As ListRow, wb As Workbook, ws As Worksheet, n As Long, file As Variant
    Dim eno As Long, msg As String
    On Error GoTo Failed
    root = RX_ChooseRoot(): If Len(root) = 0 Then Exit Sub
    Set h = RX_Required("tTQMRFQ", root)
    file = Application.GetSaveAsFilename(InitialFileName:=CStr(h.Cells(1, 2).Value2) & ".pdf", FileFilter:="PDF (*.pdf), *.pdf")
    If VarType(file) = vbBoolean Then Exit Sub
    Set wb = Workbooks.Add(xlWBATWorksheet): Set ws = wb.Worksheets(1)
    ws.Range("A1:G1").Merge: ws.Range("A1").Value2 = "CERERE DE OFERTA " & h.Cells(1, 2).Value2
    ws.Range("A2").Value2 = "Data:": ws.Range("B2").Value2 = h.Cells(1, 3).Value2: ws.Range("B2").NumberFormat = "dd.mm.yyyy"
    ws.Range("A3").Value2 = "Solicitant:": ws.Range("B3").Value2 = h.Cells(1, 5).Value2
    ws.Range("A4").Value2 = "Raspuns pana la:": ws.Range("B4").Value2 = h.Cells(1, 6).Value2: ws.Range("B4").NumberFormat = "dd.mm.yyyy"
    ws.Range("A5:G5").Merge: ws.Range("A5").Value2 = h.Cells(1, 7).Value2
    ws.Range("A7:G7").Value2 = Array("Poz.", "Material", "Specificatie", "UM", "Cantitate", "Data necesara", "Proiect")
    n = 8
    For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root And CStr(lr.Range.Cells(1, 5).Value2) = "Activa" Then
            Set p = RX_Required(CO_REQ, CStr(lr.Range.Cells(1, 1).Value2))
            ws.Cells(n, 1).Value2 = lr.Range.Cells(1, 3).Value2: ws.Cells(n, 2).Value2 = p.Cells(1, 4).Value2: ws.Cells(n, 3).Value2 = p.Cells(1, 13).Value2
            ws.Cells(n, 4).Value2 = p.Cells(1, 5).Value2: ws.Cells(n, 5).Value2 = p.Cells(1, 6).Value2: ws.Cells(n, 6).Value2 = p.Cells(1, 7).Value2
            ws.Cells(n, 7).Value2 = p.Cells(1, 3).Value2: n = n + 1
        End If
    Next lr
    ws.Cells.Font.name = "Aptos": ws.Columns("A").ColumnWidth = 7: ws.Columns("B:C").ColumnWidth = 37: ws.Columns("D:E").ColumnWidth = 12
    ws.Columns("F:G").ColumnWidth = 22: ws.Columns("F").NumberFormat = "dd.mm.yyyy": ws.Range("A1:G" & n).WrapText = True
    ws.rows("1:" & n).AutoFit: ws.Range("A1").Font.size = 16: ws.Range("A7:G7").Interior.Color = RGB(219, 234, 254)
    ws.Cells(n + 1, 1).Value2 = "Puteti raspunde doar pentru pozitiile disponibile. Indicati pretul net, livrarea, valabilitatea si costurile comune separat."
    ws.Range("A" & n + 1 & ":G" & n + 2).Merge
    With ws.PageSetup
        .Orientation = xlLandscape: .Zoom = False: .FitToPagesWide = 1: .FitToPagesTall = False
        .PrintArea = ws.Range("A1:G" & n + 2).address: .PrintTitleRows = "$1:$7"
    End With
    ws.ExportAsFixedFormat Type:=xlTypePDF, Filename:=CStr(file), OpenAfterPublish:=False
    wb.Close SaveChanges:=False: Set wb = Nothing
    RX_Begin: h.Cells(1, 10).Value2 = CStr(file): DOC_RFQRefresh: RX_End False
    MsgBox "PDF creat. Linkul cererii este disponibil in Documente. Trimiterea la furnizori si marcarea Trimisa sunt manuale.", vbInformation, "TQM - RFQ"
    Exit Sub
Failed:
    eno = Err.Number: msg = Err.description
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    If mRXWriting Then
        On Error Resume Next: RX_End True: On Error GoTo 0
    End If
    MsgBox msg, vbExclamation, "TQM - RFQ"
End Sub

' Excel Windows acceptance tests run ONLY in a disposable copy.
Public Sub RFQ_TesteCircuit()
    Dim path As String, testBook As Workbook, result As Variant, wb As Workbook, ws As Worksheet, lines As Variant, i As Long, message As String
    On Error GoTo Failed
    If mRXWriting Or RX_FormOpen() Then Err.Raise vbObjectError + 2400, "RFQ", "Inchideti formularele RFQ inainte de test."
    path = Environ$("TEMP") & "\TQM_RFQ_TEST_" & Format$(Now, "yyyymmdd_hhnnss") & "_" & Right$(Hex$(CLng(Timer * 100)), 6) & ".xlsm"
    If Len(Dir$(path)) > 0 Then Err.Raise vbObjectError + 2401, "RFQ", "Copia de test exista deja. Reluati testul."
    ThisWorkbook.SaveCopyAs path
    Set testBook = Workbooks.Open(Filename:=path, UpdateLinks:=False)
    testBook.Worksheets("_TQM_RFQ").Range("X1").Value2 = "RFQ_TEST_COPY_ONLY"
    result = Application.Run("'" & Replace(testBook.name, "'", "''") & "'!RFQ_TestInternal")
    testBook.Close SaveChanges:=False: Set testBook = Nothing
    Kill path
    Set wb = Workbooks.Add(xlWBATWorksheet): Set ws = wb.Worksheets(1): ws.name = "Rezultat_teste_RFQ"
    lines = Split(CStr(result), vbCrLf)
    For i = 0 To UBound(lines): ws.Cells(i + 1, 1).Value2 = lines(i): Next i
    ws.Columns("A").ColumnWidth = 120: ws.Cells.Font.name = "Aptos"
    MsgBox "Testele au rulat intr-o copie temporara, fara modificarea datelor din fisierul principal. Rezultatele sunt in registrul nou.", vbInformation, "TQM"
    Exit Sub
Failed:
    message = Err.description
    On Error Resume Next
    If Not testBook Is Nothing Then testBook.Close SaveChanges:=False
    If Len(path) > 0 Then If Len(Dir$(path)) > 0 Then Kill path
    On Error GoTo 0
    MsgBox "Test oprit: " & message, vbExclamation, "TQM - Test RFQ"
End Sub

Private Sub RX_Assert(ByVal condition As Boolean, ByVal caption As String, ByRef report As String)
    If Not condition Then Err.Raise vbObjectError + 2402, "RFQ_Test", "FAIL: " & caption
    report = report & "PASS: " & caption & vbCrLf
End Sub

Public Function RFQ_TestInternal() As String
    Dim report As String, root As String, packageRoot As String, reqIDs(1 To 10) As String, matIDs(1 To 10) As String
    Dim code As String, name As String, r As Range, p As Range, h As Range, o As Range, receipt As String, orderID As String, posID As String
    Dim header(1 To 12) As Variant, a(1 To 24) As Variant, reqLine(1 To 13) As Variant, offLine(1 To 8) As Variant, lines As Collection
    Dim lr As ListRow, i As Long, j As Long, docA As String, docB As String, docC As String, docPkg As String, n As Long, errorCode As Long
    Dim offerA As String, offerB As String, price As Double, projectID As String, locationID As String, invoice As String, allocation As String, paid As Double, before As String
    Dim packagePos(1 To 2) As String, firstPackageOffer As String, rowCount As Long, offerHeaderRow As Long
    Dim projectTwo As String, extras As Object
    On Error GoTo Failed
    If CStr(ThisWorkbook.Worksheets("_TQM_RFQ").Range("X1").Value2) <> "RFQ_TEST_COPY_ONLY" Then Err.Raise vbObjectError + 2403, "RFQ_Test", "Rulati RFQ_TesteCircuit. Testul intern este permis numai in copia temporara."
    report = "TQM RFQ v2 - teste Excel Windows, " & Format$(Now, "dd.mm.yyyy hh:nn:ss") & vbCrLf
    RX_Begin
    For i = 1 To 10
        code = "TEST-RFQ-" & Format$(i, "00"): name = "Material fictiv RFQ " & i: matIDs(i) = RX_ID("NM")
        Set r = RX_Add("tTQMNMMateriale")
        For j = 1 To 24: a(j) = Empty: Next j
        r.Cells(1, 1).Value2 = code: r.Cells(1, 2).Value2 = name: r.Cells(1, 3).Value2 = "TEST"
        r.Cells(1, 5).Value2 = "Specificatie test": r.Cells(1, 6).Value2 = "buc": r.Cells(1, 9).Value2 = "Activ"
        r.Cells(1, 11).Value2 = matIDs(i): r.Cells(1, 12).Value2 = 1: r.Cells(1, 13).Value2 = CDbl(Now): r.Cells(1, 14).Value2 = CDbl(Now)
    Next i
    projectID = RX_ID("PRJ"): locationID = RX_ID("LOC")
    Set r = RX_Add("tTQMNMProiecte"): r.Cells(1, 1).Value2 = projectID: r.Cells(1, 2).Value2 = "TEST-RFQ"
    r.Cells(1, 3).Value2 = "Proiect fictiv RFQ": r.Cells(1, 8).Value2 = "Activ": r.Cells(1, 10).Value2 = 1
    Set r = RX_Add("tTQMNMLocatii"): r.Cells(1, 1).Value2 = locationID: r.Cells(1, 2).Value2 = "TEST-RFQ"
    r.Cells(1, 3).Value2 = "Depozit fictiv RFQ": r.Cells(1, 8).Value2 = "Activ": r.Cells(1, 10).Value2 = 1
    For i = 1 To 3
        Set r = RX_Add("tTQMNMParteneri"): r.Cells(1, 1).Value2 = RX_ID("PAR"): r.Cells(1, 2).Value2 = "TEST-RFQ-" & i
        r.Cells(1, 3).Value2 = "Furnizor fictiv " & Chr$(64 + i): r.Cells(1, 5).Value2 = "Furnizor"
        r.Cells(1, 13).Value2 = "Activ": r.Cells(1, 15).Value2 = 1
    Next i
    RX_End False
    header(1) = RX_Friendly("TEST-RFQ", "tTQMRFQ"): header(2) = CDbl(Date): header(3) = "Proiect fictiv RFQ"
    header(4) = "TESTER": header(5) = CDbl(Date + 2): header(6) = "Date fictive; numai copie temporara."
    Set lines = New Collection
    For i = 1 To 10
        reqLine(1) = "": reqLine(2) = i: reqLine(3) = "TEST-RFQ-" & Format$(i, "00"): reqLine(4) = "Material fictiv RFQ " & i
        reqLine(5) = "Specificatie test": reqLine(6) = "buc": reqLine(7) = 100: reqLine(8) = CDbl(Date + 30)
        reqLine(9) = "Proiect fictiv RFQ": reqLine(10) = "Normala": reqLine(11) = "": reqLine(12) = "Activa": reqLine(13) = Empty: lines.Add reqLine
    Next i
    root = RFQ_SaveRequest("", header, lines)
    n = 0
    For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root Then reqIDs(CLng(lr.Range.Cells(1, 3).Value2)) = CStr(lr.Range.Cells(1, 1).Value2): n = n + 1
    Next lr
    RX_Assert n = 10, "10 materiale au un singur ID RFQ si 10 ID-uri de pozitie stabile", report
    For i = 1 To 3
        header(1) = "Furnizor fictiv " & Chr$(64 + i): header(2) = "TEST-OF-" & i: header(3) = CDbl(Date): header(4) = CDbl(Date + 14)
        header(5) = i * 100: header(6) = 0: header(7) = 0: header(8) = "Independent": header(9) = 0: header(10) = "30 zile": header(11) = "": header(12) = "TEST"
        Set lines = New Collection
        For j = 1 To 10
            offLine(1) = reqIDs(j): offLine(2) = 0: offLine(3) = i * 10: offLine(4) = 0: offLine(5) = CDbl(Date + 3): offLine(6) = "Da": offLine(7) = 0: offLine(8) = "TEST"
            If i = 1 And j <= 6 Then offLine(2) = 100
            If i = 2 And (j = 1 Or j >= 7) Then offLine(2) = 100
            If i = 3 Then offLine(2) = 100
            If j = 1 And i = 1 Then offLine(2) = 60
            If j = 1 And i = 2 Then offLine(2) = 40
            lines.Add offLine
        Next j
        name = RFQ_SaveQuote(root, "", header, lines)
        If i = 1 Then docA = name
        If i = 2 Then docB = name
        If i = 3 Then docC = name
    Next i
    n = 0
    For Each lr In RFQ_Table("tTQMRFQLiniiOferte").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = docA Then
            n = n + 1: Set o = RX_Required(CO_OFF, CStr(lr.Range.Cells(1, 1).Value2))
            If CStr(o.Cells(1, 2).Value2) = reqIDs(1) Then offerA = CStr(o.Cells(1, 1).Value2)
        ElseIf CStr(lr.Range.Cells(1, 2).Value2) = docB Then
            Set o = RX_Required(CO_OFF, CStr(lr.Range.Cells(1, 1).Value2))
            If CStr(o.Cells(1, 2).Value2) = reqIDs(1) Then offerB = CStr(o.Cells(1, 1).Value2)
        End If
    Next lr
    RX_Assert n = 6, "Raspuns partial: 4 pozitii neofertate nu creeaza oferte cu pret 0", report
    RFQ_Approve offerA, 60, "TESTER", "Disponibil partial"
    RFQ_Approve offerB, 40, "TESTER", "Completeaza necesarul"
    RX_Assert Abs(RX_Allocated(reqIDs(1), False) - 100) < 0.00000001, "Atribuire 60 + 40 la doi furnizori pe acelasi material", report
    name = ""
    For Each lr In RFQ_Table("tTQMRFQLiniiOferte").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = docC Then
            Set o = RX_Required(CO_OFF, CStr(lr.Range.Cells(1, 1).Value2))
            If CStr(o.Cells(1, 2).Value2) = reqIDs(1) Then name = CStr(o.Cells(1, 1).Value2)
        End If
    Next lr
    On Error Resume Next: Err.Clear: RFQ_Approve name, 1, "TESTER", "Trebuie respins": errorCode = Err.Number: Err.Clear: On Error GoTo Failed
    RX_Assert errorCode = vbObjectError + 2263, "Depasirea necesarului este respinsa", report
    For Each lr In RFQ_Table("tTQMRFQLiniiOferte").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = docA Or CStr(lr.Range.Cells(1, 2).Value2) = docB Then
            Set o = RX_Required(CO_OFF, CStr(lr.Range.Cells(1, 1).Value2))
            If CStr(o.Cells(1, 2).Value2) <> reqIDs(1) Then RFQ_Approve CStr(o.Cells(1, 1).Value2), 100, "TESTER", "TEST"
        End If
    Next lr
    Set h = RX_Required("tTQMRFQOferte", docA): h.Cells(1, 9).Value2 = 100000
    CO_RefreshCore
    n = 0
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = root And CStr(lr.Range.Cells(1, 6).Value2) = "De reconfirmat" Then n = n + 1
    Next lr
    RX_Assert n = 6, "Schimbarea conditiilor ofertei invalideaza toate aprobarile necomandate ale documentului", report
    h.Cells(1, 9).Value2 = 0
    For Each lr In RFQ_Table("tTQMRFQLiniiOferte").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = docA Then
            Set o = RX_Required(CO_OFF, CStr(lr.Range.Cells(1, 1).Value2))
            RFQ_Approve CStr(o.Cells(1, 1).Value2), CDbl(o.Cells(1, 4).Value2), "TESTER", "Reconfirmat dupa schimbare"
        End If
    Next lr
    n = RFQ_GenerateOrders(root): RX_Assert n = 2, "Comenzi Ciorna grupate pe cei doi furnizori selectati", report
    RX_Assert RFQ_GenerateOrders(root) = 0, "Generarea repetata nu dubleaza comenzile", report
    Set r = Nothing
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If CStr(lr.Range.Cells(1, 4).Value2) = offerA And Len(CStr(lr.Range.Cells(1, 11).Value2)) > 0 Then Set r = lr.Range
    Next lr
    orderID = CStr(r.Cells(1, 13).Value2): posID = CStr(r.Cells(1, 11).Value2): Set h = RX_Required("tTQMComenzi", orderID)
    RX_Assert Abs(CDbl(h.Cells(1, 15).Value2) - 100) < 0.005, "Transportul ofertei A apare o singura data pentru 6 pozitii", report
    RX_Assert Abs(CDbl(h.Cells(1, 11).Value2) - 5700) < 0.005, "Total comanda A: 5600 marfa + 100 transport", report
    RX_Begin
    h.Cells(1, 9).Value2 = "Trimisa"
    receipt = RX_ID("REC"): Set r = RX_Add("tTQMCFRec")
    r.Cells(1, 1).Value2 = receipt: r.Cells(1, 2).Value2 = posID: r.Cells(1, 3).Value2 = orderID: r.Cells(1, 4).Value2 = CDbl(Date)
    r.Cells(1, 5).Value2 = "AVIZ-TEST": r.Cells(1, 6).Value2 = 25: r.Cells(1, 7).Value2 = "Valida": r.Cells(1, 9).Value2 = "TESTER": r.Cells(1, 10).Value2 = CDbl(Now)
    CF_RFQRefresh: RX_End False
    Set p = RX_Required("tTQMCFPoz", posID)
    RX_Assert Abs(CDbl(p.Cells(1, 10).Value2) - 25) < 0.00000001 And Abs(CDbl(p.Cells(1, 12).Value2) - 35) < 0.00000001, "Receptie partiala 25 din 60; ramane 35 pe pozitia corecta", report
    RX_Begin
    Set r = RX_Add("tTQMSTMateriale"): r.Cells(1, 1).Value2 = matIDs(1): r.Cells(1, 2).Value2 = "TEST-RFQ-01": r.Cells(1, 3).Value2 = "Material fictiv RFQ 1"
    r.Cells(1, 4).Value2 = "Specificatie test": r.Cells(1, 5).Value2 = "buc": r.Cells(1, 6).Value2 = CDbl(Now)
    Set r = RX_Add("tTQMSTLocatii"): r.Cells(1, 1).Value2 = locationID: r.Cells(1, 2).Value2 = "Depozit fictiv RFQ": r.Cells(1, 3).Value2 = CDbl(Now)
    Set r = RX_Add("tTQMSTMiscari"): r.Cells(1, 1).Value2 = RX_ID("MV"): r.Cells(1, 2).Value2 = RX_ID("OP"): r.Cells(1, 3).Value2 = CDbl(Date)
    r.Cells(1, 4).Value2 = "Receptie": r.Cells(1, 5).Value2 = matIDs(1): r.Cells(1, 6).Value2 = locationID: r.Cells(1, 7).Value2 = 25
    r.Cells(1, 8).Value2 = "AVIZ-TEST": r.Cells(1, 9).Value2 = "TESTER": r.Cells(1, 11).Value2 = receipt: r.Cells(1, 12).Value2 = posID
    r.Cells(1, 13).Value2 = orderID: r.Cells(1, 14).Value2 = "Valida": r.Cells(1, 15).Value2 = CDbl(Now): r.Cells(1, 19).Value2 = "Proiect fictiv RFQ"
    r.Cells(1, 20).Value2 = "Furnizor fictiv A": ST_RFQRefresh: RX_End False
    n = 0
    For Each lr In RFQ_Table("tTQMStoc").ListRows
        If CStr(lr.Range.Cells(1, 10).Value2) = matIDs(1) And CStr(lr.Range.Cells(1, 11).Value2) = locationID Then n = n + 1: price = CDbl(lr.Range.Cells(1, 7).Value2)
    Next lr
    RX_Assert n = 1 And Abs(price - 25) < 0.00000001, "Receptia intra in stoc cu acelasi material si locatie canonice", report
    invoice = RX_ID("FAC"): allocation = RX_ID("REP"): RX_Begin
    Set r = RX_Add("tTQMFacturi")
    r.Cells(1, 1).Value2 = "FACT-TEST": r.Cells(1, 2).Value2 = CDbl(Date): r.Cells(1, 3).Value2 = "Furnizor fictiv A": r.Cells(1, 5).Value2 = "Factura"
    r.Cells(1, 6).Value2 = CDbl(Date + 30): r.Cells(1, 7).Value2 = 250: r.Cells(1, 8).Value2 = 47.5: r.Cells(1, 16).Value2 = invoice
    r.Cells(1, 18).Value2 = "TESTER": r.Cells(1, 19).Value2 = "Valida": r.Cells(1, 20).Value2 = CDbl(Now): r.Cells(1, 21).Value2 = CDbl(Now)
    Set r = RX_Add("tTQMFPRepartizari")
    r.Cells(1, 1).Value2 = allocation: r.Cells(1, 2).Value2 = invoice: r.Cells(1, 3).Value2 = "Proiect fictiv RFQ": r.Cells(1, 4).Value2 = 250: r.Cells(1, 5).Value2 = 47.5
    r.Cells(1, 9).Value2 = orderID: r.Cells(1, 10).Value2 = posID: r.Cells(1, 11).Value2 = receipt: r.Cells(1, 12).Value2 = "Receptie TEST": r.Cells(1, 13).Value2 = "Valida"
    r.Cells(1, 14).Value2 = CDbl(Now): r.Cells(1, 15).Value2 = 1
    Set r = RX_Add("tTQMFPPlati")
    r.Cells(1, 1).Value2 = RX_ID("PL"): r.Cells(1, 2).Value2 = RX_ID("OP"): r.Cells(1, 3).Value2 = invoice: r.Cells(1, 4).Value2 = allocation
    r.Cells(1, 5).Value2 = "Proiect fictiv RFQ": r.Cells(1, 6).Value2 = CDbl(Date): r.Cells(1, 7).Value2 = 100: r.Cells(1, 8).Value2 = "Plata"
    r.Cells(1, 9).Value2 = "OP": r.Cells(1, 10).Value2 = "OP-TEST": r.Cells(1, 11).Value2 = "TESTER": r.Cells(1, 14).Value2 = "Valida": r.Cells(1, 15).Value2 = CDbl(Now)
    FP_RFQRefresh: PB_RFQRefresh: DOC_RFQRefresh: RX_End False
    Set r = RX_Find("tTQMFacturi", invoice, 16)
    RX_Assert Abs(CDbl(r.Cells(1, 11).Value2) - 197.5) < 0.005, "Factura partiala 250 net + 47,50 TVA; plata 100; sold 197,50", report
    Set r = RX_Find("tTQMProiecteBugete", projectID, 22)
    RX_Assert Abs(CDbl(r.Cells(1, 6).Value2) - 5700) < 0.005, "Buget: factura + comanda nefacturata = 5700; fara dubla numarare", report
    RX_Begin: p.Parent.Unprotect: p.Cells(1, 11).Value2 = 35: CF_RFQRefresh: CO_RefreshCore: RX_End False
    RX_Assert Abs(RX_Allocated(reqIDs(1), False) - 65) < 0.00000001, "Anularea restului elibereaza numai 35; cele 25 primite si 40 atribuite B raman", report
    RFQ_Approve name, 35, "TESTER", "Inlocuire rest anulat"
    RX_Assert Abs(RX_Allocated(reqIDs(1), False) - 100) < 0.00000001, "Restul anulat poate fi reatribuit fara pierderea receptiei", report
    RX_Begin: projectTwo = RX_ID("PRJ"): Set r = RX_Add("tTQMNMProiecte")
    r.Cells(1, 1).Value2 = projectTwo: r.Cells(1, 2).Value2 = "TEST-RFQ-2": r.Cells(1, 3).Value2 = "Proiect fictiv RFQ 2": r.Cells(1, 8).Value2 = "Activ": r.Cells(1, 10).Value2 = 1: RX_End False
    header(1) = RX_Friendly("TEST-PACHET", "tTQMRFQ"): header(2) = CDbl(Date): header(3) = "Proiect fictiv RFQ"
    header(4) = "TESTER": header(5) = CDbl(Date + 2): header(6) = "TEST pachet si prag"
    Set lines = New Collection
    For i = 1 To 2
        reqLine(1) = "": reqLine(2) = i: reqLine(3) = "TEST-RFQ-" & Format$(i, "00"): reqLine(4) = "Material fictiv RFQ " & i
        reqLine(5) = "Specificatie test": reqLine(6) = "buc": reqLine(7) = 10: reqLine(8) = CDbl(Date + 30): reqLine(9) = "Proiect fictiv RFQ"
        reqLine(10) = "Normala": reqLine(11) = "": reqLine(12) = "Activa": reqLine(13) = Empty
        If i = 2 Then reqLine(9) = "Proiect fictiv RFQ 2"
        lines.Add reqLine
    Next i
    packageRoot = RFQ_SaveRequest("", header, lines)
    For Each lr In RFQ_Table("tTQMRFQPozitii").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = packageRoot Then packagePos(CLng(lr.Range.Cells(1, 3).Value2)) = CStr(lr.Range.Cells(1, 1).Value2)
    Next lr
    header(1) = "Furnizor fictiv A": header(2) = "TEST-PACHET-OF": header(3) = CDbl(Date): header(4) = CDbl(Date + 14)
    header(5) = 40: header(6) = 0: header(7) = 200: header(8) = "Integral": header(9) = 50: header(10) = "30 zile": header(11) = "": header(12) = "TEST"
    Set lines = New Collection
    For i = 1 To 2
        offLine(1) = packagePos(i): offLine(2) = 10: offLine(3) = 10: offLine(4) = 0: offLine(5) = CDbl(Date + 3): offLine(6) = "Da": offLine(7) = 5: offLine(8) = "TEST": lines.Add offLine
    Next i
    docPkg = RFQ_SaveQuote(packageRoot, "", header, lines)
    firstPackageOffer = ""
    For Each lr In RFQ_Table("tTQMRFQLiniiOferte").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = docPkg Then firstPackageOffer = CStr(lr.Range.Cells(1, 1).Value2): Exit For
    Next lr
    RFQ_Approve firstPackageOffer, 1, "TESTER", "Acceptare integrala"
    RX_Assert Abs(RX_Allocated(packagePos(1), False) - 10) < 0.00000001 And Abs(RX_Allocated(packagePos(2), False) - 10) < 0.00000001, "Integral aproba toate liniile si cantitatile, nu o linie izolata", report
    On Error Resume Next: Err.Clear: n = RFQ_GenerateOrders(packageRoot): errorCode = Err.Number: Err.Clear: On Error GoTo Failed
    RX_Assert errorCode = vbObjectError + 2293, "Pragul minim se verifica dupa discountul pachetului, inainte de orice comanda", report
    Set h = RX_Required("tTQMRFQOferte", docPkg): h.Cells(1, 9).Value2 = 0: CO_RefreshCore
    RFQ_Approve firstPackageOffer, 1, "TESTER", "Prag renegociat; acceptare integrala"
    RX_Assert RFQ_GenerateOrders(packageRoot) = 1, "Pachetul valid genereaza o singura comanda", report
    For Each lr In RFQ_Table("tTQMRFQAtribuiri").ListRows
        If CStr(lr.Range.Cells(1, 2).Value2) = packageRoot And Len(CStr(lr.Range.Cells(1, 13).Value2)) > 0 Then orderID = CStr(lr.Range.Cells(1, 13).Value2): Exit For
    Next lr
    Set h = RX_Required("tTQMComenzi", orderID)
    RX_Assert Abs(CDbl(h.Cells(1, 11).Value2) - 190) < 0.005, "Pachet: 200 marfa - 50 discount + 40 transport = 190 net", report
    Set extras = RFQ_ProjectExtras(orderID)
    RX_Assert extras.count = 2 And Abs(CDbl(extras("Proiect fictiv RFQ")) - 20) < 0.005 And Abs(CDbl(extras("Proiect fictiv RFQ 2")) - 20) < 0.005, "Transportul comun este repartizat pe cele doua proiecte, 20 + 20", report
    RX_Begin: h.Parent.Unprotect: h.Cells(1, 9).Value2 = "Trimisa": CF_RFQRefresh: PB_RFQRefresh: RX_End False
    Set r = RX_Find("tTQMProiecteBugete", projectTwo, 22)
    RX_Assert Abs(CDbl(r.Cells(1, 6).Value2) - 95) < 0.005, "Bugetul proiectului 2 include 75 marfa si 20 transport", report
    rowCount = CO_Table(CO_REQ).ListRows.count: offerHeaderRow = CO_Table(CO_OFF).HeaderRowRange.row
    Set p = RX_Required(CO_REQ, packagePos(1)): price = CDbl(p.Cells(1, 6).Value2)
    On Error Resume Next: Err.Clear: RX_TestRollbackCore packagePos(1): errorCode = Err.Number: Err.Clear: On Error GoTo Failed
    RFQ_ResetCache: Set p = RX_Required(CO_REQ, packagePos(1))
    RX_Assert errorCode = vbObjectError + 2499 And CO_Table(CO_REQ).ListRows.count = rowCount And CO_Table(CO_OFF).HeaderRowRange.row = offerHeaderRow And CDbl(p.Cells(1, 6).Value2) = price, "Eroare dupa scriere: randul inserat, antetul ofertelor si cantitatea initiala sunt restaurate", report
    RFQ_TestInternal = report & "FINAL: toate verificarile executate de acest test au trecut." & vbCrLf & "Formularele, sortarea, filtrele si exportul PDF se verifica separat conform ghidului."
    Exit Function
Failed:
    errorCode = Err.Number: name = Err.description
    On Error Resume Next: RX_End True: On Error GoTo 0
    RFQ_TestInternal = report & "FAIL / OPRIT: " & CStr(errorCode) & " - " & name
End Function

Private Sub RX_TestRollbackCore(ByVal requestID As String)
    Dim r As Range, eno As Long, msg As String
    On Error GoTo Failed
    RX_Begin
    Set r = RX_Required(CO_REQ, requestID): r.Cells(1, 6).Value2 = 999
    Set r = RX_Add(CO_REQ): r.Cells(1, 1).Value2 = "ROLLBACK-TEST-ONLY"
    Err.Raise vbObjectError + 2499, "RFQ_Test", "Eroare injectata in copia de test."
Failed:
    eno = Err.Number: msg = Err.description
    If mRXWriting Then RX_Fail eno, msg Else Err.Raise eno, "RFQ_Test", msg
End Sub
